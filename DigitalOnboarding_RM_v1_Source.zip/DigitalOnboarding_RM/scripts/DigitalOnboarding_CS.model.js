﻿define("DigitalOnboarding_CS.model$OB_CustomerPricingRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var OB_CustomerPricingRec = (function (_super) {
__extends(OB_CustomerPricingRec, _super);
function OB_CustomerPricingRec(defaults) {
_super.apply(this, arguments);
}
OB_CustomerPricingRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("APIIntegrationCharges", "aPIIntegrationChargesAttr", "APIIntegrationCharges", false, false, OS.Types.Currency, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("AMC", "aMCAttr", "AMC", false, false, OS.Types.Currency, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("MaintenenceIntegrationCost", "maintenenceIntegrationCostAttr", "MaintenenceIntegrationCost", false, false, OS.Types.Currency, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("TxnFee_RTGS", "txnFee_RTGSAttr", "TxnFee_RTGS", false, false, OS.Types.Currency, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("TxnFee_NEFT", "txnFee_NEFTAttr", "TxnFee_NEFT", false, false, OS.Types.Currency, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("TxnFee_A2A", "txnFee_A2AAttr", "TxnFee_A2A", false, false, OS.Types.Currency, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("TxnFee_IMPS1K", "txnFee_IMPS1KAttr", "TxnFee_IMPS1K", false, false, OS.Types.Currency, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("TxnFee_IMPSG25K", "txnFee_IMPSG25KAttr", "TxnFee_IMPSG25K", false, false, OS.Types.Currency, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("TxnFee_IMPSL25K", "txnFee_IMPSL25KAttr", "TxnFee_IMPSL25K", false, false, OS.Types.Currency, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("DebitAccountNumber", "debitAccountNumberAttr", "DebitAccountNumber", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("IsDeviation", "isDeviationAttr", "IsDeviation", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
OB_CustomerPricingRec.init();
return OB_CustomerPricingRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.OB_CustomerPricingRec = OB_CustomerPricingRec;

});
define("DigitalOnboarding_CS.model$", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var TextList = (function (_super) {
__extends(TextList, _super);
function TextList(defaults) {
_super.apply(this, arguments);
}
TextList.itemType = OS.Types.Text;
return TextList;
})(OS.DataTypes.GenericRecordList);
DigitalOnboarding_CSModel.TextList = TextList;

});
define("DigitalOnboarding_CS.model$ApiResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var ApiResponseRec = (function (_super) {
__extends(ApiResponseRec, _super);
function ApiResponseRec(defaults) {
_super.apply(this, arguments);
}
ApiResponseRec.attributesToDeclare = function () {
return [
this.attr("Code", "codeAttr", "code", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Message", "messageAttr", "message", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RequestId", "requestIdAttr", "requestId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Errors", "errorsAttr", "Errors", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new OS.DataTypes.TextList());
}, true, OS.DataTypes.TextList)
].concat(_super.attributesToDeclare.call(this));
};
ApiResponseRec.init();
return ApiResponseRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.ApiResponseRec = ApiResponseRec;

});
define("DigitalOnboarding_CS.model$CustAuthorizedSignatoryRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var CustAuthorizedSignatoryRec = (function (_super) {
__extends(CustAuthorizedSignatoryRec, _super);
function CustAuthorizedSignatoryRec(defaults) {
_super.apply(this, arguments);
}
CustAuthorizedSignatoryRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("CustomerId", "customerIdAttr", "CustomerId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("AuthorizedSignatoryId", "authorizedSignatoryIdAttr", "AuthorizedSignatoryId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustAuthorizedSignatoryRec.init();
return CustAuthorizedSignatoryRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.CustAuthorizedSignatoryRec = CustAuthorizedSignatoryRec;

});
define("DigitalOnboarding_CS.model$SignMethodsRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var SignMethodsRec = (function (_super) {
__extends(SignMethodsRec, _super);
function SignMethodsRec(defaults) {
_super.apply(this, arguments);
}
SignMethodsRec.attributesToDeclare = function () {
return [
this.attr("eSign", "eSignAttr", "eSign", false, false, OS.Types.Text, function () {
return "1";
}, true), 
this.attr("PhysicalSign", "physicalSignAttr", "PhysicalSign", false, false, OS.Types.Text, function () {
return "2";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SignMethodsRec.init();
return SignMethodsRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.SignMethodsRec = SignMethodsRec;

});
define("DigitalOnboarding_CS.model$DeviationDocumentRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var DeviationDocumentRec = (function (_super) {
__extends(DeviationDocumentRec, _super);
function DeviationDocumentRec(defaults) {
_super.apply(this, arguments);
}
DeviationDocumentRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("OB_CustomerPricingId", "oB_CustomerPricingIdAttr", "OB_CustomerPricingId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Name", "nameAttr", "Name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Type", "typeAttr", "Type", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("BinaryData", "binaryDataAttr", "BinaryData", false, false, OS.Types.BinaryData, function () {
return OS.DataTypes.BinaryData.defaultValue;
}, true), 
this.attr("DateTime", "dateTimeAttr", "DateTime", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DeviationDocumentRec.init();
return DeviationDocumentRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.DeviationDocumentRec = DeviationDocumentRec;

});
define("DigitalOnboarding_CS.model$ExceptionReportRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var ExceptionReportRec = (function (_super) {
__extends(ExceptionReportRec, _super);
function ExceptionReportRec(defaults) {
_super.apply(this, arguments);
}
ExceptionReportRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("ExceptionSystemChecksId", "exceptionSystemChecksIdAttr", "ExceptionSystemChecksId", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Status", "statusAttr", "Status", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OnboardingJourneyId", "onboardingJourneyIdAttr", "OnboardingJourneyId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("RemarkId", "remarkIdAttr", "RemarkId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ExceptionReportRec.init();
return ExceptionReportRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.ExceptionReportRec = ExceptionReportRec;

});
define("DigitalOnboarding_CS.model$CityRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var CityRec = (function (_super) {
__extends(CityRec, _super);
function CityRec(defaults) {
_super.apply(this, arguments);
}
CityRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Name", "nameAttr", "Name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("StateId", "stateIdAttr", "StateId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CityRec.init();
return CityRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.CityRec = CityRec;

});
define("DigitalOnboarding_CS.model$DeviationTypeRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var DeviationTypeRec = (function (_super) {
__extends(DeviationTypeRec, _super);
function DeviationTypeRec(defaults) {
_super.apply(this, arguments);
}
DeviationTypeRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DeviationTypeRec.init();
return DeviationTypeRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.DeviationTypeRec = DeviationTypeRec;

});
define("DigitalOnboarding_CS.model$Setup_AutoNotificationEmailRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var Setup_AutoNotificationEmailRec = (function (_super) {
__extends(Setup_AutoNotificationEmailRec, _super);
function Setup_AutoNotificationEmailRec(defaults) {
_super.apply(this, arguments);
}
Setup_AutoNotificationEmailRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("SetupSheetId", "setupSheetIdAttr", "SetupSheetId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("NotificationTypeId", "notificationTypeIdAttr", "NotificationTypeId", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Email", "emailAttr", "Email", false, false, OS.Types.Email, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Setup_AutoNotificationEmailRec.init();
return Setup_AutoNotificationEmailRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.Setup_AutoNotificationEmailRec = Setup_AutoNotificationEmailRec;

});
define("DigitalOnboarding_CS.model$DocumentDetailRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var DocumentDetailRec = (function (_super) {
__extends(DocumentDetailRec, _super);
function DocumentDetailRec(defaults) {
_super.apply(this, arguments);
}
DocumentDetailRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Name", "nameAttr", "Name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Type", "typeAttr", "Type", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("BinaryData", "binaryDataAttr", "BinaryData", false, false, OS.Types.BinaryData, function () {
return OS.DataTypes.BinaryData.defaultValue;
}, true), 
this.attr("DateTime", "dateTimeAttr", "DateTime", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("OnBoardingJourneyId", "onBoardingJourneyIdAttr", "OnBoardingJourneyId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("HTML", "hTMLAttr", "HTML", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CompanySectory", "companySectoryAttr", "CompanySectory", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OfficerName", "officerNameAttr", "OfficerName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Date", "dateAttr", "Date", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("Signature", "signatureAttr", "Signature", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DocumentDetailRec.init();
return DocumentDetailRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.DocumentDetailRec = DocumentDetailRec;

});
define("DigitalOnboarding_CS.model$Setup_AuthorizedSignatoryRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var Setup_AuthorizedSignatoryRec = (function (_super) {
__extends(Setup_AuthorizedSignatoryRec, _super);
function Setup_AuthorizedSignatoryRec(defaults) {
_super.apply(this, arguments);
}
Setup_AuthorizedSignatoryRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("SetupSheetId", "setupSheetIdAttr", "SetupSheetId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("AuthorizedSignatoryId", "authorizedSignatoryIdAttr", "AuthorizedSignatoryId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("IsAUS_TO_API", "isAUS_TO_APIAttr", "IsAUS_TO_API", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("IsPassword", "isPasswordAttr", "IsPassword", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("IsMaker", "isMakerAttr", "IsMaker", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("IsChecker", "isCheckerAttr", "IsChecker", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Setup_AuthorizedSignatoryRec.init();
return Setup_AuthorizedSignatoryRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.Setup_AuthorizedSignatoryRec = Setup_AuthorizedSignatoryRec;

});
define("DigitalOnboarding_CS.model$CustomerAccountRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var CustomerAccountRec = (function (_super) {
__extends(CustomerAccountRec, _super);
function CustomerAccountRec(defaults) {
_super.apply(this, arguments);
}
CustomerAccountRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Name", "nameAttr", "Name", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomerAccountRec.init();
return CustomerAccountRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.CustomerAccountRec = CustomerAccountRec;

});
define("DigitalOnboarding_CS.model$CustomerRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var CustomerRec = (function (_super) {
__extends(CustomerRec, _super);
function CustomerRec(defaults) {
_super.apply(this, arguments);
}
CustomerRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("CutomerId", "cutomerIdAttr", "CutomerId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("CustomerType", "customerTypeAttr", "CustomerType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CustomerFullName", "customerFullNameAttr", "CustomerFullName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EmailID", "emailIDAttr", "EmailID", false, false, OS.Types.Email, function () {
return "";
}, true), 
this.attr("MobileNumber", "mobileNumberAttr", "MobileNumber", false, false, OS.Types.PhoneNumber, function () {
return "";
}, true), 
this.attr("ContractPersonName", "contractPersonNameAttr", "ContractPersonName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Status", "statusAttr", "Status", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomerRec.init();
return CustomerRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.CustomerRec = CustomerRec;

});
define("DigitalOnboarding_CS.model$UserDesignationRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var UserDesignationRec = (function (_super) {
__extends(UserDesignationRec, _super);
function UserDesignationRec(defaults) {
_super.apply(this, arguments);
}
UserDesignationRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
UserDesignationRec.init();
return UserDesignationRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.UserDesignationRec = UserDesignationRec;

});
define("DigitalOnboarding_CS.model$OnboardingRequestRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var OnboardingRequestRec = (function (_super) {
__extends(OnboardingRequestRec, _super);
function OnboardingRequestRec(defaults) {
_super.apply(this, arguments);
}
OnboardingRequestRec.attributesToDeclare = function () {
return [
this.attr("AccountNumber", "accountNumberAttr", "accountNumber", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RequestID", "requestIDAttr", "requestID", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Product", "productAttr", "product", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Source", "sourceAttr", "source", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("SubSource", "subSourceAttr", "subSource", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PartnerName", "partnerNameAttr", "partnerName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AppId", "appIdAttr", "appId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CustIdPartner", "custIdPartnerAttr", "custIdPartner", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CustIdCustomer", "custIdCustomerAttr", "custIdCustomer", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EmailId", "emailIdAttr", "emailId", false, false, OS.Types.Email, function () {
return "";
}, true), 
this.attr("MobileNo", "mobileNoAttr", "mobileNo", false, false, OS.Types.PhoneNumber, function () {
return "";
}, true), 
this.attr("PanNo", "panNoAttr", "panNo", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OrgId", "orgIdAttr", "orgId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ProductId", "productIdAttr", "productId", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("TimeStamp", "timeStampAttr", "timeStamp", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
OnboardingRequestRec.init();
return OnboardingRequestRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.OnboardingRequestRec = OnboardingRequestRec;

});
define("DigitalOnboarding_CS.model$strProductFieldsRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var strProductFieldsRec = (function (_super) {
__extends(strProductFieldsRec, _super);
function strProductFieldsRec(defaults) {
_super.apply(this, arguments);
}
strProductFieldsRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
strProductFieldsRec.init();
return strProductFieldsRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.strProductFieldsRec = strProductFieldsRec;

});
define("DigitalOnboarding_CS.model$SetupSheetRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var SetupSheetRec = (function (_super) {
__extends(SetupSheetRec, _super);
function SetupSheetRec(defaults) {
_super.apply(this, arguments);
}
SetupSheetRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("AppId", "appIdAttr", "AppId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IdentityUserId", "identityUserIdAttr", "IdentityUserId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("NEFT", "nEFTAttr", "NEFT", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("RTGS", "rTGSAttr", "RTGS", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("IMPS", "iMPSAttr", "IMPS", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("BenRegistration", "benRegistrationAttr", "BenRegistration", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("NotifyAppCode", "notifyAppCodeAttr", "NotifyAppCode", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SetupSheetRec.init();
return SetupSheetRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.SetupSheetRec = SetupSheetRec;

});
define("DigitalOnboarding_CS.model$CustStatusItemRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var CustStatusItemRec = (function (_super) {
__extends(CustStatusItemRec, _super);
function CustStatusItemRec(defaults) {
_super.apply(this, arguments);
}
CustStatusItemRec.attributesToDeclare = function () {
return [
this.attr("RequestId", "requestIdAttr", "requestId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Product", "productAttr", "product", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Status", "statusAttr", "status", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustStatusItemRec.init();
return CustStatusItemRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.CustStatusItemRec = CustStatusItemRec;

});
define("DigitalOnboarding_CS.model$ProductFieldsRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var ProductFieldsRec = (function (_super) {
__extends(ProductFieldsRec, _super);
function ProductFieldsRec(defaults) {
_super.apply(this, arguments);
}
ProductFieldsRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ProductFieldsRec.init();
return ProductFieldsRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.ProductFieldsRec = ProductFieldsRec;

});
define("DigitalOnboarding_CS.model$PartnerRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var PartnerRec = (function (_super) {
__extends(PartnerRec, _super);
function PartnerRec(defaults) {
_super.apply(this, arguments);
}
PartnerRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Productid", "productidAttr", "Productid", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("PartnerName", "partnerNameAttr", "PartnerName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CreatedBy", "createdByAttr", "CreatedBy", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("CreatedOn", "createdOnAttr", "CreatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("UpdatedBy", "updatedByAttr", "UpdatedBy", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("UpdatedOn", "updatedOnAttr", "UpdatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PartnerRec.init();
return PartnerRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.PartnerRec = PartnerRec;

});
define("DigitalOnboarding_CS.model$ApprovalStatusRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var ApprovalStatusRec = (function (_super) {
__extends(ApprovalStatusRec, _super);
function ApprovalStatusRec(defaults) {
_super.apply(this, arguments);
}
ApprovalStatusRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ApprovalStatusRec.init();
return ApprovalStatusRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.ApprovalStatusRec = ApprovalStatusRec;

});
define("DigitalOnboarding_CS.model$SigningRequestRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var SigningRequestRec = (function (_super) {
__extends(SigningRequestRec, _super);
function SigningRequestRec(defaults) {
_super.apply(this, arguments);
}
SigningRequestRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("IsBRFormSigned", "isBRFormSignedAttr", "IsBRFormSigned", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("OnboardingJourneyId", "onboardingJourneyIdAttr", "OnboardingJourneyId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("AuthSignatoryId", "authSignatoryIdAttr", "AuthSignatoryId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SigningRequestRec.init();
return SigningRequestRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.SigningRequestRec = SigningRequestRec;

});
define("DigitalOnboarding_CS.model$CustomerOnBoardingStatusRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var CustomerOnBoardingStatusRec = (function (_super) {
__extends(CustomerOnBoardingStatusRec, _super);
function CustomerOnBoardingStatusRec(defaults) {
_super.apply(this, arguments);
}
CustomerOnBoardingStatusRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomerOnBoardingStatusRec.init();
return CustomerOnBoardingStatusRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.CustomerOnBoardingStatusRec = CustomerOnBoardingStatusRec;

});
define("DigitalOnboarding_CS.model$DeleteRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var DeleteRec = (function (_super) {
__extends(DeleteRec, _super);
function DeleteRec(defaults) {
_super.apply(this, arguments);
}
DeleteRec.attributesToDeclare = function () {
return [
this.attr("Delete", "deleteAttr", "Delete", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DeleteRec.fromStructure = function (str) {
return new DeleteRec(new DeleteRec.RecordClass({
deleteAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DeleteRec.init();
return DeleteRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.DeleteRec = DeleteRec;

});
define("DigitalOnboarding_CS.model$OrderRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var OrderRec = (function (_super) {
__extends(OrderRec, _super);
function OrderRec(defaults) {
_super.apply(this, arguments);
}
OrderRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Items", "itemsAttr", "Items", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Description", "descriptionAttr", "Description", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Email", "emailAttr", "Email", false, false, OS.Types.Email, function () {
return "";
}, true), 
this.attr("Price", "priceAttr", "Price", false, false, OS.Types.Currency, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("IsActive", "isActiveAttr", "IsActive", false, false, OS.Types.Boolean, function () {
return true;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
OrderRec.init();
return OrderRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.OrderRec = OrderRec;

});
define("DigitalOnboarding_CS.model$ExceptionSystemCheckRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var ExceptionSystemCheckRec = (function (_super) {
__extends(ExceptionSystemCheckRec, _super);
function ExceptionSystemCheckRec(defaults) {
_super.apply(this, arguments);
}
ExceptionSystemCheckRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("SystemCheck", "systemCheckAttr", "SystemCheck", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsActive", "isActiveAttr", "IsActive", false, false, OS.Types.Boolean, function () {
return true;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ExceptionSystemCheckRec.init();
return ExceptionSystemCheckRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.ExceptionSystemCheckRec = ExceptionSystemCheckRec;

});
define("DigitalOnboarding_CS.model$PartnerFieldConFigRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var PartnerFieldConFigRec = (function (_super) {
__extends(PartnerFieldConFigRec, _super);
function PartnerFieldConFigRec(defaults) {
_super.apply(this, arguments);
}
PartnerFieldConFigRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("PartnerId", "partnerIdAttr", "PartnerId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("ProductFields", "productFieldsAttr", "ProductFields", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Value", "valueAttr", "Value", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsEditable", "isEditableAttr", "IsEditable", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("IsVisible", "isVisibleAttr", "IsVisible", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PartnerFieldConFigRec.init();
return PartnerFieldConFigRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.PartnerFieldConFigRec = PartnerFieldConFigRec;

});
define("DigitalOnboarding_CS.model$NotificationTypeRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var NotificationTypeRec = (function (_super) {
__extends(NotificationTypeRec, _super);
function NotificationTypeRec(defaults) {
_super.apply(this, arguments);
}
NotificationTypeRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
NotificationTypeRec.init();
return NotificationTypeRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.NotificationTypeRec = NotificationTypeRec;

});
define("DigitalOnboarding_CS.model$KYCStatusRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var KYCStatusRec = (function (_super) {
__extends(KYCStatusRec, _super);
function KYCStatusRec(defaults) {
_super.apply(this, arguments);
}
KYCStatusRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
KYCStatusRec.init();
return KYCStatusRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.KYCStatusRec = KYCStatusRec;

});
define("DigitalOnboarding_CS.model$ProductTypeRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var ProductTypeRec = (function (_super) {
__extends(ProductTypeRec, _super);
function ProductTypeRec(defaults) {
_super.apply(this, arguments);
}
ProductTypeRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ProductTypeRec.init();
return ProductTypeRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.ProductTypeRec = ProductTypeRec;

});
define("DigitalOnboarding_CS.model$BranchRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var BranchRec = (function (_super) {
__extends(BranchRec, _super);
function BranchRec(defaults) {
_super.apply(this, arguments);
}
BranchRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("BranchCode", "branchCodeAttr", "BranchCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("BranchLocation", "branchLocationAttr", "BranchLocation", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("BranchAddress", "branchAddressAttr", "BranchAddress", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CountryId", "countryIdAttr", "CountryId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("CityId", "cityIdAttr", "CityId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("StateId", "stateIdAttr", "StateId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("BranchName", "branchNameAttr", "BranchName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("State", "stateAttr", "State", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsActive", "isActiveAttr", "IsActive", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
BranchRec.init();
return BranchRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.BranchRec = BranchRec;

});
define("DigitalOnboarding_CS.model$OnBoardingJourneyRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var OnBoardingJourneyRec = (function (_super) {
__extends(OnBoardingJourneyRec, _super);
function OnBoardingJourneyRec(defaults) {
_super.apply(this, arguments);
}
OnBoardingJourneyRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("CustomerId", "customerIdAttr", "CustomerId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("ProductId", "productIdAttr", "ProductId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("AssignedTo", "assignedToAttr", "AssignedTo", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("OnBoardingStatus", "onBoardingStatusAttr", "OnBoardingStatus", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("RequestNo", "requestNoAttr", "RequestNo", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AssignTeam", "assignTeamAttr", "AssignTeam", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ApprovalStatusId", "approvalStatusIdAttr", "ApprovalStatusId", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
OnBoardingJourneyRec.init();
return OnBoardingJourneyRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.OnBoardingJourneyRec = OnBoardingJourneyRec;

});
define("DigitalOnboarding_CS.model$DeviationRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var DeviationRec = (function (_super) {
__extends(DeviationRec, _super);
function DeviationRec(defaults) {
_super.apply(this, arguments);
}
DeviationRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("OB_CustomerPricingId", "oB_CustomerPricingIdAttr", "OB_CustomerPricingId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("DeviationType", "deviationTypeAttr", "DeviationType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OldValue", "oldValueAttr", "OldValue", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("NewValue", "newValueAttr", "NewValue", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CreatedBy", "createdByAttr", "CreatedBy", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CreatedOn", "createdOnAttr", "CreatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("OnBoardingId", "onBoardingIdAttr", "OnBoardingId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DeviationRec.init();
return DeviationRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.DeviationRec = DeviationRec;

});
define("DigitalOnboarding_CS.model$OnBoardingRemarksRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var OnBoardingRemarksRec = (function (_super) {
__extends(OnBoardingRemarksRec, _super);
function OnBoardingRemarksRec(defaults) {
_super.apply(this, arguments);
}
OnBoardingRemarksRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("OnBoardingId", "onBoardingIdAttr", "OnBoardingId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Remark", "remarkAttr", "Remark", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("UserId", "userIdAttr", "UserId", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("DateTime", "dateTimeAttr", "DateTime", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
OnBoardingRemarksRec.init();
return OnBoardingRemarksRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.OnBoardingRemarksRec = OnBoardingRemarksRec;

});
define("DigitalOnboarding_CS.model$CusstBranchRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var CusstBranchRec = (function (_super) {
__extends(CusstBranchRec, _super);
function CusstBranchRec(defaults) {
_super.apply(this, arguments);
}
CusstBranchRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("BranchId", "branchIdAttr", "BranchId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("CustomerId", "customerIdAttr", "CustomerId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CusstBranchRec.init();
return CusstBranchRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.CusstBranchRec = CusstBranchRec;

});
define("DigitalOnboarding_CS.model$strPartnerFieldConFigRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model", "DigitalOnboarding_CS.model$strProductFieldsRec"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var strPartnerFieldConFigRec = (function (_super) {
__extends(strPartnerFieldConFigRec, _super);
function strPartnerFieldConFigRec(defaults) {
_super.apply(this, arguments);
}
strPartnerFieldConFigRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("PartnerId", "partnerIdAttr", "PartnerId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("ProductFields", "productFieldsAttr", "ProductFields", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Value", "valueAttr", "Value", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsEditable", "isEditableAttr", "IsEditable", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("IsVisible", "isVisibleAttr", "IsVisible", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("strProductFields", "strProductFieldsAttr", "strProductFields", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new DigitalOnboarding_CSModel.strProductFieldsRec());
}, true, DigitalOnboarding_CSModel.strProductFieldsRec)
].concat(_super.attributesToDeclare.call(this));
};
strPartnerFieldConFigRec.init();
return strPartnerFieldConFigRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.strPartnerFieldConFigRec = strPartnerFieldConFigRec;

});
define("DigitalOnboarding_CS.model$Setup_SelectedAccRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var Setup_SelectedAccRec = (function (_super) {
__extends(Setup_SelectedAccRec, _super);
function Setup_SelectedAccRec(defaults) {
_super.apply(this, arguments);
}
Setup_SelectedAccRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("CustAccountId", "custAccountIdAttr", "CustAccountId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("SetupSheetId", "setupSheetIdAttr", "SetupSheetId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Setup_SelectedAccRec.init();
return Setup_SelectedAccRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.Setup_SelectedAccRec = Setup_SelectedAccRec;

});
define("DigitalOnboarding_CS.model$AuthSigUserTypeRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var AuthSigUserTypeRec = (function (_super) {
__extends(AuthSigUserTypeRec, _super);
function AuthSigUserTypeRec(defaults) {
_super.apply(this, arguments);
}
AuthSigUserTypeRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
AuthSigUserTypeRec.init();
return AuthSigUserTypeRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.AuthSigUserTypeRec = AuthSigUserTypeRec;

});
define("DigitalOnboarding_CS.model$StateRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var StateRec = (function (_super) {
__extends(StateRec, _super);
function StateRec(defaults) {
_super.apply(this, arguments);
}
StateRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Name", "nameAttr", "Name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CountryId", "countryIdAttr", "CountryId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
StateRec.init();
return StateRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.StateRec = StateRec;

});
define("DigitalOnboarding_CS.model$RemarksRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var RemarksRec = (function (_super) {
__extends(RemarksRec, _super);
function RemarksRec(defaults) {
_super.apply(this, arguments);
}
RemarksRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("DevationId", "devationIdAttr", "DevationId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("OnboardingId", "onboardingIdAttr", "OnboardingId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("FinalRemarks", "finalRemarksAttr", "FinalRemarks", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("COD_Remarks", "cOD_RemarksAttr", "COD_Remarks", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Maker_Remarks", "maker_RemarksAttr", "Maker_Remarks", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Checker_Remarks", "checker_RemarksAttr", "Checker_Remarks", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ExceptionId", "exceptionIdAttr", "ExceptionId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
RemarksRec.init();
return RemarksRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.RemarksRec = RemarksRec;

});
define("DigitalOnboarding_CS.model$OnBoardingStatusRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var OnBoardingStatusRec = (function (_super) {
__extends(OnBoardingStatusRec, _super);
function OnBoardingStatusRec(defaults) {
_super.apply(this, arguments);
}
OnBoardingStatusRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
OnBoardingStatusRec.init();
return OnBoardingStatusRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.OnBoardingStatusRec = OnBoardingStatusRec;

});
define("DigitalOnboarding_CS.model$TemplateTagsRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var TemplateTagsRec = (function (_super) {
__extends(TemplateTagsRec, _super);
function TemplateTagsRec(defaults) {
_super.apply(this, arguments);
}
TemplateTagsRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("Description", "descriptionAttr", "Description", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
TemplateTagsRec.init();
return TemplateTagsRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.TemplateTagsRec = TemplateTagsRec;

});
define("DigitalOnboarding_CS.model$CustAccountDetailsRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var CustAccountDetailsRec = (function (_super) {
__extends(CustAccountDetailsRec, _super);
function CustAccountDetailsRec(defaults) {
_super.apply(this, arguments);
}
CustAccountDetailsRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("CustomerId", "customerIdAttr", "CustomerId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("AccountNumber", "accountNumberAttr", "AccountNumber", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustAccountDetailsRec.init();
return CustAccountDetailsRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.CustAccountDetailsRec = CustAccountDetailsRec;

});
define("DigitalOnboarding_CS.model$CountryRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var CountryRec = (function (_super) {
__extends(CountryRec, _super);
function CountryRec(defaults) {
_super.apply(this, arguments);
}
CountryRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Name", "nameAttr", "Name", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CountryRec.init();
return CountryRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.CountryRec = CountryRec;

});
define("DigitalOnboarding_CS.model$ProductRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var ProductRec = (function (_super) {
__extends(ProductRec, _super);
function ProductRec(defaults) {
_super.apply(this, arguments);
}
ProductRec.attributesToDeclare = function () {
return [
this.attr("ProductId", "productIdAttr", "ProductId", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("ProductTypeId", "productTypeIdAttr", "ProductTypeId", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("ProductName", "productNameAttr", "ProductName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ProductionDescription", "productionDescriptionAttr", "ProductionDescription", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CreatedBy", "createdByAttr", "CreatedBy", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("CreatedOn", "createdOnAttr", "CreatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("UpdatedBy", "updatedByAttr", "UpdatedBy", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("UpdatedOn", "updatedOnAttr", "UpdatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ProductRec.init();
return ProductRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.ProductRec = ProductRec;

});
define("DigitalOnboarding_CS.model$ProductPricingRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var ProductPricingRec = (function (_super) {
__extends(ProductPricingRec, _super);
function ProductPricingRec(defaults) {
_super.apply(this, arguments);
}
ProductPricingRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("APIIntegrationCharges", "aPIIntegrationChargesAttr", "APIIntegrationCharges", false, false, OS.Types.Currency, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("AMC", "aMCAttr", "AMC", false, false, OS.Types.Currency, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("MaintenenceIntegrationCost", "maintenenceIntegrationCostAttr", "MaintenenceIntegrationCost", false, false, OS.Types.Currency, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("TxnFee_RTGS", "txnFee_RTGSAttr", "TxnFee_RTGS", false, false, OS.Types.Currency, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("TxnFee_NEFT", "txnFee_NEFTAttr", "TxnFee_NEFT", false, false, OS.Types.Currency, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("TxnFee_A2A", "txnFee_A2AAttr", "TxnFee_A2A", false, false, OS.Types.Currency, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("TxnFee_IMPS1K", "txnFee_IMPS1KAttr", "TxnFee_IMPS1K", false, false, OS.Types.Currency, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("TxnFee_IMPSG25K", "txnFee_IMPSG25KAttr", "TxnFee_IMPSG25K", false, false, OS.Types.Currency, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("TxnFee_IMPSL25K", "txnFee_IMPSL25KAttr", "TxnFee_IMPSL25K", false, false, OS.Types.Currency, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ProductPricingRec.init();
return ProductPricingRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.ProductPricingRec = ProductPricingRec;

});
define("DigitalOnboarding_CS.model$TemplateContentRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var TemplateContentRec = (function (_super) {
__extends(TemplateContentRec, _super);
function TemplateContentRec(defaults) {
_super.apply(this, arguments);
}
TemplateContentRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("ProductId", "productIdAttr", "ProductId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("HTMLContent", "hTMLContentAttr", "HTMLContent", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
TemplateContentRec.init();
return TemplateContentRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.TemplateContentRec = TemplateContentRec;

});
define("DigitalOnboarding_CS.model$StatusRequestRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var StatusRequestRec = (function (_super) {
__extends(StatusRequestRec, _super);
function StatusRequestRec(defaults) {
_super.apply(this, arguments);
}
StatusRequestRec.attributesToDeclare = function () {
return [
this.attr("CustomerId", "customerIdAttr", "customerId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RequestId", "requestIdAttr", "requestId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AppId", "appIdAttr", "appId", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
StatusRequestRec.init();
return StatusRequestRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.StatusRequestRec = StatusRequestRec;

});
define("DigitalOnboarding_CS.model$AuthorizedSignatoryRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var AuthorizedSignatoryRec = (function (_super) {
__extends(AuthorizedSignatoryRec, _super);
function AuthorizedSignatoryRec(defaults) {
_super.apply(this, arguments);
}
AuthorizedSignatoryRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Name", "nameAttr", "Name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Type", "typeAttr", "Type", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Email", "emailAttr", "Email", false, false, OS.Types.Email, function () {
return "";
}, true), 
this.attr("PANNo", "pANNoAttr", "PANNo", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Mobile", "mobileAttr", "Mobile", false, false, OS.Types.PhoneNumber, function () {
return "";
}, true), 
this.attr("KYCStatus", "kYCStatusAttr", "KYCStatus", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("IsVerififyedYblPAN", "isVerififyedYblPANAttr", "IsVerififyedYblPAN", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("UserDesignationId", "userDesignationIdAttr", "UserDesignationId", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Designation", "designationAttr", "Designation", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
AuthorizedSignatoryRec.init();
return AuthorizedSignatoryRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.AuthorizedSignatoryRec = AuthorizedSignatoryRec;

});
define("DigitalOnboarding_CS.model$CustStatusItemList", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model", "DigitalOnboarding_CS.model$CustStatusItemRec"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var CustStatusItemList = (function (_super) {
__extends(CustStatusItemList, _super);
function CustStatusItemList(defaults) {
_super.apply(this, arguments);
}
CustStatusItemList.itemType = DigitalOnboarding_CSModel.CustStatusItemRec;
return CustStatusItemList;
})(OS.DataTypes.GenericRecordList);
DigitalOnboarding_CSModel.CustStatusItemList = CustStatusItemList;

});
define("DigitalOnboarding_CS.model$StatusResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_CS.model", "DigitalOnboarding_CS.model$CustStatusItemList"], function (exports, OutSystems, DigitalOnboarding_CSModel) {
var OS = OutSystems.Internal;
var StatusResponseRec = (function (_super) {
__extends(StatusResponseRec, _super);
function StatusResponseRec(defaults) {
_super.apply(this, arguments);
}
StatusResponseRec.attributesToDeclare = function () {
return [
this.attr("Code", "codeAttr", "code", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Message", "messageAttr", "message", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CustStatus", "custStatusAttr", "custStatus", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new DigitalOnboarding_CSModel.CustStatusItemList());
}, true, DigitalOnboarding_CSModel.CustStatusItemList)
].concat(_super.attributesToDeclare.call(this));
};
StatusResponseRec.init();
return StatusResponseRec;
})(OS.DataTypes.GenericRecord);
DigitalOnboarding_CSModel.StatusResponseRec = StatusResponseRec;

});
define("DigitalOnboarding_CS.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var DigitalOnboarding_CSModel = exports;
});
