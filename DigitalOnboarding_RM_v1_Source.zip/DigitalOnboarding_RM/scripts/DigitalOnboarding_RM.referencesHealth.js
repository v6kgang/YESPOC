﻿define("DigitalOnboarding_RM.referencesHealth$DigitalOnboarding_CS",[], function() {
	// Reference to producer 'DigitalOnboarding_CS' is OK.
});
define("DigitalOnboarding_RM.referencesHealth$ServiceCenter",[], function() {
	// Reference to producer 'ServiceCenter' is OK.
});
define("DigitalOnboarding_RM.referencesHealth$Users",[], function() {
	// Reference to producer 'Users' is OK.
});
define("DigitalOnboarding_RM.referencesHealth",[], function() {
});
