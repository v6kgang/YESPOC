﻿define("DigitalOnboarding_RM.model$ApplicationUserRec",["exports", "OutSystems/ClientRuntime/Main", "DigitalOnboarding_RM.model"], function(exports, OutSystems, DigitalOnboarding_RMModel) {
	var OS = OutSystems.Internal;
	var ApplicationUserRec = (function(_super) {
		__extends(ApplicationUserRec, _super);
		function ApplicationUserRec(defaults) {
			_super.apply(this, arguments);
		}
		ApplicationUserRec.attributesToDeclare = function() {
			return[
			this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function() {
				return OS.DataTypes.LongInteger.defaultValue;
			}
			, true),
			this.attr("UserID", "userIDAttr", "UserID", false, false, OS.Types.Integer, function() {
				return 0;
			}
			, true),
			this.attr("BranchId", "branchIdAttr", "BranchId", false, false, OS.Types.LongInteger, function() {
				return OS.DataTypes.LongInteger.defaultValue;
			}
			, true)
			] .concat(_super.attributesToDeclare.call(this));
		};
		ApplicationUserRec.init();
		return ApplicationUserRec;
	}
	) (OS.DataTypes.GenericRecord);
	DigitalOnboarding_RMModel.ApplicationUserRec = ApplicationUserRec;

});
define("DigitalOnboarding_RM.model",["exports", "OutSystems/ClientRuntime/Main"], function(exports, OutSystems) {
	var OS = OutSystems.Internal;
	var DigitalOnboarding_RMModel = exports;
});
