﻿define("DigitalOnboarding_CS.referencesHealth$ESB_FCR_IS", [], function () {
// Reference to producer 'ESB_FCR_IS' is OK.
});
define("DigitalOnboarding_CS.referencesHealth$HTTPRequestHandler", [], function () {
// Reference to producer 'HTTPRequestHandler' is OK.
});
define("DigitalOnboarding_CS.referencesHealth$ServiceCenter", [], function () {
// Reference to producer 'ServiceCenter' is OK.
});
define("DigitalOnboarding_CS.referencesHealth$Users", [], function () {
// Reference to producer 'Users' is OK.
});
define("DigitalOnboarding_CS.referencesHealth", [], function () {
});
