﻿define("OutSystemsSampleDataDB.model$Sample_TransactionTypeRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var Sample_TransactionTypeRec = (function (_super) {
__extends(Sample_TransactionTypeRec, _super);
function Sample_TransactionTypeRec(defaults) {
_super.apply(this, arguments);
}
Sample_TransactionTypeRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Sample_TransactionTypeRec.init();
return Sample_TransactionTypeRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.Sample_TransactionTypeRec = Sample_TransactionTypeRec;

});
define("OutSystemsSampleDataDB.model$Sample_AccountsRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var Sample_AccountsRec = (function (_super) {
__extends(Sample_AccountsRec, _super);
function Sample_AccountsRec(defaults) {
_super.apply(this, arguments);
}
Sample_AccountsRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Name", "nameAttr", "Name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AccountNumber", "accountNumberAttr", "AccountNumber", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Balance", "balanceAttr", "Balance", false, false, OS.Types.Currency, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("IsActive", "isActiveAttr", "IsActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("CreatedOn", "createdOnAttr", "CreatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("Overdraft", "overdraftAttr", "Overdraft", false, false, OS.Types.Currency, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("CreatedBy", "createdByAttr", "CreatedBy", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Manager", "managerAttr", "Manager", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Owner", "ownerAttr", "Owner", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("IsPersonal", "isPersonalAttr", "IsPersonal", false, false, OS.Types.Boolean, function () {
return true;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Sample_AccountsRec.init();
return Sample_AccountsRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.Sample_AccountsRec = Sample_AccountsRec;

});
define("OutSystemsSampleDataDB.model$DEPRECATED_Sample_ProductSalesRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var DEPRECATED_Sample_ProductSalesRec = (function (_super) {
__extends(DEPRECATED_Sample_ProductSalesRec, _super);
function DEPRECATED_Sample_ProductSalesRec(defaults) {
_super.apply(this, arguments);
}
DEPRECATED_Sample_ProductSalesRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Date", "dateAttr", "Date", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("Cost", "costAttr", "Cost", false, false, OS.Types.Currency, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("Quantity", "quantityAttr", "Quantity", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Product", "productAttr", "Product", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DEPRECATED_Sample_ProductSalesRec.init();
return DEPRECATED_Sample_ProductSalesRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.DEPRECATED_Sample_ProductSalesRec = DEPRECATED_Sample_ProductSalesRec;

});
define("OutSystemsSampleDataDB.model$Sample_LocationTypeRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var Sample_LocationTypeRec = (function (_super) {
__extends(Sample_LocationTypeRec, _super);
function Sample_LocationTypeRec(defaults) {
_super.apply(this, arguments);
}
Sample_LocationTypeRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Sample_LocationTypeRec.init();
return Sample_LocationTypeRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.Sample_LocationTypeRec = Sample_LocationTypeRec;

});
define("OutSystemsSampleDataDB.model$Sample_LocationReviewsRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var Sample_LocationReviewsRec = (function (_super) {
__extends(Sample_LocationReviewsRec, _super);
function Sample_LocationReviewsRec(defaults) {
_super.apply(this, arguments);
}
Sample_LocationReviewsRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("LocationId", "locationIdAttr", "LocationId", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("ReviewId", "reviewIdAttr", "ReviewId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Sample_LocationReviewsRec.init();
return Sample_LocationReviewsRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.Sample_LocationReviewsRec = Sample_LocationReviewsRec;

});
define("OutSystemsSampleDataDB.model$Sample_DepartmentRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var Sample_DepartmentRec = (function (_super) {
__extends(Sample_DepartmentRec, _super);
function Sample_DepartmentRec(defaults) {
_super.apply(this, arguments);
}
Sample_DepartmentRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Name", "nameAttr", "Name", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Sample_DepartmentRec.init();
return Sample_DepartmentRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.Sample_DepartmentRec = Sample_DepartmentRec;

});
define("OutSystemsSampleDataDB.model$Sample_LocationRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var Sample_LocationRec = (function (_super) {
__extends(Sample_LocationRec, _super);
function Sample_LocationRec(defaults) {
_super.apply(this, arguments);
}
Sample_LocationRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Name", "nameAttr", "Name", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Address", "addressAttr", "Address", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Latitude", "latitudeAttr", "Latitude", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Longitude", "longitudeAttr", "Longitude", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("LocationType", "locationTypeAttr", "LocationType", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Phone", "phoneAttr", "Phone", false, false, OS.Types.PhoneNumber, function () {
return "";
}, true), 
this.attr("Website", "websiteAttr", "Website", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Services", "servicesAttr", "Services", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OpeningHour", "openingHourAttr", "OpeningHour", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ClosingHour", "closingHourAttr", "ClosingHour", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("BusinessHours", "businessHoursAttr", "BusinessHours", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("WeekdaysBusinessHours", "weekdaysBusinessHoursAttr", "WeekdaysBusinessHours", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("SaturdayBusinessHours", "saturdayBusinessHoursAttr", "SaturdayBusinessHours", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("SundayBusinessHours", "sundayBusinessHoursAttr", "SundayBusinessHours", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("HolidaysBusinessHours", "holidaysBusinessHoursAttr", "HolidaysBusinessHours", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Sample_LocationRec.init();
return Sample_LocationRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.Sample_LocationRec = Sample_LocationRec;

});
define("OutSystemsSampleDataDB.model$Sample_LocationPicturesRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var Sample_LocationPicturesRec = (function (_super) {
__extends(Sample_LocationPicturesRec, _super);
function Sample_LocationPicturesRec(defaults) {
_super.apply(this, arguments);
}
Sample_LocationPicturesRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("LocationId", "locationIdAttr", "LocationId", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Filename", "filenameAttr", "Filename", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Filetype", "filetypeAttr", "Filetype", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("File", "fileAttr", "File", false, false, OS.Types.BinaryData, function () {
return OS.DataTypes.BinaryData.defaultValue;
}, true), 
this.attr("CreatedOn", "createdOnAttr", "CreatedOn", false, false, OS.Types.DateTime, function () {
return OS.BuiltinFunctions.currDateTime();
}, true), 
this.attr("IsCoverImage", "isCoverImageAttr", "IsCoverImage", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Sample_LocationPicturesRec.init();
return Sample_LocationPicturesRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.Sample_LocationPicturesRec = Sample_LocationPicturesRec;

});
define("OutSystemsSampleDataDB.model$Sample_NotificationRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var Sample_NotificationRec = (function (_super) {
__extends(Sample_NotificationRec, _super);
function Sample_NotificationRec(defaults) {
_super.apply(this, arguments);
}
Sample_NotificationRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Description", "descriptionAttr", "Description", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CreatedOn", "createdOnAttr", "CreatedOn", false, false, OS.Types.DateTime, function () {
return OS.BuiltinFunctions.currDateTime();
}, true), 
this.attr("CreatedBy", "createdByAttr", "CreatedBy", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Sample_NotificationRec.init();
return Sample_NotificationRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.Sample_NotificationRec = Sample_NotificationRec;

});
define("OutSystemsSampleDataDB.model$Sample_PriorityRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var Sample_PriorityRec = (function (_super) {
__extends(Sample_PriorityRec, _super);
function Sample_PriorityRec(defaults) {
_super.apply(this, arguments);
}
Sample_PriorityRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Sample_PriorityRec.init();
return Sample_PriorityRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.Sample_PriorityRec = Sample_PriorityRec;

});
define("OutSystemsSampleDataDB.model$Sample_TransactionRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var Sample_TransactionRec = (function (_super) {
__extends(Sample_TransactionRec, _super);
function Sample_TransactionRec(defaults) {
_super.apply(this, arguments);
}
Sample_TransactionRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("SourceAccount", "sourceAccountAttr", "SourceAccount", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("DestinationAccount", "destinationAccountAttr", "DestinationAccount", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Date", "dateAttr", "Date", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("Description", "descriptionAttr", "Description", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Amount", "amountAttr", "Amount", false, false, OS.Types.Currency, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("Balance", "balanceAttr", "Balance", false, false, OS.Types.Currency, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("Type", "typeAttr", "Type", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Sample_TransactionRec.init();
return Sample_TransactionRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.Sample_TransactionRec = Sample_TransactionRec;

});
define("OutSystemsSampleDataDB.model$Sample_LocationMainPictureRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var Sample_LocationMainPictureRec = (function (_super) {
__extends(Sample_LocationMainPictureRec, _super);
function Sample_LocationMainPictureRec(defaults) {
_super.apply(this, arguments);
}
Sample_LocationMainPictureRec.attributesToDeclare = function () {
return [
this.attr("LocationId", "locationIdAttr", "LocationId", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Filename", "filenameAttr", "Filename", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Filetype", "filetypeAttr", "Filetype", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("File", "fileAttr", "File", false, false, OS.Types.BinaryData, function () {
return OS.DataTypes.BinaryData.defaultValue;
}, true), 
this.attr("CreatedOn", "createdOnAttr", "CreatedOn", false, false, OS.Types.DateTime, function () {
return OS.BuiltinFunctions.currDateTime();
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Sample_LocationMainPictureRec.init();
return Sample_LocationMainPictureRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.Sample_LocationMainPictureRec = Sample_LocationMainPictureRec;

});
define("OutSystemsSampleDataDB.model$DEPRECATED_Sample_ProductReviewsRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var DEPRECATED_Sample_ProductReviewsRec = (function (_super) {
__extends(DEPRECATED_Sample_ProductReviewsRec, _super);
function DEPRECATED_Sample_ProductReviewsRec(defaults) {
_super.apply(this, arguments);
}
DEPRECATED_Sample_ProductReviewsRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("ProductId", "productIdAttr", "ProductId", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("ReviewId", "reviewIdAttr", "ReviewId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DEPRECATED_Sample_ProductReviewsRec.init();
return DEPRECATED_Sample_ProductReviewsRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.DEPRECATED_Sample_ProductReviewsRec = DEPRECATED_Sample_ProductReviewsRec;

});
define("OutSystemsSampleDataDB.model$Sample_ShippingRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var Sample_ShippingRec = (function (_super) {
__extends(Sample_ShippingRec, _super);
function Sample_ShippingRec(defaults) {
_super.apply(this, arguments);
}
Sample_ShippingRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("DeliveryType", "deliveryTypeAttr", "DeliveryType", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Info", "infoAttr", "Info", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Price", "priceAttr", "Price", false, false, OS.Types.Currency, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("TimeToDeliver", "timeToDeliverAttr", "TimeToDeliver", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Sample_ShippingRec.init();
return Sample_ShippingRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.Sample_ShippingRec = Sample_ShippingRec;

});
define("OutSystemsSampleDataDB.model$Sample_ProductReviewsRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var Sample_ProductReviewsRec = (function (_super) {
__extends(Sample_ProductReviewsRec, _super);
function Sample_ProductReviewsRec(defaults) {
_super.apply(this, arguments);
}
Sample_ProductReviewsRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("ProductId", "productIdAttr", "ProductId", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("ReviewId", "reviewIdAttr", "ReviewId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Sample_ProductReviewsRec.init();
return Sample_ProductReviewsRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.Sample_ProductReviewsRec = Sample_ProductReviewsRec;

});
define("OutSystemsSampleDataDB.model$Sample_ReviewsRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var Sample_ReviewsRec = (function (_super) {
__extends(Sample_ReviewsRec, _super);
function Sample_ReviewsRec(defaults) {
_super.apply(this, arguments);
}
Sample_ReviewsRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Review", "reviewAttr", "Review", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Rating", "ratingAttr", "Rating", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("ReviewedBy", "reviewedByAttr", "ReviewedBy", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ReviewedOn", "reviewedOnAttr", "ReviewedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Sample_ReviewsRec.init();
return Sample_ReviewsRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.Sample_ReviewsRec = Sample_ReviewsRec;

});
define("OutSystemsSampleDataDB.model$Sample_ColorRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var Sample_ColorRec = (function (_super) {
__extends(Sample_ColorRec, _super);
function Sample_ColorRec(defaults) {
_super.apply(this, arguments);
}
Sample_ColorRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Sample_ColorRec.init();
return Sample_ColorRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.Sample_ColorRec = Sample_ColorRec;

});
define("OutSystemsSampleDataDB.model$Sample_ProductTypeRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var Sample_ProductTypeRec = (function (_super) {
__extends(Sample_ProductTypeRec, _super);
function Sample_ProductTypeRec(defaults) {
_super.apply(this, arguments);
}
Sample_ProductTypeRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Sample_ProductTypeRec.init();
return Sample_ProductTypeRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.Sample_ProductTypeRec = Sample_ProductTypeRec;

});
define("OutSystemsSampleDataDB.model$Sample_OfficeRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var Sample_OfficeRec = (function (_super) {
__extends(Sample_OfficeRec, _super);
function Sample_OfficeRec(defaults) {
_super.apply(this, arguments);
}
Sample_OfficeRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Name", "nameAttr", "Name", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Address", "addressAttr", "Address", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Latitude", "latitudeAttr", "Latitude", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Longitude", "longitudeAttr", "Longitude", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Sample_OfficeRec.init();
return Sample_OfficeRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.Sample_OfficeRec = Sample_OfficeRec;

});
define("OutSystemsSampleDataDB.model$Sample_ProductRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var Sample_ProductRec = (function (_super) {
__extends(Sample_ProductRec, _super);
function Sample_ProductRec(defaults) {
_super.apply(this, arguments);
}
Sample_ProductRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Name", "nameAttr", "Name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Description", "descriptionAttr", "Description", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Price", "priceAttr", "Price", false, false, OS.Types.Currency, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("Stock", "stockAttr", "Stock", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("MaxStock", "maxStockAttr", "MaxStock", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("StockThreshold", "stockThresholdAttr", "StockThreshold", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("Category", "categoryAttr", "Category", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("CreatedOn", "createdOnAttr", "CreatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("IsFavourite", "isFavouriteAttr", "IsFavourite", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("Rating", "ratingAttr", "Rating", false, false, OS.Types.Decimal, function () {
return OS.BuiltinFunctions.integerToDecimal(0);
}, true), 
this.attr("Likes", "likesAttr", "Likes", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Reference", "referenceAttr", "Reference", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EAN", "eANAttr", "EAN", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Brand", "brandAttr", "Brand", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Model", "modelAttr", "Model", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Weight", "weightAttr", "Weight", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Dimensions", "dimensionsAttr", "Dimensions", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Sample_Color", "sample_ColorAttr", "Sample_Color", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Sample_Size", "sample_SizeAttr", "Sample_Size", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Sample_ProductRec.init();
return Sample_ProductRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.Sample_ProductRec = Sample_ProductRec;

});
define("OutSystemsSampleDataDB.model$Sample_ProductMainImageRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var Sample_ProductMainImageRec = (function (_super) {
__extends(Sample_ProductMainImageRec, _super);
function Sample_ProductMainImageRec(defaults) {
_super.apply(this, arguments);
}
Sample_ProductMainImageRec.attributesToDeclare = function () {
return [
this.attr("ProductId", "productIdAttr", "ProductId", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Filename", "filenameAttr", "Filename", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Filetype", "filetypeAttr", "Filetype", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("File", "fileAttr", "File", false, false, OS.Types.BinaryData, function () {
return OS.DataTypes.BinaryData.defaultValue;
}, true), 
this.attr("CreatedOn", "createdOnAttr", "CreatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Sample_ProductMainImageRec.init();
return Sample_ProductMainImageRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.Sample_ProductMainImageRec = Sample_ProductMainImageRec;

});
define("OutSystemsSampleDataDB.model$Sample_OfficeReviewsRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var Sample_OfficeReviewsRec = (function (_super) {
__extends(Sample_OfficeReviewsRec, _super);
function Sample_OfficeReviewsRec(defaults) {
_super.apply(this, arguments);
}
Sample_OfficeReviewsRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("OfficeId", "officeIdAttr", "OfficeId", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("ReviewId", "reviewIdAttr", "ReviewId", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Sample_OfficeReviewsRec.init();
return Sample_OfficeReviewsRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.Sample_OfficeReviewsRec = Sample_OfficeReviewsRec;

});
define("OutSystemsSampleDataDB.model$Sample_ProductSalesRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var Sample_ProductSalesRec = (function (_super) {
__extends(Sample_ProductSalesRec, _super);
function Sample_ProductSalesRec(defaults) {
_super.apply(this, arguments);
}
Sample_ProductSalesRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Date", "dateAttr", "Date", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("Cost", "costAttr", "Cost", false, false, OS.Types.Currency, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("Quantity", "quantityAttr", "Quantity", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Product", "productAttr", "Product", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Sample_ProductSalesRec.init();
return Sample_ProductSalesRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.Sample_ProductSalesRec = Sample_ProductSalesRec;

});
define("OutSystemsSampleDataDB.model$Sample_BudgetRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var Sample_BudgetRec = (function (_super) {
__extends(Sample_BudgetRec, _super);
function Sample_BudgetRec(defaults) {
_super.apply(this, arguments);
}
Sample_BudgetRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Budget", "budgetAttr", "Budget", false, false, OS.Types.Currency, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("CurrentAmount", "currentAmountAttr", "CurrentAmount", false, false, OS.Types.Currency, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("Account", "accountAttr", "Account", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Type", "typeAttr", "Type", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Sample_BudgetRec.init();
return Sample_BudgetRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.Sample_BudgetRec = Sample_BudgetRec;

});
define("OutSystemsSampleDataDB.model$DEPRECATED_Sample_ProductRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var DEPRECATED_Sample_ProductRec = (function (_super) {
__extends(DEPRECATED_Sample_ProductRec, _super);
function DEPRECATED_Sample_ProductRec(defaults) {
_super.apply(this, arguments);
}
DEPRECATED_Sample_ProductRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Name", "nameAttr", "Name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Description", "descriptionAttr", "Description", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Image", "imageAttr", "Image", false, false, OS.Types.BinaryData, function () {
return OS.DataTypes.BinaryData.defaultValue;
}, true), 
this.attr("Filename", "filenameAttr", "Filename", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Price", "priceAttr", "Price", false, false, OS.Types.Currency, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("Stock", "stockAttr", "Stock", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("MaxStock", "maxStockAttr", "MaxStock", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("StockThreshold", "stockThresholdAttr", "StockThreshold", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("Category", "categoryAttr", "Category", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("CreatedOn", "createdOnAttr", "CreatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("IsFavourite", "isFavouriteAttr", "IsFavourite", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("Rating", "ratingAttr", "Rating", false, false, OS.Types.Decimal, function () {
return OS.BuiltinFunctions.integerToDecimal(0);
}, true), 
this.attr("Likes", "likesAttr", "Likes", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Reference", "referenceAttr", "Reference", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EAN", "eANAttr", "EAN", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Brand", "brandAttr", "Brand", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Model", "modelAttr", "Model", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Weight", "weightAttr", "Weight", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Dimensions", "dimensionsAttr", "Dimensions", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DEPRECATED_Sample_ProductRec.init();
return DEPRECATED_Sample_ProductRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.DEPRECATED_Sample_ProductRec = DEPRECATED_Sample_ProductRec;

});
define("OutSystemsSampleDataDB.model$Sample_RequestStatusRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var Sample_RequestStatusRec = (function (_super) {
__extends(Sample_RequestStatusRec, _super);
function Sample_RequestStatusRec(defaults) {
_super.apply(this, arguments);
}
Sample_RequestStatusRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Sample_RequestStatusRec.init();
return Sample_RequestStatusRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.Sample_RequestStatusRec = Sample_RequestStatusRec;

});
define("OutSystemsSampleDataDB.model$Sample_SizeRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var Sample_SizeRec = (function (_super) {
__extends(Sample_SizeRec, _super);
function Sample_SizeRec(defaults) {
_super.apply(this, arguments);
}
Sample_SizeRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Sample_SizeRec.init();
return Sample_SizeRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.Sample_SizeRec = Sample_SizeRec;

});
define("OutSystemsSampleDataDB.model$DEPRECATED_Sample_ProductImageRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var DEPRECATED_Sample_ProductImageRec = (function (_super) {
__extends(DEPRECATED_Sample_ProductImageRec, _super);
function DEPRECATED_Sample_ProductImageRec(defaults) {
_super.apply(this, arguments);
}
DEPRECATED_Sample_ProductImageRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("ProductId", "productIdAttr", "ProductId", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Filename", "filenameAttr", "Filename", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Filetype", "filetypeAttr", "Filetype", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("File", "fileAttr", "File", false, false, OS.Types.BinaryData, function () {
return OS.DataTypes.BinaryData.defaultValue;
}, true), 
this.attr("CreatedOn", "createdOnAttr", "CreatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DEPRECATED_Sample_ProductImageRec.init();
return DEPRECATED_Sample_ProductImageRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.DEPRECATED_Sample_ProductImageRec = DEPRECATED_Sample_ProductImageRec;

});
define("OutSystemsSampleDataDB.model$Sample_ProductImageRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var Sample_ProductImageRec = (function (_super) {
__extends(Sample_ProductImageRec, _super);
function Sample_ProductImageRec(defaults) {
_super.apply(this, arguments);
}
Sample_ProductImageRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("ProductId", "productIdAttr", "ProductId", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Filename", "filenameAttr", "Filename", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Filetype", "filetypeAttr", "Filetype", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("File", "fileAttr", "File", false, false, OS.Types.BinaryData, function () {
return OS.DataTypes.BinaryData.defaultValue;
}, true), 
this.attr("CreatedOn", "createdOnAttr", "CreatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("IsCoverImage", "isCoverImageAttr", "IsCoverImage", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Sample_ProductImageRec.init();
return Sample_ProductImageRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.Sample_ProductImageRec = Sample_ProductImageRec;

});
define("OutSystemsSampleDataDB.model$Sample_RequestRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var Sample_RequestRec = (function (_super) {
__extends(Sample_RequestRec, _super);
function Sample_RequestRec(defaults) {
_super.apply(this, arguments);
}
Sample_RequestRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("RequestName", "requestNameAttr", "RequestName", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Description", "descriptionAttr", "Description", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DueDate", "dueDateAttr", "DueDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("CreatedOn", "createdOnAttr", "CreatedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("CompletedOn", "completedOnAttr", "CompletedOn", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("Priority", "priorityAttr", "Priority", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("AssignedTo", "assignedToAttr", "AssignedTo", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("ReviewedBy", "reviewedByAttr", "ReviewedBy", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Status", "statusAttr", "Status", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("RequestedBy", "requestedByAttr", "RequestedBy", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Sample_RequestRec.init();
return Sample_RequestRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.Sample_RequestRec = Sample_RequestRec;

});
define("OutSystemsSampleDataDB.model$Sample_DeliveryTypeRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var Sample_DeliveryTypeRec = (function (_super) {
__extends(Sample_DeliveryTypeRec, _super);
function Sample_DeliveryTypeRec(defaults) {
_super.apply(this, arguments);
}
Sample_DeliveryTypeRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Sample_DeliveryTypeRec.init();
return Sample_DeliveryTypeRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.Sample_DeliveryTypeRec = Sample_DeliveryTypeRec;

});
define("OutSystemsSampleDataDB.model$Sample_OfficePicturesRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var Sample_OfficePicturesRec = (function (_super) {
__extends(Sample_OfficePicturesRec, _super);
function Sample_OfficePicturesRec(defaults) {
_super.apply(this, arguments);
}
Sample_OfficePicturesRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("OfficeId", "officeIdAttr", "OfficeId", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Filename", "filenameAttr", "Filename", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Filetype", "filetypeAttr", "Filetype", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("File", "fileAttr", "File", false, false, OS.Types.BinaryData, function () {
return OS.DataTypes.BinaryData.defaultValue;
}, true), 
this.attr("CreatedOn", "createdOnAttr", "CreatedOn", false, false, OS.Types.DateTime, function () {
return OS.BuiltinFunctions.currDateTime();
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Sample_OfficePicturesRec.init();
return Sample_OfficePicturesRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.Sample_OfficePicturesRec = Sample_OfficePicturesRec;

});
define("OutSystemsSampleDataDB.model$DEPRECATED_Sample_ProductInventoryRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var DEPRECATED_Sample_ProductInventoryRec = (function (_super) {
__extends(DEPRECATED_Sample_ProductInventoryRec, _super);
function DEPRECATED_Sample_ProductInventoryRec(defaults) {
_super.apply(this, arguments);
}
DEPRECATED_Sample_ProductInventoryRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Inventory", "inventoryAttr", "Inventory", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("Date", "dateAttr", "Date", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("Product", "productAttr", "Product", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("WarehouseLocation", "warehouseLocationAttr", "WarehouseLocation", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DEPRECATED_Sample_ProductInventoryRec.init();
return DEPRECATED_Sample_ProductInventoryRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.DEPRECATED_Sample_ProductInventoryRec = DEPRECATED_Sample_ProductInventoryRec;

});
define("OutSystemsSampleDataDB.model$Sample_ProductInventoryRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var Sample_ProductInventoryRec = (function (_super) {
__extends(Sample_ProductInventoryRec, _super);
function Sample_ProductInventoryRec(defaults) {
_super.apply(this, arguments);
}
Sample_ProductInventoryRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Inventory", "inventoryAttr", "Inventory", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("Date", "dateAttr", "Date", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("Product", "productAttr", "Product", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("WarehouseLocation", "warehouseLocationAttr", "WarehouseLocation", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Sample_ProductInventoryRec.init();
return Sample_ProductInventoryRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.Sample_ProductInventoryRec = Sample_ProductInventoryRec;

});
define("OutSystemsSampleDataDB.model$Sample_EmployeeRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var Sample_EmployeeRec = (function (_super) {
__extends(Sample_EmployeeRec, _super);
function Sample_EmployeeRec(defaults) {
_super.apply(this, arguments);
}
Sample_EmployeeRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("FirstName", "firstNameAttr", "FirstName", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("LastName", "lastNameAttr", "LastName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("BirthDate", "birthDateAttr", "BirthDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("Email", "emailAttr", "Email", false, false, OS.Types.Email, function () {
return "";
}, true), 
this.attr("Phone", "phoneAttr", "Phone", false, false, OS.Types.PhoneNumber, function () {
return "";
}, true), 
this.attr("Bio", "bioAttr", "Bio", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("HiringDate", "hiringDateAttr", "HiringDate", false, false, OS.Types.Date, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("Office", "officeAttr", "Office", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Picture", "pictureAttr", "Picture", false, false, OS.Types.BinaryData, function () {
return OS.DataTypes.BinaryData.defaultValue;
}, true), 
this.attr("Filename", "filenameAttr", "Filename", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("JobPosition", "jobPositionAttr", "JobPosition", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Department", "departmentAttr", "Department", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Manager", "managerAttr", "Manager", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Address", "addressAttr", "Address", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("City", "cityAttr", "City", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ZipCode", "zipCodeAttr", "ZipCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsActive", "isActiveAttr", "IsActive", false, false, OS.Types.Boolean, function () {
return true;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Sample_EmployeeRec.init();
return Sample_EmployeeRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.Sample_EmployeeRec = Sample_EmployeeRec;

});
define("OutSystemsSampleDataDB.model$Sample_ProductCategoryRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var Sample_ProductCategoryRec = (function (_super) {
__extends(Sample_ProductCategoryRec, _super);
function Sample_ProductCategoryRec(defaults) {
_super.apply(this, arguments);
}
Sample_ProductCategoryRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("IsActive", "isActiveAttr", "IsActive", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("ProductType", "productTypeAttr", "ProductType", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Sample_ProductCategoryRec.init();
return Sample_ProductCategoryRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.Sample_ProductCategoryRec = Sample_ProductCategoryRec;

});
define("OutSystemsSampleDataDB.model$DEPRECATED_Sample_WarehouseLocationRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var DEPRECATED_Sample_WarehouseLocationRec = (function (_super) {
__extends(DEPRECATED_Sample_WarehouseLocationRec, _super);
function DEPRECATED_Sample_WarehouseLocationRec(defaults) {
_super.apply(this, arguments);
}
DEPRECATED_Sample_WarehouseLocationRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Name", "nameAttr", "Name", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Location", "locationAttr", "Location", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DEPRECATED_Sample_WarehouseLocationRec.init();
return DEPRECATED_Sample_WarehouseLocationRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.DEPRECATED_Sample_WarehouseLocationRec = DEPRECATED_Sample_WarehouseLocationRec;

});
define("OutSystemsSampleDataDB.model$Sample_RequestFileRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsSampleDataDB.model"], function (exports, OutSystems, OutSystemsSampleDataDBModel) {
var OS = OutSystems.Internal;
var Sample_RequestFileRec = (function (_super) {
__extends(Sample_RequestFileRec, _super);
function Sample_RequestFileRec(defaults) {
_super.apply(this, arguments);
}
Sample_RequestFileRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Sample_RequestId", "sample_RequestIdAttr", "Sample_RequestId", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("File", "fileAttr", "File", false, false, OS.Types.BinaryData, function () {
return OS.DataTypes.BinaryData.defaultValue;
}, true), 
this.attr("Filename", "filenameAttr", "Filename", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Filetype", "filetypeAttr", "Filetype", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Sample_RequestFileRec.init();
return Sample_RequestFileRec;
})(OS.DataTypes.GenericRecord);
OutSystemsSampleDataDBModel.Sample_RequestFileRec = Sample_RequestFileRec;

});
define("OutSystemsSampleDataDB.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var OutSystemsSampleDataDBModel = exports;
});
