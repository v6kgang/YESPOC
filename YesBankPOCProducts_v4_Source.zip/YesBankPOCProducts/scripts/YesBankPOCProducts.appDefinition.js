﻿define("YesBankPOCProducts.appDefinition",["OutSystems/ClientRuntime/Main"], function(OutSystems) {
	var OS = OutSystems.Internal;
	return {
		environmentKey: "b580868a-b86d-467d-b601-f21000d92a52",
		environmentName: "Development",
		applicationKey: "307164f3-bd2d-4dc5-9d7d-979c79bb4d1b",
		applicationName: "YesBankPOC-Products",
		userProviderName: "Users",
		debugEnabled: false,
		homeModuleName: "YesBankPOCProducts",
		homeModuleKey: "3475d833-1c2f-4a08-927c-fe376ba3e08d",
		homeModuleControllerName: "YesBankPOCProducts.controller",
		homeModuleLanguageResourcesName: "YesBankPOCProducts.languageResources",
		defaultTransition: "Fade",
		errorPageConfig: {
			showExceptionStack: false
		}
		,
		isWeb: true,
		personalArea: null,
		showWatermark: false
	};
});
