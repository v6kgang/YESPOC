﻿try {
	require(["es6-promise", "tslib"], function(es6promise, tslib) {
		require(["OutSystems/ClientRuntime/Main", "YesBankPOCProducts.appDefinition"], function(OutSystems, YesBankPOCProductsAppDefinition) {
			var OS = OutSystems.Internal;
			OS.Settings.setPlatformSettings( {
				IndexedDBOffline: false,
				UseNewWebSQLImpl: false
			}
			);
			OS.ErrorScreen.initializeErrorPage(YesBankPOCProductsAppDefinition, OS.Application);
		}
		);
	}
	);
} catch (ex) {
	console.error(e);
}

