﻿define("OutSystemsCharts.model$legendItemRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var legendItemRec = (function (_super) {
__extends(legendItemRec, _super);
function legendItemRec(defaults) {
_super.apply(this, arguments);
}
legendItemRec.attributesToDeclare = function () {
return [
this.attr("align", "alignAttr", "align", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("verticalAlign", "verticalAlignAttr", "verticalAlign", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("layout", "layoutAttr", "layout", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("enabled", "enabledAttr", "enabled", true, false, OS.Types.Boolean, function () {
return true;
}, true), 
this.attr("floating", "floatingAttr", "floating", true, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("itemMarginBottom", "itemMarginBottomAttr", "itemMarginBottom", true, false, OS.Types.Integer, function () {
return 10;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
legendItemRec.init();
return legendItemRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.legendItemRec = legendItemRec;

});
define("OutSystemsCharts.model$legendItemList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$legendItemRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var legendItemList = (function (_super) {
__extends(legendItemList, _super);
function legendItemList(defaults) {
_super.apply(this, arguments);
}
legendItemList.itemType = OutSystemsChartsModel.legendItemRec;
return legendItemList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.legendItemList = legendItemList;

});
define("OutSystemsCharts.model$DataItemRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var DataItemRec = (function (_super) {
__extends(DataItemRec, _super);
function DataItemRec(defaults) {
_super.apply(this, arguments);
}
DataItemRec.attributesToDeclare = function () {
return [
this.attr("name", "nameAttr", "name", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("y", "yAttr", "y", true, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("sliced", "slicedAttr", "sliced", true, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("selected", "selectedAttr", "selected", true, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("custom", "customAttr", "custom", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("color", "colorAttr", "color", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DataItemRec.init();
return DataItemRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.DataItemRec = DataItemRec;

});
define("OutSystemsCharts.model$labelsRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var labelsRec = (function (_super) {
__extends(labelsRec, _super);
function labelsRec(defaults) {
_super.apply(this, arguments);
}
labelsRec.attributesToDeclare = function () {
return [
this.attr("rotation", "rotationAttr", "rotation", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
labelsRec.fromStructure = function (str) {
return new labelsRec(new labelsRec.RecordClass({
rotationAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
labelsRec.init();
return labelsRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.labelsRec = labelsRec;

});
define("OutSystemsCharts.model$tooltipRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var tooltipRec = (function (_super) {
__extends(tooltipRec, _super);
function tooltipRec(defaults) {
_super.apply(this, arguments);
}
tooltipRec.attributesToDeclare = function () {
return [
this.attr("pointFormat", "pointFormatAttr", "pointFormat", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
tooltipRec.fromStructure = function (str) {
return new tooltipRec(new tooltipRec.RecordClass({
pointFormatAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
tooltipRec.init();
return tooltipRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.tooltipRec = tooltipRec;

});
define("OutSystemsCharts.model$tooltipRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$tooltipRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var tooltipRecord = (function (_super) {
__extends(tooltipRecord, _super);
function tooltipRecord(defaults) {
_super.apply(this, arguments);
}
tooltipRecord.attributesToDeclare = function () {
return [
this.attr("tooltip", "tooltipAttr", "tooltip", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.tooltipRec());
}, true, OutSystemsChartsModel.tooltipRec)
].concat(_super.attributesToDeclare.call(this));
};
tooltipRecord.fromStructure = function (str) {
return new tooltipRecord(new tooltipRecord.RecordClass({
tooltipAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
tooltipRecord._isAnonymousRecord = true;
tooltipRecord.UniqueId = "071b16af-4c8a-c3a9-f6a0-9e8df7617baa";
tooltipRecord.init();
return tooltipRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.tooltipRecord = tooltipRecord;

});
define("OutSystemsCharts.model$titleRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var titleRec = (function (_super) {
__extends(titleRec, _super);
function titleRec(defaults) {
_super.apply(this, arguments);
}
titleRec.attributesToDeclare = function () {
return [
this.attr("text", "textAttr", "text", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
titleRec.fromStructure = function (str) {
return new titleRec(new titleRec.RecordClass({
textAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
titleRec.init();
return titleRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.titleRec = titleRec;

});
define("OutSystemsCharts.model$stackLabelsRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var stackLabelsRec = (function (_super) {
__extends(stackLabelsRec, _super);
function stackLabelsRec(defaults) {
_super.apply(this, arguments);
}
stackLabelsRec.attributesToDeclare = function () {
return [
this.attr("enabled", "enabledAttr", "enabled", true, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
stackLabelsRec.fromStructure = function (str) {
return new stackLabelsRec(new stackLabelsRec.RecordClass({
enabledAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
stackLabelsRec.init();
return stackLabelsRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.stackLabelsRec = stackLabelsRec;

});
define("OutSystemsCharts.model$yAxisRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$titleRec", "OutSystemsCharts.model$stackLabelsRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var yAxisRec = (function (_super) {
__extends(yAxisRec, _super);
function yAxisRec(defaults) {
_super.apply(this, arguments);
}
yAxisRec.attributesToDeclare = function () {
return [
this.attr("title", "titleAttr", "title", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.titleRec());
}, true, OutSystemsChartsModel.titleRec), 
this.attr("reversedStacks", "reversedStacksAttr", "reversedStacks", true, false, OS.Types.Boolean, function () {
return true;
}, true), 
this.attr("stackLabels", "stackLabelsAttr", "stackLabels", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.stackLabelsRec());
}, true, OutSystemsChartsModel.stackLabelsRec), 
this.attr("tickInterval", "tickIntervalAttr", "tickInterval", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("max", "maxAttr", "max", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("min", "minAttr", "min", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
yAxisRec.init();
return yAxisRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.yAxisRec = yAxisRec;

});
define("OutSystemsCharts.model$YAxesRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var YAxesRec = (function (_super) {
__extends(YAxesRec, _super);
function YAxesRec(defaults) {
_super.apply(this, arguments);
}
YAxesRec.attributesToDeclare = function () {
return [
this.attr("GridLineStep", "gridLineStepAttr", "GridLineStep", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("MaxValue", "maxValueAttr", "MaxValue", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("MinValue", "minValueAttr", "MinValue", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("Title", "titleAttr", "Title", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
YAxesRec.init();
return YAxesRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.YAxesRec = YAxesRec;

});
define("OutSystemsCharts.model$YAxesRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$YAxesRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var YAxesRecord = (function (_super) {
__extends(YAxesRecord, _super);
function YAxesRecord(defaults) {
_super.apply(this, arguments);
}
YAxesRecord.attributesToDeclare = function () {
return [
this.attr("YAxes", "yAxesAttr", "YAxes", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.YAxesRec());
}, true, OutSystemsChartsModel.YAxesRec)
].concat(_super.attributesToDeclare.call(this));
};
YAxesRecord.fromStructure = function (str) {
return new YAxesRecord(new YAxesRecord.RecordClass({
yAxesAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
YAxesRecord._isAnonymousRecord = true;
YAxesRecord.UniqueId = "09730fbc-2998-92e9-f9e4-270a5cb22999";
YAxesRecord.init();
return YAxesRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.YAxesRecord = YAxesRecord;

});
define("OutSystemsCharts.model$StackingTypeRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var StackingTypeRec = (function (_super) {
__extends(StackingTypeRec, _super);
function StackingTypeRec(defaults) {
_super.apply(this, arguments);
}
StackingTypeRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
StackingTypeRec.init();
return StackingTypeRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.StackingTypeRec = StackingTypeRec;

});
define("OutSystemsCharts.model$eventsRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var eventsRec = (function (_super) {
__extends(eventsRec, _super);
function eventsRec(defaults) {
_super.apply(this, arguments);
}
eventsRec.attributesToDeclare = function () {
return [
this.attr("click", "clickAttr", "click", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
eventsRec.fromStructure = function (str) {
return new eventsRec(new eventsRec.RecordClass({
clickAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
eventsRec.init();
return eventsRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.eventsRec = eventsRec;

});
define("OutSystemsCharts.model$PointItemRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$eventsRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var PointItemRec = (function (_super) {
__extends(PointItemRec, _super);
function PointItemRec(defaults) {
_super.apply(this, arguments);
}
PointItemRec.attributesToDeclare = function () {
return [
this.attr("events", "eventsAttr", "events", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.eventsRec());
}, true, OutSystemsChartsModel.eventsRec)
].concat(_super.attributesToDeclare.call(this));
};
PointItemRec.fromStructure = function (str) {
return new PointItemRec(new PointItemRec.RecordClass({
eventsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PointItemRec.init();
return PointItemRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.PointItemRec = PointItemRec;

});
define("OutSystemsCharts.model$PointItemRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$PointItemRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var PointItemRecord = (function (_super) {
__extends(PointItemRecord, _super);
function PointItemRecord(defaults) {
_super.apply(this, arguments);
}
PointItemRecord.attributesToDeclare = function () {
return [
this.attr("PointItem", "pointItemAttr", "PointItem", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.PointItemRec());
}, true, OutSystemsChartsModel.PointItemRec)
].concat(_super.attributesToDeclare.call(this));
};
PointItemRecord.fromStructure = function (str) {
return new PointItemRecord(new PointItemRecord.RecordClass({
pointItemAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PointItemRecord._isAnonymousRecord = true;
PointItemRecord.UniqueId = "d99b9c3e-4df1-c1c5-4c6a-61acf9f3daee";
PointItemRecord.init();
return PointItemRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.PointItemRecord = PointItemRecord;

});
define("OutSystemsCharts.model$PointItemRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$PointItemRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var PointItemRecordList = (function (_super) {
__extends(PointItemRecordList, _super);
function PointItemRecordList(defaults) {
_super.apply(this, arguments);
}
PointItemRecordList.itemType = OutSystemsChartsModel.PointItemRecord;
return PointItemRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.PointItemRecordList = PointItemRecordList;

});
define("OutSystemsCharts.model$DataLabelRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var DataLabelRec = (function (_super) {
__extends(DataLabelRec, _super);
function DataLabelRec(defaults) {
_super.apply(this, arguments);
}
DataLabelRec.attributesToDeclare = function () {
return [
this.attr("enabled", "enabledAttr", "enabled", true, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("format", "formatAttr", "format", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DataLabelRec.init();
return DataLabelRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.DataLabelRec = DataLabelRec;

});
define("OutSystemsCharts.model$pieRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$DataLabelRec", "OutSystemsCharts.model$PointItemRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var pieRec = (function (_super) {
__extends(pieRec, _super);
function pieRec(defaults) {
_super.apply(this, arguments);
}
pieRec.attributesToDeclare = function () {
return [
this.attr("allowPointSelect", "allowPointSelectAttr", "allowPointSelect", true, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("cursor", "cursorAttr", "cursor", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("dataLabels", "dataLabelsAttr", "dataLabels", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.DataLabelRec());
}, true, OutSystemsChartsModel.DataLabelRec), 
this.attr("point", "pointAttr", "point", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.PointItemRec());
}, true, OutSystemsChartsModel.PointItemRec), 
this.attr("animation", "animationAttr", "animation", true, false, OS.Types.Boolean, function () {
return true;
}, true), 
this.attr("showInLegend", "showInLegendAttr", "showInLegend", true, false, OS.Types.Boolean, function () {
return true;
}, true), 
this.attr("borderColor", "borderColorAttr", "borderColor", true, false, OS.Types.Text, function () {
return "rgba(255,255,255,0)";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
pieRec.init();
return pieRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.pieRec = pieRec;

});
define("OutSystemsCharts.model$PlotOptionSerieItemRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$PointItemRec", "OutSystemsCharts.model$DataLabelRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var PlotOptionSerieItemRec = (function (_super) {
__extends(PlotOptionSerieItemRec, _super);
function PlotOptionSerieItemRec(defaults) {
_super.apply(this, arguments);
}
PlotOptionSerieItemRec.attributesToDeclare = function () {
return [
this.attr("cursor", "cursorAttr", "cursor", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("point", "pointAttr", "point", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.PointItemRec());
}, true, OutSystemsChartsModel.PointItemRec), 
this.attr("dataLabels", "dataLabelsAttr", "dataLabels", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.DataLabelRec());
}, true, OutSystemsChartsModel.DataLabelRec), 
this.attr("stacking", "stackingAttr", "stacking", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("innerSize", "innerSizeAttr", "innerSize", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("borderRadius", "borderRadiusAttr", "borderRadius", true, false, OS.Types.Integer, function () {
return 1;
}, true), 
this.attr("borderWidth", "borderWidthAttr", "borderWidth", true, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PlotOptionSerieItemRec.init();
return PlotOptionSerieItemRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.PlotOptionSerieItemRec = PlotOptionSerieItemRec;

});
define("OutSystemsCharts.model$markerRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var markerRec = (function (_super) {
__extends(markerRec, _super);
function markerRec(defaults) {
_super.apply(this, arguments);
}
markerRec.attributesToDeclare = function () {
return [
this.attr("enabled", "enabledAttr", "enabled", true, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
markerRec.fromStructure = function (str) {
return new markerRec(new markerRec.RecordClass({
enabledAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
markerRec.init();
return markerRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.markerRec = markerRec;

});
define("OutSystemsCharts.model$lineRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$DataLabelRec", "OutSystemsCharts.model$PointItemRec", "OutSystemsCharts.model$markerRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var lineRec = (function (_super) {
__extends(lineRec, _super);
function lineRec(defaults) {
_super.apply(this, arguments);
}
lineRec.attributesToDeclare = function () {
return [
this.attr("allowPointSelect", "allowPointSelectAttr", "allowPointSelect", true, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("cursor", "cursorAttr", "cursor", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("dataLabels", "dataLabelsAttr", "dataLabels", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.DataLabelRec());
}, true, OutSystemsChartsModel.DataLabelRec), 
this.attr("point", "pointAttr", "point", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.PointItemRec());
}, true, OutSystemsChartsModel.PointItemRec), 
this.attr("marker", "markerAttr", "marker", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.markerRec());
}, true, OutSystemsChartsModel.markerRec), 
this.attr("animation", "animationAttr", "animation", true, false, OS.Types.Boolean, function () {
return true;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
lineRec.init();
return lineRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.lineRec = lineRec;

});
define("OutSystemsCharts.model$columnRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$DataLabelRec", "OutSystemsCharts.model$PointItemRec", "OutSystemsCharts.model$markerRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var columnRec = (function (_super) {
__extends(columnRec, _super);
function columnRec(defaults) {
_super.apply(this, arguments);
}
columnRec.attributesToDeclare = function () {
return [
this.attr("allowPointSelect", "allowPointSelectAttr", "allowPointSelect", true, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("cursor", "cursorAttr", "cursor", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("dataLabels", "dataLabelsAttr", "dataLabels", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.DataLabelRec());
}, true, OutSystemsChartsModel.DataLabelRec), 
this.attr("point", "pointAttr", "point", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.PointItemRec());
}, true, OutSystemsChartsModel.PointItemRec), 
this.attr("marker", "markerAttr", "marker", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.markerRec());
}, true, OutSystemsChartsModel.markerRec), 
this.attr("animation", "animationAttr", "animation", true, false, OS.Types.Boolean, function () {
return true;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
columnRec.init();
return columnRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.columnRec = columnRec;

});
define("OutSystemsCharts.model$areaRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$DataLabelRec", "OutSystemsCharts.model$PointItemRec", "OutSystemsCharts.model$markerRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var areaRec = (function (_super) {
__extends(areaRec, _super);
function areaRec(defaults) {
_super.apply(this, arguments);
}
areaRec.attributesToDeclare = function () {
return [
this.attr("allowPointSelect", "allowPointSelectAttr", "allowPointSelect", true, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("cursor", "cursorAttr", "cursor", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("dataLabels", "dataLabelsAttr", "dataLabels", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.DataLabelRec());
}, true, OutSystemsChartsModel.DataLabelRec), 
this.attr("point", "pointAttr", "point", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.PointItemRec());
}, true, OutSystemsChartsModel.PointItemRec), 
this.attr("marker", "markerAttr", "marker", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.markerRec());
}, true, OutSystemsChartsModel.markerRec)
].concat(_super.attributesToDeclare.call(this));
};
areaRec.init();
return areaRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.areaRec = areaRec;

});
define("OutSystemsCharts.model$barRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$DataLabelRec", "OutSystemsCharts.model$PointItemRec", "OutSystemsCharts.model$markerRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var barRec = (function (_super) {
__extends(barRec, _super);
function barRec(defaults) {
_super.apply(this, arguments);
}
barRec.attributesToDeclare = function () {
return [
this.attr("allowPointSelect", "allowPointSelectAttr", "allowPointSelect", true, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("cursor", "cursorAttr", "cursor", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("dataLabels", "dataLabelsAttr", "dataLabels", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.DataLabelRec());
}, true, OutSystemsChartsModel.DataLabelRec), 
this.attr("point", "pointAttr", "point", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.PointItemRec());
}, true, OutSystemsChartsModel.PointItemRec), 
this.attr("marker", "markerAttr", "marker", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.markerRec());
}, true, OutSystemsChartsModel.markerRec)
].concat(_super.attributesToDeclare.call(this));
};
barRec.init();
return barRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.barRec = barRec;

});
define("OutSystemsCharts.model$plotOptionRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$pieRec", "OutSystemsCharts.model$PlotOptionSerieItemRec", "OutSystemsCharts.model$lineRec", "OutSystemsCharts.model$columnRec", "OutSystemsCharts.model$areaRec", "OutSystemsCharts.model$barRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var plotOptionRec = (function (_super) {
__extends(plotOptionRec, _super);
function plotOptionRec(defaults) {
_super.apply(this, arguments);
}
plotOptionRec.attributesToDeclare = function () {
return [
this.attr("pie", "pieAttr", "pie", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.pieRec());
}, true, OutSystemsChartsModel.pieRec), 
this.attr("series", "seriesAttr", "series", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.PlotOptionSerieItemRec());
}, true, OutSystemsChartsModel.PlotOptionSerieItemRec), 
this.attr("line", "lineAttr", "line", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.lineRec());
}, true, OutSystemsChartsModel.lineRec), 
this.attr("column", "columnAttr", "column", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.columnRec());
}, true, OutSystemsChartsModel.columnRec), 
this.attr("area", "areaAttr", "area", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.areaRec());
}, true, OutSystemsChartsModel.areaRec), 
this.attr("bar", "barAttr", "bar", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.barRec());
}, true, OutSystemsChartsModel.barRec)
].concat(_super.attributesToDeclare.call(this));
};
plotOptionRec.init();
return plotOptionRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.plotOptionRec = plotOptionRec;

});
define("OutSystemsCharts.model$plotOptionRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$plotOptionRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var plotOptionRecord = (function (_super) {
__extends(plotOptionRecord, _super);
function plotOptionRecord(defaults) {
_super.apply(this, arguments);
}
plotOptionRecord.attributesToDeclare = function () {
return [
this.attr("plotOption", "plotOptionAttr", "plotOption", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.plotOptionRec());
}, true, OutSystemsChartsModel.plotOptionRec)
].concat(_super.attributesToDeclare.call(this));
};
plotOptionRecord.fromStructure = function (str) {
return new plotOptionRecord(new plotOptionRecord.RecordClass({
plotOptionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
plotOptionRecord._isAnonymousRecord = true;
plotOptionRecord.UniqueId = "98bc8991-c03c-3dcd-adc4-fc428bc5ef67";
plotOptionRecord.init();
return plotOptionRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.plotOptionRecord = plotOptionRecord;

});
define("OutSystemsCharts.model$plotOptionRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$plotOptionRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var plotOptionRecordList = (function (_super) {
__extends(plotOptionRecordList, _super);
function plotOptionRecordList(defaults) {
_super.apply(this, arguments);
}
plotOptionRecordList.itemType = OutSystemsChartsModel.plotOptionRecord;
return plotOptionRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.plotOptionRecordList = plotOptionRecordList;

});
define("OutSystemsCharts.model$PlotOptionSerieItemRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$PlotOptionSerieItemRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var PlotOptionSerieItemRecord = (function (_super) {
__extends(PlotOptionSerieItemRecord, _super);
function PlotOptionSerieItemRecord(defaults) {
_super.apply(this, arguments);
}
PlotOptionSerieItemRecord.attributesToDeclare = function () {
return [
this.attr("PlotOptionSerieItem", "plotOptionSerieItemAttr", "PlotOptionSerieItem", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.PlotOptionSerieItemRec());
}, true, OutSystemsChartsModel.PlotOptionSerieItemRec)
].concat(_super.attributesToDeclare.call(this));
};
PlotOptionSerieItemRecord.fromStructure = function (str) {
return new PlotOptionSerieItemRecord(new PlotOptionSerieItemRecord.RecordClass({
plotOptionSerieItemAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PlotOptionSerieItemRecord._isAnonymousRecord = true;
PlotOptionSerieItemRecord.UniqueId = "21fe1dc5-36b3-f293-718b-adca0d7b68b7";
PlotOptionSerieItemRecord.init();
return PlotOptionSerieItemRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.PlotOptionSerieItemRecord = PlotOptionSerieItemRecord;

});
define("OutSystemsCharts.model$PlotOptionSerieItemRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$PlotOptionSerieItemRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var PlotOptionSerieItemRecordList = (function (_super) {
__extends(PlotOptionSerieItemRecordList, _super);
function PlotOptionSerieItemRecordList(defaults) {
_super.apply(this, arguments);
}
PlotOptionSerieItemRecordList.itemType = OutSystemsChartsModel.PlotOptionSerieItemRecord;
return PlotOptionSerieItemRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.PlotOptionSerieItemRecordList = PlotOptionSerieItemRecordList;

});
define("OutSystemsCharts.model$SSDataSeriesFormatItemRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var SSDataSeriesFormatItemRec = (function (_super) {
__extends(SSDataSeriesFormatItemRec, _super);
function SSDataSeriesFormatItemRec(defaults) {
_super.apply(this, arguments);
}
SSDataSeriesFormatItemRec.attributesToDeclare = function () {
return [
this.attr("DataSeriesName", "dataSeriesNameAttr", "DataSeriesName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DataSeriesJSON", "dataSeriesJSONAttr", "DataSeriesJSON", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SSDataSeriesFormatItemRec.init();
return SSDataSeriesFormatItemRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.SSDataSeriesFormatItemRec = SSDataSeriesFormatItemRec;

});
define("OutSystemsCharts.model$SSDataSeriesFormatItemRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$SSDataSeriesFormatItemRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var SSDataSeriesFormatItemRecord = (function (_super) {
__extends(SSDataSeriesFormatItemRecord, _super);
function SSDataSeriesFormatItemRecord(defaults) {
_super.apply(this, arguments);
}
SSDataSeriesFormatItemRecord.attributesToDeclare = function () {
return [
this.attr("SSDataSeriesFormatItem", "sSDataSeriesFormatItemAttr", "SSDataSeriesFormatItem", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.SSDataSeriesFormatItemRec());
}, true, OutSystemsChartsModel.SSDataSeriesFormatItemRec)
].concat(_super.attributesToDeclare.call(this));
};
SSDataSeriesFormatItemRecord.fromStructure = function (str) {
return new SSDataSeriesFormatItemRecord(new SSDataSeriesFormatItemRecord.RecordClass({
sSDataSeriesFormatItemAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SSDataSeriesFormatItemRecord._isAnonymousRecord = true;
SSDataSeriesFormatItemRecord.UniqueId = "14a6ded5-bd51-5063-f85c-e037259b4016";
SSDataSeriesFormatItemRecord.init();
return SSDataSeriesFormatItemRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.SSDataSeriesFormatItemRecord = SSDataSeriesFormatItemRecord;

});
define("OutSystemsCharts.model$SSDataSeriesFormatItemList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$SSDataSeriesFormatItemRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var SSDataSeriesFormatItemList = (function (_super) {
__extends(SSDataSeriesFormatItemList, _super);
function SSDataSeriesFormatItemList(defaults) {
_super.apply(this, arguments);
}
SSDataSeriesFormatItemList.itemType = OutSystemsChartsModel.SSDataSeriesFormatItemRec;
return SSDataSeriesFormatItemList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.SSDataSeriesFormatItemList = SSDataSeriesFormatItemList;

});
define("OutSystemsCharts.model$YAxesRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$YAxesRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var YAxesRecordList = (function (_super) {
__extends(YAxesRecordList, _super);
function YAxesRecordList(defaults) {
_super.apply(this, arguments);
}
YAxesRecordList.itemType = OutSystemsChartsModel.YAxesRecord;
return YAxesRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.YAxesRecordList = YAxesRecordList;

});
define("OutSystemsCharts.model$eventsList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$eventsRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var eventsList = (function (_super) {
__extends(eventsList, _super);
function eventsList(defaults) {
_super.apply(this, arguments);
}
eventsList.itemType = OutSystemsChartsModel.eventsRec;
return eventsList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.eventsList = eventsList;

});
define("OutSystemsCharts.model$", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var TextList = (function (_super) {
__extends(TextList, _super);
function TextList(defaults) {
_super.apply(this, arguments);
}
TextList.itemType = OS.Types.Text;
return TextList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.TextList = TextList;

});
define("OutSystemsCharts.model$xAxisRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$labelsRec", "OutSystemsCharts.model$titleRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var xAxisRec = (function (_super) {
__extends(xAxisRec, _super);
function xAxisRec(defaults) {
_super.apply(this, arguments);
}
xAxisRec.attributesToDeclare = function () {
return [
this.attr("categories", "categoriesAttr", "categories", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new OS.DataTypes.TextList());
}, true, OS.DataTypes.TextList), 
this.attr("type", "typeAttr", "type", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("labels", "labelsAttr", "labels", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.labelsRec());
}, true, OutSystemsChartsModel.labelsRec), 
this.attr("max", "maxAttr", "max", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("min", "minAttr", "min", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("title", "titleAttr", "title", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.titleRec());
}, true, OutSystemsChartsModel.titleRec)
].concat(_super.attributesToDeclare.call(this));
};
xAxisRec.init();
return xAxisRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.xAxisRec = xAxisRec;

});
define("OutSystemsCharts.model$xAxisRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$xAxisRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var xAxisRecord = (function (_super) {
__extends(xAxisRecord, _super);
function xAxisRecord(defaults) {
_super.apply(this, arguments);
}
xAxisRecord.attributesToDeclare = function () {
return [
this.attr("xAxis", "xAxisAttr", "xAxis", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.xAxisRec());
}, true, OutSystemsChartsModel.xAxisRec)
].concat(_super.attributesToDeclare.call(this));
};
xAxisRecord.fromStructure = function (str) {
return new xAxisRecord(new xAxisRecord.RecordClass({
xAxisAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
xAxisRecord._isAnonymousRecord = true;
xAxisRecord.UniqueId = "d723d7d7-e180-5717-ecb5-d63d07c1dcf4";
xAxisRecord.init();
return xAxisRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.xAxisRecord = xAxisRecord;

});
define("OutSystemsCharts.model$xAxisRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$xAxisRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var xAxisRecordList = (function (_super) {
__extends(xAxisRecordList, _super);
function xAxisRecordList(defaults) {
_super.apply(this, arguments);
}
xAxisRecordList.itemType = OutSystemsChartsModel.xAxisRecord;
return xAxisRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.xAxisRecordList = xAxisRecordList;

});
define("OutSystemsCharts.model$SSChartFormatRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var SSChartFormatRec = (function (_super) {
__extends(SSChartFormatRec, _super);
function SSChartFormatRec(defaults) {
_super.apply(this, arguments);
}
SSChartFormatRec.attributesToDeclare = function () {
return [
this.attr("ShowDataPointValues", "showDataPointValuesAttr", "ShowDataPointValues", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("UseAnimation", "useAnimationAttr", "UseAnimation", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SSChartFormatRec.init();
return SSChartFormatRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.SSChartFormatRec = SSChartFormatRec;

});
define("OutSystemsCharts.model$LegendPositionRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var LegendPositionRec = (function (_super) {
__extends(LegendPositionRec, _super);
function LegendPositionRec(defaults) {
_super.apply(this, arguments);
}
LegendPositionRec.attributesToDeclare = function () {
return [
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
LegendPositionRec.init();
return LegendPositionRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.LegendPositionRec = LegendPositionRec;

});
define("OutSystemsCharts.model$LegendPositionRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$LegendPositionRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var LegendPositionRecord = (function (_super) {
__extends(LegendPositionRecord, _super);
function LegendPositionRecord(defaults) {
_super.apply(this, arguments);
}
LegendPositionRecord.attributesToDeclare = function () {
return [
this.attr("LegendPosition", "legendPositionAttr", "LegendPosition", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.LegendPositionRec());
}, true, OutSystemsChartsModel.LegendPositionRec)
].concat(_super.attributesToDeclare.call(this));
};
LegendPositionRecord.fromStructure = function (str) {
return new LegendPositionRecord(new LegendPositionRecord.RecordClass({
legendPositionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
LegendPositionRecord._isAnonymousRecord = true;
LegendPositionRecord.UniqueId = "d2362d0d-0bb3-6623-a5f0-020a47954dfc";
LegendPositionRecord.init();
return LegendPositionRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.LegendPositionRecord = LegendPositionRecord;

});
define("OutSystemsCharts.model$LegendPositionRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$LegendPositionRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var LegendPositionRecordList = (function (_super) {
__extends(LegendPositionRecordList, _super);
function LegendPositionRecordList(defaults) {
_super.apply(this, arguments);
}
LegendPositionRecordList.itemType = OutSystemsChartsModel.LegendPositionRecord;
return LegendPositionRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.LegendPositionRecordList = LegendPositionRecordList;

});
define("OutSystemsCharts.model$lineList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$lineRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var lineList = (function (_super) {
__extends(lineList, _super);
function lineList(defaults) {
_super.apply(this, arguments);
}
lineList.itemType = OutSystemsChartsModel.lineRec;
return lineList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.lineList = lineList;

});
define("OutSystemsCharts.model$DataItemList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$DataItemRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var DataItemList = (function (_super) {
__extends(DataItemList, _super);
function DataItemList(defaults) {
_super.apply(this, arguments);
}
DataItemList.itemType = OutSystemsChartsModel.DataItemRec;
return DataItemList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.DataItemList = DataItemList;

});
define("OutSystemsCharts.model$SeriesItemRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$DataItemList", "OutSystemsCharts.model$PointItemRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var SeriesItemRec = (function (_super) {
__extends(SeriesItemRec, _super);
function SeriesItemRec(defaults) {
_super.apply(this, arguments);
}
SeriesItemRec.attributesToDeclare = function () {
return [
this.attr("name", "nameAttr", "name", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("colorByPoint", "colorByPointAttr", "colorByPoint", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("data", "dataAttr", "data", true, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.DataItemList());
}, true, OutSystemsChartsModel.DataItemList), 
this.attr("point", "pointAttr", "point", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.PointItemRec());
}, true, OutSystemsChartsModel.PointItemRec)
].concat(_super.attributesToDeclare.call(this));
};
SeriesItemRec.init();
return SeriesItemRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.SeriesItemRec = SeriesItemRec;

});
define("OutSystemsCharts.model$SeriesItemRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$SeriesItemRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var SeriesItemRecord = (function (_super) {
__extends(SeriesItemRecord, _super);
function SeriesItemRecord(defaults) {
_super.apply(this, arguments);
}
SeriesItemRecord.attributesToDeclare = function () {
return [
this.attr("SeriesItem", "seriesItemAttr", "SeriesItem", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.SeriesItemRec());
}, true, OutSystemsChartsModel.SeriesItemRec)
].concat(_super.attributesToDeclare.call(this));
};
SeriesItemRecord.fromStructure = function (str) {
return new SeriesItemRecord(new SeriesItemRecord.RecordClass({
seriesItemAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SeriesItemRecord._isAnonymousRecord = true;
SeriesItemRecord.UniqueId = "8d14db52-60a4-f7a4-be0c-c0cd5293bb68";
SeriesItemRecord.init();
return SeriesItemRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.SeriesItemRecord = SeriesItemRecord;

});
define("OutSystemsCharts.model$SeriesItemRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$SeriesItemRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var SeriesItemRecordList = (function (_super) {
__extends(SeriesItemRecordList, _super);
function SeriesItemRecordList(defaults) {
_super.apply(this, arguments);
}
SeriesItemRecordList.itemType = OutSystemsChartsModel.SeriesItemRecord;
return SeriesItemRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.SeriesItemRecordList = SeriesItemRecordList;

});
define("OutSystemsCharts.model$titleRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$titleRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var titleRecord = (function (_super) {
__extends(titleRecord, _super);
function titleRecord(defaults) {
_super.apply(this, arguments);
}
titleRecord.attributesToDeclare = function () {
return [
this.attr("title", "titleAttr", "title", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.titleRec());
}, true, OutSystemsChartsModel.titleRec)
].concat(_super.attributesToDeclare.call(this));
};
titleRecord.fromStructure = function (str) {
return new titleRecord(new titleRecord.RecordClass({
titleAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
titleRecord._isAnonymousRecord = true;
titleRecord.UniqueId = "28c609f6-0bec-ee3e-805d-b9e332bec5b4";
titleRecord.init();
return titleRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.titleRecord = titleRecord;

});
define("OutSystemsCharts.model$ChartFormatRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var ChartFormatRec = (function (_super) {
__extends(ChartFormatRec, _super);
function ChartFormatRec(defaults) {
_super.apply(this, arguments);
}
ChartFormatRec.attributesToDeclare = function () {
return [
this.attr("ShowDataPointValues", "showDataPointValuesAttr", "ShowDataPointValues", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("UseAnimation", "useAnimationAttr", "UseAnimation", true, false, OS.Types.Boolean, function () {
return true;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ChartFormatRec.init();
return ChartFormatRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.ChartFormatRec = ChartFormatRec;

});
define("OutSystemsCharts.model$ChartFormatRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$ChartFormatRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var ChartFormatRecord = (function (_super) {
__extends(ChartFormatRecord, _super);
function ChartFormatRecord(defaults) {
_super.apply(this, arguments);
}
ChartFormatRecord.attributesToDeclare = function () {
return [
this.attr("ChartFormat", "chartFormatAttr", "ChartFormat", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.ChartFormatRec());
}, true, OutSystemsChartsModel.ChartFormatRec)
].concat(_super.attributesToDeclare.call(this));
};
ChartFormatRecord.fromStructure = function (str) {
return new ChartFormatRecord(new ChartFormatRecord.RecordClass({
chartFormatAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ChartFormatRecord._isAnonymousRecord = true;
ChartFormatRecord.UniqueId = "2b9e4142-8d5c-5ca3-b04a-80be4ce98f53";
ChartFormatRecord.init();
return ChartFormatRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.ChartFormatRecord = ChartFormatRecord;

});
define("OutSystemsCharts.model$SSAdvanceFormatRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var SSAdvanceFormatRec = (function (_super) {
__extends(SSAdvanceFormatRec, _super);
function SSAdvanceFormatRec(defaults) {
_super.apply(this, arguments);
}
SSAdvanceFormatRec.attributesToDeclare = function () {
return [
this.attr("XAxisJSON", "xAxisJSONAttr", "XAxisJSON", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("YAxisJSON", "yAxisJSONAttr", "YAxisJSON", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("HighchartsJSON", "highchartsJSONAttr", "HighchartsJSON", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SSAdvanceFormatRec.init();
return SSAdvanceFormatRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.SSAdvanceFormatRec = SSAdvanceFormatRec;

});
define("OutSystemsCharts.model$SSAdvanceFormatRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$SSAdvanceFormatRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var SSAdvanceFormatRecord = (function (_super) {
__extends(SSAdvanceFormatRecord, _super);
function SSAdvanceFormatRecord(defaults) {
_super.apply(this, arguments);
}
SSAdvanceFormatRecord.attributesToDeclare = function () {
return [
this.attr("SSAdvanceFormat", "sSAdvanceFormatAttr", "SSAdvanceFormat", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.SSAdvanceFormatRec());
}, true, OutSystemsChartsModel.SSAdvanceFormatRec)
].concat(_super.attributesToDeclare.call(this));
};
SSAdvanceFormatRecord.fromStructure = function (str) {
return new SSAdvanceFormatRecord(new SSAdvanceFormatRecord.RecordClass({
sSAdvanceFormatAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SSAdvanceFormatRecord._isAnonymousRecord = true;
SSAdvanceFormatRecord.UniqueId = "89012dad-6783-07f9-7672-66cf4b146adc";
SSAdvanceFormatRecord.init();
return SSAdvanceFormatRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.SSAdvanceFormatRecord = SSAdvanceFormatRecord;

});
define("OutSystemsCharts.model$SSAdvanceFormatRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$SSAdvanceFormatRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var SSAdvanceFormatRecordList = (function (_super) {
__extends(SSAdvanceFormatRecordList, _super);
function SSAdvanceFormatRecordList(defaults) {
_super.apply(this, arguments);
}
SSAdvanceFormatRecordList.itemType = OutSystemsChartsModel.SSAdvanceFormatRecord;
return SSAdvanceFormatRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.SSAdvanceFormatRecordList = SSAdvanceFormatRecordList;

});
define("OutSystemsCharts.model$XAxisValuesTypeRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var XAxisValuesTypeRec = (function (_super) {
__extends(XAxisValuesTypeRec, _super);
function XAxisValuesTypeRec(defaults) {
_super.apply(this, arguments);
}
XAxisValuesTypeRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
XAxisValuesTypeRec.init();
return XAxisValuesTypeRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.XAxisValuesTypeRec = XAxisValuesTypeRec;

});
define("OutSystemsCharts.model$XAxisValuesTypeRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$XAxisValuesTypeRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var XAxisValuesTypeRecord = (function (_super) {
__extends(XAxisValuesTypeRecord, _super);
function XAxisValuesTypeRecord(defaults) {
_super.apply(this, arguments);
}
XAxisValuesTypeRecord.attributesToDeclare = function () {
return [
this.attr("XAxisValuesType", "xAxisValuesTypeAttr", "XAxisValuesType", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.XAxisValuesTypeRec());
}, true, OutSystemsChartsModel.XAxisValuesTypeRec)
].concat(_super.attributesToDeclare.call(this));
};
XAxisValuesTypeRecord.fromStructure = function (str) {
return new XAxisValuesTypeRecord(new XAxisValuesTypeRecord.RecordClass({
xAxisValuesTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
XAxisValuesTypeRecord._isAnonymousRecord = true;
XAxisValuesTypeRecord.UniqueId = "700a042c-18a5-2538-bbda-09226917700a";
XAxisValuesTypeRecord.init();
return XAxisValuesTypeRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.XAxisValuesTypeRecord = XAxisValuesTypeRecord;

});
define("OutSystemsCharts.model$XAxisValuesTypeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$XAxisValuesTypeRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var XAxisValuesTypeRecordList = (function (_super) {
__extends(XAxisValuesTypeRecordList, _super);
function XAxisValuesTypeRecordList(defaults) {
_super.apply(this, arguments);
}
XAxisValuesTypeRecordList.itemType = OutSystemsChartsModel.XAxisValuesTypeRecord;
return XAxisValuesTypeRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.XAxisValuesTypeRecordList = XAxisValuesTypeRecordList;

});
define("OutSystemsCharts.model$ChartRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var ChartRec = (function (_super) {
__extends(ChartRec, _super);
function ChartRec(defaults) {
_super.apply(this, arguments);
}
ChartRec.attributesToDeclare = function () {
return [
this.attr("plotShadow", "plotShadowAttr", "plotShadow", true, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("type", "typeAttr", "type", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("renderTo", "renderToAttr", "renderTo", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("height", "heightAttr", "height", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("animation", "animationAttr", "animation", true, false, OS.Types.Boolean, function () {
return true;
}, true), 
this.attr("backgroundColor", "backgroundColorAttr", "backgroundColor", true, false, OS.Types.Text, function () {
return "rgba(255, 255, 255, 0)";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ChartRec.init();
return ChartRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.ChartRec = ChartRec;

});
define("OutSystemsCharts.model$SeriesItemList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$SeriesItemRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var SeriesItemList = (function (_super) {
__extends(SeriesItemList, _super);
function SeriesItemList(defaults) {
_super.apply(this, arguments);
}
SeriesItemList.itemType = OutSystemsChartsModel.SeriesItemRec;
return SeriesItemList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.SeriesItemList = SeriesItemList;

});
define("OutSystemsCharts.model$HighChartRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$ChartRec", "OutSystemsCharts.model$titleRec", "OutSystemsCharts.model$tooltipRec", "OutSystemsCharts.model$plotOptionRec", "OutSystemsCharts.model$SeriesItemList", "OutSystemsCharts.model$legendItemRec", "OutSystemsCharts.model$xAxisRec", "OutSystemsCharts.model$yAxisRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var HighChartRec = (function (_super) {
__extends(HighChartRec, _super);
function HighChartRec(defaults) {
_super.apply(this, arguments);
}
HighChartRec.attributesToDeclare = function () {
return [
this.attr("chart", "chartAttr", "chart", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.ChartRec());
}, true, OutSystemsChartsModel.ChartRec), 
this.attr("title", "titleAttr", "title", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.titleRec());
}, true, OutSystemsChartsModel.titleRec), 
this.attr("tooltip", "tooltipAttr", "tooltip", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.tooltipRec());
}, true, OutSystemsChartsModel.tooltipRec), 
this.attr("plotOptions", "plotOptionsAttr", "plotOptions", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.plotOptionRec());
}, true, OutSystemsChartsModel.plotOptionRec), 
this.attr("series", "seriesAttr", "series", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.SeriesItemList());
}, true, OutSystemsChartsModel.SeriesItemList), 
this.attr("legend", "legendAttr", "legend", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.legendItemRec());
}, true, OutSystemsChartsModel.legendItemRec), 
this.attr("xAxis", "xAxisAttr", "xAxis", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.xAxisRec());
}, true, OutSystemsChartsModel.xAxisRec), 
this.attr("yAxis", "yAxisAttr", "yAxis", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.yAxisRec());
}, true, OutSystemsChartsModel.yAxisRec), 
this.attr("containerId", "containerIdAttr", "containerId", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
HighChartRec.init();
return HighChartRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.HighChartRec = HighChartRec;

});
define("OutSystemsCharts.model$HighChartList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$HighChartRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var HighChartList = (function (_super) {
__extends(HighChartList, _super);
function HighChartList(defaults) {
_super.apply(this, arguments);
}
HighChartList.itemType = OutSystemsChartsModel.HighChartRec;
return HighChartList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.HighChartList = HighChartList;

});
define("OutSystemsCharts.model$HighChartRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$HighChartRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var HighChartRecord = (function (_super) {
__extends(HighChartRecord, _super);
function HighChartRecord(defaults) {
_super.apply(this, arguments);
}
HighChartRecord.attributesToDeclare = function () {
return [
this.attr("HighChart", "highChartAttr", "HighChart", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.HighChartRec());
}, true, OutSystemsChartsModel.HighChartRec)
].concat(_super.attributesToDeclare.call(this));
};
HighChartRecord.fromStructure = function (str) {
return new HighChartRecord(new HighChartRecord.RecordClass({
highChartAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
HighChartRecord._isAnonymousRecord = true;
HighChartRecord.UniqueId = "34d2a9a4-1f0c-04f9-6fa6-cdc65effe25f";
HighChartRecord.init();
return HighChartRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.HighChartRecord = HighChartRecord;

});
define("OutSystemsCharts.model$lineRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$lineRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var lineRecord = (function (_super) {
__extends(lineRecord, _super);
function lineRecord(defaults) {
_super.apply(this, arguments);
}
lineRecord.attributesToDeclare = function () {
return [
this.attr("line", "lineAttr", "line", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.lineRec());
}, true, OutSystemsChartsModel.lineRec)
].concat(_super.attributesToDeclare.call(this));
};
lineRecord.fromStructure = function (str) {
return new lineRecord(new lineRecord.RecordClass({
lineAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
lineRecord._isAnonymousRecord = true;
lineRecord.UniqueId = "39c487a8-f418-0912-72b6-e0d14b87bcfa";
lineRecord.init();
return lineRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.lineRecord = lineRecord;

});
define("OutSystemsCharts.model$lineRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$lineRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var lineRecordList = (function (_super) {
__extends(lineRecordList, _super);
function lineRecordList(defaults) {
_super.apply(this, arguments);
}
lineRecordList.itemType = OutSystemsChartsModel.lineRecord;
return lineRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.lineRecordList = lineRecordList;

});
define("OutSystemsCharts.model$StackingTypeRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$StackingTypeRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var StackingTypeRecord = (function (_super) {
__extends(StackingTypeRecord, _super);
function StackingTypeRecord(defaults) {
_super.apply(this, arguments);
}
StackingTypeRecord.attributesToDeclare = function () {
return [
this.attr("StackingType", "stackingTypeAttr", "StackingType", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.StackingTypeRec());
}, true, OutSystemsChartsModel.StackingTypeRec)
].concat(_super.attributesToDeclare.call(this));
};
StackingTypeRecord.fromStructure = function (str) {
return new StackingTypeRecord(new StackingTypeRecord.RecordClass({
stackingTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
StackingTypeRecord._isAnonymousRecord = true;
StackingTypeRecord.UniqueId = "35e37489-cb29-f7a3-04d5-12a403000665";
StackingTypeRecord.init();
return StackingTypeRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.StackingTypeRecord = StackingTypeRecord;

});
define("OutSystemsCharts.model$StackingTypeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$StackingTypeRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var StackingTypeRecordList = (function (_super) {
__extends(StackingTypeRecordList, _super);
function StackingTypeRecordList(defaults) {
_super.apply(this, arguments);
}
StackingTypeRecordList.itemType = OutSystemsChartsModel.StackingTypeRecord;
return StackingTypeRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.StackingTypeRecordList = StackingTypeRecordList;

});
define("OutSystemsCharts.model$labelsRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$labelsRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var labelsRecord = (function (_super) {
__extends(labelsRecord, _super);
function labelsRecord(defaults) {
_super.apply(this, arguments);
}
labelsRecord.attributesToDeclare = function () {
return [
this.attr("labels", "labelsAttr", "labels", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.labelsRec());
}, true, OutSystemsChartsModel.labelsRec)
].concat(_super.attributesToDeclare.call(this));
};
labelsRecord.fromStructure = function (str) {
return new labelsRecord(new labelsRecord.RecordClass({
labelsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
labelsRecord._isAnonymousRecord = true;
labelsRecord.UniqueId = "3a53c0a0-4da4-9534-722e-fd10ff706aab";
labelsRecord.init();
return labelsRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.labelsRecord = labelsRecord;

});
define("OutSystemsCharts.model$SSDataSeriesFormatItemRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$SSDataSeriesFormatItemRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var SSDataSeriesFormatItemRecordList = (function (_super) {
__extends(SSDataSeriesFormatItemRecordList, _super);
function SSDataSeriesFormatItemRecordList(defaults) {
_super.apply(this, arguments);
}
SSDataSeriesFormatItemRecordList.itemType = OutSystemsChartsModel.SSDataSeriesFormatItemRecord;
return SSDataSeriesFormatItemRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.SSDataSeriesFormatItemRecordList = SSDataSeriesFormatItemRecordList;

});
define("OutSystemsCharts.model$stackLabelsRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$stackLabelsRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var stackLabelsRecord = (function (_super) {
__extends(stackLabelsRecord, _super);
function stackLabelsRecord(defaults) {
_super.apply(this, arguments);
}
stackLabelsRecord.attributesToDeclare = function () {
return [
this.attr("stackLabels", "stackLabelsAttr", "stackLabels", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.stackLabelsRec());
}, true, OutSystemsChartsModel.stackLabelsRec)
].concat(_super.attributesToDeclare.call(this));
};
stackLabelsRecord.fromStructure = function (str) {
return new stackLabelsRecord(new stackLabelsRecord.RecordClass({
stackLabelsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
stackLabelsRecord._isAnonymousRecord = true;
stackLabelsRecord.UniqueId = "3cf75b4b-937c-2ea9-dfc1-1e84ca3966fd";
stackLabelsRecord.init();
return stackLabelsRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.stackLabelsRecord = stackLabelsRecord;

});
define("OutSystemsCharts.model$pieRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$pieRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var pieRecord = (function (_super) {
__extends(pieRecord, _super);
function pieRecord(defaults) {
_super.apply(this, arguments);
}
pieRecord.attributesToDeclare = function () {
return [
this.attr("pie", "pieAttr", "pie", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.pieRec());
}, true, OutSystemsChartsModel.pieRec)
].concat(_super.attributesToDeclare.call(this));
};
pieRecord.fromStructure = function (str) {
return new pieRecord(new pieRecord.RecordClass({
pieAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
pieRecord._isAnonymousRecord = true;
pieRecord.UniqueId = "3f8a9be6-89db-b00b-3eaa-f4e206618ba2";
pieRecord.init();
return pieRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.pieRecord = pieRecord;

});
define("OutSystemsCharts.model$XAxesRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var XAxesRec = (function (_super) {
__extends(XAxesRec, _super);
function XAxesRec(defaults) {
_super.apply(this, arguments);
}
XAxesRec.attributesToDeclare = function () {
return [
this.attr("Title", "titleAttr", "title", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("LabelsRotation", "labelsRotationAttr", "labelsRotation", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("MinValue", "minValueAttr", "minValue", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("MaxValue", "maxValueAttr", "maxValue", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
XAxesRec.init();
return XAxesRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.XAxesRec = XAxesRec;

});
define("OutSystemsCharts.model$XAxesList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$XAxesRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var XAxesList = (function (_super) {
__extends(XAxesList, _super);
function XAxesList(defaults) {
_super.apply(this, arguments);
}
XAxesList.itemType = OutSystemsChartsModel.XAxesRec;
return XAxesList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.XAxesList = XAxesList;

});
define("OutSystemsCharts.model$XAxisFormatRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var XAxisFormatRec = (function (_super) {
__extends(XAxisFormatRec, _super);
function XAxisFormatRec(defaults) {
_super.apply(this, arguments);
}
XAxisFormatRec.attributesToDeclare = function () {
return [
this.attr("Title", "titleAttr", "Title", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("LabelsRotation", "labelsRotationAttr", "LabelsRotation", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("MinValue", "minValueAttr", "MinValue", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MaxValue", "maxValueAttr", "MaxValue", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ValuesType", "valuesTypeAttr", "ValuesType", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
XAxisFormatRec.init();
return XAxisFormatRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.XAxisFormatRec = XAxisFormatRec;

});
define("OutSystemsCharts.model$XAxisFormatRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$XAxisFormatRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var XAxisFormatRecord = (function (_super) {
__extends(XAxisFormatRecord, _super);
function XAxisFormatRecord(defaults) {
_super.apply(this, arguments);
}
XAxisFormatRecord.attributesToDeclare = function () {
return [
this.attr("XAxisFormat", "xAxisFormatAttr", "XAxisFormat", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.XAxisFormatRec());
}, true, OutSystemsChartsModel.XAxisFormatRec)
].concat(_super.attributesToDeclare.call(this));
};
XAxisFormatRecord.fromStructure = function (str) {
return new XAxisFormatRecord(new XAxisFormatRecord.RecordClass({
xAxisFormatAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
XAxisFormatRecord._isAnonymousRecord = true;
XAxisFormatRecord.UniqueId = "424d57a2-d666-c8ed-b034-3600d6705eee";
XAxisFormatRecord.init();
return XAxisFormatRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.XAxisFormatRecord = XAxisFormatRecord;

});
define("OutSystemsCharts.model$ChartRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$ChartRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var ChartRecord = (function (_super) {
__extends(ChartRecord, _super);
function ChartRecord(defaults) {
_super.apply(this, arguments);
}
ChartRecord.attributesToDeclare = function () {
return [
this.attr("Chart", "chartAttr", "Chart", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.ChartRec());
}, true, OutSystemsChartsModel.ChartRec)
].concat(_super.attributesToDeclare.call(this));
};
ChartRecord.fromStructure = function (str) {
return new ChartRecord(new ChartRecord.RecordClass({
chartAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ChartRecord._isAnonymousRecord = true;
ChartRecord.UniqueId = "60c0eb96-7674-6216-236a-33a6fde51bea";
ChartRecord.init();
return ChartRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.ChartRecord = ChartRecord;

});
define("OutSystemsCharts.model$ChartRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$ChartRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var ChartRecordList = (function (_super) {
__extends(ChartRecordList, _super);
function ChartRecordList(defaults) {
_super.apply(this, arguments);
}
ChartRecordList.itemType = OutSystemsChartsModel.ChartRecord;
return ChartRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.ChartRecordList = ChartRecordList;

});
define("OutSystemsCharts.model$SSChartFormatRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$SSChartFormatRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var SSChartFormatRecord = (function (_super) {
__extends(SSChartFormatRecord, _super);
function SSChartFormatRecord(defaults) {
_super.apply(this, arguments);
}
SSChartFormatRecord.attributesToDeclare = function () {
return [
this.attr("SSChartFormat", "sSChartFormatAttr", "SSChartFormat", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.SSChartFormatRec());
}, true, OutSystemsChartsModel.SSChartFormatRec)
].concat(_super.attributesToDeclare.call(this));
};
SSChartFormatRecord.fromStructure = function (str) {
return new SSChartFormatRecord(new SSChartFormatRecord.RecordClass({
sSChartFormatAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SSChartFormatRecord._isAnonymousRecord = true;
SSChartFormatRecord.UniqueId = "d8d14f67-d283-2c87-9492-57ced46dc655";
SSChartFormatRecord.init();
return SSChartFormatRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.SSChartFormatRecord = SSChartFormatRecord;

});
define("OutSystemsCharts.model$SSChartFormatRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$SSChartFormatRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var SSChartFormatRecordList = (function (_super) {
__extends(SSChartFormatRecordList, _super);
function SSChartFormatRecordList(defaults) {
_super.apply(this, arguments);
}
SSChartFormatRecordList.itemType = OutSystemsChartsModel.SSChartFormatRecord;
return SSChartFormatRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.SSChartFormatRecordList = SSChartFormatRecordList;

});
define("OutSystemsCharts.model$HighChartRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$HighChartRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var HighChartRecordList = (function (_super) {
__extends(HighChartRecordList, _super);
function HighChartRecordList(defaults) {
_super.apply(this, arguments);
}
HighChartRecordList.itemType = OutSystemsChartsModel.HighChartRecord;
return HighChartRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.HighChartRecordList = HighChartRecordList;

});
define("OutSystemsCharts.model$markerRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$markerRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var markerRecord = (function (_super) {
__extends(markerRecord, _super);
function markerRecord(defaults) {
_super.apply(this, arguments);
}
markerRecord.attributesToDeclare = function () {
return [
this.attr("marker", "markerAttr", "marker", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.markerRec());
}, true, OutSystemsChartsModel.markerRec)
].concat(_super.attributesToDeclare.call(this));
};
markerRecord.fromStructure = function (str) {
return new markerRecord(new markerRecord.RecordClass({
markerAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
markerRecord._isAnonymousRecord = true;
markerRecord.UniqueId = "4d6b02d0-13ae-4005-57d0-b016da83f772";
markerRecord.init();
return markerRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.markerRecord = markerRecord;

});
define("OutSystemsCharts.model$areaList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$areaRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var areaList = (function (_super) {
__extends(areaList, _super);
function areaList(defaults) {
_super.apply(this, arguments);
}
areaList.itemType = OutSystemsChartsModel.areaRec;
return areaList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.areaList = areaList;

});
define("OutSystemsCharts.model$DataPointRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var DataPointRec = (function (_super) {
__extends(DataPointRec, _super);
function DataPointRec(defaults) {
_super.apply(this, arguments);
}
DataPointRec.attributesToDeclare = function () {
return [
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Value", "valueAttr", "Value", true, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("DataSeriesName", "dataSeriesNameAttr", "DataSeriesName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Tooltip", "tooltipAttr", "Tooltip", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Color", "colorAttr", "Color", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DataPointRec.init();
return DataPointRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.DataPointRec = DataPointRec;

});
define("OutSystemsCharts.model$DataPointList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$DataPointRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var DataPointList = (function (_super) {
__extends(DataPointList, _super);
function DataPointList(defaults) {
_super.apply(this, arguments);
}
DataPointList.itemType = OutSystemsChartsModel.DataPointRec;
return DataPointList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.DataPointList = DataPointList;

});
define("OutSystemsCharts.model$StackingTypeList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$StackingTypeRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var StackingTypeList = (function (_super) {
__extends(StackingTypeList, _super);
function StackingTypeList(defaults) {
_super.apply(this, arguments);
}
StackingTypeList.itemType = OutSystemsChartsModel.StackingTypeRec;
return StackingTypeList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.StackingTypeList = StackingTypeList;

});
define("OutSystemsCharts.model$LegendPositionList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$LegendPositionRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var LegendPositionList = (function (_super) {
__extends(LegendPositionList, _super);
function LegendPositionList(defaults) {
_super.apply(this, arguments);
}
LegendPositionList.itemType = OutSystemsChartsModel.LegendPositionRec;
return LegendPositionList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.LegendPositionList = LegendPositionList;

});
define("OutSystemsCharts.model$AdvancedDataSeriesFormatRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var AdvancedDataSeriesFormatRec = (function (_super) {
__extends(AdvancedDataSeriesFormatRec, _super);
function AdvancedDataSeriesFormatRec(defaults) {
_super.apply(this, arguments);
}
AdvancedDataSeriesFormatRec.attributesToDeclare = function () {
return [
this.attr("DataSeriesName", "dataSeriesNameAttr", "DataSeriesName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DataSeriesJSON", "dataSeriesJSONAttr", "DataSeriesJSON", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
AdvancedDataSeriesFormatRec.init();
return AdvancedDataSeriesFormatRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.AdvancedDataSeriesFormatRec = AdvancedDataSeriesFormatRec;

});
define("OutSystemsCharts.model$AdvancedDataSeriesFormatRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$AdvancedDataSeriesFormatRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var AdvancedDataSeriesFormatRecord = (function (_super) {
__extends(AdvancedDataSeriesFormatRecord, _super);
function AdvancedDataSeriesFormatRecord(defaults) {
_super.apply(this, arguments);
}
AdvancedDataSeriesFormatRecord.attributesToDeclare = function () {
return [
this.attr("AdvancedDataSeriesFormat", "advancedDataSeriesFormatAttr", "AdvancedDataSeriesFormat", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.AdvancedDataSeriesFormatRec());
}, true, OutSystemsChartsModel.AdvancedDataSeriesFormatRec)
].concat(_super.attributesToDeclare.call(this));
};
AdvancedDataSeriesFormatRecord.fromStructure = function (str) {
return new AdvancedDataSeriesFormatRecord(new AdvancedDataSeriesFormatRecord.RecordClass({
advancedDataSeriesFormatAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
AdvancedDataSeriesFormatRecord._isAnonymousRecord = true;
AdvancedDataSeriesFormatRecord.UniqueId = "e3eb1896-9a1d-0856-d6aa-6db7946dac4d";
AdvancedDataSeriesFormatRecord.init();
return AdvancedDataSeriesFormatRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.AdvancedDataSeriesFormatRecord = AdvancedDataSeriesFormatRecord;

});
define("OutSystemsCharts.model$AdvancedDataSeriesFormatRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$AdvancedDataSeriesFormatRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var AdvancedDataSeriesFormatRecordList = (function (_super) {
__extends(AdvancedDataSeriesFormatRecordList, _super);
function AdvancedDataSeriesFormatRecordList(defaults) {
_super.apply(this, arguments);
}
AdvancedDataSeriesFormatRecordList.itemType = OutSystemsChartsModel.AdvancedDataSeriesFormatRecord;
return AdvancedDataSeriesFormatRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.AdvancedDataSeriesFormatRecordList = AdvancedDataSeriesFormatRecordList;

});
define("OutSystemsCharts.model$XAxesRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$XAxesRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var XAxesRecord = (function (_super) {
__extends(XAxesRecord, _super);
function XAxesRecord(defaults) {
_super.apply(this, arguments);
}
XAxesRecord.attributesToDeclare = function () {
return [
this.attr("XAxes", "xAxesAttr", "XAxes", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.XAxesRec());
}, true, OutSystemsChartsModel.XAxesRec)
].concat(_super.attributesToDeclare.call(this));
};
XAxesRecord.fromStructure = function (str) {
return new XAxesRecord(new XAxesRecord.RecordClass({
xAxesAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
XAxesRecord._isAnonymousRecord = true;
XAxesRecord.UniqueId = "d997b96c-2ce4-f21d-a216-2ad8f92f777a";
XAxesRecord.init();
return XAxesRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.XAxesRecord = XAxesRecord;

});
define("OutSystemsCharts.model$XAxesRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$XAxesRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var XAxesRecordList = (function (_super) {
__extends(XAxesRecordList, _super);
function XAxesRecordList(defaults) {
_super.apply(this, arguments);
}
XAxesRecordList.itemType = OutSystemsChartsModel.XAxesRecord;
return XAxesRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.XAxesRecordList = XAxesRecordList;

});
define("OutSystemsCharts.model$areaRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$areaRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var areaRecord = (function (_super) {
__extends(areaRecord, _super);
function areaRecord(defaults) {
_super.apply(this, arguments);
}
areaRecord.attributesToDeclare = function () {
return [
this.attr("area", "areaAttr", "area", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.areaRec());
}, true, OutSystemsChartsModel.areaRec)
].concat(_super.attributesToDeclare.call(this));
};
areaRecord.fromStructure = function (str) {
return new areaRecord(new areaRecord.RecordClass({
areaAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
areaRecord._isAnonymousRecord = true;
areaRecord.UniqueId = "6ac1e799-8990-5f9c-4e16-b1bc414e4025";
areaRecord.init();
return areaRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.areaRecord = areaRecord;

});
define("OutSystemsCharts.model$DataPointRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$DataPointRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var DataPointRecord = (function (_super) {
__extends(DataPointRecord, _super);
function DataPointRecord(defaults) {
_super.apply(this, arguments);
}
DataPointRecord.attributesToDeclare = function () {
return [
this.attr("DataPoint", "dataPointAttr", "DataPoint", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.DataPointRec());
}, true, OutSystemsChartsModel.DataPointRec)
].concat(_super.attributesToDeclare.call(this));
};
DataPointRecord.fromStructure = function (str) {
return new DataPointRecord(new DataPointRecord.RecordClass({
dataPointAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DataPointRecord._isAnonymousRecord = true;
DataPointRecord.UniqueId = "6ceb0a54-ddbc-9244-6ab6-6e8c847870c1";
DataPointRecord.init();
return DataPointRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.DataPointRecord = DataPointRecord;

});
define("OutSystemsCharts.model$SSParameterRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$SSChartFormatRec", "OutSystemsCharts.model$XAxesRec", "OutSystemsCharts.model$YAxesRec", "OutSystemsCharts.model$SSAdvanceFormatRec", "OutSystemsCharts.model$SSDataSeriesFormatItemList"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var SSParameterRec = (function (_super) {
__extends(SSParameterRec, _super);
function SSParameterRec(defaults) {
_super.apply(this, arguments);
}
SSParameterRec.attributesToDeclare = function () {
return [
this.attr("Legend", "legendAttr", "legend", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Height", "heightAttr", "height", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("StackingType", "stackingTypeAttr", "stackingType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ChartFormat", "chartFormatAttr", "ChartFormat", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.SSChartFormatRec());
}, true, OutSystemsChartsModel.SSChartFormatRec), 
this.attr("XAxis", "xAxisAttr", "xAxis", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.XAxesRec());
}, true, OutSystemsChartsModel.XAxesRec), 
this.attr("YAxis", "yAxisAttr", "yAxis", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.YAxesRec());
}, true, OutSystemsChartsModel.YAxesRec), 
this.attr("AdvanceFormat", "advanceFormatAttr", "AdvanceFormat", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.SSAdvanceFormatRec());
}, true, OutSystemsChartsModel.SSAdvanceFormatRec), 
this.attr("DataSeriesFormats", "dataSeriesFormatsAttr", "DataSeriesFormats", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.SSDataSeriesFormatItemList());
}, true, OutSystemsChartsModel.SSDataSeriesFormatItemList)
].concat(_super.attributesToDeclare.call(this));
};
SSParameterRec.init();
return SSParameterRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.SSParameterRec = SSParameterRec;

});
define("OutSystemsCharts.model$DataPointRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$DataPointRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var DataPointRecordList = (function (_super) {
__extends(DataPointRecordList, _super);
function DataPointRecordList(defaults) {
_super.apply(this, arguments);
}
DataPointRecordList.itemType = OutSystemsChartsModel.DataPointRecord;
return DataPointRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.DataPointRecordList = DataPointRecordList;

});
define("OutSystemsCharts.model$AdvancedDataPointFormatRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$DataPointRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var AdvancedDataPointFormatRec = (function (_super) {
__extends(AdvancedDataPointFormatRec, _super);
function AdvancedDataPointFormatRec(defaults) {
_super.apply(this, arguments);
}
AdvancedDataPointFormatRec.attributesToDeclare = function () {
return [
this.attr("DataPoint", "dataPointAttr", "DataPoint", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.DataPointRec());
}, true, OutSystemsChartsModel.DataPointRec), 
this.attr("DataPointJSON", "dataPointJSONAttr", "DataPointJSON", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
AdvancedDataPointFormatRec.init();
return AdvancedDataPointFormatRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.AdvancedDataPointFormatRec = AdvancedDataPointFormatRec;

});
define("OutSystemsCharts.model$AdvancedDataPointFormatList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$AdvancedDataPointFormatRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var AdvancedDataPointFormatList = (function (_super) {
__extends(AdvancedDataPointFormatList, _super);
function AdvancedDataPointFormatList(defaults) {
_super.apply(this, arguments);
}
AdvancedDataPointFormatList.itemType = OutSystemsChartsModel.AdvancedDataPointFormatRec;
return AdvancedDataPointFormatList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.AdvancedDataPointFormatList = AdvancedDataPointFormatList;

});
define("OutSystemsCharts.model$columnRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$columnRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var columnRecord = (function (_super) {
__extends(columnRecord, _super);
function columnRecord(defaults) {
_super.apply(this, arguments);
}
columnRecord.attributesToDeclare = function () {
return [
this.attr("column", "columnAttr", "column", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.columnRec());
}, true, OutSystemsChartsModel.columnRec)
].concat(_super.attributesToDeclare.call(this));
};
columnRecord.fromStructure = function (str) {
return new columnRecord(new columnRecord.RecordClass({
columnAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
columnRecord._isAnonymousRecord = true;
columnRecord.UniqueId = "99372c24-e21a-de3d-163c-088b22c14297";
columnRecord.init();
return columnRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.columnRecord = columnRecord;

});
define("OutSystemsCharts.model$columnRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$columnRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var columnRecordList = (function (_super) {
__extends(columnRecordList, _super);
function columnRecordList(defaults) {
_super.apply(this, arguments);
}
columnRecordList.itemType = OutSystemsChartsModel.columnRecord;
return columnRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.columnRecordList = columnRecordList;

});
define("OutSystemsCharts.model$titleRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$titleRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var titleRecordList = (function (_super) {
__extends(titleRecordList, _super);
function titleRecordList(defaults) {
_super.apply(this, arguments);
}
titleRecordList.itemType = OutSystemsChartsModel.titleRecord;
return titleRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.titleRecordList = titleRecordList;

});
define("OutSystemsCharts.model$DataItemRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$DataItemRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var DataItemRecord = (function (_super) {
__extends(DataItemRecord, _super);
function DataItemRecord(defaults) {
_super.apply(this, arguments);
}
DataItemRecord.attributesToDeclare = function () {
return [
this.attr("DataItem", "dataItemAttr", "DataItem", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.DataItemRec());
}, true, OutSystemsChartsModel.DataItemRec)
].concat(_super.attributesToDeclare.call(this));
};
DataItemRecord.fromStructure = function (str) {
return new DataItemRecord(new DataItemRecord.RecordClass({
dataItemAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DataItemRecord._isAnonymousRecord = true;
DataItemRecord.UniqueId = "a673699e-334e-c13c-e8b7-1d04bf4e5179";
DataItemRecord.init();
return DataItemRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.DataItemRecord = DataItemRecord;

});
define("OutSystemsCharts.model$DataItemRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$DataItemRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var DataItemRecordList = (function (_super) {
__extends(DataItemRecordList, _super);
function DataItemRecordList(defaults) {
_super.apply(this, arguments);
}
DataItemRecordList.itemType = OutSystemsChartsModel.DataItemRecord;
return DataItemRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.DataItemRecordList = DataItemRecordList;

});
define("OutSystemsCharts.model$XAxisValuesTypeList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$XAxisValuesTypeRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var XAxisValuesTypeList = (function (_super) {
__extends(XAxisValuesTypeList, _super);
function XAxisValuesTypeList(defaults) {
_super.apply(this, arguments);
}
XAxisValuesTypeList.itemType = OutSystemsChartsModel.XAxisValuesTypeRec;
return XAxisValuesTypeList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.XAxisValuesTypeList = XAxisValuesTypeList;

});
define("OutSystemsCharts.model$YAxisFormatRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var YAxisFormatRec = (function (_super) {
__extends(YAxisFormatRec, _super);
function YAxisFormatRec(defaults) {
_super.apply(this, arguments);
}
YAxisFormatRec.attributesToDeclare = function () {
return [
this.attr("Title", "titleAttr", "Title", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MinValue", "minValueAttr", "MinValue", false, false, OS.Types.Decimal, function () {
return OS.BuiltinFunctions.integerToDecimal(-2147483647);
}, true), 
this.attr("MaxValue", "maxValueAttr", "MaxValue", false, false, OS.Types.Decimal, function () {
return OS.BuiltinFunctions.integerToDecimal(-2147483647);
}, true), 
this.attr("ValuesPrefix", "valuesPrefixAttr", "ValuesPrefix", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ValuesSuffix", "valuesSuffixAttr", "ValuesSuffix", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("GridLineStep", "gridLineStepAttr", "GridLineStep", false, false, OS.Types.Decimal, function () {
return OS.BuiltinFunctions.integerToDecimal(-2147483647);
}, true)
].concat(_super.attributesToDeclare.call(this));
};
YAxisFormatRec.init();
return YAxisFormatRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.YAxisFormatRec = YAxisFormatRec;

});
define("OutSystemsCharts.model$DataLabelRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$DataLabelRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var DataLabelRecord = (function (_super) {
__extends(DataLabelRecord, _super);
function DataLabelRecord(defaults) {
_super.apply(this, arguments);
}
DataLabelRecord.attributesToDeclare = function () {
return [
this.attr("DataLabel", "dataLabelAttr", "DataLabel", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.DataLabelRec());
}, true, OutSystemsChartsModel.DataLabelRec)
].concat(_super.attributesToDeclare.call(this));
};
DataLabelRecord.fromStructure = function (str) {
return new DataLabelRecord(new DataLabelRecord.RecordClass({
dataLabelAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DataLabelRecord._isAnonymousRecord = true;
DataLabelRecord.UniqueId = "82039da8-8d39-9da4-2c55-f3923bd33915";
DataLabelRecord.init();
return DataLabelRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.DataLabelRecord = DataLabelRecord;

});
define("OutSystemsCharts.model$SSParameterList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$SSParameterRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var SSParameterList = (function (_super) {
__extends(SSParameterList, _super);
function SSParameterList(defaults) {
_super.apply(this, arguments);
}
SSParameterList.itemType = OutSystemsChartsModel.SSParameterRec;
return SSParameterList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.SSParameterList = SSParameterList;

});
define("OutSystemsCharts.model$AdvancedDataPointFormatRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$AdvancedDataPointFormatRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var AdvancedDataPointFormatRecord = (function (_super) {
__extends(AdvancedDataPointFormatRecord, _super);
function AdvancedDataPointFormatRecord(defaults) {
_super.apply(this, arguments);
}
AdvancedDataPointFormatRecord.attributesToDeclare = function () {
return [
this.attr("AdvancedDataPointFormat", "advancedDataPointFormatAttr", "AdvancedDataPointFormat", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.AdvancedDataPointFormatRec());
}, true, OutSystemsChartsModel.AdvancedDataPointFormatRec)
].concat(_super.attributesToDeclare.call(this));
};
AdvancedDataPointFormatRecord.fromStructure = function (str) {
return new AdvancedDataPointFormatRecord(new AdvancedDataPointFormatRecord.RecordClass({
advancedDataPointFormatAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
AdvancedDataPointFormatRecord._isAnonymousRecord = true;
AdvancedDataPointFormatRecord.UniqueId = "860a186f-93e9-fe7f-e0d4-2f4282c2ec00";
AdvancedDataPointFormatRecord.init();
return AdvancedDataPointFormatRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.AdvancedDataPointFormatRecord = AdvancedDataPointFormatRecord;

});
define("OutSystemsCharts.model$XAxisFormatRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$XAxisFormatRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var XAxisFormatRecordList = (function (_super) {
__extends(XAxisFormatRecordList, _super);
function XAxisFormatRecordList(defaults) {
_super.apply(this, arguments);
}
XAxisFormatRecordList.itemType = OutSystemsChartsModel.XAxisFormatRecord;
return XAxisFormatRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.XAxisFormatRecordList = XAxisFormatRecordList;

});
define("OutSystemsCharts.model$AdvancedDataSeriesFormatList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$AdvancedDataSeriesFormatRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var AdvancedDataSeriesFormatList = (function (_super) {
__extends(AdvancedDataSeriesFormatList, _super);
function AdvancedDataSeriesFormatList(defaults) {
_super.apply(this, arguments);
}
AdvancedDataSeriesFormatList.itemType = OutSystemsChartsModel.AdvancedDataSeriesFormatRec;
return AdvancedDataSeriesFormatList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.AdvancedDataSeriesFormatList = AdvancedDataSeriesFormatList;

});
define("OutSystemsCharts.model$AdvancedFormatRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$AdvancedDataPointFormatList", "OutSystemsCharts.model$AdvancedDataSeriesFormatList"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var AdvancedFormatRec = (function (_super) {
__extends(AdvancedFormatRec, _super);
function AdvancedFormatRec(defaults) {
_super.apply(this, arguments);
}
AdvancedFormatRec.attributesToDeclare = function () {
return [
this.attr("DataPointFormats", "dataPointFormatsAttr", "DataPointFormats", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.AdvancedDataPointFormatList());
}, true, OutSystemsChartsModel.AdvancedDataPointFormatList), 
this.attr("DataSeriesFormats", "dataSeriesFormatsAttr", "DataSeriesFormats", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.AdvancedDataSeriesFormatList());
}, true, OutSystemsChartsModel.AdvancedDataSeriesFormatList), 
this.attr("XAxisJSON", "xAxisJSONAttr", "XAxisJSON", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("YAxisJSON", "yAxisJSONAttr", "YAxisJSON", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("HighchartsJSON", "highchartsJSONAttr", "HighchartsJSON", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
AdvancedFormatRec.init();
return AdvancedFormatRec;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.AdvancedFormatRec = AdvancedFormatRec;

});
define("OutSystemsCharts.model$AdvancedFormatRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$AdvancedFormatRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var AdvancedFormatRecord = (function (_super) {
__extends(AdvancedFormatRecord, _super);
function AdvancedFormatRecord(defaults) {
_super.apply(this, arguments);
}
AdvancedFormatRecord.attributesToDeclare = function () {
return [
this.attr("AdvancedFormat", "advancedFormatAttr", "AdvancedFormat", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.AdvancedFormatRec());
}, true, OutSystemsChartsModel.AdvancedFormatRec)
].concat(_super.attributesToDeclare.call(this));
};
AdvancedFormatRecord.fromStructure = function (str) {
return new AdvancedFormatRecord(new AdvancedFormatRecord.RecordClass({
advancedFormatAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
AdvancedFormatRecord._isAnonymousRecord = true;
AdvancedFormatRecord.UniqueId = "8bd0ab07-a3f3-c2d2-a572-a84134c564bd";
AdvancedFormatRecord.init();
return AdvancedFormatRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.AdvancedFormatRecord = AdvancedFormatRecord;

});
define("OutSystemsCharts.model$ChartFormatList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$ChartFormatRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var ChartFormatList = (function (_super) {
__extends(ChartFormatList, _super);
function ChartFormatList(defaults) {
_super.apply(this, arguments);
}
ChartFormatList.itemType = OutSystemsChartsModel.ChartFormatRec;
return ChartFormatList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.ChartFormatList = ChartFormatList;

});
define("OutSystemsCharts.model$ChartFormatRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$ChartFormatRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var ChartFormatRecordList = (function (_super) {
__extends(ChartFormatRecordList, _super);
function ChartFormatRecordList(defaults) {
_super.apply(this, arguments);
}
ChartFormatRecordList.itemType = OutSystemsChartsModel.ChartFormatRecord;
return ChartFormatRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.ChartFormatRecordList = ChartFormatRecordList;

});
define("OutSystemsCharts.model$YAxisFormatRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$YAxisFormatRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var YAxisFormatRecord = (function (_super) {
__extends(YAxisFormatRecord, _super);
function YAxisFormatRecord(defaults) {
_super.apply(this, arguments);
}
YAxisFormatRecord.attributesToDeclare = function () {
return [
this.attr("YAxisFormat", "yAxisFormatAttr", "YAxisFormat", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.YAxisFormatRec());
}, true, OutSystemsChartsModel.YAxisFormatRec)
].concat(_super.attributesToDeclare.call(this));
};
YAxisFormatRecord.fromStructure = function (str) {
return new YAxisFormatRecord(new YAxisFormatRecord.RecordClass({
yAxisFormatAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
YAxisFormatRecord._isAnonymousRecord = true;
YAxisFormatRecord.UniqueId = "9ac3a73b-5c3d-dd8f-3923-cd00427e8e10";
YAxisFormatRecord.init();
return YAxisFormatRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.YAxisFormatRecord = YAxisFormatRecord;

});
define("OutSystemsCharts.model$YAxisFormatRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$YAxisFormatRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var YAxisFormatRecordList = (function (_super) {
__extends(YAxisFormatRecordList, _super);
function YAxisFormatRecordList(defaults) {
_super.apply(this, arguments);
}
YAxisFormatRecordList.itemType = OutSystemsChartsModel.YAxisFormatRecord;
return YAxisFormatRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.YAxisFormatRecordList = YAxisFormatRecordList;

});
define("OutSystemsCharts.model$DataLabelList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$DataLabelRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var DataLabelList = (function (_super) {
__extends(DataLabelList, _super);
function DataLabelList(defaults) {
_super.apply(this, arguments);
}
DataLabelList.itemType = OutSystemsChartsModel.DataLabelRec;
return DataLabelList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.DataLabelList = DataLabelList;

});
define("OutSystemsCharts.model$yAxisRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$yAxisRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var yAxisRecord = (function (_super) {
__extends(yAxisRecord, _super);
function yAxisRecord(defaults) {
_super.apply(this, arguments);
}
yAxisRecord.attributesToDeclare = function () {
return [
this.attr("yAxis", "yAxisAttr", "yAxis", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.yAxisRec());
}, true, OutSystemsChartsModel.yAxisRec)
].concat(_super.attributesToDeclare.call(this));
};
yAxisRecord.fromStructure = function (str) {
return new yAxisRecord(new yAxisRecord.RecordClass({
yAxisAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
yAxisRecord._isAnonymousRecord = true;
yAxisRecord.UniqueId = "90cf8951-86e4-99c0-ccf9-e0b47d1a0733";
yAxisRecord.init();
return yAxisRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.yAxisRecord = yAxisRecord;

});
define("OutSystemsCharts.model$AdvancedFormatList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$AdvancedFormatRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var AdvancedFormatList = (function (_super) {
__extends(AdvancedFormatList, _super);
function AdvancedFormatList(defaults) {
_super.apply(this, arguments);
}
AdvancedFormatList.itemType = OutSystemsChartsModel.AdvancedFormatRec;
return AdvancedFormatList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.AdvancedFormatList = AdvancedFormatList;

});
define("OutSystemsCharts.model$barRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$barRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var barRecord = (function (_super) {
__extends(barRecord, _super);
function barRecord(defaults) {
_super.apply(this, arguments);
}
barRecord.attributesToDeclare = function () {
return [
this.attr("bar", "barAttr", "bar", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.barRec());
}, true, OutSystemsChartsModel.barRec)
].concat(_super.attributesToDeclare.call(this));
};
barRecord.fromStructure = function (str) {
return new barRecord(new barRecord.RecordClass({
barAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
barRecord._isAnonymousRecord = true;
barRecord.UniqueId = "957fca98-bff6-489c-cc7e-4460c7e84123";
barRecord.init();
return barRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.barRecord = barRecord;

});
define("OutSystemsCharts.model$xAxisList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$xAxisRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var xAxisList = (function (_super) {
__extends(xAxisList, _super);
function xAxisList(defaults) {
_super.apply(this, arguments);
}
xAxisList.itemType = OutSystemsChartsModel.xAxisRec;
return xAxisList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.xAxisList = xAxisList;

});
define("OutSystemsCharts.model$plotOptionList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$plotOptionRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var plotOptionList = (function (_super) {
__extends(plotOptionList, _super);
function plotOptionList(defaults) {
_super.apply(this, arguments);
}
plotOptionList.itemType = OutSystemsChartsModel.plotOptionRec;
return plotOptionList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.plotOptionList = plotOptionList;

});
define("OutSystemsCharts.model$yAxisRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$yAxisRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var yAxisRecordList = (function (_super) {
__extends(yAxisRecordList, _super);
function yAxisRecordList(defaults) {
_super.apply(this, arguments);
}
yAxisRecordList.itemType = OutSystemsChartsModel.yAxisRecord;
return yAxisRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.yAxisRecordList = yAxisRecordList;

});
define("OutSystemsCharts.model$pieList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$pieRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var pieList = (function (_super) {
__extends(pieList, _super);
function pieList(defaults) {
_super.apply(this, arguments);
}
pieList.itemType = OutSystemsChartsModel.pieRec;
return pieList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.pieList = pieList;

});
define("OutSystemsCharts.model$columnList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$columnRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var columnList = (function (_super) {
__extends(columnList, _super);
function columnList(defaults) {
_super.apply(this, arguments);
}
columnList.itemType = OutSystemsChartsModel.columnRec;
return columnList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.columnList = columnList;

});
define("OutSystemsCharts.model$PointItemList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$PointItemRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var PointItemList = (function (_super) {
__extends(PointItemList, _super);
function PointItemList(defaults) {
_super.apply(this, arguments);
}
PointItemList.itemType = OutSystemsChartsModel.PointItemRec;
return PointItemList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.PointItemList = PointItemList;

});
define("OutSystemsCharts.model$eventsRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$eventsRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var eventsRecord = (function (_super) {
__extends(eventsRecord, _super);
function eventsRecord(defaults) {
_super.apply(this, arguments);
}
eventsRecord.attributesToDeclare = function () {
return [
this.attr("events", "eventsAttr", "events", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.eventsRec());
}, true, OutSystemsChartsModel.eventsRec)
].concat(_super.attributesToDeclare.call(this));
};
eventsRecord.fromStructure = function (str) {
return new eventsRecord(new eventsRecord.RecordClass({
eventsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
eventsRecord._isAnonymousRecord = true;
eventsRecord.UniqueId = "a64921e6-bc48-3cf7-8107-f4a1f446bdab";
eventsRecord.init();
return eventsRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.eventsRecord = eventsRecord;

});
define("OutSystemsCharts.model$labelsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$labelsRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var labelsRecordList = (function (_super) {
__extends(labelsRecordList, _super);
function labelsRecordList(defaults) {
_super.apply(this, arguments);
}
labelsRecordList.itemType = OutSystemsChartsModel.labelsRecord;
return labelsRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.labelsRecordList = labelsRecordList;

});
define("OutSystemsCharts.model$tooltipList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$tooltipRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var tooltipList = (function (_super) {
__extends(tooltipList, _super);
function tooltipList(defaults) {
_super.apply(this, arguments);
}
tooltipList.itemType = OutSystemsChartsModel.tooltipRec;
return tooltipList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.tooltipList = tooltipList;

});
define("OutSystemsCharts.model$eventsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$eventsRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var eventsRecordList = (function (_super) {
__extends(eventsRecordList, _super);
function eventsRecordList(defaults) {
_super.apply(this, arguments);
}
eventsRecordList.itemType = OutSystemsChartsModel.eventsRecord;
return eventsRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.eventsRecordList = eventsRecordList;

});
define("OutSystemsCharts.model$AdvancedDataPointFormatRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$AdvancedDataPointFormatRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var AdvancedDataPointFormatRecordList = (function (_super) {
__extends(AdvancedDataPointFormatRecordList, _super);
function AdvancedDataPointFormatRecordList(defaults) {
_super.apply(this, arguments);
}
AdvancedDataPointFormatRecordList.itemType = OutSystemsChartsModel.AdvancedDataPointFormatRecord;
return AdvancedDataPointFormatRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.AdvancedDataPointFormatRecordList = AdvancedDataPointFormatRecordList;

});
define("OutSystemsCharts.model$barRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$barRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var barRecordList = (function (_super) {
__extends(barRecordList, _super);
function barRecordList(defaults) {
_super.apply(this, arguments);
}
barRecordList.itemType = OutSystemsChartsModel.barRecord;
return barRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.barRecordList = barRecordList;

});
define("OutSystemsCharts.model$SSParameterRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$SSParameterRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var SSParameterRecord = (function (_super) {
__extends(SSParameterRecord, _super);
function SSParameterRecord(defaults) {
_super.apply(this, arguments);
}
SSParameterRecord.attributesToDeclare = function () {
return [
this.attr("SSParameter", "sSParameterAttr", "SSParameter", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.SSParameterRec());
}, true, OutSystemsChartsModel.SSParameterRec)
].concat(_super.attributesToDeclare.call(this));
};
SSParameterRecord.fromStructure = function (str) {
return new SSParameterRecord(new SSParameterRecord.RecordClass({
sSParameterAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SSParameterRecord._isAnonymousRecord = true;
SSParameterRecord.UniqueId = "b8fcab91-4a8d-b6d2-67f3-b00fe18a56d9";
SSParameterRecord.init();
return SSParameterRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.SSParameterRecord = SSParameterRecord;

});
define("OutSystemsCharts.model$SSAdvanceFormatList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$SSAdvanceFormatRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var SSAdvanceFormatList = (function (_super) {
__extends(SSAdvanceFormatList, _super);
function SSAdvanceFormatList(defaults) {
_super.apply(this, arguments);
}
SSAdvanceFormatList.itemType = OutSystemsChartsModel.SSAdvanceFormatRec;
return SSAdvanceFormatList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.SSAdvanceFormatList = SSAdvanceFormatList;

});
define("OutSystemsCharts.model$yAxisList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$yAxisRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var yAxisList = (function (_super) {
__extends(yAxisList, _super);
function yAxisList(defaults) {
_super.apply(this, arguments);
}
yAxisList.itemType = OutSystemsChartsModel.yAxisRec;
return yAxisList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.yAxisList = yAxisList;

});
define("OutSystemsCharts.model$YAxesList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$YAxesRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var YAxesList = (function (_super) {
__extends(YAxesList, _super);
function YAxesList(defaults) {
_super.apply(this, arguments);
}
YAxesList.itemType = OutSystemsChartsModel.YAxesRec;
return YAxesList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.YAxesList = YAxesList;

});
define("OutSystemsCharts.model$pieRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$pieRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var pieRecordList = (function (_super) {
__extends(pieRecordList, _super);
function pieRecordList(defaults) {
_super.apply(this, arguments);
}
pieRecordList.itemType = OutSystemsChartsModel.pieRecord;
return pieRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.pieRecordList = pieRecordList;

});
define("OutSystemsCharts.model$tooltipRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$tooltipRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var tooltipRecordList = (function (_super) {
__extends(tooltipRecordList, _super);
function tooltipRecordList(defaults) {
_super.apply(this, arguments);
}
tooltipRecordList.itemType = OutSystemsChartsModel.tooltipRecord;
return tooltipRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.tooltipRecordList = tooltipRecordList;

});
define("OutSystemsCharts.model$AdvancedFormatRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$AdvancedFormatRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var AdvancedFormatRecordList = (function (_super) {
__extends(AdvancedFormatRecordList, _super);
function AdvancedFormatRecordList(defaults) {
_super.apply(this, arguments);
}
AdvancedFormatRecordList.itemType = OutSystemsChartsModel.AdvancedFormatRecord;
return AdvancedFormatRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.AdvancedFormatRecordList = AdvancedFormatRecordList;

});
define("OutSystemsCharts.model$DataLabelRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$DataLabelRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var DataLabelRecordList = (function (_super) {
__extends(DataLabelRecordList, _super);
function DataLabelRecordList(defaults) {
_super.apply(this, arguments);
}
DataLabelRecordList.itemType = OutSystemsChartsModel.DataLabelRecord;
return DataLabelRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.DataLabelRecordList = DataLabelRecordList;

});
define("OutSystemsCharts.model$areaRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$areaRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var areaRecordList = (function (_super) {
__extends(areaRecordList, _super);
function areaRecordList(defaults) {
_super.apply(this, arguments);
}
areaRecordList.itemType = OutSystemsChartsModel.areaRecord;
return areaRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.areaRecordList = areaRecordList;

});
define("OutSystemsCharts.model$titleList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$titleRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var titleList = (function (_super) {
__extends(titleList, _super);
function titleList(defaults) {
_super.apply(this, arguments);
}
titleList.itemType = OutSystemsChartsModel.titleRec;
return titleList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.titleList = titleList;

});
define("OutSystemsCharts.model$labelsList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$labelsRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var labelsList = (function (_super) {
__extends(labelsList, _super);
function labelsList(defaults) {
_super.apply(this, arguments);
}
labelsList.itemType = OutSystemsChartsModel.labelsRec;
return labelsList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.labelsList = labelsList;

});
define("OutSystemsCharts.model$ChartList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$ChartRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var ChartList = (function (_super) {
__extends(ChartList, _super);
function ChartList(defaults) {
_super.apply(this, arguments);
}
ChartList.itemType = OutSystemsChartsModel.ChartRec;
return ChartList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.ChartList = ChartList;

});
define("OutSystemsCharts.model$stackLabelsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$stackLabelsRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var stackLabelsRecordList = (function (_super) {
__extends(stackLabelsRecordList, _super);
function stackLabelsRecordList(defaults) {
_super.apply(this, arguments);
}
stackLabelsRecordList.itemType = OutSystemsChartsModel.stackLabelsRecord;
return stackLabelsRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.stackLabelsRecordList = stackLabelsRecordList;

});
define("OutSystemsCharts.model$XAxisFormatList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$XAxisFormatRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var XAxisFormatList = (function (_super) {
__extends(XAxisFormatList, _super);
function XAxisFormatList(defaults) {
_super.apply(this, arguments);
}
XAxisFormatList.itemType = OutSystemsChartsModel.XAxisFormatRec;
return XAxisFormatList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.XAxisFormatList = XAxisFormatList;

});
define("OutSystemsCharts.model$legendItemRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$legendItemRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var legendItemRecord = (function (_super) {
__extends(legendItemRecord, _super);
function legendItemRecord(defaults) {
_super.apply(this, arguments);
}
legendItemRecord.attributesToDeclare = function () {
return [
this.attr("legendItem", "legendItemAttr", "legendItem", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsChartsModel.legendItemRec());
}, true, OutSystemsChartsModel.legendItemRec)
].concat(_super.attributesToDeclare.call(this));
};
legendItemRecord.fromStructure = function (str) {
return new legendItemRecord(new legendItemRecord.RecordClass({
legendItemAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
legendItemRecord._isAnonymousRecord = true;
legendItemRecord.UniqueId = "e3944c4e-f711-c65e-410f-9e95395bba61";
legendItemRecord.init();
return legendItemRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsChartsModel.legendItemRecord = legendItemRecord;

});
define("OutSystemsCharts.model$SSChartFormatList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$SSChartFormatRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var SSChartFormatList = (function (_super) {
__extends(SSChartFormatList, _super);
function SSChartFormatList(defaults) {
_super.apply(this, arguments);
}
SSChartFormatList.itemType = OutSystemsChartsModel.SSChartFormatRec;
return SSChartFormatList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.SSChartFormatList = SSChartFormatList;

});
define("OutSystemsCharts.model$barList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$barRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var barList = (function (_super) {
__extends(barList, _super);
function barList(defaults) {
_super.apply(this, arguments);
}
barList.itemType = OutSystemsChartsModel.barRec;
return barList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.barList = barList;

});
define("OutSystemsCharts.model$legendItemRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$legendItemRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var legendItemRecordList = (function (_super) {
__extends(legendItemRecordList, _super);
function legendItemRecordList(defaults) {
_super.apply(this, arguments);
}
legendItemRecordList.itemType = OutSystemsChartsModel.legendItemRecord;
return legendItemRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.legendItemRecordList = legendItemRecordList;

});
define("OutSystemsCharts.model$markerList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$markerRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var markerList = (function (_super) {
__extends(markerList, _super);
function markerList(defaults) {
_super.apply(this, arguments);
}
markerList.itemType = OutSystemsChartsModel.markerRec;
return markerList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.markerList = markerList;

});
define("OutSystemsCharts.model$SSParameterRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$SSParameterRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var SSParameterRecordList = (function (_super) {
__extends(SSParameterRecordList, _super);
function SSParameterRecordList(defaults) {
_super.apply(this, arguments);
}
SSParameterRecordList.itemType = OutSystemsChartsModel.SSParameterRecord;
return SSParameterRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.SSParameterRecordList = SSParameterRecordList;

});
define("OutSystemsCharts.model$stackLabelsList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$stackLabelsRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var stackLabelsList = (function (_super) {
__extends(stackLabelsList, _super);
function stackLabelsList(defaults) {
_super.apply(this, arguments);
}
stackLabelsList.itemType = OutSystemsChartsModel.stackLabelsRec;
return stackLabelsList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.stackLabelsList = stackLabelsList;

});
define("OutSystemsCharts.model$markerRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$markerRecord"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var markerRecordList = (function (_super) {
__extends(markerRecordList, _super);
function markerRecordList(defaults) {
_super.apply(this, arguments);
}
markerRecordList.itemType = OutSystemsChartsModel.markerRecord;
return markerRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.markerRecordList = markerRecordList;

});
define("OutSystemsCharts.model$PlotOptionSerieItemList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$PlotOptionSerieItemRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var PlotOptionSerieItemList = (function (_super) {
__extends(PlotOptionSerieItemList, _super);
function PlotOptionSerieItemList(defaults) {
_super.apply(this, arguments);
}
PlotOptionSerieItemList.itemType = OutSystemsChartsModel.PlotOptionSerieItemRec;
return PlotOptionSerieItemList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.PlotOptionSerieItemList = PlotOptionSerieItemList;

});
define("OutSystemsCharts.model$YAxisFormatList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsCharts.model", "OutSystemsCharts.model$YAxisFormatRec"], function (exports, OutSystems, OutSystemsChartsModel) {
var OS = OutSystems.Internal;
var YAxisFormatList = (function (_super) {
__extends(YAxisFormatList, _super);
function YAxisFormatList(defaults) {
_super.apply(this, arguments);
}
YAxisFormatList.itemType = OutSystemsChartsModel.YAxisFormatRec;
return YAxisFormatList;
})(OS.DataTypes.GenericRecordList);
OutSystemsChartsModel.YAxisFormatList = YAxisFormatList;

});
define("OutSystemsCharts.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var OutSystemsChartsModel = exports;
Object.defineProperty(OutSystemsChartsModel, "module", {
get: function () {
return OS.ApplicationInfo.getModules()["38b70e23-50fc-4710-80cf-3682a9dc998a"];
}
});

OutSystemsChartsModel.staticEntities = {};
OutSystemsChartsModel.staticEntities.stackingType = {};
var getStackingTypeRecord = function (record) {
return OutSystemsChartsModel.module.staticEntities["1aaafcbe-99a5-4857-83f2-e4754e65edcf"][record];
};
Object.defineProperty(OutSystemsChartsModel.staticEntities.stackingType, "stacked100Percent", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getStackingTypeRecord("5a048369-2987-4af5-b052-ab363ac4b748"));
}
});

Object.defineProperty(OutSystemsChartsModel.staticEntities.stackingType, "noStacking", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getStackingTypeRecord("b664d44a-e707-43cc-b782-cc4fd9c3ce8a"));
}
});

Object.defineProperty(OutSystemsChartsModel.staticEntities.stackingType, "stacked", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getStackingTypeRecord("f5816dfa-da3b-4031-aa5f-06a7a08dcc94"));
}
});

OutSystemsChartsModel.staticEntities.legendPosition = {};
var getLegendPositionRecord = function (record) {
return OutSystemsChartsModel.module.staticEntities["6f55558f-9a5c-49bb-bc32-8180c0ac0d73"][record];
};
Object.defineProperty(OutSystemsChartsModel.staticEntities.legendPosition, "bottom", {
get: function () {
return getLegendPositionRecord("24063cd8-b015-4fb7-8ceb-c4cf65110444");
}
});

Object.defineProperty(OutSystemsChartsModel.staticEntities.legendPosition, "right", {
get: function () {
return getLegendPositionRecord("2c2e4610-d5b5-4738-9474-83ca4e40f33b");
}
});

Object.defineProperty(OutSystemsChartsModel.staticEntities.legendPosition, "inside", {
get: function () {
return getLegendPositionRecord("33fda788-9eba-426b-be1d-284323c6ae2a");
}
});

Object.defineProperty(OutSystemsChartsModel.staticEntities.legendPosition, "left", {
get: function () {
return getLegendPositionRecord("5314c097-85bd-407c-84f9-f0ebd17b75ce");
}
});

Object.defineProperty(OutSystemsChartsModel.staticEntities.legendPosition, "hidden", {
get: function () {
return getLegendPositionRecord("6519bee3-d71b-41ae-8e57-a377f8aaa6c3");
}
});

Object.defineProperty(OutSystemsChartsModel.staticEntities.legendPosition, "top", {
get: function () {
return getLegendPositionRecord("e0495156-d508-4fc2-a3ed-77a194c65b49");
}
});

OutSystemsChartsModel.staticEntities.xAxisValuesType = {};
var getXAxisValuesTypeRecord = function (record) {
return OutSystemsChartsModel.module.staticEntities["e24bffa0-82f5-4cd2-9d43-97b142649f77"][record];
};
Object.defineProperty(OutSystemsChartsModel.staticEntities.xAxisValuesType, "text", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getXAxisValuesTypeRecord("31d40404-1f4d-4f1a-8c04-aa7377da778a"));
}
});

Object.defineProperty(OutSystemsChartsModel.staticEntities.xAxisValuesType, "auto", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getXAxisValuesTypeRecord("6599ec19-4160-4794-81cd-6ba06b0bb84d"));
}
});

});
