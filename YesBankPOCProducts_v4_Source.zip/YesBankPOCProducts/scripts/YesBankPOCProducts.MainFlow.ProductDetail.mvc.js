﻿define("YesBankPOCProducts.MainFlow.ProductDetail.mvc$model",["OutSystems/ClientRuntime/Main", "YesBankPOCProducts.model", "YesBankPOCProducts.model$ProductRec", "YesBankPOCProducts.model$ProductRecord", "YesBankPOCProducts.model$ProductRecordList"], function(OutSystems, YesBankPOCProductsModel) {
	var OS = OutSystems.Internal;
	var GetProductByIdAggrRec = (function(_super) {
		__extends(GetProductByIdAggrRec, _super);
		function GetProductByIdAggrRec(defaults) {
			_super.apply(this, arguments);
		}
		GetProductByIdAggrRec.RecordListType = YesBankPOCProductsModel.ProductRecordList;
		GetProductByIdAggrRec.init();
		return GetProductByIdAggrRec;
	}
	) (OS.Model.AggregateRecord);


	var VariablesRecord = (function(_super) {
		__extends(VariablesRecord, _super);
		function VariablesRecord(defaults) {
			_super.apply(this, arguments);
		}
		VariablesRecord.attributesToDeclare = function() {
			return[
			this.attr("ProductId", "productIdIn", "ProductId", true, false, OS.Types.LongInteger, function() {
				return OS.DataTypes.LongInteger.defaultValue;
			}
			, false),
			this.attr("_productIdInDataFetchStatus", "_productIdInDataFetchStatus", "_productIdInDataFetchStatus", true, false, OS.Types.Integer, function() {
				return/*Fetched*/ 1;
			}
			, false),
			this.attr("GetProductById", "getProductByIdAggr", "getProductByIdAggr", true, true, OS.Types.Record, function() {
				return OS.DataTypes.ImmutableBase.getData(new GetProductByIdAggrRec());
			}
			, true, GetProductByIdAggrRec)
			] .concat(_super.attributesToDeclare.call(this));
		};
		VariablesRecord.init();
		return VariablesRecord;
	}
	) (OS.DataTypes.GenericRecord);
	var WidgetsRecord = (function(_super) {
		__extends(WidgetsRecord, _super);
		function WidgetsRecord() {
			_super.apply(this, arguments);
		}
		WidgetsRecord.getWidgetsType = function() {
			return {
				Form1: OS.Model.ValidationWidgetRecord,
				Input_ProductName: OS.Model.ValidationWidgetRecord,
				Input_ProductCode: OS.Model.ValidationWidgetRecord,
				Input_Picture: OS.Model.ValidationWidgetRecord,
				Input_Category: OS.Model.ValidationWidgetRecord,
				Input_ProductDescription: OS.Model.ValidationWidgetRecord,
				Input_DistributorLogo: OS.Model.ValidationWidgetRecord,
				Input_Price: OS.Model.ValidationWidgetRecord,
				Input_DistributorPhone: OS.Model.ValidationWidgetRecord,
				Input_QuantityStock: OS.Model.ValidationWidgetRecord
			};
		};

		return WidgetsRecord;
	}
	) (OS.Model.BaseWidgetRecordMap);
	var Model = (function(_super) {
		__extends(Model, _super);
		function Model() {
			_super.apply(this, arguments);
		}
		Model.getVariablesRecordConstructor = function() {
			return VariablesRecord;
		};
		Model.getWidgetsRecordConstructor = function() {
			return WidgetsRecord;
		};
		Object.defineProperty(Model, "hasValidationWidgets", {
			enumerable: true,
			configurable: true,
			get: function() {
				return true;
			}
		}
		);

		Model.prototype.setInputs = function(inputs) {
			if ("ProductId" in inputs) {
				this.variables.productIdIn = OS.DataConversion.ServerDataConverter.from(inputs.ProductId, OS.Types.LongInteger);
			}

		};
		return Model;
	}
	) (OS.Model.BaseViewModel);
	return new OS.Model.ModelFactory(Model);
});
define("YesBankPOCProducts.MainFlow.ProductDetail.mvc$view",["OutSystems/ClientRuntime/Main", "YesBankPOCProducts.model", "YesBankPOCProducts.controller", "react", "OutSystems/ReactView/Main", "YesBankPOCProducts.MainFlow.ProductDetail.mvc$model", "YesBankPOCProducts.MainFlow.ProductDetail.mvc$controller", "YesBankPOCProducts.clientVariables", "YesBankPOCProducts.Layouts.LayoutTopMenu.mvc$view", "OutSystems/ReactWidgets/Main", "OutSystemsUI.Adaptive.Columns2.mvc$view", "YesBankPOCProducts.Common.Menu.mvc$view", "YesBankPOCProducts.model$ProductRec", "YesBankPOCProducts.model$ProductRecord", "YesBankPOCProducts.model$ProductRecordList"], function(OutSystems, YesBankPOCProductsModel, YesBankPOCProductsController, React, OSView, YesBankPOCProducts_MainFlow_ProductDetail_mvc_model, YesBankPOCProducts_MainFlow_ProductDetail_mvc_controller, YesBankPOCProductsClientVariables, YesBankPOCProducts_Layouts_LayoutTopMenu_mvc_view, OSWidgets, OutSystemsUI_Adaptive_Columns2_mvc_view, YesBankPOCProducts_Common_Menu_mvc_view) {
	var OS = OutSystems.Internal;
	var PlaceholderContent = OSView.Widget.PlaceholderContent;
	var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


	var View = (function(_super) {
		__extends(View, _super);
		function View() {
			try {
				this.initialize.apply(this, arguments);
			} catch (error) {
				View.handleError(error);
				throw error;
			}
		}
		View.prototype.initialize = function() {
			_super.apply(this, arguments);
		};
		View.displayName = "MainFlow.ProductDetail";
		View.getCssDependencies = function() {
			return["css/OutSystemsReactWidgets.css", "css/OutSystemsUI.OutSystemsUI.css", "css/YesBankPOCProducts.YesBankPOCProducts.css", "css/YesBankPOCProducts.YesBankPOCProducts.extra.css"];
		};
		View.getJsDependencies = function() {
			return[];
		};
		View.getBlocks = function() {
			return[YesBankPOCProducts_Layouts_LayoutTopMenu_mvc_view, OutSystemsUI_Adaptive_Columns2_mvc_view, YesBankPOCProducts_Common_Menu_mvc_view];
		};
		Object.defineProperty(View.prototype, "modelFactory", {
			get: function() {
				return YesBankPOCProducts_MainFlow_ProductDetail_mvc_model;
			}
			,
			enumerable: true,
			configurable: true
		});
		Object.defineProperty(View.prototype, "controllerFactory", {
			get: function() {
				return YesBankPOCProducts_MainFlow_ProductDetail_mvc_controller;
			}
			,
			enumerable: true,
			configurable: true
		});
		Object.defineProperty(View.prototype, "title", {
			get: function() {
				return "ProductDetail";
			}
			,
			enumerable: true,
			configurable: true
		});
		View.prototype.internalRender = function() {
			var model = this.model;
			var controller = this.controller;
			var idService = this.idService;
			var validationService = controller.validationService;
			var widgetsRecordProvider = this.widgetsRecordProvider;
			var callContext = controller.callContext();
			var $if = View.ifWidget;
			var $text = View.textWidget;
			var asPrimitiveValue = View.asPrimitiveValue;
			var getTranslation = View.getTranslation;
			var _this = this;

			return React.createElement("div", this.getRootNodeProperties(), React.createElement(YesBankPOCProducts_Layouts_LayoutTopMenu_mvc_view, {
				inputs: {}
				,
				events: {
					_handleError: function(ex) {
						controller.handleError(ex);
					}
				}
				,
				_validationProps: {
					validationService: validationService
				}
				,
				_idProps: {
					service: idService,
					uuid: "0",
					alias: "1"
				}
				,
				_widgetRecordProvider: widgetsRecordProvider,
				placeholders: {
					breadcrumbs: PlaceholderContent.Empty,
					title: new PlaceholderContent(function() {
						return[$if(!(model.variables.productIdIn.equals(OS.BuiltinFunctions.integerToLongInteger(OS.BuiltinFunctions.nullIdentifier()))), false, this, function() {
							return[React.createElement(OSWidgets.AdvancedHtml, {
								tag: "h1",
								_idProps: {
									service: idService,
									uuid: "1"
								}
								,
								_widgetRecordProvider: widgetsRecordProvider
							}
							, "Edit Product")];
						}
						, function() {
							return[React.createElement(OSWidgets.AdvancedHtml, {
								tag: "h1",
								_idProps: {
									service: idService,
									uuid: "2"
								}
								,
								_widgetRecordProvider: widgetsRecordProvider
							}
							, "New Product")];
						})];
					}),
					actions: PlaceholderContent.Empty,
					mainContent: new PlaceholderContent(function() {
						return[React.createElement(OutSystemsUI_Adaptive_Columns2_mvc_view, {
							inputs: {
								PhoneBehavior: YesBankPOCProductsModel.staticEntities.breakColumns.all
							}
							,
							events: {
								_handleError: function(ex) {
									controller.handleError(ex);
								}
							}
							,
							_validationProps: {
								validationService: validationService
							}
							,
							_idProps: {
								service: idService,
								uuid: "3",
								alias: "2"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider,
							placeholders: {
								column1: new PlaceholderContent(function() {
									return[React.createElement(OSWidgets.Form, {
										_validationProps: {
											validationService: validationService
										}
										,
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										style: "form card",
										_idProps: {
											service: idService,
											name: "Form1"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, React.createElement(OSWidgets.Container, {
										align:/*Default*/ 0,
										animate: false,
										visible: true,
										_idProps: {
											service: idService,
											uuid: "5"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, React.createElement(OSWidgets.Label, {
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										mandatory: false,
										targetWidget: "Input_ProductName",
										_idProps: {
											service: idService,
											uuid: "6"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, "Product Name"), React.createElement(OSWidgets.Input, {
										_validationProps: {
											validationService: validationService,
											validationParentId: idService.getId("Form1")
										}
										,
										enabled: true,
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										inputType:/*Text*/ 0,
										mandatory: false,
										maxLength: 50,
										style: "form-control",
										variable: model.createVariable(OS.Types.Text, model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.productNameAttr, function(value) {
											model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.productNameAttr = value;
										}),
										_idProps: {
											service: idService,
											name: "Input_ProductName"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										variable_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getProductByIdAggr.dataFetchStatusAttr)
									})), React.createElement(OSWidgets.Container, {
										align:/*Default*/ 0,
										animate: false,
										visible: true,
										_idProps: {
											service: idService,
											uuid: "8"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, React.createElement(OSWidgets.Label, {
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										mandatory: false,
										targetWidget: "Input_ProductCode",
										_idProps: {
											service: idService,
											uuid: "9"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, "Product Code"), React.createElement(OSWidgets.Input, {
										_validationProps: {
											validationService: validationService,
											validationParentId: idService.getId("Form1")
										}
										,
										enabled: true,
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										inputType:/*Text*/ 0,
										mandatory: false,
										maxLength: 50,
										style: "form-control",
										variable: model.createVariable(OS.Types.Text, model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.productCodeAttr, function(value) {
											model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.productCodeAttr = value;
										}),
										_idProps: {
											service: idService,
											name: "Input_ProductCode"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										variable_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getProductByIdAggr.dataFetchStatusAttr)
									})), React.createElement(OSWidgets.Container, {
										align:/*Default*/ 0,
										animate: false,
										visible: true,
										_idProps: {
											service: idService,
											uuid: "11"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, React.createElement(OSWidgets.Label, {
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										mandatory: false,
										targetWidget: "Input_Picture",
										_idProps: {
											service: idService,
											uuid: "12"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, "Picture"), React.createElement(OSWidgets.Input, {
										_validationProps: {
											validationService: validationService,
											validationParentId: idService.getId("Form1")
										}
										,
										enabled: true,
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										inputType:/*Text*/ 0,
										mandatory: false,
										maxLength: 100,
										style: "form-control",
										variable: model.createVariable(OS.Types.Text, model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.pictureAttr, function(value) {
											model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.pictureAttr = value;
										}),
										_idProps: {
											service: idService,
											name: "Input_Picture"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										variable_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getProductByIdAggr.dataFetchStatusAttr)
									})), React.createElement(OSWidgets.Container, {
										align:/*Default*/ 0,
										animate: false,
										visible: true,
										_idProps: {
											service: idService,
											uuid: "14"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, React.createElement(OSWidgets.Label, {
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										mandatory: false,
										targetWidget: "Input_Category",
										_idProps: {
											service: idService,
											uuid: "15"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, "Category"), React.createElement(OSWidgets.Input, {
										_validationProps: {
											validationService: validationService,
											validationParentId: idService.getId("Form1")
										}
										,
										enabled: true,
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										inputType:/*Text*/ 0,
										mandatory: false,
										maxLength: 50,
										style: "form-control",
										variable: model.createVariable(OS.Types.Text, model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.categoryAttr, function(value) {
											model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.categoryAttr = value;
										}),
										_idProps: {
											service: idService,
											name: "Input_Category"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										variable_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getProductByIdAggr.dataFetchStatusAttr)
									})), React.createElement(OSWidgets.Container, {
										align:/*Default*/ 0,
										animate: false,
										visible: true,
										_idProps: {
											service: idService,
											uuid: "17"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, React.createElement(OSWidgets.Label, {
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										mandatory: false,
										targetWidget: "Input_ProductDescription",
										_idProps: {
											service: idService,
											uuid: "18"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, "Product Description"), React.createElement(OSWidgets.Input, {
										_validationProps: {
											validationService: validationService,
											validationParentId: idService.getId("Form1")
										}
										,
										enabled: true,
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										inputType:/*Text*/ 0,
										mandatory: false,
										maxLength: 250,
										style: "form-control",
										variable: model.createVariable(OS.Types.Text, model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.productDescriptionAttr, function(value) {
											model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.productDescriptionAttr = value;
										}),
										_idProps: {
											service: idService,
											name: "Input_ProductDescription"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										variable_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getProductByIdAggr.dataFetchStatusAttr)
									})), React.createElement(OSWidgets.Container, {
										align:/*Default*/ 0,
										animate: false,
										visible: true,
										_idProps: {
											service: idService,
											uuid: "20"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, React.createElement(OSWidgets.Label, {
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										mandatory: false,
										targetWidget: "Input_DistributorLogo",
										_idProps: {
											service: idService,
											uuid: "21"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, "Distributor Logo"), React.createElement(OSWidgets.Input, {
										_validationProps: {
											validationService: validationService,
											validationParentId: idService.getId("Form1")
										}
										,
										enabled: true,
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										inputType:/*Text*/ 0,
										mandatory: false,
										maxLength: 100,
										style: "form-control",
										variable: model.createVariable(OS.Types.Text, model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.distributorLogoAttr, function(value) {
											model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.distributorLogoAttr = value;
										}),
										_idProps: {
											service: idService,
											name: "Input_DistributorLogo"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										variable_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getProductByIdAggr.dataFetchStatusAttr)
									})), React.createElement(OSWidgets.Container, {
										align:/*Default*/ 0,
										animate: false,
										visible: true,
										_idProps: {
											service: idService,
											uuid: "23"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, React.createElement(OSWidgets.Label, {
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										mandatory: false,
										targetWidget: "Input_Price",
										_idProps: {
											service: idService,
											uuid: "24"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, "Price"), React.createElement(OSWidgets.Input, {
										_validationProps: {
											validationService: validationService,
											validationParentId: idService.getId("Form1")
										}
										,
										enabled: true,
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										inputType:/*Number*/ 2,
										mandatory: false,
										maxLength: 0,
										style: "form-control",
										variable: model.createVariable(OS.Types.Integer, model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.priceAttr, function(value) {
											model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.priceAttr = value;
										}),
										_idProps: {
											service: idService,
											name: "Input_Price"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										variable_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getProductByIdAggr.dataFetchStatusAttr)
									})), React.createElement(OSWidgets.Container, {
										align:/*Default*/ 0,
										animate: false,
										visible: true,
										_idProps: {
											service: idService,
											uuid: "26"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, React.createElement(OSWidgets.Label, {
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										mandatory: false,
										targetWidget: "Input_DistributorPhone",
										_idProps: {
											service: idService,
											uuid: "27"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, "Distributor Phone"), React.createElement(OSWidgets.Input, {
										_validationProps: {
											validationService: validationService,
											validationParentId: idService.getId("Form1")
										}
										,
										enabled: true,
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										inputType:/*Number*/ 2,
										mandatory: false,
										maxLength: 37,
										style: "form-control",
										variable: model.createVariable(OS.Types.Decimal, model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.distributorPhoneAttr, function(value) {
											model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.distributorPhoneAttr = value;
										}),
										_idProps: {
											service: idService,
											name: "Input_DistributorPhone"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										variable_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getProductByIdAggr.dataFetchStatusAttr)
									})), React.createElement(OSWidgets.Container, {
										align:/*Default*/ 0,
										animate: false,
										visible: true,
										_idProps: {
											service: idService,
											uuid: "29"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, React.createElement(OSWidgets.Label, {
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										mandatory: false,
										targetWidget: "Input_QuantityStock",
										_idProps: {
											service: idService,
											uuid: "30"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, "Quantity Stock"), React.createElement(OSWidgets.Input, {
										_validationProps: {
											validationService: validationService,
											validationParentId: idService.getId("Form1")
										}
										,
										enabled: true,
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										inputType:/*Number*/ 2,
										mandatory: false,
										maxLength: 0,
										style: "form-control",
										variable: model.createVariable(OS.Types.Integer, model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.quantityStockAttr, function(value) {
											model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.quantityStockAttr = value;
										}),
										_idProps: {
											service: idService,
											name: "Input_QuantityStock"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										variable_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getProductByIdAggr.dataFetchStatusAttr)
									})), React.createElement(OSWidgets.Container, {
										align:/*Default*/ 0,
										animate: false,
										visible: true,
										_idProps: {
											service: idService,
											uuid: "32"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, React.createElement(OSWidgets.Button, {
										enabled: true,
										isDefault: false,
										onClick: function() {
											OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("YesBankPOCProducts", "Products", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default));
										}
										,
										style: "btn",
										visible: true,
										_idProps: {
											service: idService,
											uuid: "33"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, "Back"), React.createElement(OSWidgets.Button, {
										enabled: true,
										gridProperties: {
											classes: "ThemeGrid_MarginGutter"
										}
										,
										isDefault: true,
										onClick: function() {
											_this.validateWidget(idService.getId("Form1"));
											return Promise.resolve().then(function() {
												var eventHandlerContext = callContext.clone();
												controller.saveDetail$Action(controller.callContext(eventHandlerContext));
											});

											;
										}
										,
										style: "btn btn-primary",
										visible: true,
										_idProps: {
											service: idService,
											uuid: "34"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, "Save")))];
								}),
								column2: new PlaceholderContent(function() {
									return[React.createElement(OSWidgets.Image, {
										extendedProperties: {
											alt: "",
											style: "margin-top: 0px;"
										}
										,
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										image: OS.Navigation.VersionedURL.getVersionedUrl("img/YesBankPOCProducts.Request.png"),
										type:/*Static*/ 0,
										_idProps: {
											service: idService,
											uuid: "35"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									})];
								})
							}
							,
							_dependencies:[asPrimitiveValue(model.variables.getProductByIdAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.quantityStockAttr), asPrimitiveValue(model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.distributorPhoneAttr), asPrimitiveValue(model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.priceAttr), asPrimitiveValue(model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.distributorLogoAttr), asPrimitiveValue(model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.productDescriptionAttr), asPrimitiveValue(model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.categoryAttr), asPrimitiveValue(model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.pictureAttr), asPrimitiveValue(model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.productCodeAttr), asPrimitiveValue(model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.productNameAttr)]
						})];
					}),
					footer: PlaceholderContent.Empty,
					header: new PlaceholderContent(function() {
						return[React.createElement(YesBankPOCProducts_Common_Menu_mvc_view, {
							inputs: {}
							,
							events: {
								_handleError: function(ex) {
									controller.handleError(ex);
								}
							}
							,
							_validationProps: {
								validationService: validationService
							}
							,
							_idProps: {
								service: idService,
								uuid: "36",
								alias: "3"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider,
							_dependencies:[]
						})];
					})
				}
				,
				_dependencies:[asPrimitiveValue(model.variables.getProductByIdAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.quantityStockAttr), asPrimitiveValue(model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.distributorPhoneAttr), asPrimitiveValue(model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.priceAttr), asPrimitiveValue(model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.distributorLogoAttr), asPrimitiveValue(model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.productDescriptionAttr), asPrimitiveValue(model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.categoryAttr), asPrimitiveValue(model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.pictureAttr), asPrimitiveValue(model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.productCodeAttr), asPrimitiveValue(model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr.productNameAttr), asPrimitiveValue(model.variables.productIdIn)]
			}));
		};
		return View;
	})(OSView.BaseView.BaseWebScreen);

	return View;
});
define("YesBankPOCProducts.MainFlow.ProductDetail.mvc$controller",["OutSystems/ClientRuntime/Main", "YesBankPOCProducts.model", "YesBankPOCProducts.controller", "YesBankPOCProducts.languageResources", "YesBankPOCProducts.clientVariables", "YesBankPOCProducts.MainFlow.controller", "YesBankPOCProducts.model$ProductRec", "YesBankPOCProducts.model$ProductRecord", "YesBankPOCProducts.model$ProductRecordList"], function(OutSystems, YesBankPOCProductsModel, YesBankPOCProductsController, YesBankPOCProductsLanguageResources, YesBankPOCProductsClientVariables, YesBankPOCProducts_MainFlowController) {
	var OS = OutSystems.Internal;
	var Controller = (function(_super) {
		__extends(Controller, _super);
		function Controller() {
			_super.apply(this, arguments);
			var controller = this.controller;
			this.clientActionProxies = {};
			this.dataFetchDependenciesOriginal = {
				getProductById$AggrRefresh: 0
			};
			this.dataFetchDependentsGraph = {
				getProductById$AggrRefresh:[]
			};
			this.shouldSendClientVarsToDataSources = false;
		}
		// Server Actions
		Controller.prototype.productCreateOrUpdate$ServerAction = function(sourceIn, callContext) {
			var controller = this.controller;
			var inputs = {
				Source: OS.DataConversion.ServerDataConverter.to(sourceIn, OS.Types.Record)
			};
			return controller.callServerAction("ProductCreateOrUpdate", "screenservices/YesBankPOCProducts/MainFlow/ProductDetail/ActionProductCreateOrUpdate", "uwngbmpSceQA05jidSn26g", inputs, controller.callContext(callContext), undefined, undefined, false).then(function(outputs) {
				var executeServerActionResult = new(controller.constructor.getVariableGroupType("YesBankPOCProducts.MainFlow.ProductDetail$ActionProductCreateOrUpdate")) ();
				executeServerActionResult.idOut = OS.DataConversion.ServerDataConverter.from(outputs.Id, OS.Types.LongInteger);
				return executeServerActionResult;
			}
			);
		};
		Controller.registerVariableGroupType("YesBankPOCProducts.MainFlow.ProductDetail$ActionProductCreateOrUpdate",[ {
			name: "Id",
			attrName: "idOut",
			mandatory: false,
			dataType: OS.Types.LongInteger,
			defaultValue: function() {
				return OS.DataTypes.LongInteger.defaultValue;
			}
		}
		]);

		// Aggregates and Data Actions
		Controller.prototype.getProductById$AggrRefresh = function(maxRecords, startIndex, callContext) {
			var model = this.model;
			var controller = this.controller;
			var callContext = controller.callContext(callContext);
			return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetProductById", "screenservices/YesBankPOCProducts/MainFlow/ProductDetail/ScreenDataSetGetProductById", "EMmhJdZRTuJb55UcCRKJUg", maxRecords, startIndex, function(b) {
				model.variables.getProductByIdAggr.dataFetchStatusAttr = b;
			}
			, function(json) {
				model.variables.getProductByIdAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getProductByIdAggr.constructor));
			}
			, undefined, undefined, undefined, callContext, undefined, false);
		};

		Controller.prototype.dataFetchActionNames =["getProductById$AggrRefresh"];
		// Client Actions
		Controller.prototype._saveDetail$Action = function(callContext) {
			var model = this.model;
			var controller = this.controller;
			var idService = this.idService;
			controller.ensureControllerAlive("SaveDetail");
			callContext = controller.callContext(callContext);
			var productCreateOrUpdateVar = new OS.DataTypes.VariableHolder();
			return OS.Flow.executeAsyncFlow(function() {
				return OS.Flow.executeSequence(function() {
					if ((model.widgets.get(idService.getId("Form1")).validAttr)) {
						// Execute Action: ProductCreateOrUpdate
						model.flush();
						return controller.productCreateOrUpdate$ServerAction(model.variables.getProductByIdAggr.listOut.getCurrent(callContext.iterationContext).productAttr, callContext).then(function(value) {
							productCreateOrUpdateVar.value = value;
						}
						).then(function() {
							// Destination: /YesBankPOCProducts/Products
							return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("YesBankPOCProducts", "Products", {}
							), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true));
						}
						);
					} else {
						OS.FeedbackMessageService.showFeedbackMessage("Navigate to another screen or implement the required logic.",/*Info*/ 0);
					}

				}
				);
			}
			);
		};

		Controller.prototype.saveDetail$Action = function(callContext) {
			var controller = this.controller;
			return controller.safeExecuteClientAction(controller._saveDetail$Action, callContext);

		};

		// Event Handler Actions
		Controller.prototype.onInitializeEventHandler = null;
		Controller.prototype.onReadyEventHandler = null;
		Controller.prototype.onRenderEventHandler = null;
		Controller.prototype.onDestroyEventHandler = null;
		Controller.prototype.onParametersChangedEventHandler = null;
		Controller.prototype.handleError = function(ex) {
			return YesBankPOCProducts_MainFlowController.default.handleError(ex, this.callContext());
		};
		Controller.checkPermissions = function() {
		};
		Controller.prototype.getDefaultTimeout = function() {
			return YesBankPOCProductsController.default.defaultTimeout;
		};
		return Controller;
	}
	) (OS.Controller.BaseViewController);
	return new OS.Controller.ControllerFactory(Controller, YesBankPOCProductsLanguageResources);
});

