﻿define("OutSystemsUI.Interaction.Search.mvc$model", ["OutSystems/ClientRuntime/Main", "OutSystemsUI.model"], function (OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("IsOpen", "isOpenVar", "IsOpen", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("ExtendedClass", "extendedClassIn", "ExtendedClass", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("_extendedClassInDataFetchStatus", "_extendedClassInDataFetchStatus", "_extendedClassInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return false;
}
});

Model.prototype.setInputs = function (inputs) {
if("ExtendedClass" in inputs) {
this.variables.extendedClassIn = inputs.ExtendedClass;
if("_extendedClassInDataFetchStatus" in inputs) {
this.variables._extendedClassInDataFetchStatus = inputs._extendedClassInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model);
});
define("OutSystemsUI.Interaction.Search.mvc$view", ["OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "react", "OutSystems/ReactView/Main", "OutSystemsUI.Interaction.Search.mvc$model", "OutSystemsUI.Interaction.Search.mvc$controller", "OutSystems/ReactWidgets/Main"], function (OutSystems, OutSystemsUIModel, OutSystemsUIController, React, OSView, OutSystemsUI_Interaction_Search_mvc_model, OutSystemsUI_Interaction_Search_mvc_controller, OSWidgets) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Interaction.Search";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return ["scripts/OutSystemsUI.OutSystemsUI.js"];
        };
        View.getBlocks = function() {
            return [];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return OutSystemsUI_Interaction_Search_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return OutSystemsUI_Interaction_Search_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), $if(false, false, this, function () {
return [];
}, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
role: "search"
},
style: model.getCachedValue(idService.getId("S6aijVciXEGbtICZX3Gl3g.Style"), function () {
return ((("search " + ((model.variables.isOpenVar) ? ("open") : (""))) + " ") + model.variables.extendedClassIn);
}, function () {
return model.variables.isOpenVar;
}, function () {
return model.variables.extendedClassIn;
}),
visible: true,
_idProps: {
service: idService,
uuid: "0"
},
_widgetRecordProvider: widgetsRecordProvider,
style_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._extendedClassInDataFetchStatus)
}, React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.input,
style: "search-input",
_idProps: {
service: idService,
name: "Input"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedEvents: {
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Interaction/Search/Container onclick");
return controller.expandOrCollapse$Action(controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
}
},
style: "search-glass",
visible: true,
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "search-stick-bottom",
visible: true,
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "search-round",
visible: true,
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
})))];
}));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("OutSystemsUI.Interaction.Search.mvc$controller", ["OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.languageResources", "OutSystemsUI.Interaction.Search.mvc$translationsResources", "OutSystemsUI.Interaction.Search.mvc$debugger", "OutSystemsUI.Interaction.Search.mvc$controller.OnReady.InputFilledJS", "OutSystemsUI.Interaction.Search.mvc$controller.ExpandOrCollapse.FocusInputJS"], function (OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUILanguageResources, OutSystemsUI_Interaction_Search_mvc_TranslationsResources, OutSystemsUI_Interaction_Search_mvc_Debugger, OutSystemsUI_Interaction_Search_mvc_controller_OnReady_InputFilledJS, OutSystemsUI_Interaction_Search_mvc_controller_ExpandOrCollapse_FocusInputJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
Controller.prototype.translationResources = OutSystemsUI_Interaction_Search_mvc_TranslationsResources;
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._onReady$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnReady");
callContext = controller.callContext(callContext);
var inputFilledJSResult = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.inputFilledJSResult = inputFilledJSResult;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:Lq9nELH65UGZkcywrIMfIA:/NRWebFlows.qQS9OZYcu0SRmBsR92a4Og/NodesShownInESpaceTree.3qsnfpvavE6r2dHV85K20w/ClientActions.Lq9nELH65UGZkcywrIMfIA:b387trCAqpYeEoh5L+zUYA", "OutSystemsUI", "OnReady", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:DcDelN+6VUKnufCkYD9ZDg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:xFtjKsEK3U6v+Ll2ITv6jQ", callContext.id);
inputFilledJSResult.value = controller.safeExecuteJSNode(OutSystemsUI_Interaction_Search_mvc_controller_OnReady_InputFilledJS, "InputFilled", "OnReady", {
WidgetId: OS.DataConversion.JSNodeParamConverter.to(idService.getId("Input"), OS.Types.Text),
HasValue: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsUI.Interaction.Search.OnReady$inputFilledJSResult"))();
jsNodeResult.hasValueOut = OS.DataConversion.JSNodeParamConverter.from($parameters.HasValue, OS.Types.Boolean);
return jsNodeResult;
}, {}, {});
if((OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:BbzDn6+olkq0gL1cOHIz0A", callContext.id) && inputFilledJSResult.value.hasValueOut)) {
// Open Search
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ke4bzN+UkUWw17zqaIUEvQ", callContext.id);
// IsOpen = True
model.variables.isOpenVar = true;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:X__FwlHAxkioP3k7J6KuGA", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:T14OJijJZE6bcLk2sJpcwA", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:Lq9nELH65UGZkcywrIMfIA", callContext.id);
}

};
Controller.registerVariableGroupType("OutSystemsUI.Interaction.Search.OnReady$inputFilledJSResult", [{
name: "HasValue",
attrName: "hasValueOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Controller.prototype._expandOrCollapse$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("ExpandOrCollapse");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:q9wV0NZwjEW71eQxeDR13g:/NRWebFlows.qQS9OZYcu0SRmBsR92a4Og/NodesShownInESpaceTree.3qsnfpvavE6r2dHV85K20w/ClientActions.q9wV0NZwjEW71eQxeDR13g:BcIaQI6X0p+SyBbUAMfmhA", "OutSystemsUI", "ExpandOrCollapse", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:5BBWgMKywU2+S_QXjvIvhw", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
// Toggle Open
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:KfUYxyww5kG8maoVKRcR2Q", callContext.id);
// IsOpen = notIsOpen
model.variables.isOpenVar = !(model.variables.isOpenVar);
// Collapsed?
return OS.Flow.executeSequence(function () {
if((OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ML+GJCGnZ0mrWJt7HDtlJg", callContext.id) && !(model.variables.isOpenVar))) {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:rFypZC5G5UKajdBho5isJA", callContext.id);
// Trigger Event: OnCollapse
return controller.onCollapse$Action(callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:6NBIJBg09EK4FZ48nZrLSw", callContext.id);
});
} else {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:oRY7fbYAeUiRB22NOwTEnA", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_Interaction_Search_mvc_controller_ExpandOrCollapse_FocusInputJS, "FocusInput", "ExpandOrCollapse", {
WidgetId: OS.DataConversion.JSNodeParamConverter.to(idService.getId("Input"), OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:z3WqDnfteU2medKSnqhh6w", callContext.id);
}

});
}).then(function (res) {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:q9wV0NZwjEW71eQxeDR13g", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:q9wV0NZwjEW71eQxeDR13g", callContext.id);
throw ex;

});
};

Controller.prototype.onReady$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

};
Controller.prototype.expandOrCollapse$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._expandOrCollapse$Action, callContext);

};
Controller.prototype.onCollapse$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:qQS9OZYcu0SRmBsR92a4Og:/NRWebFlows.qQS9OZYcu0SRmBsR92a4Og:cCeye6FxgU_f6ZKcVQfbmQ", "OutSystemsUI", "Interaction", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:3qsnfpvavE6r2dHV85K20w:/NRWebFlows.qQS9OZYcu0SRmBsR92a4Og/NodesShownInESpaceTree.3qsnfpvavE6r2dHV85K20w:bnVNKcva7fxn3_j8tg0I2g", "OutSystemsUI", "Search", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:3qsnfpvavE6r2dHV85K20w", callContext.id);
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:qQS9OZYcu0SRmBsR92a4Og", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Interaction/Search On Ready");
return controller.onReady$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return OutSystemsUIController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, OutSystemsUILanguageResources);
});
define("OutSystemsUI.Interaction.Search.mvc$controller.OnReady.InputFilledJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.HasValue = false;

// Check if there is any input inside the placeholder and if so, checks if it is has value
var input = document.getElementById($parameters.WidgetId).querySelector('input');

if (input) {
    $parameters.HasValue = input.value !== '';
}
};
});
define("OutSystemsUI.Interaction.Search.mvc$controller.ExpandOrCollapse.FocusInputJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
//Focus on input inside placeholder only if no value is already there
var input = document.getElementById($parameters.WidgetId).querySelector('input');

if (input && input.value === '') {
    setTimeout(function() { input.focus(); }, 300);
}
};
});

define("OutSystemsUI.Interaction.Search.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"xFtjKsEK3U6v+Ll2ITv6jQ": {
getter: function (varBag, idService) {
return varBag.inputFilledJSResult.value;
}
},
"oRY7fbYAeUiRB22NOwTEnA": {
getter: function (varBag, idService) {
return varBag.focusInputJSResult.value;
}
},
"61+h0s4EtE2XeI4iFTCyhg": {
getter: function (varBag, idService) {
return varBag.model.variables.isOpenVar;
},
dataType: OS.Types.Boolean
},
"yrw28DgeRU6iyL0mAR2ztg": {
getter: function (varBag, idService) {
return varBag.model.variables.extendedClassIn;
},
dataType: OS.Types.Text
},
"WmlvkOpYZkWSp4cCamuWDw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
define("OutSystemsUI.Interaction.Search.mvc$translationsResources", ["exports"], function (exports) {
return {};
});
