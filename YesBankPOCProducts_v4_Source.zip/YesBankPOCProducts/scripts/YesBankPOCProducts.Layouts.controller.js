﻿define("YesBankPOCProducts.Layouts.controller",["exports", "OutSystems/ClientRuntime/Main", "YesBankPOCProducts.model", "YesBankPOCProducts.controller", "YesBankPOCProducts.Common.controller", "YesBankPOCProducts.clientVariables"], function(exports, OutSystems, YesBankPOCProductsModel, YesBankPOCProductsController, YesBankPOCProducts_CommonController, YesBankPOCProductsClientVariables) {
	var OS = OutSystems.Internal;
	var YesBankPOCProducts_LayoutsController = exports;
	var Controller = (function(_super) {
		__extends(Controller, _super);
		function Controller() {
			_super.apply(this, arguments);
		}
		Controller.prototype.getDefaultTimeout = function() {
			return YesBankPOCProductsController.default.defaultTimeout;
		};
		Controller.prototype.handleError = function(ex, callContext) {
			var controller = this.controller;
			OS.Logger.trace("Layouts", OS.Exceptions.getMessage(ex), ex.name);
			return YesBankPOCProducts_CommonController.default.handleError(ex, callContext);


		};
		return Controller;
	}
	) (OS.Controller.BaseController);
	YesBankPOCProducts_LayoutsController.default = new Controller();
});

