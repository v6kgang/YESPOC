﻿define("YesBankPOCProducts.referencesHealth$OutSystemsCharts",[], function() {
	// Reference to producer 'OutSystemsCharts' is OK.
});
define("YesBankPOCProducts.referencesHealth$OutSystemsMaps",[], function() {
	// Reference to producer 'OutSystemsMaps' is OK.
});
define("YesBankPOCProducts.referencesHealth$OutSystemsSampleDataDB",[], function() {
	// Reference to producer 'OutSystemsSampleDataDB' is OK.
});
define("YesBankPOCProducts.referencesHealth$OutSystemsUI",[], function() {
	// Reference to producer 'OutSystemsUI' is OK.
});
define("YesBankPOCProducts.referencesHealth$ServiceCenter",[], function() {
	// Reference to producer 'ServiceCenter' is OK.
});
define("YesBankPOCProducts.referencesHealth$Users",[], function() {
	// Reference to producer 'Users' is OK.
});
define("YesBankPOCProducts.referencesHealth",[], function() {
});
