﻿define("YesBankPOCProducts.MainFlow.Products.mvc$model",["OutSystems/ClientRuntime/Main", "YesBankPOCProducts.model", "YesBankPOCProducts.model$ProductRecordList"], function(OutSystems, YesBankPOCProductsModel) {
	var OS = OutSystems.Internal;
	var GetProductsAggrRec = (function(_super) {
		__extends(GetProductsAggrRec, _super);
		function GetProductsAggrRec(defaults) {
			_super.apply(this, arguments);
		}
		GetProductsAggrRec.RecordListType = YesBankPOCProductsModel.ProductRecordList;
		GetProductsAggrRec.init();
		return GetProductsAggrRec;
	}
	) (OS.Model.AggregateRecord);


	var VariablesRecord = (function(_super) {
		__extends(VariablesRecord, _super);
		function VariablesRecord(defaults) {
			_super.apply(this, arguments);
		}
		VariablesRecord.attributesToDeclare = function() {
			return[
			this.attr("SearchKeyword", "searchKeywordVar", "SearchKeyword", true, false, OS.Types.Text, function() {
				return "";
			}
			, false),
			this.attr("StartIndex", "startIndexVar", "StartIndex", true, false, OS.Types.Integer, function() {
				return 0;
			}
			, false),
			this.attr("MaxRecords", "maxRecordsVar", "MaxRecords", true, false, OS.Types.Integer, function() {
				return 10;
			}
			, false),
			this.attr("TableSort", "tableSortVar", "TableSort", true, false, OS.Types.Text, function() {
				return "";
			}
			, false),
			this.attr("GetProducts", "getProductsAggr", "getProductsAggr", true, true, OS.Types.Record, function() {
				return OS.DataTypes.ImmutableBase.getData(new GetProductsAggrRec());
			}
			, true, GetProductsAggrRec)
			] .concat(_super.attributesToDeclare.call(this));
		};
		VariablesRecord.init();
		return VariablesRecord;
	}
	) (OS.DataTypes.GenericRecord);
	var WidgetsRecord = (function(_super) {
		__extends(WidgetsRecord, _super);
		function WidgetsRecord() {
			_super.apply(this, arguments);
		}
		WidgetsRecord.getWidgetsType = function() {
			return {
				Input_TextVar: OS.Model.ValidationWidgetRecord
			};
		};

		return WidgetsRecord;
	}
	) (OS.Model.BaseWidgetRecordMap);
	var Model = (function(_super) {
		__extends(Model, _super);
		function Model() {
			_super.apply(this, arguments);
		}
		Model.getVariablesRecordConstructor = function() {
			return VariablesRecord;
		};
		Model.getWidgetsRecordConstructor = function() {
			return WidgetsRecord;
		};
		Object.defineProperty(Model, "hasValidationWidgets", {
			enumerable: true,
			configurable: true,
			get: function() {
				return true;
			}
		}
		);

		Model.prototype.setInputs = function(inputs) {
		};
		return Model;
	}
	) (OS.Model.BaseViewModel);
	return new OS.Model.ModelFactory(Model);
});
define("YesBankPOCProducts.MainFlow.Products.mvc$view",["OutSystems/ClientRuntime/Main", "YesBankPOCProducts.model", "YesBankPOCProducts.controller", "react", "OutSystems/ReactView/Main", "YesBankPOCProducts.MainFlow.Products.mvc$model", "YesBankPOCProducts.MainFlow.Products.mvc$controller", "YesBankPOCProducts.clientVariables", "YesBankPOCProducts.Layouts.LayoutTopMenu.mvc$view", "OutSystems/ReactWidgets/Main", "OutSystemsUI.Interaction.Search.mvc$view", "OutSystemsUI.Utilities.AlignCenter.mvc$view", "OutSystemsUI.Navigation.Pagination.mvc$view", "YesBankPOCProducts.Common.Menu.mvc$view", "YesBankPOCProducts.model$ProductRecordList"], function(OutSystems, YesBankPOCProductsModel, YesBankPOCProductsController, React, OSView, YesBankPOCProducts_MainFlow_Products_mvc_model, YesBankPOCProducts_MainFlow_Products_mvc_controller, YesBankPOCProductsClientVariables, YesBankPOCProducts_Layouts_LayoutTopMenu_mvc_view, OSWidgets, OutSystemsUI_Interaction_Search_mvc_view, OutSystemsUI_Utilities_AlignCenter_mvc_view, OutSystemsUI_Navigation_Pagination_mvc_view, YesBankPOCProducts_Common_Menu_mvc_view) {
	var OS = OutSystems.Internal;
	var PlaceholderContent = OSView.Widget.PlaceholderContent;
	var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


	var View = (function(_super) {
		__extends(View, _super);
		function View() {
			try {
				this.initialize.apply(this, arguments);
			} catch (error) {
				View.handleError(error);
				throw error;
			}
		}
		View.prototype.initialize = function() {
			_super.apply(this, arguments);
		};
		View.displayName = "MainFlow.Products";
		View.getCssDependencies = function() {
			return["css/OutSystemsReactWidgets.css", "css/OutSystemsUI.OutSystemsUI.css", "css/YesBankPOCProducts.YesBankPOCProducts.css", "css/YesBankPOCProducts.YesBankPOCProducts.extra.css"];
		};
		View.getJsDependencies = function() {
			return[];
		};
		View.getBlocks = function() {
			return[YesBankPOCProducts_Layouts_LayoutTopMenu_mvc_view, OutSystemsUI_Interaction_Search_mvc_view, OutSystemsUI_Utilities_AlignCenter_mvc_view, OutSystemsUI_Navigation_Pagination_mvc_view, YesBankPOCProducts_Common_Menu_mvc_view];
		};
		Object.defineProperty(View.prototype, "modelFactory", {
			get: function() {
				return YesBankPOCProducts_MainFlow_Products_mvc_model;
			}
			,
			enumerable: true,
			configurable: true
		});
		Object.defineProperty(View.prototype, "controllerFactory", {
			get: function() {
				return YesBankPOCProducts_MainFlow_Products_mvc_controller;
			}
			,
			enumerable: true,
			configurable: true
		});
		Object.defineProperty(View.prototype, "title", {
			get: function() {
				return "Products";
			}
			,
			enumerable: true,
			configurable: true
		});
		View.prototype.internalRender = function() {
			var model = this.model;
			var controller = this.controller;
			var idService = this.idService;
			var validationService = controller.validationService;
			var widgetsRecordProvider = this.widgetsRecordProvider;
			var callContext = controller.callContext();
			var $if = View.ifWidget;
			var $text = View.textWidget;
			var asPrimitiveValue = View.asPrimitiveValue;
			var getTranslation = View.getTranslation;
			var _this = this;

			return React.createElement("div", this.getRootNodeProperties(), React.createElement(YesBankPOCProducts_Layouts_LayoutTopMenu_mvc_view, {
				inputs: {}
				,
				events: {
					_handleError: function(ex) {
						controller.handleError(ex);
					}
				}
				,
				_validationProps: {
					validationService: validationService
				}
				,
				_idProps: {
					service: idService,
					uuid: "0",
					alias: "1"
				}
				,
				_widgetRecordProvider: widgetsRecordProvider,
				placeholders: {
					breadcrumbs: PlaceholderContent.Empty,
					title: new PlaceholderContent(function() {
						return[React.createElement(OSWidgets.AdvancedHtml, {
							tag: "h1",
							_idProps: {
								service: idService,
								name: "Screen_Title"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider
						}
						, "Product List")];
					}),
					actions: new PlaceholderContent(function() {
						return[React.createElement(OSWidgets.Container, {
							align:/*Default*/ 0,
							animate: false,
							gridProperties: {
								classes: "ThemeGrid_Width4"
							}
							,
							visible: true,
							_idProps: {
								service: idService,
								uuid: "2"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider
						}
						, React.createElement(OutSystemsUI_Interaction_Search_mvc_view, {
							inputs: {}
							,
							events: {
								_handleError: function(ex) {
									controller.handleError(ex);
								}
							}
							,
							_validationProps: {
								validationService: validationService
							}
							,
							_idProps: {
								service: idService,
								uuid: "3",
								alias: "2"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider,
							placeholders: {
								input: new PlaceholderContent(function() {
									return[React.createElement(OSWidgets.Input, {
										_validationProps: {
											validationService: validationService
										}
										,
										enabled: true,
										extendedProperties: {
											title: "Search"
										}
										,
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										inputType:/*Search*/ 8,
										mandatory: false,
										maxLength: 50,
										onChange: function() {
											return Promise.resolve().then(function() {
												var eventHandlerContext = callContext.clone();
												controller.onSearch$Action(controller.callContext(eventHandlerContext));
											});
											;
										}
										,
										prompt: "Search",
										style: "form-control",
										variable: model.createVariable(OS.Types.Text, model.variables.searchKeywordVar, function(value) {
											model.variables.searchKeywordVar = value;
										}),
										_idProps: {
											service: idService,
											name: "Input_TextVar"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									})];
								})
							}
							,
							_dependencies:[asPrimitiveValue(model.variables.searchKeywordVar)]
						})), React.createElement(OSWidgets.Button, {
							enabled: true,
							gridProperties: {
								classes: "ThemeGrid_MarginGutter",
								width: "150px"
							}
							,
							isDefault: false,
							onClick: function() {
								OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("YesBankPOCProducts", "ProductDetail", {
									ProductId: OS.DataConversion.ServerDataConverter.to(OS.BuiltinFunctions.integerToLongInteger(OS.BuiltinFunctions.nullIdentifier()), OS.Types.LongInteger)
								}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default));
							}
							,
							style: "btn btn-primary",
							visible: true,
							_idProps: {
								service: idService,
								uuid: "5"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider
						}
						, "Add Product", React.createElement(OSWidgets.Icon, {
							extendedProperties: {
								style: "padding: 0px 0px 0px 8px;"
							}
							,
							gridProperties: {
								classes: "ThemeGrid_MarginGutter"
							}
							,
							icon: "plus",
							iconSize:/*FontSize*/ 0,
							style: "icon",
							visible: true,
							_idProps: {
								service: idService,
								uuid: "6"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider
						}))];
					}),
					mainContent: new PlaceholderContent(function() {
						return[React.createElement(OSWidgets.TableRecords, {
							onSort: function(clickedColumnIn) {
								return Promise.resolve().then(function() {
									var eventHandlerContext = callContext.clone();
									controller.onSort$Action(clickedColumnIn, controller.callContext(eventHandlerContext));
								});
								;
							}
							,
							showHeader: true,
							source: model.variables.getProductsAggr.listOut,
							style: "table",
							styleHeader: "table-header",
							styleRow: "table-row",
							_idProps: {
								service: idService,
								uuid: "7"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider,
							source_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getProductsAggr.dataFetchStatusAttr),
							placeholders: {
								headerRow: new PlaceholderContent(function() {
									return[React.createElement(OSWidgets.HeaderCell, {
										sortAttribute: "Product.ProductName",
										_idProps: {
											service: idService,
											uuid: "8"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										_dependencies:[]
									}
									, "Product Name"), React.createElement(OSWidgets.HeaderCell, {
										_idProps: {
											service: idService,
											uuid: "9"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										_dependencies:[]
									}
									, "Distributor"), React.createElement(OSWidgets.HeaderCell, {
										sortAttribute: "Product.ProductCode",
										_idProps: {
											service: idService,
											uuid: "10"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										_dependencies:[]
									}
									, "Product Code"), React.createElement(OSWidgets.HeaderCell, {
										sortAttribute: "Product.Category",
										_idProps: {
											service: idService,
											uuid: "11"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										_dependencies:[]
									}
									, "Category"), React.createElement(OSWidgets.HeaderCell, {
										_idProps: {
											service: idService,
											uuid: "12"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										_dependencies:[]
									})];
								}),
								row: new IteratorPlaceholderContent(function(idService, callContext) {
									return[React.createElement(OSWidgets.RowCell, {
										_idProps: {
											service: idService,
											uuid: "13"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										_dependencies:[asPrimitiveValue(model.variables.getProductsAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getProductsAggr.listOut.getCurrent(callContext.iterationContext).productAttr.productNameAttr), asPrimitiveValue(model.variables.getProductsAggr.listOut.getCurrent(callContext.iterationContext).productAttr.pictureAttr)]
									}
									, React.createElement(OutSystemsUI_Utilities_AlignCenter_mvc_view, {
										inputs: {}
										,
										events: {
											_handleError: function(ex) {
												controller.handleError(ex);
											}
										}
										,
										_validationProps: {
											validationService: validationService
										}
										,
										_idProps: {
											service: idService,
											uuid: "14",
											alias: "3"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										placeholders: {
											content: new PlaceholderContent(function() {
												return[React.createElement(OSWidgets.Image, {
													gridProperties: {
														classes: "ThemeGrid_Width2"
													}
													,
													type:/*External*/ 1,
													url: model.variables.getProductsAggr.listOut.getCurrent(callContext.iterationContext).productAttr.pictureAttr,
													_idProps: {
														service: idService,
														uuid: "15"
													}
													,
													_widgetRecordProvider: widgetsRecordProvider,
													url_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getProductsAggr.dataFetchStatusAttr)
												}), React.createElement(OSWidgets.Expression, {
													gridProperties: {
														classes: "ThemeGrid_MarginGutter"
													}
													,
													value: model.variables.getProductsAggr.listOut.getCurrent(callContext.iterationContext).productAttr.productNameAttr,
													_idProps: {
														service: idService,
														uuid: "16"
													}
													,
													_widgetRecordProvider: widgetsRecordProvider,
													value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getProductsAggr.dataFetchStatusAttr)
												})];
											})
										}
										,
										_dependencies:[asPrimitiveValue(model.variables.getProductsAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getProductsAggr.listOut.getCurrent(callContext.iterationContext).productAttr.productNameAttr), asPrimitiveValue(model.variables.getProductsAggr.listOut.getCurrent(callContext.iterationContext).productAttr.pictureAttr)]
									})), React.createElement(OSWidgets.RowCell, {
										_idProps: {
											service: idService,
											uuid: "17"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										_dependencies:[asPrimitiveValue(model.variables.getProductsAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getProductsAggr.listOut.getCurrent(callContext.iterationContext).productAttr.distributorLogoAttr)]
									}
									, React.createElement(OSWidgets.Image, {
										gridProperties: {
											classes: "ThemeGrid_Width3"
										}
										,
										type:/*External*/ 1,
										url: model.variables.getProductsAggr.listOut.getCurrent(callContext.iterationContext).productAttr.distributorLogoAttr,
										_idProps: {
											service: idService,
											uuid: "18"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										url_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getProductsAggr.dataFetchStatusAttr)
									})), React.createElement(OSWidgets.RowCell, {
										_idProps: {
											service: idService,
											uuid: "19"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										_dependencies:[asPrimitiveValue(model.variables.getProductsAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getProductsAggr.listOut.getCurrent(callContext.iterationContext).productAttr.productCodeAttr)]
									}
									, React.createElement(OSWidgets.Expression, {
										value: model.variables.getProductsAggr.listOut.getCurrent(callContext.iterationContext).productAttr.productCodeAttr,
										_idProps: {
											service: idService,
											uuid: "20"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getProductsAggr.dataFetchStatusAttr)
									})), React.createElement(OSWidgets.RowCell, {
										_idProps: {
											service: idService,
											uuid: "21"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										_dependencies:[asPrimitiveValue(model.variables.getProductsAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getProductsAggr.listOut.getCurrent(callContext.iterationContext).productAttr.categoryAttr)]
									}
									, React.createElement(OSWidgets.Expression, {
										value: model.variables.getProductsAggr.listOut.getCurrent(callContext.iterationContext).productAttr.categoryAttr,
										_idProps: {
											service: idService,
											uuid: "22"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getProductsAggr.dataFetchStatusAttr)
									})), React.createElement(OSWidgets.RowCell, {
										_idProps: {
											service: idService,
											uuid: "23"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										_dependencies:[]
									}
									, React.createElement(OSWidgets.Link, {
										enabled: true,
										transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default),
										url: OS.Navigation.generateScreenURL("YesBankPOCProducts", "ProductDetail", {
											ProductId: OS.DataConversion.ServerDataConverter.to(model.variables.getProductsAggr.listOut.getCurrent(callContext.iterationContext).productAttr.idAttr, OS.Types.LongInteger)
										}),
										visible: true,
										_idProps: {
											service: idService,
											uuid: "24"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, React.createElement(OSWidgets.Icon, {
										icon: "pencil-square-o",
										iconSize:/*Twotimes*/ 1,
										style: "icon",
										visible: true,
										_idProps: {
											service: idService,
											uuid: "25"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									})))];
								}
								, callContext, idService, "1_0")
							}
							,
							_dependencies:[asPrimitiveValue(model.variables.getProductsAggr.dataFetchStatusAttr)]
						}), React.createElement(OSWidgets.Container, {
							align:/*Default*/ 0,
							animate: false,
							visible: true,
							_idProps: {
								service: idService,
								name: "IsTableLoadingOrEmpty"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider
						}
						, $if((model.variables.getProductsAggr.isDataFetchedAttr && model.variables.getProductsAggr.listOut.isEmpty), false, this, function() {
							return[React.createElement(OSWidgets.Container, {
								align:/*Default*/ 0,
								animate: false,
								style: "table-empty",
								visible: true,
								_idProps: {
									service: idService,
									uuid: "27"
								}
								,
								_widgetRecordProvider: widgetsRecordProvider
							}
							, React.createElement(OSWidgets.Text, {
								extendedProperties: {
									role: "status"
								}
								,
								text:["No items to show..."],
								_idProps: {
									service: idService,
									uuid: "28"
								}
								,
								_widgetRecordProvider: widgetsRecordProvider
							}))];
						}
						, function() {
							return[$if(!(model.variables.getProductsAggr.isDataFetchedAttr), false, this, function() {
								return[React.createElement(OSWidgets.Container, {
									align:/*Default*/ 0,
									animate: false,
									style: "list-updating",
									visible: true,
									_idProps: {
										service: idService,
										uuid: "29"
									}
									,
									_widgetRecordProvider: widgetsRecordProvider
								})];
							}
							, function() {
								return[];
							})];
						})), React.createElement(OutSystemsUI_Navigation_Pagination_mvc_view, {
							inputs: {
								MaxRecords: model.variables.maxRecordsVar,
								StartIndex: model.variables.startIndexVar,
								TotalCount: model.variables.getProductsAggr.countOut,
								_totalCountInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getProductsAggr.dataFetchStatusAttr)
							}
							,
							events: {
								_handleError: function(ex) {
									controller.handleError(ex);
								}
								,
								onNavigate$Action: function(newStartIndexIn) {
									return Promise.resolve().then(function() {
										var eventHandlerContext = callContext.clone();
										controller.onPaginationNavigate$Action(newStartIndexIn, controller.callContext(eventHandlerContext));
									});
									;
								}
							}
							,
							_validationProps: {
								validationService: validationService
							}
							,
							_idProps: {
								service: idService,
								uuid: "30",
								alias: "4"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider,
							placeholders: {
								previous: new PlaceholderContent(function() {
									return[React.createElement(OSWidgets.Icon, {
										icon: "angle-left",
										iconSize:/*FontSize*/ 0,
										style: "icon",
										visible: true,
										_idProps: {
											service: idService,
											uuid: "31"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									})];
								}),
								next: new PlaceholderContent(function() {
									return[React.createElement(OSWidgets.Icon, {
										icon: "angle-right",
										iconSize:/*FontSize*/ 0,
										style: "icon",
										visible: true,
										_idProps: {
											service: idService,
											uuid: "32"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									})];
								})
							}
							,
							_dependencies:[]
						})];
					}),
					footer: PlaceholderContent.Empty,
					header: new PlaceholderContent(function() {
						return[React.createElement(YesBankPOCProducts_Common_Menu_mvc_view, {
							inputs: {}
							,
							events: {
								_handleError: function(ex) {
									controller.handleError(ex);
								}
							}
							,
							_validationProps: {
								validationService: validationService
							}
							,
							_idProps: {
								service: idService,
								uuid: "33",
								alias: "5"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider,
							_dependencies:[]
						})];
					})
				}
				,
				_dependencies:[asPrimitiveValue(model.variables.startIndexVar), asPrimitiveValue(model.variables.maxRecordsVar), asPrimitiveValue(model.variables.getProductsAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getProductsAggr.countOut), asPrimitiveValue(model.variables.getProductsAggr.isDataFetchedAttr), asPrimitiveValue(model.variables.getProductsAggr.listOut), asPrimitiveValue(model.variables.searchKeywordVar)]
			}));
		};
		return View;
	})(OSView.BaseView.BaseWebScreen);

	return View;
});
define("YesBankPOCProducts.MainFlow.Products.mvc$controller",["OutSystems/ClientRuntime/Main", "YesBankPOCProducts.model", "YesBankPOCProducts.controller", "YesBankPOCProducts.languageResources", "YesBankPOCProducts.clientVariables", "YesBankPOCProducts.MainFlow.controller", "YesBankPOCProducts.model$ProductRecordList"], function(OutSystems, YesBankPOCProductsModel, YesBankPOCProductsController, YesBankPOCProductsLanguageResources, YesBankPOCProductsClientVariables, YesBankPOCProducts_MainFlowController) {
	var OS = OutSystems.Internal;
	var Controller = (function(_super) {
		__extends(Controller, _super);
		function Controller() {
			_super.apply(this, arguments);
			var controller = this.controller;
			this.clientActionProxies = {};
			this.dataFetchDependenciesOriginal = {
				getProducts$AggrRefresh: 0
			};
			this.dataFetchDependentsGraph = {
				getProducts$AggrRefresh:[]
			};
			this.shouldSendClientVarsToDataSources = false;
		}
		// Server Actions

		// Aggregates and Data Actions
		Controller.prototype.getProducts$AggrRefresh = function(maxRecords, startIndex, callContext) {
			var model = this.model;
			var controller = this.controller;
			var callContext = controller.callContext(callContext);
			return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetProducts", "screenservices/YesBankPOCProducts/MainFlow/Products/ScreenDataSetGetProducts", "4jXzwkPDRvOJ8a2gmCk8FA", maxRecords, startIndex, function(b) {
				model.variables.getProductsAggr.dataFetchStatusAttr = b;
			}
			, function(json) {
				model.variables.getProductsAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getProductsAggr.constructor));
			}
			, undefined, undefined, undefined, callContext, undefined, false);
		};

		Controller.prototype.dataFetchActionNames =["getProducts$AggrRefresh"];
		// Client Actions
		Controller.prototype._onSearch$Action = function(callContext) {
			var model = this.model;
			var controller = this.controller;
			var idService = this.idService;
			controller.ensureControllerAlive("OnSearch");
			callContext = controller.callContext(callContext);
			return OS.Flow.executeAsyncFlow(function() {
				// StartIndex = 0
				// StartIndex = 0
				model.variables.startIndexVar = 0;
				// Refresh Query: GetProducts
				var result = controller.getProducts$AggrRefresh(model.variables.maxRecordsVar, model.variables.startIndexVar, callContext);
				model.flush();
				return result;
			}
			);
		};
		Controller.prototype._onPaginationNavigate$Action = function(newStartIndexIn, callContext) {
			var model = this.model;
			var controller = this.controller;
			var idService = this.idService;
			controller.ensureControllerAlive("OnPaginationNavigate");
			callContext = controller.callContext(callContext);
			var vars = new OS.DataTypes.VariableHolder(new(controller.constructor.getVariableGroupType("YesBankPOCProducts.MainFlow.Products.OnPaginationNavigate$vars")) ());
			vars.value.newStartIndexInLocal = newStartIndexIn;
			return OS.Flow.executeAsyncFlow(function() {
				// StartIndex = NewStartIndex
				// StartIndex = NewStartIndex
				model.variables.startIndexVar = vars.value.newStartIndexInLocal;
				// Refresh Query: GetProducts
				var result = controller.getProducts$AggrRefresh(model.variables.maxRecordsVar, model.variables.startIndexVar, callContext);
				model.flush();
				return result;
			}
			);
		};
		Controller.registerVariableGroupType("YesBankPOCProducts.MainFlow.Products.OnPaginationNavigate$vars",[ {
			name: "NewStartIndex",
			attrName: "newStartIndexInLocal",
			mandatory: true,
			dataType: OS.Types.Integer,
			defaultValue: function() {
				return 0;
			}
		}
		]);
		Controller.prototype._onSort$Action = function(sortByIn, callContext) {
			var model = this.model;
			var controller = this.controller;
			var idService = this.idService;
			controller.ensureControllerAlive("OnSort");
			callContext = controller.callContext(callContext);
			var vars = new OS.DataTypes.VariableHolder(new(controller.constructor.getVariableGroupType("YesBankPOCProducts.MainFlow.Products.OnSort$vars")) ());
			vars.value.sortByInLocal = sortByIn;
			return OS.Flow.executeAsyncFlow(function() {
				if ((((model.variables.tableSortVar === vars.value.sortByInLocal) && ((vars.value.sortByInLocal) !==(""))))) {
					// TableSort2 += DESC
					// TableSort = SortBy + " DESC"
					model.variables.tableSortVar = (vars.value.sortByInLocal + " DESC");
				} else {
					// TableSort = SortBy
					// TableSort = SortBy
					model.variables.tableSortVar = vars.value.sortByInLocal;
				}

				// StartIndex = 0
				// StartIndex = 0
				model.variables.startIndexVar = 0;
				// Refresh Query: GetProducts
				var result = controller.getProducts$AggrRefresh(model.variables.maxRecordsVar, model.variables.startIndexVar, callContext);
				model.flush();
				return result;
			}
			);
		};
		Controller.registerVariableGroupType("YesBankPOCProducts.MainFlow.Products.OnSort$vars",[ {
			name: "SortBy",
			attrName: "sortByInLocal",
			mandatory: true,
			dataType: OS.Types.Text,
			defaultValue: function() {
				return "";
			}
		}
		]);

		Controller.prototype.onSearch$Action = function(callContext) {
			var controller = this.controller;
			return controller.safeExecuteClientAction(controller._onSearch$Action, callContext);

		};
		Controller.prototype.onPaginationNavigate$Action = function(newStartIndexIn, callContext) {
			var controller = this.controller;
			return controller.safeExecuteClientAction(controller._onPaginationNavigate$Action, callContext, newStartIndexIn);

		};
		Controller.prototype.onSort$Action = function(sortByIn, callContext) {
			var controller = this.controller;
			return controller.safeExecuteClientAction(controller._onSort$Action, callContext, sortByIn);

		};

		// Event Handler Actions
		Controller.prototype.onInitializeEventHandler = null;
		Controller.prototype.onReadyEventHandler = null;
		Controller.prototype.onRenderEventHandler = null;
		Controller.prototype.onDestroyEventHandler = null;
		Controller.prototype.onParametersChangedEventHandler = null;
		Controller.prototype.handleError = function(ex) {
			return YesBankPOCProducts_MainFlowController.default.handleError(ex, this.callContext());
		};
		Controller.checkPermissions = function() {
		};
		Controller.prototype.getDefaultTimeout = function() {
			return YesBankPOCProductsController.default.defaultTimeout;
		};
		return Controller;
	}
	) (OS.Controller.BaseViewController);
	return new OS.Controller.ControllerFactory(Controller, YesBankPOCProductsLanguageResources);
});

