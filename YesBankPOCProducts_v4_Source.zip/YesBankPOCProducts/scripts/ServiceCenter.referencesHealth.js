﻿define("ServiceCenter.referencesHealth$IntegrationStudio", [], function () {
// Reference to producer 'IntegrationStudio' is OK.
});
define("ServiceCenter.referencesHealth$OMLProcessor", [], function () {
// Reference to producer 'OMLProcessor' is OK.
});
define("ServiceCenter.referencesHealth$PlatformLogs", [], function () {
// Reference to producer 'PlatformLogs' is OK.
});
define("ServiceCenter.referencesHealth", [], function () {
});
