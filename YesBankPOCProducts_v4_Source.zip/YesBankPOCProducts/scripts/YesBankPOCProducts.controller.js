﻿define("YesBankPOCProducts.controller$ServerAction.User_GetUnifiedLoginUrl",["exports", "OutSystems/ClientRuntime/Main", "YesBankPOCProducts.model", "YesBankPOCProducts.controller"], function(exports, OutSystems, YesBankPOCProductsModel, YesBankPOCProductsController) {
	var OS = OutSystems.Internal;
	YesBankPOCProductsController.default.user_GetUnifiedLoginUrl$ServerAction = function(originalUrlIn, callContext) {
		var controller = this.controller;
		var inputs = {
			OriginalUrl: OS.DataConversion.ServerDataConverter.to(originalUrlIn, OS.Types.Text)
		};
		return controller.callServerAction("User_GetUnifiedLoginUrl", "screenservices/YesBankPOCProducts/ActionUser_GetUnifiedLoginUrl", "_P06lQSrtqLQ7tACGPrNeQ", inputs, controller.callContext(callContext), undefined, undefined, false).then(function(outputs) {
			var executeServerActionResult = new(controller.constructor.getVariableGroupType("YesBankPOCProducts$rssespaceusers_ActionUser_GetUnifiedLoginUrl")) ();
			executeServerActionResult.urlOut = OS.DataConversion.ServerDataConverter.from(outputs.Url, OS.Types.Text);
			return executeServerActionResult;
		}
		);
	};
	YesBankPOCProductsController.default.constructor.registerVariableGroupType("YesBankPOCProducts$rssespaceusers_ActionUser_GetUnifiedLoginUrl",[ {
		name: "Url",
		attrName: "urlOut",
		mandatory: false,
		dataType: OS.Types.Text,
		defaultValue: function() {
			return "";
		}
	}
	]);
});
define("YesBankPOCProducts.controller",["exports", "OutSystems/ClientRuntime/Main", "YesBankPOCProducts.model"], function(exports, OutSystems, YesBankPOCProductsModel) {
	var OS = OutSystems.Internal;
	var YesBankPOCProductsController = exports;
	var Controller = (function(_super) {
		__extends(Controller, _super);
		function Controller() {
			_super.apply(this, arguments);
		}
		Controller.prototype.clientActionProxies = {};
		Controller.prototype.roles = {};
		Controller.prototype.defaultTimeout = 10;
		Controller.prototype.getDefaultTimeout = function() {
			return YesBankPOCProductsController.default.defaultTimeout;
		};
		return Controller;
	}
	) (OS.Controller.BaseModuleController);
	YesBankPOCProductsController.default = new Controller();
});
