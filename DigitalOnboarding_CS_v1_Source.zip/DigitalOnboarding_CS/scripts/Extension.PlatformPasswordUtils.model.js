﻿define("Extension.PlatformPasswordUtils.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var Extension_PlatformPasswordUtilsModel = exports;
});
