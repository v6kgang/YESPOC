﻿define("ESB_FCR_IS.referencesHealth$ServiceCenter", [], function () {
// Reference to producer 'ServiceCenter' is OK.
});
define("ESB_FCR_IS.referencesHealth$Users", [], function () {
// Reference to producer 'Users' is OK.
});
define("ESB_FCR_IS.referencesHealth$Xml", [], function () {
// Reference to producer 'Xml' is OK.
});
define("ESB_FCR_IS.referencesHealth", [], function () {
});
