﻿define("Extension.AsynchronousLogging.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var Extension_AsynchronousLoggingModel = exports;
});
