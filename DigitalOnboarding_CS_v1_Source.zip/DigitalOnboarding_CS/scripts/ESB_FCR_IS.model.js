﻿define("ESB_FCR_IS.model$ResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "ESB_FCR_IS.model"], function (exports, OutSystems, ESB_FCR_ISModel) {
var OS = OutSystems.Internal;
var ResponseRec = (function (_super) {
__extends(ResponseRec, _super);
function ResponseRec(defaults) {
_super.apply(this, arguments);
}
ResponseRec.attributesToDeclare = function () {
return [
this.attr("Name", "nameAttr", "Name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Designation", "designationAttr", "Designation", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ResponseRec.init();
return ResponseRec;
})(OS.DataTypes.GenericRecord);
ESB_FCR_ISModel.ResponseRec = ResponseRec;

});
define("ESB_FCR_IS.model$HeaderRec", ["exports", "OutSystems/ClientRuntime/Main", "ESB_FCR_IS.model"], function (exports, OutSystems, ESB_FCR_ISModel) {
var OS = OutSystems.Internal;
var HeaderRec = (function (_super) {
__extends(HeaderRec, _super);
function HeaderRec(defaults) {
_super.apply(this, arguments);
}
HeaderRec.attributesToDeclare = function () {
return [
this.attr("Version", "versionAttr", "Version", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Channel", "channelAttr", "Channel", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ExtUniqueRefId", "extUniqueRefIdAttr", "ExtUniqueRefId", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
HeaderRec.init();
return HeaderRec;
})(OS.DataTypes.GenericRecord);
ESB_FCR_ISModel.HeaderRec = HeaderRec;

});
define("ESB_FCR_IS.model$ResponseBodyRec", ["exports", "OutSystems/ClientRuntime/Main", "ESB_FCR_IS.model"], function (exports, OutSystems, ESB_FCR_ISModel) {
var OS = OutSystems.Internal;
var ResponseBodyRec = (function (_super) {
__extends(ResponseBodyRec, _super);
function ResponseBodyRec(defaults) {
_super.apply(this, arguments);
}
ResponseBodyRec.attributesToDeclare = function () {
return [
this.attr("FlagCustType", "flagCustTypeAttr", "FlagCustType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CustomerType", "customerTypeAttr", "CustomerType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CustomerID", "customerIDAttr", "CustomerID", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("BranchCode", "branchCodeAttr", "BranchCode", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("BranchName", "branchNameAttr", "BranchName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Title", "titleAttr", "Title", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CustomerFullName", "customerFullNameAttr", "CustomerFullName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CustomerFirstName", "customerFirstNameAttr", "CustomerFirstName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DateofBirth", "dateofBirthAttr", "DateofBirth", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AddressLine1", "addressLine1Attr", "AddressLine1", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AddressLine2", "addressLine2Attr", "AddressLine2", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("City", "cityAttr", "City", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("State", "stateAttr", "State", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Country", "countryAttr", "Country", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PINCode", "pINCodeAttr", "PINCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EmailID", "emailIDAttr", "EmailID", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MobileNumber", "mobileNumberAttr", "MobileNumber", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Gender", "genderAttr", "Gender", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PANCardNumber", "pANCardNumberAttr", "PANCardNumber", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PhoneRes", "phoneResAttr", "Phone-Res", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PAddressLine1", "pAddressLine1Attr", "PAddressLine1", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PAddressLine2", "pAddressLine2Attr", "PAddressLine2", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Pcity", "pcityAttr", "Pcity", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Pstate", "pstateAttr", "Pstate", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Pcountry", "pcountryAttr", "Pcountry", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Ppincode", "ppincodeAttr", "Ppincode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Mstat", "mstatAttr", "mstat", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Stnam", "stnamAttr", "Stnam", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Dtissu", "dtissuAttr", "Dtissu", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Dtexp", "dtexpAttr", "Dtexp", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Rcat", "rcatAttr", "Rcat", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("LstKYC", "lstKYCAttr", "LstKYC", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("SalesRM", "salesRMAttr", "SalesRM", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ServiceRM", "serviceRMAttr", "ServiceRM", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("AssetRM", "assetRMAttr", "AssetRM", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("Segment", "segmentAttr", "Segment", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Occupation", "occupationAttr", "Occupation", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ResponseBodyRec.init();
return ResponseBodyRec;
})(OS.DataTypes.GenericRecord);
ESB_FCR_ISModel.ResponseBodyRec = ResponseBodyRec;

});
define("ESB_FCR_IS.model$PostGetContactDetails2ResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "ESB_FCR_IS.model", "ESB_FCR_IS.model$HeaderRec", "ESB_FCR_IS.model$ResponseBodyRec"], function (exports, OutSystems, ESB_FCR_ISModel) {
var OS = OutSystems.Internal;
var PostGetContactDetails2ResponseRec = (function (_super) {
__extends(PostGetContactDetails2ResponseRec, _super);
function PostGetContactDetails2ResponseRec(defaults) {
_super.apply(this, arguments);
}
PostGetContactDetails2ResponseRec.attributesToDeclare = function () {
return [
this.attr("Header", "headerAttr", "Header", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ESB_FCR_ISModel.HeaderRec());
}, true, ESB_FCR_ISModel.HeaderRec), 
this.attr("ResponseBody", "responseBodyAttr", "ResponseBody", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ESB_FCR_ISModel.ResponseBodyRec());
}, true, ESB_FCR_ISModel.ResponseBodyRec)
].concat(_super.attributesToDeclare.call(this));
};
PostGetContactDetails2ResponseRec.init();
return PostGetContactDetails2ResponseRec;
})(OS.DataTypes.GenericRecord);
ESB_FCR_ISModel.PostGetContactDetails2ResponseRec = PostGetContactDetails2ResponseRec;

});
define("ESB_FCR_IS.model$StatusItemRec", ["exports", "OutSystems/ClientRuntime/Main", "ESB_FCR_IS.model"], function (exports, OutSystems, ESB_FCR_ISModel) {
var OS = OutSystems.Internal;
var StatusItemRec = (function (_super) {
__extends(StatusItemRec, _super);
function StatusItemRec(defaults) {
_super.apply(this, arguments);
}
StatusItemRec.attributesToDeclare = function () {
return [
this.attr("ErrorCode", "errorCodeAttr", "ErrorCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ExternalReferenceNo", "externalReferenceNoAttr", "ExternalReferenceNo", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsOverriden", "isOverridenAttr", "IsOverriden", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IsServiceChargeApplied", "isServiceChargeAppliedAttr", "IsServiceChargeApplied", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ReplyCode", "replyCodeAttr", "ReplyCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("SpReturnValue", "spReturnValueAttr", "SpReturnValue", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
StatusItemRec.init();
return StatusItemRec;
})(OS.DataTypes.GenericRecord);
ESB_FCR_ISModel.StatusItemRec = StatusItemRec;

});
define("ESB_FCR_IS.model$ReqBodyRec", ["exports", "OutSystems/ClientRuntime/Main", "ESB_FCR_IS.model"], function (exports, OutSystems, ESB_FCR_ISModel) {
var OS = OutSystems.Internal;
var ReqBodyRec = (function (_super) {
__extends(ReqBodyRec, _super);
function ReqBodyRec(defaults) {
_super.apply(this, arguments);
}
ReqBodyRec.attributesToDeclare = function () {
return [
this.attr("CustomerId", "customerIdAttr", "CustomerId", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("GetSavingsAcc", "getSavingsAccAttr", "GetSavingsAcc", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("GetCurAcc", "getCurAccAttr", "GetCurAcc", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("GetFDAcc", "getFDAccAttr", "GetFDAcc", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("GetRDAcc", "getRDAccAttr", "GetRDAcc", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ReqBodyRec.init();
return ReqBodyRec;
})(OS.DataTypes.GenericRecord);
ESB_FCR_ISModel.ReqBodyRec = ReqBodyRec;

});
define("ESB_FCR_IS.model$ConsumerContextRec", ["exports", "OutSystems/ClientRuntime/Main", "ESB_FCR_IS.model"], function (exports, OutSystems, ESB_FCR_ISModel) {
var OS = OutSystems.Internal;
var ConsumerContextRec = (function (_super) {
__extends(ConsumerContextRec, _super);
function ConsumerContextRec(defaults) {
_super.apply(this, arguments);
}
ConsumerContextRec.attributesToDeclare = function () {
return [
this.attr("RequesterID", "requesterIDAttr", "RequesterID", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ConsumerContextRec.fromStructure = function (str) {
return new ConsumerContextRec(new ConsumerContextRec.RecordClass({
requesterIDAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ConsumerContextRec.init();
return ConsumerContextRec;
})(OS.DataTypes.GenericRecord);
ESB_FCR_ISModel.ConsumerContextRec = ConsumerContextRec;

});
define("ESB_FCR_IS.model$ServiceContextRec", ["exports", "OutSystems/ClientRuntime/Main", "ESB_FCR_IS.model"], function (exports, OutSystems, ESB_FCR_ISModel) {
var OS = OutSystems.Internal;
var ServiceContextRec = (function (_super) {
__extends(ServiceContextRec, _super);
function ServiceContextRec(defaults) {
_super.apply(this, arguments);
}
ServiceContextRec.attributesToDeclare = function () {
return [
this.attr("ServiceName", "serviceNameAttr", "ServiceName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ReqRefNum", "reqRefNumAttr", "ReqRefNum", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ReqRefTimeStamp", "reqRefTimeStampAttr", "ReqRefTimeStamp", false, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("ServiceVersionNo", "serviceVersionNoAttr", "ServiceVersionNo", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ServiceContextRec.init();
return ServiceContextRec;
})(OS.DataTypes.GenericRecord);
ESB_FCR_ISModel.ServiceContextRec = ServiceContextRec;

});
define("ESB_FCR_IS.model$ServiceResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "ESB_FCR_IS.model"], function (exports, OutSystems, ESB_FCR_ISModel) {
var OS = OutSystems.Internal;
var ServiceResponseRec = (function (_super) {
__extends(ServiceResponseRec, _super);
function ServiceResponseRec(defaults) {
_super.apply(this, arguments);
}
ServiceResponseRec.attributesToDeclare = function () {
return [
this.attr("EsbResTimeStamp", "esbResTimeStampAttr", "EsbResTimeStamp", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EsbResStatus", "esbResStatusAttr", "EsbResStatus", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ServiceResponseRec.init();
return ServiceResponseRec;
})(OS.DataTypes.GenericRecord);
ESB_FCR_ISModel.ServiceResponseRec = ServiceResponseRec;

});
define("ESB_FCR_IS.model$ReqHdrRec", ["exports", "OutSystems/ClientRuntime/Main", "ESB_FCR_IS.model", "ESB_FCR_IS.model$ConsumerContextRec", "ESB_FCR_IS.model$ServiceContextRec", "ESB_FCR_IS.model$ServiceResponseRec"], function (exports, OutSystems, ESB_FCR_ISModel) {
var OS = OutSystems.Internal;
var ReqHdrRec = (function (_super) {
__extends(ReqHdrRec, _super);
function ReqHdrRec(defaults) {
_super.apply(this, arguments);
}
ReqHdrRec.attributesToDeclare = function () {
return [
this.attr("ConsumerContext", "consumerContextAttr", "ConsumerContext", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ESB_FCR_ISModel.ConsumerContextRec());
}, true, ESB_FCR_ISModel.ConsumerContextRec), 
this.attr("ServiceContext", "serviceContextAttr", "ServiceContext", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ESB_FCR_ISModel.ServiceContextRec());
}, true, ESB_FCR_ISModel.ServiceContextRec), 
this.attr("ServiceResponse", "serviceResponseAttr", "ServiceResponse", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ESB_FCR_ISModel.ServiceResponseRec());
}, true, ESB_FCR_ISModel.ServiceResponseRec)
].concat(_super.attributesToDeclare.call(this));
};
ReqHdrRec.init();
return ReqHdrRec;
})(OS.DataTypes.GenericRecord);
ESB_FCR_ISModel.ReqHdrRec = ReqHdrRec;

});
define("ESB_FCR_IS.model$RequestPayloadRec", ["exports", "OutSystems/ClientRuntime/Main", "ESB_FCR_IS.model"], function (exports, OutSystems, ESB_FCR_ISModel) {
var OS = OutSystems.Internal;
var RequestPayloadRec = (function (_super) {
__extends(RequestPayloadRec, _super);
function RequestPayloadRec(defaults) {
_super.apply(this, arguments);
}
RequestPayloadRec.attributesToDeclare = function () {
return [
this.attr("CustomerID", "customerIDAttr", "CustomerID", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
RequestPayloadRec.fromStructure = function (str) {
return new RequestPayloadRec(new RequestPayloadRec.RecordClass({
customerIDAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
RequestPayloadRec.init();
return RequestPayloadRec;
})(OS.DataTypes.GenericRecord);
ESB_FCR_ISModel.RequestPayloadRec = RequestPayloadRec;

});
define("ESB_FCR_IS.model$GetAllAccountsReqRec", ["exports", "OutSystems/ClientRuntime/Main", "ESB_FCR_IS.model", "ESB_FCR_IS.model$ReqHdrRec", "ESB_FCR_IS.model$ReqBodyRec"], function (exports, OutSystems, ESB_FCR_ISModel) {
var OS = OutSystems.Internal;
var GetAllAccountsReqRec = (function (_super) {
__extends(GetAllAccountsReqRec, _super);
function GetAllAccountsReqRec(defaults) {
_super.apply(this, arguments);
}
GetAllAccountsReqRec.attributesToDeclare = function () {
return [
this.attr("ReqHdr", "reqHdrAttr", "ReqHdr", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ESB_FCR_ISModel.ReqHdrRec());
}, true, ESB_FCR_ISModel.ReqHdrRec), 
this.attr("ReqBody", "reqBodyAttr", "ReqBody", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ESB_FCR_ISModel.ReqBodyRec());
}, true, ESB_FCR_ISModel.ReqBodyRec)
].concat(_super.attributesToDeclare.call(this));
};
GetAllAccountsReqRec.init();
return GetAllAccountsReqRec;
})(OS.DataTypes.GenericRecord);
ESB_FCR_ISModel.GetAllAccountsReqRec = GetAllAccountsReqRec;

});
define("ESB_FCR_IS.model$PostGetAllAccountsRequestRec", ["exports", "OutSystems/ClientRuntime/Main", "ESB_FCR_IS.model", "ESB_FCR_IS.model$GetAllAccountsReqRec"], function (exports, OutSystems, ESB_FCR_ISModel) {
var OS = OutSystems.Internal;
var PostGetAllAccountsRequestRec = (function (_super) {
__extends(PostGetAllAccountsRequestRec, _super);
function PostGetAllAccountsRequestRec(defaults) {
_super.apply(this, arguments);
}
PostGetAllAccountsRequestRec.attributesToDeclare = function () {
return [
this.attr("GetAllAccountsReq", "getAllAccountsReqAttr", "GetAllAccountsReq", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ESB_FCR_ISModel.GetAllAccountsReqRec());
}, true, ESB_FCR_ISModel.GetAllAccountsReqRec)
].concat(_super.attributesToDeclare.call(this));
};
PostGetAllAccountsRequestRec.fromStructure = function (str) {
return new PostGetAllAccountsRequestRec(new PostGetAllAccountsRequestRec.RecordClass({
getAllAccountsReqAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PostGetAllAccountsRequestRec.init();
return PostGetAllAccountsRequestRec;
})(OS.DataTypes.GenericRecord);
ESB_FCR_ISModel.PostGetAllAccountsRequestRec = PostGetAllAccountsRequestRec;

});
define("ESB_FCR_IS.model$PostGetContactDetails2RequestRec", ["exports", "OutSystems/ClientRuntime/Main", "ESB_FCR_IS.model", "ESB_FCR_IS.model$HeaderRec", "ESB_FCR_IS.model$RequestPayloadRec"], function (exports, OutSystems, ESB_FCR_ISModel) {
var OS = OutSystems.Internal;
var PostGetContactDetails2RequestRec = (function (_super) {
__extends(PostGetContactDetails2RequestRec, _super);
function PostGetContactDetails2RequestRec(defaults) {
_super.apply(this, arguments);
}
PostGetContactDetails2RequestRec.attributesToDeclare = function () {
return [
this.attr("Header", "headerAttr", "Header", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ESB_FCR_ISModel.HeaderRec());
}, true, ESB_FCR_ISModel.HeaderRec), 
this.attr("RequestPayload", "requestPayloadAttr", "RequestPayload", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ESB_FCR_ISModel.RequestPayloadRec());
}, true, ESB_FCR_ISModel.RequestPayloadRec)
].concat(_super.attributesToDeclare.call(this));
};
PostGetContactDetails2RequestRec.init();
return PostGetContactDetails2RequestRec;
})(OS.DataTypes.GenericRecord);
ESB_FCR_ISModel.PostGetContactDetails2RequestRec = PostGetContactDetails2RequestRec;

});
define("ESB_FCR_IS.model$AccountDetailItemRec", ["exports", "OutSystems/ClientRuntime/Main", "ESB_FCR_IS.model"], function (exports, OutSystems, ESB_FCR_ISModel) {
var OS = OutSystems.Internal;
var AccountDetailItemRec = (function (_super) {
__extends(AccountDetailItemRec, _super);
function AccountDetailItemRec(defaults) {
_super.apply(this, arguments);
}
AccountDetailItemRec.attributesToDeclare = function () {
return [
this.attr("AccountNumber", "accountNumberAttr", "AccountNumber", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Balance", "balanceAttr", "Balance", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AccountCustomerRelationship", "accountCustomerRelationshipAttr", "AccountCustomerRelationship", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AccountStatus", "accountStatusAttr", "AccountStatus", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("BranchCode", "branchCodeAttr", "BranchCode", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("ProductCode", "productCodeAttr", "ProductCode", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("BookBalance", "bookBalanceAttr", "BookBalance", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AccountTitle", "accountTitleAttr", "AccountTitle", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
AccountDetailItemRec.init();
return AccountDetailItemRec;
})(OS.DataTypes.GenericRecord);
ESB_FCR_ISModel.AccountDetailItemRec = AccountDetailItemRec;

});
define("ESB_FCR_IS.model$AccountDetailItemList", ["exports", "OutSystems/ClientRuntime/Main", "ESB_FCR_IS.model", "ESB_FCR_IS.model$AccountDetailItemRec"], function (exports, OutSystems, ESB_FCR_ISModel) {
var OS = OutSystems.Internal;
var AccountDetailItemList = (function (_super) {
__extends(AccountDetailItemList, _super);
function AccountDetailItemList(defaults) {
_super.apply(this, arguments);
}
AccountDetailItemList.itemType = ESB_FCR_ISModel.AccountDetailItemRec;
return AccountDetailItemList;
})(OS.DataTypes.GenericRecordList);
ESB_FCR_ISModel.AccountDetailItemList = AccountDetailItemList;

});
define("ESB_FCR_IS.model$AccountTypeListItemRec", ["exports", "OutSystems/ClientRuntime/Main", "ESB_FCR_IS.model", "ESB_FCR_IS.model$AccountDetailItemList"], function (exports, OutSystems, ESB_FCR_ISModel) {
var OS = OutSystems.Internal;
var AccountTypeListItemRec = (function (_super) {
__extends(AccountTypeListItemRec, _super);
function AccountTypeListItemRec(defaults) {
_super.apply(this, arguments);
}
AccountTypeListItemRec.attributesToDeclare = function () {
return [
this.attr("AccountType", "accountTypeAttr", "accountType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AccountDetails", "accountDetailsAttr", "AccountDetails", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ESB_FCR_ISModel.AccountDetailItemList());
}, true, ESB_FCR_ISModel.AccountDetailItemList)
].concat(_super.attributesToDeclare.call(this));
};
AccountTypeListItemRec.init();
return AccountTypeListItemRec;
})(OS.DataTypes.GenericRecord);
ESB_FCR_ISModel.AccountTypeListItemRec = AccountTypeListItemRec;

});
define("ESB_FCR_IS.model$AccountTypeListItemList", ["exports", "OutSystems/ClientRuntime/Main", "ESB_FCR_IS.model", "ESB_FCR_IS.model$AccountTypeListItemRec"], function (exports, OutSystems, ESB_FCR_ISModel) {
var OS = OutSystems.Internal;
var AccountTypeListItemList = (function (_super) {
__extends(AccountTypeListItemList, _super);
function AccountTypeListItemList(defaults) {
_super.apply(this, arguments);
}
AccountTypeListItemList.itemType = ESB_FCR_ISModel.AccountTypeListItemRec;
return AccountTypeListItemList;
})(OS.DataTypes.GenericRecordList);
ESB_FCR_ISModel.AccountTypeListItemList = AccountTypeListItemList;

});
define("ESB_FCR_IS.model$ResBodyRec", ["exports", "OutSystems/ClientRuntime/Main", "ESB_FCR_IS.model", "ESB_FCR_IS.model$AccountTypeListItemList"], function (exports, OutSystems, ESB_FCR_ISModel) {
var OS = OutSystems.Internal;
var ResBodyRec = (function (_super) {
__extends(ResBodyRec, _super);
function ResBodyRec(defaults) {
_super.apply(this, arguments);
}
ResBodyRec.attributesToDeclare = function () {
return [
this.attr("AccountTypeList", "accountTypeListAttr", "AccountTypeList", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ESB_FCR_ISModel.AccountTypeListItemList());
}, true, ESB_FCR_ISModel.AccountTypeListItemList)
].concat(_super.attributesToDeclare.call(this));
};
ResBodyRec.fromStructure = function (str) {
return new ResBodyRec(new ResBodyRec.RecordClass({
accountTypeListAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ResBodyRec.init();
return ResBodyRec;
})(OS.DataTypes.GenericRecord);
ESB_FCR_ISModel.ResBodyRec = ResBodyRec;

});
define("ESB_FCR_IS.model$GetAllAccountsReRec", ["exports", "OutSystems/ClientRuntime/Main", "ESB_FCR_IS.model", "ESB_FCR_IS.model$ReqHdrRec", "ESB_FCR_IS.model$ResBodyRec"], function (exports, OutSystems, ESB_FCR_ISModel) {
var OS = OutSystems.Internal;
var GetAllAccountsReRec = (function (_super) {
__extends(GetAllAccountsReRec, _super);
function GetAllAccountsReRec(defaults) {
_super.apply(this, arguments);
}
GetAllAccountsReRec.attributesToDeclare = function () {
return [
this.attr("ResHdr", "resHdrAttr", "ResHdr", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ESB_FCR_ISModel.ReqHdrRec());
}, true, ESB_FCR_ISModel.ReqHdrRec), 
this.attr("ResBody", "resBodyAttr", "ResBody", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ESB_FCR_ISModel.ResBodyRec());
}, true, ESB_FCR_ISModel.ResBodyRec)
].concat(_super.attributesToDeclare.call(this));
};
GetAllAccountsReRec.init();
return GetAllAccountsReRec;
})(OS.DataTypes.GenericRecord);
ESB_FCR_ISModel.GetAllAccountsReRec = GetAllAccountsReRec;

});
define("ESB_FCR_IS.model$StatusItemList", ["exports", "OutSystems/ClientRuntime/Main", "ESB_FCR_IS.model", "ESB_FCR_IS.model$StatusItemRec"], function (exports, OutSystems, ESB_FCR_ISModel) {
var OS = OutSystems.Internal;
var StatusItemList = (function (_super) {
__extends(StatusItemList, _super);
function StatusItemList(defaults) {
_super.apply(this, arguments);
}
StatusItemList.itemType = ESB_FCR_ISModel.StatusItemRec;
return StatusItemList;
})(OS.DataTypes.GenericRecordList);
ESB_FCR_ISModel.StatusItemList = StatusItemList;

});
define("ESB_FCR_IS.model$CustomerDetailsResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "ESB_FCR_IS.model", "ESB_FCR_IS.model$StatusItemList"], function (exports, OutSystems, ESB_FCR_ISModel) {
var OS = OutSystems.Internal;
var CustomerDetailsResponseRec = (function (_super) {
__extends(CustomerDetailsResponseRec, _super);
function CustomerDetailsResponseRec(defaults) {
_super.apply(this, arguments);
}
CustomerDetailsResponseRec.attributesToDeclare = function () {
return [
this.attr("Status", "statusAttr", "Status", false, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new ESB_FCR_ISModel.StatusItemList());
}, true, ESB_FCR_ISModel.StatusItemList), 
this.attr("CustomerID", "customerIDAttr", "CustomerID", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IC", "iCAttr", "IC", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("FullName", "fullNameAttr", "FullName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ShortName", "shortNameAttr", "ShortName", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("KIO", "kIOAttr", "KIO", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Salutation", "salutationAttr", "Salutation", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Category", "categoryAttr", "Category", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DateofIssue", "dateofIssueAttr", "DateofIssue", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DateofExpiry", "dateofExpiryAttr", "DateofExpiry", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("SpecialCustomer", "specialCustomerAttr", "SpecialCustomer", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Staff", "staffAttr", "Staff", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IncomeTaxNo", "incomeTaxNoAttr", "IncomeTaxNo", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("SecrecyLevel", "secrecyLevelAttr", "SecrecyLevel", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("SpendAnalysis", "spendAnalysisAttr", "SpendAnalysis", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CRIFConsentLevel", "cRIFConsentLevelAttr", "CRIFConsentLevel", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("RiskCategory", "riskCategoryAttr", "RiskCategory", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MailingAddressLine1", "mailingAddressLine1Attr", "MailingAddressLine1", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MailingAddressLine2", "mailingAddressLine2Attr", "MailingAddressLine2", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MailingAddressCity", "mailingAddressCityAttr", "MailingAddressCity", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MailingAddressState", "mailingAddressStateAttr", "MailingAddressState", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MailingAddressCountry", "mailingAddressCountryAttr", "MailingAddressCountry", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MailingAddressPostalCode", "mailingAddressPostalCodeAttr", "MailingAddressPostalCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("TelexHandphone", "telexHandphoneAttr", "TelexHandphone", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("FaxNo", "faxNoAttr", "FaxNo", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Mobile", "mobileAttr", "Mobile", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PhoneResidence", "phoneResidenceAttr", "PhoneResidence", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Addresschangeadvice", "addresschangeadviceAttr", "Addresschangeadvice", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PermanentAddressLine1", "permanentAddressLine1Attr", "PermanentAddressLine1", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PermanentAddressLine2", "permanentAddressLine2Attr", "PermanentAddressLine2", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PermanentAddressCity", "permanentAddressCityAttr", "PermanentAddressCity", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PermanentAddressState", "permanentAddressStateAttr", "PermanentAddressState", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PermanentAddressCountry", "permanentAddressCountryAttr", "PermanentAddressCountry", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PermanentAddressPostalCode", "permanentAddressPostalCodeAttr", "PermanentAddressPostalCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Email", "emailAttr", "Email", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Channelforstatement", "channelforstatementAttr", "Channelforstatement", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CustomerMISCode2", "customerMISCode2Attr", "CustomerMISCode2", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CustomerMISDescription2", "customerMISDescription2Attr", "CustomerMISDescription2", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("text", "textAttr", "#text", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ProfessionalCode", "professionalCodeAttr", "ProfessionalCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DateofBirth", "dateofBirthAttr", "DateofBirth", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Media", "mediaAttr", "Media", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IFSCCode", "iFSCCodeAttr", "IFSCCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EEFCPercentage", "eEFCPercentageAttr", "EEFCPercentage", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("BillMargin", "billMarginAttr", "BillMargin", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("BusinessType", "businessTypeAttr", "BusinessType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DateRegistered", "dateRegisteredAttr", "DateRegistered", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Signatory1Name", "signatory1NameAttr", "Signatory1Name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Signatory1Designation", "signatory1DesignationAttr", "Signatory1Designation", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Signatory2Name", "signatory2NameAttr", "Signatory2Name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Signatory2Designation", "signatory2DesignationAttr", "Signatory2Designation", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Signatory3Name", "signatory3NameAttr", "Signatory3Name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Signatory3Designation", "signatory3DesignationAttr", "Signatory3Designation", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Signatory4Name", "signatory4NameAttr", "Signatory4Name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Signatory4Designation", "signatory4DesignationAttr", "Signatory4Designation", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Signatory5Name", "signatory5NameAttr", "Signatory5Name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Signatory5Designation", "signatory5DesignationAttr", "Signatory5Designation", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DirectorPartner1Name", "directorPartner1NameAttr", "DirectorPartner1Name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DirectorPartner2Name", "directorPartner2NameAttr", "DirectorPartner2Name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DirectorPartner3Name", "directorPartner3NameAttr", "DirectorPartner3Name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DirectorPartner4Name", "directorPartner4NameAttr", "DirectorPartner4Name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DirectorPartner5Name", "directorPartner5NameAttr", "DirectorPartner5Name", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("HomeBranch", "homeBranchAttr", "HomeBranch", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CIFType", "cIFTypeAttr", "CIFType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ICType", "iCTypeAttr", "ICType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CurrentIcNo", "currentIcNoAttr", "CurrentIcNo", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("OfficerID", "officerIDAttr", "OfficerID", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Restricted", "restrictedAttr", "Restricted", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CustomerBlockStatus", "customerBlockStatusAttr", "CustomerBlockStatus", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("VerificationStatus", "verificationStatusAttr", "VerificationStatus", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ReasonofVerification", "reasonofVerificationAttr", "ReasonofVerification", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("GuardianType", "guardianTypeAttr", "GuardianType", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CustomerStatus", "customerStatusAttr", "CustomerStatus", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("KYCStatus", "kYCStatusAttr", "KYCStatus", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Riskreviewdate", "riskreviewdateAttr", "Riskreviewdate", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AddressChangeDate", "addressChangeDateAttr", "AddressChangeDate", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Contactable", "contactableAttr", "Contactable", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ContactableUpdatedon", "contactableUpdatedonAttr", "ContactableUpdatedon", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("HoldAddressLine1", "holdAddressLine1Attr", "HoldAddressLine1", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("HoldAddressLine2", "holdAddressLine2Attr", "HoldAddressLine2", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("HoldAddressLine3", "holdAddressLine3Attr", "HoldAddressLine3", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("HoldAddressPostalCode", "holdAddressPostalCodeAttr", "HoldAddressPostalCode", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CustomerMISclass2", "customerMISclass2Attr", "CustomerMISclass2", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("IntroduceriD", "introduceriDAttr", "IntroduceriD", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("LockRegistrationATM", "lockRegistrationATMAttr", "LockRegistrationATM", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("LockRegistrationIB", "lockRegistrationIBAttr", "LockRegistrationIB", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("LockRegistrationPOS", "lockRegistrationPOSAttr", "LockRegistrationPOS", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("LockRegistrationIVR", "lockRegistrationIVRAttr", "LockRegistrationIVR", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MemoFlag", "memoFlagAttr", "MemoFlag", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("LastModifiedDate", "lastModifiedDateAttr", "LastModifiedDate", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ELCMCustomerNo", "eLCMCustomerNoAttr", "ELCMCustomerNo", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CustomerOpenDate", "customerOpenDateAttr", "CustomerOpenDate", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("LiabilityID", "liabilityIDAttr", "LiabilityID", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("FlagReplicate", "flagReplicateAttr", "FlagReplicate", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CustomerDetailsResponseRec.init();
return CustomerDetailsResponseRec;
})(OS.DataTypes.GenericRecord);
ESB_FCR_ISModel.CustomerDetailsResponseRec = CustomerDetailsResponseRec;

});
define("ESB_FCR_IS.model$PostGetAllAccountsResponseRec", ["exports", "OutSystems/ClientRuntime/Main", "ESB_FCR_IS.model", "ESB_FCR_IS.model$GetAllAccountsReRec"], function (exports, OutSystems, ESB_FCR_ISModel) {
var OS = OutSystems.Internal;
var PostGetAllAccountsResponseRec = (function (_super) {
__extends(PostGetAllAccountsResponseRec, _super);
function PostGetAllAccountsResponseRec(defaults) {
_super.apply(this, arguments);
}
PostGetAllAccountsResponseRec.attributesToDeclare = function () {
return [
this.attr("GetAllAccountsRes", "getAllAccountsResAttr", "GetAllAccountsRes", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ESB_FCR_ISModel.GetAllAccountsReRec());
}, true, ESB_FCR_ISModel.GetAllAccountsReRec)
].concat(_super.attributesToDeclare.call(this));
};
PostGetAllAccountsResponseRec.fromStructure = function (str) {
return new PostGetAllAccountsResponseRec(new PostGetAllAccountsResponseRec.RecordClass({
getAllAccountsResAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PostGetAllAccountsResponseRec.init();
return PostGetAllAccountsResponseRec;
})(OS.DataTypes.GenericRecord);
ESB_FCR_ISModel.PostGetAllAccountsResponseRec = PostGetAllAccountsResponseRec;

});
define("ESB_FCR_IS.model$AuthorizedSignatoryRec", ["exports", "OutSystems/ClientRuntime/Main", "ESB_FCR_IS.model", "ESB_FCR_IS.model$CustomerDetailsResponseRec"], function (exports, OutSystems, ESB_FCR_ISModel) {
var OS = OutSystems.Internal;
var AuthorizedSignatoryRec = (function (_super) {
__extends(AuthorizedSignatoryRec, _super);
function AuthorizedSignatoryRec(defaults) {
_super.apply(this, arguments);
}
AuthorizedSignatoryRec.attributesToDeclare = function () {
return [
this.attr("CustomerDetailsResponse", "customerDetailsResponseAttr", "CustomerDetailsResponse", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new ESB_FCR_ISModel.CustomerDetailsResponseRec());
}, true, ESB_FCR_ISModel.CustomerDetailsResponseRec)
].concat(_super.attributesToDeclare.call(this));
};
AuthorizedSignatoryRec.fromStructure = function (str) {
return new AuthorizedSignatoryRec(new AuthorizedSignatoryRec.RecordClass({
customerDetailsResponseAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
AuthorizedSignatoryRec.init();
return AuthorizedSignatoryRec;
})(OS.DataTypes.GenericRecord);
ESB_FCR_ISModel.AuthorizedSignatoryRec = AuthorizedSignatoryRec;

});
define("ESB_FCR_IS.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var ESB_FCR_ISModel = exports;
});
