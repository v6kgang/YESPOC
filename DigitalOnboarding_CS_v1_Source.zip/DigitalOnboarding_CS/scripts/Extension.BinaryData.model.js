﻿define("Extension.BinaryData.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var Extension_BinaryDataModel = exports;
});
