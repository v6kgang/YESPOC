﻿define("Extension.PlatformRuntime_API.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var Extension_PlatformRuntime_APIModel = exports;
});
