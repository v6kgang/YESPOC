﻿define("YESBankPOC.Common.InvalidPermissions.mvc$model",["OutSystems/ClientRuntime/Main", "YESBankPOC.model", "YESBankPOC.Layouts.LayoutTopMenu.mvc$model", "OutSystemsUI.Content.BlankSlate.mvc$model"], function(OutSystems, YESBankPOCModel, YESBankPOC_Layouts_LayoutTopMenu_mvcModel, OutSystemsUI_Content_BlankSlate_mvcModel) {
	var OS = OutSystems.Internal;


	var VariablesRecord = (function(_super) {
		__extends(VariablesRecord, _super);
		function VariablesRecord(defaults) {
			_super.apply(this, arguments);
		}
		VariablesRecord.attributesToDeclare = function() {
			return[] .concat(_super.attributesToDeclare.call(this));
		};
		VariablesRecord.init();
		return VariablesRecord;
	}
	) (OS.DataTypes.GenericRecord);
	var WidgetsRecord = (function(_super) {
		__extends(WidgetsRecord, _super);
		function WidgetsRecord() {
			_super.apply(this, arguments);
		}
		WidgetsRecord.getWidgetsType = function() {
			return {};
		};

		return WidgetsRecord;
	}
	) (OS.Model.BaseWidgetRecordMap);
	var Model = (function(_super) {
		__extends(Model, _super);
		function Model() {
			_super.apply(this, arguments);
		}
		Model.getVariablesRecordConstructor = function() {
			return VariablesRecord;
		};
		Model.getWidgetsRecordConstructor = function() {
			return WidgetsRecord;
		};
		Model._hasValidationWidgetsValue = undefined;
		Object.defineProperty(Model, "hasValidationWidgets", {
			enumerable: true,
			configurable: true,
			get: function() {
				if ((Model._hasValidationWidgetsValue === undefined)) {
					Model._hasValidationWidgetsValue = (YESBankPOC_Layouts_LayoutTopMenu_mvcModel.hasValidationWidgets || OutSystemsUI_Content_BlankSlate_mvcModel.hasValidationWidgets);
				}

				return Model._hasValidationWidgetsValue;
			}
		}
		);

		Model.prototype.setInputs = function(inputs) {
		};
		return Model;
	}
	) (OS.Model.VariablelessViewModel);
	return new OS.Model.ModelFactory(Model);
});
define("YESBankPOC.Common.InvalidPermissions.mvc$view",["OutSystems/ClientRuntime/Main", "YESBankPOC.model", "YESBankPOC.controller", "react", "OutSystems/ReactView/Main", "YESBankPOC.Common.InvalidPermissions.mvc$model", "YESBankPOC.Common.InvalidPermissions.mvc$controller", "YESBankPOC.clientVariables", "YESBankPOC.Layouts.LayoutTopMenu.mvc$view", "OutSystems/ReactWidgets/Main", "OutSystemsUI.Content.BlankSlate.mvc$view"], function(OutSystems, YESBankPOCModel, YESBankPOCController, React, OSView, YESBankPOC_Common_InvalidPermissions_mvc_model, YESBankPOC_Common_InvalidPermissions_mvc_controller, YESBankPOCClientVariables, YESBankPOC_Layouts_LayoutTopMenu_mvc_view, OSWidgets, OutSystemsUI_Content_BlankSlate_mvc_view) {
	var OS = OutSystems.Internal;
	var PlaceholderContent = OSView.Widget.PlaceholderContent;
	var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


	var View = (function(_super) {
		__extends(View, _super);
		function View() {
			try {
				this.initialize.apply(this, arguments);
			} catch (error) {
				View.handleError(error);
				throw error;
			}
		}
		View.prototype.initialize = function() {
			_super.apply(this, arguments);
		};
		View.displayName = "Common.InvalidPermissions";
		View.getCssDependencies = function() {
			return["css/OutSystemsReactWidgets.css", "css/OutSystemsUI.OutSystemsUI.css", "css/YESBankPOC.YESBankPOC.css", "css/YESBankPOC.YESBankPOC.extra.css"];
		};
		View.getJsDependencies = function() {
			return[];
		};
		View.getBlocks = function() {
			return[YESBankPOC_Layouts_LayoutTopMenu_mvc_view, OutSystemsUI_Content_BlankSlate_mvc_view];
		};
		Object.defineProperty(View.prototype, "modelFactory", {
			get: function() {
				return YESBankPOC_Common_InvalidPermissions_mvc_model;
			}
			,
			enumerable: true,
			configurable: true
		});
		Object.defineProperty(View.prototype, "controllerFactory", {
			get: function() {
				return YESBankPOC_Common_InvalidPermissions_mvc_controller;
			}
			,
			enumerable: true,
			configurable: true
		});
		Object.defineProperty(View.prototype, "title", {
			get: function() {
				return "InvalidPermissions";
			}
			,
			enumerable: true,
			configurable: true
		});
		View.prototype.internalRender = function() {
			var model = this.model;
			var controller = this.controller;
			var idService = this.idService;
			var validationService = controller.validationService;
			var widgetsRecordProvider = this.widgetsRecordProvider;
			var callContext = controller.callContext();
			var $if = View.ifWidget;
			var $text = View.textWidget;
			var asPrimitiveValue = View.asPrimitiveValue;
			var getTranslation = View.getTranslation;
			var _this = this;

			return React.createElement("div", this.getRootNodeProperties(), React.createElement(YESBankPOC_Layouts_LayoutTopMenu_mvc_view, {
				inputs: {}
				,
				events: {
					_handleError: function(ex) {
						controller.handleError(ex);
					}
				}
				,
				_validationProps: {
					validationService: validationService
				}
				,
				_idProps: {
					service: idService,
					uuid: "0",
					alias: "1"
				}
				,
				_widgetRecordProvider: widgetsRecordProvider,
				placeholders: {
					header: PlaceholderContent.Empty,
					breadcrumbs: PlaceholderContent.Empty,
					title: PlaceholderContent.Empty,
					actions: PlaceholderContent.Empty,
					mainContent: new PlaceholderContent(function() {
						return[React.createElement(OutSystemsUI_Content_BlankSlate_mvc_view, {
							inputs: {
								FullHeight: true
							}
							,
							events: {
								_handleError: function(ex) {
									controller.handleError(ex);
								}
							}
							,
							_validationProps: {
								validationService: validationService
							}
							,
							_idProps: {
								service: idService,
								uuid: "1",
								alias: "2"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider,
							placeholders: {
								icon: new PlaceholderContent(function() {
									return[React.createElement(OSWidgets.Icon, {
										icon: "exclamation-triangle",
										iconSize:/*FontSize*/ 0,
										style: "icon text-neutral-4",
										visible: true,
										_idProps: {
											service: idService,
											name: "Icon1"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									})];
								}),
								content: new PlaceholderContent(function() {
									return[React.createElement(OSWidgets.Container, {
										align:/*Default*/ 0,
										animate: false,
										visible: true,
										_idProps: {
											service: idService,
											uuid: "3"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, React.createElement(OSWidgets.Text, {
										style: "heading6",
										text:["You don\'t have permissions to view this screen."],
										_idProps: {
											service: idService,
											uuid: "4"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									})), React.createElement(OSWidgets.Container, {
										align:/*Default*/ 0,
										animate: false,
										style: "margin-top-s",
										visible: true,
										_idProps: {
											service: idService,
											uuid: "5"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, "Please contact your system administrator.")];
								}),
								actions: new PlaceholderContent(function() {
									return[React.createElement(OSWidgets.Button, {
										enabled: true,
										isDefault: false,
										onClick: function() {
											OS.Navigation.navigateBack(null);
										}
										,
										style: "btn",
										visible: true,
										_idProps: {
											service: idService,
											uuid: "6"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, React.createElement(OSWidgets.Icon, {
										icon: "angle-left",
										iconSize:/*FontSize*/ 0,
										style: "icon",
										visible: true,
										_idProps: {
											service: idService,
											uuid: "7"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}), React.createElement(OSWidgets.Text, {
										style: "margin-left-s",
										text:["Go Back"],
										_idProps: {
											service: idService,
											uuid: "8"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									})), $if((OS.BuiltinFunctions.getUserId() === OS.BuiltinFunctions.nullIdentifier()), false, this, function() {
										return[React.createElement(OSWidgets.Button, {
											enabled: true,
											isDefault: false,
											onClick: function() {
												OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("YESBankPOC", "Login", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default));
											}
											,
											style: "btn btn-primary margin-left-m",
											visible: true,
											_idProps: {
												service: idService,
												uuid: "9"
											}
											,
											_widgetRecordProvider: widgetsRecordProvider
										}
										, "Login")];
									}
									, function() {
										return[];
									})];
								})
							}
							,
							_dependencies:[]
						})];
					}),
					footer: PlaceholderContent.Empty
				}
				,
				_dependencies:[]
			}));
		};
		return View;
	})(OSView.BaseView.BaseWebScreen);

	return View;
});
define("YESBankPOC.Common.InvalidPermissions.mvc$controller",["OutSystems/ClientRuntime/Main", "YESBankPOC.model", "YESBankPOC.controller", "YESBankPOC.languageResources", "YESBankPOC.clientVariables", "YESBankPOC.Common.controller"], function(OutSystems, YESBankPOCModel, YESBankPOCController, YESBankPOCLanguageResources, YESBankPOCClientVariables, YESBankPOC_CommonController) {
	var OS = OutSystems.Internal;
	var Controller = (function(_super) {
		__extends(Controller, _super);
		function Controller() {
			_super.apply(this, arguments);
			var controller = this.controller;
			this.clientActionProxies = {};
			this.dataFetchDependenciesOriginal = {};
			this.dataFetchDependentsGraph = {};
			this.shouldSendClientVarsToDataSources = false;
		}
		// Server Actions

		// Aggregates and Data Actions

		Controller.prototype.dataFetchActionNames =[];
		// Client Actions


		// Event Handler Actions
		Controller.prototype.onInitializeEventHandler = null;
		Controller.prototype.onReadyEventHandler = null;
		Controller.prototype.onRenderEventHandler = null;
		Controller.prototype.onDestroyEventHandler = null;
		Controller.prototype.onParametersChangedEventHandler = null;
		Controller.prototype.handleError = function(ex) {
			return YESBankPOC_CommonController.default.handleError(ex, this.callContext());
		};
		Controller.checkPermissions = function() {
		};
		Controller.prototype.getDefaultTimeout = function() {
			return YESBankPOCController.default.defaultTimeout;
		};
		return Controller;
	}
	) (OS.Controller.BaseViewController);
	return new OS.Controller.ControllerFactory(Controller, YESBankPOCLanguageResources);
});

