﻿define("YESBankPOC.MainFlow.EmployeeDetail.mvc$model",["OutSystems/ClientRuntime/Main", "YESBankPOC.model", "YESBankPOC.model$EMPLOYEESEMPLOYEESDEPARTMENTSJOBSRecordList", "YESBankPOC.model$EMPLOYEESRecordList", "YESBankPOC.model$EMPLOYEESDEPARTMENTSLOCATIONSRecordList", "YESBankPOC.model$JOBSRecordList"], function(OutSystems, YESBankPOCModel) {
	var OS = OutSystems.Internal;
	var GetEmployeesAggrRec = (function(_super) {
		__extends(GetEmployeesAggrRec, _super);
		function GetEmployeesAggrRec(defaults) {
			_super.apply(this, arguments);
		}
		GetEmployeesAggrRec.RecordListType = YESBankPOCModel.EMPLOYEESEMPLOYEESDEPARTMENTSJOBSRecordList;
		GetEmployeesAggrRec.init();
		return GetEmployeesAggrRec;
	}
	) (OS.Model.AggregateRecord);
	var GetEmployeeByIdAggrRec = (function(_super) {
		__extends(GetEmployeeByIdAggrRec, _super);
		function GetEmployeeByIdAggrRec(defaults) {
			_super.apply(this, arguments);
		}
		GetEmployeeByIdAggrRec.RecordListType = YESBankPOCModel.EMPLOYEESRecordList;
		GetEmployeeByIdAggrRec.init();
		return GetEmployeeByIdAggrRec;
	}
	) (OS.Model.AggregateRecord);
	var GetDepartmentsAggrRec = (function(_super) {
		__extends(GetDepartmentsAggrRec, _super);
		function GetDepartmentsAggrRec(defaults) {
			_super.apply(this, arguments);
		}
		GetDepartmentsAggrRec.RecordListType = YESBankPOCModel.EMPLOYEESDEPARTMENTSLOCATIONSRecordList;
		GetDepartmentsAggrRec.init();
		return GetDepartmentsAggrRec;
	}
	) (OS.Model.AggregateRecord);
	var GetEmployeeByEMPLOYEEIDAggrRec = (function(_super) {
		__extends(GetEmployeeByEMPLOYEEIDAggrRec, _super);
		function GetEmployeeByEMPLOYEEIDAggrRec(defaults) {
			_super.apply(this, arguments);
		}
		GetEmployeeByEMPLOYEEIDAggrRec.RecordListType = YESBankPOCModel.EMPLOYEESRecordList;
		GetEmployeeByEMPLOYEEIDAggrRec.init();
		return GetEmployeeByEMPLOYEEIDAggrRec;
	}
	) (OS.Model.AggregateRecord);
	var GetJobsAggrRec = (function(_super) {
		__extends(GetJobsAggrRec, _super);
		function GetJobsAggrRec(defaults) {
			_super.apply(this, arguments);
		}
		GetJobsAggrRec.RecordListType = YESBankPOCModel.JOBSRecordList;
		GetJobsAggrRec.init();
		return GetJobsAggrRec;
	}
	) (OS.Model.AggregateRecord);


	var VariablesRecord = (function(_super) {
		__extends(VariablesRecord, _super);
		function VariablesRecord(defaults) {
			_super.apply(this, arguments);
		}
		VariablesRecord.attributesToDeclare = function() {
			return[
			this.attr("EmployeeId", "employeeIdIn", "EmployeeId", true, false, OS.Types.Integer, function() {
				return 0;
			}
			, false),
			this.attr("_employeeIdInDataFetchStatus", "_employeeIdInDataFetchStatus", "_employeeIdInDataFetchStatus", true, false, OS.Types.Integer, function() {
				return/*Fetched*/ 1;
			}
			, false),
			this.attr("GetEmployees", "getEmployeesAggr", "getEmployeesAggr", true, true, OS.Types.Record, function() {
				return OS.DataTypes.ImmutableBase.getData(new GetEmployeesAggrRec());
			}
			, true, GetEmployeesAggrRec),
			this.attr("GetEmployeeById", "getEmployeeByIdAggr", "getEmployeeByIdAggr", true, true, OS.Types.Record, function() {
				return OS.DataTypes.ImmutableBase.getData(new GetEmployeeByIdAggrRec());
			}
			, true, GetEmployeeByIdAggrRec),
			this.attr("GetDepartments", "getDepartmentsAggr", "getDepartmentsAggr", true, true, OS.Types.Record, function() {
				return OS.DataTypes.ImmutableBase.getData(new GetDepartmentsAggrRec());
			}
			, true, GetDepartmentsAggrRec),
			this.attr("GetEmployeeByEMPLOYEEID", "getEmployeeByEMPLOYEEIDAggr", "getEmployeeByEMPLOYEEIDAggr", true, true, OS.Types.Record, function() {
				return OS.DataTypes.ImmutableBase.getData(new GetEmployeeByEMPLOYEEIDAggrRec());
			}
			, true, GetEmployeeByEMPLOYEEIDAggrRec),
			this.attr("GetJobs", "getJobsAggr", "getJobsAggr", true, true, OS.Types.Record, function() {
				return OS.DataTypes.ImmutableBase.getData(new GetJobsAggrRec());
			}
			, true, GetJobsAggrRec)
			] .concat(_super.attributesToDeclare.call(this));
		};
		VariablesRecord.init();
		return VariablesRecord;
	}
	) (OS.DataTypes.GenericRecord);
	var WidgetsRecord = (function(_super) {
		__extends(WidgetsRecord, _super);
		function WidgetsRecord() {
			_super.apply(this, arguments);
		}
		WidgetsRecord.getWidgetsType = function() {
			return {
				Form1: OS.Model.ValidationWidgetRecord,
				Input_FIRST_NAME: OS.Model.ValidationWidgetRecord,
				Input_LAST_NAME: OS.Model.ValidationWidgetRecord,
				Input_EMAIL: OS.Model.ValidationWidgetRecord,
				Input_PHONE_NUMBER: OS.Model.ValidationWidgetRecord,
				Input_HIRE_DATE: OS.Model.ValidationWidgetRecord,
				Dropdown3: OS.Model.ValidationWidgetRecord,
				Input_SALARY: OS.Model.ValidationWidgetRecord,
				Input_COMMISSION_PCT: OS.Model.ValidationWidgetRecord,
				Dropdown2: OS.Model.ValidationWidgetRecord,
				Dropdown1: OS.Model.ValidationWidgetRecord
			};
		};

		return WidgetsRecord;
	}
	) (OS.Model.BaseWidgetRecordMap);
	var Model = (function(_super) {
		__extends(Model, _super);
		function Model() {
			_super.apply(this, arguments);
		}
		Model.getVariablesRecordConstructor = function() {
			return VariablesRecord;
		};
		Model.getWidgetsRecordConstructor = function() {
			return WidgetsRecord;
		};
		Object.defineProperty(Model, "hasValidationWidgets", {
			enumerable: true,
			configurable: true,
			get: function() {
				return true;
			}
		}
		);

		Model.prototype.setInputs = function(inputs) {
			if ("EmployeeId" in inputs) {
				this.variables.employeeIdIn = OS.DataConversion.ServerDataConverter.from(inputs.EmployeeId, OS.Types.Integer);
			}

		};
		return Model;
	}
	) (OS.Model.BaseViewModel);
	return new OS.Model.ModelFactory(Model);
});
define("YESBankPOC.MainFlow.EmployeeDetail.mvc$view",["OutSystems/ClientRuntime/Main", "YESBankPOC.model", "YESBankPOC.controller", "react", "OutSystems/ReactView/Main", "YESBankPOC.MainFlow.EmployeeDetail.mvc$model", "YESBankPOC.MainFlow.EmployeeDetail.mvc$controller", "YESBankPOC.clientVariables", "YESBankPOC.Layouts.LayoutTopMenu.mvc$view", "OutSystems/ReactWidgets/Main", "OutSystemsUI.Adaptive.Columns2.mvc$view", "YESBankPOC.Common.Menu.mvc$view", "YESBankPOC.model$EMPLOYEESEMPLOYEESDEPARTMENTSJOBSRecordList", "YESBankPOC.model$EMPLOYEESRecordList", "YESBankPOC.model$EMPLOYEESDEPARTMENTSLOCATIONSRecordList", "YESBankPOC.model$JOBSRecordList"], function(OutSystems, YESBankPOCModel, YESBankPOCController, React, OSView, YESBankPOC_MainFlow_EmployeeDetail_mvc_model, YESBankPOC_MainFlow_EmployeeDetail_mvc_controller, YESBankPOCClientVariables, YESBankPOC_Layouts_LayoutTopMenu_mvc_view, OSWidgets, OutSystemsUI_Adaptive_Columns2_mvc_view, YESBankPOC_Common_Menu_mvc_view) {
	var OS = OutSystems.Internal;
	var PlaceholderContent = OSView.Widget.PlaceholderContent;
	var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


	var View = (function(_super) {
		__extends(View, _super);
		function View() {
			try {
				this.initialize.apply(this, arguments);
			} catch (error) {
				View.handleError(error);
				throw error;
			}
		}
		View.prototype.initialize = function() {
			_super.apply(this, arguments);
		};
		View.displayName = "MainFlow.EmployeeDetail";
		View.getCssDependencies = function() {
			return["css/OutSystemsReactWidgets.css", "css/OutSystemsUI.OutSystemsUI.css", "css/YESBankPOC.YESBankPOC.css", "css/YESBankPOC.YESBankPOC.extra.css"];
		};
		View.getJsDependencies = function() {
			return[];
		};
		View.getBlocks = function() {
			return[YESBankPOC_Layouts_LayoutTopMenu_mvc_view, OutSystemsUI_Adaptive_Columns2_mvc_view, YESBankPOC_Common_Menu_mvc_view];
		};
		Object.defineProperty(View.prototype, "modelFactory", {
			get: function() {
				return YESBankPOC_MainFlow_EmployeeDetail_mvc_model;
			}
			,
			enumerable: true,
			configurable: true
		});
		Object.defineProperty(View.prototype, "controllerFactory", {
			get: function() {
				return YESBankPOC_MainFlow_EmployeeDetail_mvc_controller;
			}
			,
			enumerable: true,
			configurable: true
		});
		Object.defineProperty(View.prototype, "title", {
			get: function() {
				return "EmployeeDetail";
			}
			,
			enumerable: true,
			configurable: true
		});
		View.prototype.internalRender = function() {
			var model = this.model;
			var controller = this.controller;
			var idService = this.idService;
			var validationService = controller.validationService;
			var widgetsRecordProvider = this.widgetsRecordProvider;
			var callContext = controller.callContext();
			var $if = View.ifWidget;
			var $text = View.textWidget;
			var asPrimitiveValue = View.asPrimitiveValue;
			var getTranslation = View.getTranslation;
			var _this = this;

			return React.createElement("div", this.getRootNodeProperties(), React.createElement(YESBankPOC_Layouts_LayoutTopMenu_mvc_view, {
				inputs: {}
				,
				events: {
					_handleError: function(ex) {
						controller.handleError(ex);
					}
				}
				,
				_validationProps: {
					validationService: validationService
				}
				,
				_idProps: {
					service: idService,
					uuid: "0",
					alias: "1"
				}
				,
				_widgetRecordProvider: widgetsRecordProvider,
				placeholders: {
					breadcrumbs: PlaceholderContent.Empty,
					title: new PlaceholderContent(function() {
						return[$if(((model.variables.employeeIdIn) !==(OS.BuiltinFunctions.nullIdentifier())), false, this, function() {
							return[React.createElement(OSWidgets.AdvancedHtml, {
								tag: "h1",
								_idProps: {
									service: idService,
									uuid: "1"
								}
								,
								_widgetRecordProvider: widgetsRecordProvider
							}
							, "Edit Employee")];
						}
						, function() {
							return[React.createElement(OSWidgets.AdvancedHtml, {
								tag: "h1",
								_idProps: {
									service: idService,
									uuid: "2"
								}
								,
								_widgetRecordProvider: widgetsRecordProvider
							}
							, "New Employee")];
						})];
					}),
					actions: PlaceholderContent.Empty,
					mainContent: new PlaceholderContent(function() {
						return[React.createElement(OutSystemsUI_Adaptive_Columns2_mvc_view, {
							inputs: {
								PhoneBehavior: YESBankPOCModel.staticEntities.breakColumns.all
							}
							,
							events: {
								_handleError: function(ex) {
									controller.handleError(ex);
								}
							}
							,
							_validationProps: {
								validationService: validationService
							}
							,
							_idProps: {
								service: idService,
								uuid: "3",
								alias: "2"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider,
							placeholders: {
								column1: new PlaceholderContent(function() {
									return[React.createElement(OSWidgets.Form, {
										_validationProps: {
											validationService: validationService
										}
										,
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										style: "form card",
										_idProps: {
											service: idService,
											name: "Form1"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, React.createElement(OSWidgets.Container, {
										align:/*Default*/ 0,
										animate: false,
										visible: true,
										_idProps: {
											service: idService,
											uuid: "5"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, React.createElement(OSWidgets.Label, {
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										mandatory: false,
										targetWidget: "Input_FIRST_NAME",
										_idProps: {
											service: idService,
											uuid: "6"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, "FIRST_NAME"), React.createElement(OSWidgets.Input, {
										_validationProps: {
											validationService: validationService,
											validationParentId: idService.getId("Form1")
										}
										,
										enabled: true,
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										inputType:/*Text*/ 0,
										mandatory: false,
										maxLength: 20,
										style: "form-control",
										variable: model.createVariable(OS.Types.Text, model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.fIRST_NAMEAttr, function(value) {
											model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.fIRST_NAMEAttr = value;
										}),
										_idProps: {
											service: idService,
											name: "Input_FIRST_NAME"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										variable_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getEmployeeByEMPLOYEEIDAggr.dataFetchStatusAttr)
									})), React.createElement(OSWidgets.Container, {
										align:/*Default*/ 0,
										animate: false,
										visible: true,
										_idProps: {
											service: idService,
											uuid: "8"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, React.createElement(OSWidgets.Label, {
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										mandatory: true,
										targetWidget: "Input_LAST_NAME",
										_idProps: {
											service: idService,
											uuid: "9"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, "LAST_NAME"), React.createElement(OSWidgets.Input, {
										_validationProps: {
											validationService: validationService,
											validationParentId: idService.getId("Form1")
										}
										,
										enabled: true,
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										inputType:/*Text*/ 0,
										mandatory: true,
										maxLength: 25,
										style: "form-control",
										variable: model.createVariable(OS.Types.Text, model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.lAST_NAMEAttr, function(value) {
											model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.lAST_NAMEAttr = value;
										}),
										_idProps: {
											service: idService,
											name: "Input_LAST_NAME"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										variable_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getEmployeeByEMPLOYEEIDAggr.dataFetchStatusAttr)
									})), React.createElement(OSWidgets.Container, {
										align:/*Default*/ 0,
										animate: false,
										visible: true,
										_idProps: {
											service: idService,
											uuid: "11"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, React.createElement(OSWidgets.Label, {
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										mandatory: true,
										targetWidget: "Input_EMAIL",
										_idProps: {
											service: idService,
											uuid: "12"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, "EMAIL"), React.createElement(OSWidgets.Input, {
										_validationProps: {
											validationService: validationService,
											validationParentId: idService.getId("Form1")
										}
										,
										enabled: true,
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										inputType:/*Text*/ 0,
										mandatory: true,
										maxLength: 25,
										style: "form-control",
										variable: model.createVariable(OS.Types.Text, model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.eMAILAttr, function(value) {
											model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.eMAILAttr = value;
										}),
										_idProps: {
											service: idService,
											name: "Input_EMAIL"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										variable_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getEmployeeByEMPLOYEEIDAggr.dataFetchStatusAttr)
									})), React.createElement(OSWidgets.Container, {
										align:/*Default*/ 0,
										animate: false,
										visible: true,
										_idProps: {
											service: idService,
											uuid: "14"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, React.createElement(OSWidgets.Label, {
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										mandatory: false,
										targetWidget: "Input_PHONE_NUMBER",
										_idProps: {
											service: idService,
											uuid: "15"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, "PHONE_NUMBER"), React.createElement(OSWidgets.Input, {
										_validationProps: {
											validationService: validationService,
											validationParentId: idService.getId("Form1")
										}
										,
										enabled: true,
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										inputType:/*Text*/ 0,
										mandatory: false,
										maxLength: 20,
										style: "form-control",
										variable: model.createVariable(OS.Types.Text, model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.pHONE_NUMBERAttr, function(value) {
											model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.pHONE_NUMBERAttr = value;
										}),
										_idProps: {
											service: idService,
											name: "Input_PHONE_NUMBER"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										variable_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getEmployeeByEMPLOYEEIDAggr.dataFetchStatusAttr)
									})), React.createElement(OSWidgets.Container, {
										align:/*Default*/ 0,
										animate: false,
										visible: true,
										_idProps: {
											service: idService,
											uuid: "17"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, React.createElement(OSWidgets.Label, {
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										mandatory: true,
										targetWidget: "Input_HIRE_DATE",
										_idProps: {
											service: idService,
											uuid: "18"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, "HIRE_DATE"), React.createElement(OSWidgets.Input, {
										_validationProps: {
											validationService: validationService,
											validationParentId: idService.getId("Form1")
										}
										,
										enabled: true,
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										inputType:/*Datetime*/ 5,
										mandatory: true,
										maxLength: 0,
										style: "form-control",
										variable: model.createVariable(OS.Types.DateTime, model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.hIRE_DATEAttr, function(value) {
											model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.hIRE_DATEAttr = value;
										}),
										_idProps: {
											service: idService,
											name: "Input_HIRE_DATE"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										variable_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getEmployeeByEMPLOYEEIDAggr.dataFetchStatusAttr)
									})), React.createElement(OSWidgets.Container, {
										align:/*Default*/ 0,
										animate: false,
										visible: true,
										_idProps: {
											service: idService,
											uuid: "20"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, React.createElement(OSWidgets.Label, {
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										mandatory: false,
										targetWidget: "Dropdown3",
										_idProps: {
											service: idService,
											uuid: "21"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, "JOB_ID"), React.createElement(OSWidgets.Dropdown, {
										_validationProps: {
											validationService: validationService,
											validationParentId: idService.getId("Form1")
										}
										,
										dropdownMode:/*Text*/ 0,
										enabled: true,
										labels: function(elem) {
											return elem.jOBSAttr.jOB_TITLEAttr;
										}
										,
										list: model.variables.getJobsAggr.listOut,
										mandatory: false,
										style: "dropdown",
										values: function(elem) {
											return elem.jOBSAttr.jOB_IDAttr;
										}
										,
										variable: model.createVariable(OS.Types.Text, model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.jOB_IDAttr, function(value) {
											model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.jOB_IDAttr = value;
										}),
										_idProps: {
											service: idService,
											name: "Dropdown3"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										list_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getJobsAggr.dataFetchStatusAttr),
										variable_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getEmployeeByEMPLOYEEIDAggr.dataFetchStatusAttr),
										placeholders: {
											content: PlaceholderContent.Empty
										}
										,
										_dependencies:[]
									})), React.createElement(OSWidgets.Container, {
										align:/*Default*/ 0,
										animate: false,
										visible: true,
										_idProps: {
											service: idService,
											uuid: "23"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, React.createElement(OSWidgets.Label, {
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										mandatory: false,
										targetWidget: "Input_SALARY",
										_idProps: {
											service: idService,
											uuid: "24"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, "SALARY"), React.createElement(OSWidgets.Input, {
										_validationProps: {
											validationService: validationService,
											validationParentId: idService.getId("Form1")
										}
										,
										enabled: true,
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										inputType:/*Number*/ 2,
										mandatory: false,
										maxLength: 8,
										style: "form-control",
										variable: model.createVariable(OS.Types.Decimal, model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.sALARYAttr, function(value) {
											model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.sALARYAttr = value;
										}),
										_idProps: {
											service: idService,
											name: "Input_SALARY"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										variable_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getEmployeeByEMPLOYEEIDAggr.dataFetchStatusAttr)
									})), React.createElement(OSWidgets.Container, {
										align:/*Default*/ 0,
										animate: false,
										visible: true,
										_idProps: {
											service: idService,
											uuid: "26"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, React.createElement(OSWidgets.Label, {
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										mandatory: false,
										targetWidget: "Input_COMMISSION_PCT",
										_idProps: {
											service: idService,
											uuid: "27"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, "COMMISSION_PCT"), React.createElement(OSWidgets.Input, {
										_validationProps: {
											validationService: validationService,
											validationParentId: idService.getId("Form1")
										}
										,
										enabled: true,
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										inputType:/*Number*/ 2,
										mandatory: false,
										maxLength: 2,
										style: "form-control",
										variable: model.createVariable(OS.Types.Decimal, model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.cOMMISSION_PCTAttr, function(value) {
											model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.cOMMISSION_PCTAttr = value;
										}),
										_idProps: {
											service: idService,
											name: "Input_COMMISSION_PCT"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										variable_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getEmployeeByEMPLOYEEIDAggr.dataFetchStatusAttr)
									})), React.createElement(OSWidgets.Container, {
										align:/*Default*/ 0,
										animate: false,
										visible: true,
										_idProps: {
											service: idService,
											uuid: "29"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, React.createElement(OSWidgets.Label, {
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										mandatory: false,
										targetWidget: "Dropdown2",
										_idProps: {
											service: idService,
											uuid: "30"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, "MANAGER_ID"), React.createElement(OSWidgets.Dropdown, {
										_validationProps: {
											validationService: validationService,
											validationParentId: idService.getId("Form1")
										}
										,
										dropdownMode:/*Text*/ 0,
										enabled: true,
										labels: function(elem) {
											return elem.eMPLOYEESAttr.fIRST_NAMEAttr;
										}
										,
										list: model.variables.getEmployeesAggr.listOut,
										mandatory: false,
										style: "dropdown",
										values: function(elem) {
											return elem.eMPLOYEESAttr.eMPLOYEE_IDAttr;
										}
										,
										variable: model.createVariable(OS.Types.Integer, model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.mANAGER_IDAttr, function(value) {
											model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.mANAGER_IDAttr = value;
										}),
										_idProps: {
											service: idService,
											name: "Dropdown2"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										list_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getEmployeesAggr.dataFetchStatusAttr),
										variable_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getEmployeeByEMPLOYEEIDAggr.dataFetchStatusAttr),
										placeholders: {
											content: PlaceholderContent.Empty
										}
										,
										_dependencies:[]
									})), React.createElement(OSWidgets.Container, {
										align:/*Default*/ 0,
										animate: false,
										visible: true,
										_idProps: {
											service: idService,
											uuid: "32"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, React.createElement(OSWidgets.Label, {
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										mandatory: false,
										targetWidget: "Dropdown1",
										_idProps: {
											service: idService,
											uuid: "33"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, "DEPARTMENT_ID"), React.createElement(OSWidgets.Dropdown, {
										_validationProps: {
											validationService: validationService,
											validationParentId: idService.getId("Form1")
										}
										,
										dropdownMode:/*Text*/ 0,
										enabled: true,
										labels: function(elem) {
											return elem.dEPARTMENTSAttr.dEPARTMENT_NAMEAttr;
										}
										,
										list: model.variables.getDepartmentsAggr.listOut,
										mandatory: false,
										style: "dropdown",
										values: function(elem) {
											return elem.dEPARTMENTSAttr.dEPARTMENT_IDAttr;
										}
										,
										variable: model.createVariable(OS.Types.Integer, model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.dEPARTMENT_IDAttr, function(value) {
											model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.dEPARTMENT_IDAttr = value;
										}),
										_idProps: {
											service: idService,
											name: "Dropdown1"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										list_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getDepartmentsAggr.dataFetchStatusAttr),
										variable_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getEmployeeByEMPLOYEEIDAggr.dataFetchStatusAttr),
										placeholders: {
											content: PlaceholderContent.Empty
										}
										,
										_dependencies:[]
									})), React.createElement(OSWidgets.Container, {
										align:/*Default*/ 0,
										animate: false,
										visible: true,
										_idProps: {
											service: idService,
											uuid: "35"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, React.createElement(OSWidgets.Button, {
										enabled: true,
										isDefault: false,
										onClick: function() {
											OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("YESBankPOC", "Employees", {}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default));
										}
										,
										style: "btn",
										visible: true,
										_idProps: {
											service: idService,
											uuid: "36"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, "Back"), React.createElement(OSWidgets.Button, {
										enabled: true,
										gridProperties: {
											classes: "ThemeGrid_MarginGutter"
										}
										,
										isDefault: true,
										onClick: function() {
											_this.validateWidget(idService.getId("Form1"));
											var eventHandlerContext = callContext.clone();
											controller.saveDetail$Action(controller.callContext(eventHandlerContext));


											;
										}
										,
										style: "btn btn-primary",
										visible: true,
										_idProps: {
											service: idService,
											uuid: "37"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, "Save")))];
								}),
								column2: new PlaceholderContent(function() {
									return[React.createElement(OSWidgets.Image, {
										extendedProperties: {
											alt: "",
											style: "margin-top: 0px;"
										}
										,
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										image: OS.Navigation.VersionedURL.getVersionedUrl("img/YESBankPOC.Request.png"),
										type:/*Static*/ 0,
										_idProps: {
											service: idService,
											uuid: "38"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									})];
								})
							}
							,
							_dependencies:[asPrimitiveValue(model.variables.getDepartmentsAggr.listOut), asPrimitiveValue(model.variables.getEmployeesAggr.listOut), asPrimitiveValue(model.variables.getJobsAggr.listOut), asPrimitiveValue(model.variables.getDepartmentsAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getEmployeesAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getJobsAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getEmployeeByEMPLOYEEIDAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.dEPARTMENT_IDAttr), asPrimitiveValue(model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.mANAGER_IDAttr), asPrimitiveValue(model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.cOMMISSION_PCTAttr), asPrimitiveValue(model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.sALARYAttr), asPrimitiveValue(model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.jOB_IDAttr), asPrimitiveValue(model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.hIRE_DATEAttr), asPrimitiveValue(model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.pHONE_NUMBERAttr
							), asPrimitiveValue(model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.eMAILAttr), asPrimitiveValue(model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.lAST_NAMEAttr), asPrimitiveValue(model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.fIRST_NAMEAttr)]
						})];
					}),
					footer: PlaceholderContent.Empty,
					header: new PlaceholderContent(function() {
						return[React.createElement(YESBankPOC_Common_Menu_mvc_view, {
							inputs: {}
							,
							events: {
								_handleError: function(ex) {
									controller.handleError(ex);
								}
							}
							,
							_validationProps: {
								validationService: validationService
							}
							,
							_idProps: {
								service: idService,
								uuid: "39",
								alias: "3"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider,
							_dependencies:[]
						})];
					})
				}
				,
				_dependencies:[asPrimitiveValue(model.variables.getDepartmentsAggr.listOut), asPrimitiveValue(model.variables.getEmployeesAggr.listOut), asPrimitiveValue(model.variables.getJobsAggr.listOut), asPrimitiveValue(model.variables.getDepartmentsAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getEmployeesAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getJobsAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getEmployeeByEMPLOYEEIDAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.dEPARTMENT_IDAttr), asPrimitiveValue(model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.mANAGER_IDAttr), asPrimitiveValue(model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.cOMMISSION_PCTAttr), asPrimitiveValue(model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.sALARYAttr), asPrimitiveValue(model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.jOB_IDAttr), asPrimitiveValue(model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.hIRE_DATEAttr), asPrimitiveValue(model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.pHONE_NUMBERAttr),
				asPrimitiveValue(model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.eMAILAttr), asPrimitiveValue(model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.lAST_NAMEAttr), asPrimitiveValue(model.variables.getEmployeeByEMPLOYEEIDAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.fIRST_NAMEAttr), asPrimitiveValue(model.variables.employeeIdIn)]
			}));
		};
		return View;
	})(OSView.BaseView.BaseWebScreen);

	return View;
});
define("YESBankPOC.MainFlow.EmployeeDetail.mvc$controller",["OutSystems/ClientRuntime/Main", "YESBankPOC.model", "YESBankPOC.controller", "YESBankPOC.languageResources", "YESBankPOC.clientVariables", "YESBankPOC.MainFlow.controller", "YESBankPOC.model$EMPLOYEESEMPLOYEESDEPARTMENTSJOBSRecordList", "YESBankPOC.model$EMPLOYEESRecordList", "YESBankPOC.model$EMPLOYEESDEPARTMENTSLOCATIONSRecordList", "YESBankPOC.model$JOBSRecordList"], function(OutSystems, YESBankPOCModel, YESBankPOCController, YESBankPOCLanguageResources, YESBankPOCClientVariables, YESBankPOC_MainFlowController) {
	var OS = OutSystems.Internal;
	var Controller = (function(_super) {
		__extends(Controller, _super);
		function Controller() {
			_super.apply(this, arguments);
			var controller = this.controller;
			this.clientActionProxies = {};
			this.dataFetchDependenciesOriginal = {
				getEmployees$AggrRefresh: 0,
				getEmployeeById$AggrRefresh: 0,
				getDepartments$AggrRefresh: 0,
				getEmployeeByEMPLOYEEID$AggrRefresh: 0,
				getJobs$AggrRefresh: 0
			};
			this.dataFetchDependentsGraph = {
				getEmployees$AggrRefresh:[],
				getEmployeeById$AggrRefresh:[],
				getDepartments$AggrRefresh:[],
				getEmployeeByEMPLOYEEID$AggrRefresh:[],
				getJobs$AggrRefresh:[]
			};
			this.shouldSendClientVarsToDataSources = false;
		}
		// Server Actions

		// Aggregates and Data Actions
		Controller.prototype.getEmployees$AggrRefresh = function(maxRecords, startIndex, callContext) {
			var model = this.model;
			var controller = this.controller;
			var callContext = controller.callContext(callContext);
			return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetEmployees", "screenservices/YESBankPOC/MainFlow/EmployeeDetail/ScreenDataSetGetEmployees", "cSKiFETpec5lAvqRCKlUng", maxRecords, startIndex, function(b) {
				model.variables.getEmployeesAggr.dataFetchStatusAttr = b;
			}
			, function(json) {
				model.variables.getEmployeesAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getEmployeesAggr.constructor));
			}
			, undefined, undefined, undefined, callContext, undefined, false);
		};
		Controller.prototype.getEmployeeById$AggrRefresh = function(maxRecords, startIndex, callContext) {
			var model = this.model;
			var controller = this.controller;
			var callContext = controller.callContext(callContext);
			return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetEmployeeById", "screenservices/YESBankPOC/MainFlow/EmployeeDetail/ScreenDataSetGetEmployeeById", "5pgr2Ndp86BU8cMPNHDisw", maxRecords, startIndex, function(b) {
				model.variables.getEmployeeByIdAggr.dataFetchStatusAttr = b;
			}
			, function(json) {
				model.variables.getEmployeeByIdAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getEmployeeByIdAggr.constructor));
			}
			, undefined, undefined, undefined, callContext, undefined, false);
		};
		Controller.prototype.getDepartments$AggrRefresh = function(maxRecords, startIndex, callContext) {
			var model = this.model;
			var controller = this.controller;
			var callContext = controller.callContext(callContext);
			return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetDepartments", "screenservices/YESBankPOC/MainFlow/EmployeeDetail/ScreenDataSetGetDepartments", "CPGQJk03zNfriKtXRtTl9w", maxRecords, startIndex, function(b) {
				model.variables.getDepartmentsAggr.dataFetchStatusAttr = b;
			}
			, function(json) {
				model.variables.getDepartmentsAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getDepartmentsAggr.constructor));
			}
			, undefined, undefined, undefined, callContext, undefined, false);
		};
		Controller.prototype.getEmployeeByEMPLOYEEID$AggrRefresh = function(maxRecords, startIndex, callContext) {
			var model = this.model;
			var controller = this.controller;
			var callContext = controller.callContext(callContext);
			return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetEmployeeByEMPLOYEEID", "screenservices/YESBankPOC/MainFlow/EmployeeDetail/ScreenDataSetGetEmployeeByEMPLOYEEID", "x8oNZJEXr7r+BRmXSqqXAQ", maxRecords, startIndex, function(b) {
				model.variables.getEmployeeByEMPLOYEEIDAggr.dataFetchStatusAttr = b;
			}
			, function(json) {
				model.variables.getEmployeeByEMPLOYEEIDAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getEmployeeByEMPLOYEEIDAggr.constructor));
			}
			, undefined, undefined, undefined, callContext, undefined, false);
		};
		Controller.prototype.getJobs$AggrRefresh = function(maxRecords, startIndex, callContext) {
			var model = this.model;
			var controller = this.controller;
			var callContext = controller.callContext(callContext);
			return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetJobs", "screenservices/YESBankPOC/MainFlow/EmployeeDetail/ScreenDataSetGetJobs", "FeA30HjzxKp8nxm164wfVA", maxRecords, startIndex, function(b) {
				model.variables.getJobsAggr.dataFetchStatusAttr = b;
			}
			, function(json) {
				model.variables.getJobsAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getJobsAggr.constructor));
			}
			, undefined, undefined, undefined, callContext, undefined, false);
		};

		Controller.prototype.dataFetchActionNames =["getEmployees$AggrRefresh", "getEmployeeById$AggrRefresh", "getDepartments$AggrRefresh", "getEmployeeByEMPLOYEEID$AggrRefresh", "getJobs$AggrRefresh"];
		// Client Actions
		Controller.prototype._saveDetail$Action = function(callContext) {
			var model = this.model;
			var controller = this.controller;
			var idService = this.idService;
			controller.ensureControllerAlive("SaveDetail");
			callContext = controller.callContext(callContext);
			if ((model.widgets.get(idService.getId("Form1")).validAttr)) {
				OS.FeedbackMessageService.showFeedbackMessage("Save functionalty disabled.",/*Info*/ 0);
				// Destination: /YESBankPOC/Employees
				return OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("YESBankPOC", "Employees", {}
				), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default), callContext, true);
			} else {
				OS.FeedbackMessageService.showFeedbackMessage("Correct page errors!",/*Info*/ 0);
			}

		};

		Controller.prototype.saveDetail$Action = function(callContext) {
			var controller = this.controller;
			return controller.safeExecuteClientAction(controller._saveDetail$Action, callContext);

		};

		// Event Handler Actions
		Controller.prototype.onInitializeEventHandler = null;
		Controller.prototype.onReadyEventHandler = null;
		Controller.prototype.onRenderEventHandler = null;
		Controller.prototype.onDestroyEventHandler = null;
		Controller.prototype.onParametersChangedEventHandler = null;
		Controller.prototype.handleError = function(ex) {
			return YESBankPOC_MainFlowController.default.handleError(ex, this.callContext());
		};
		Controller.checkPermissions = function() {
		};
		Controller.prototype.getDefaultTimeout = function() {
			return YESBankPOCController.default.defaultTimeout;
		};
		return Controller;
	}
	) (OS.Controller.BaseViewController);
	return new OS.Controller.ControllerFactory(Controller, YESBankPOCLanguageResources);
});

