﻿define("OutSystemsUI.Navigation.Pagination.mvc$model", ["OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.model$ListNavigationList", "OutSystemsUI.controller$IsPhone", "OutSystemsUI.model$ListNavigationRec"], function (OutSystems, OutSystemsUIModel, OutSystemsUIController) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("MiddleNavigationPages", "middleNavigationPagesVar", "MiddleNavigationPages", true, false, OS.Types.RecordList, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.ListNavigationList());
}, false, OutSystemsUIModel.ListNavigationList), 
this.attr("SelectedPageButton", "selectedPageButtonVar", "SelectedPageButton", true, false, OS.Types.Integer, function () {
return 0;
}, false), 
this.attr("TotalPages", "totalPagesVar", "TotalPages", true, false, OS.Types.Integer, function () {
return 0;
}, false), 
this.attr("LastPageNumber", "lastPageNumberVar", "LastPageNumber", true, false, OS.Types.Integer, function () {
return 0;
}, false), 
this.attr("IsVisible", "isVisibleVar", "IsVisible", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("IsPhone", "isPhoneVar", "IsPhone", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("GoToValue", "goToValueVar", "GoToValue", true, false, OS.Types.Integer, function () {
return 1;
}, false), 
this.attr("StartIndex", "startIndexIn", "StartIndex", true, false, OS.Types.Integer, function () {
return 0;
}, false), 
this.attr("_startIndexInDataFetchStatus", "_startIndexInDataFetchStatus", "_startIndexInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("MaxRecords", "maxRecordsIn", "MaxRecords", true, false, OS.Types.Integer, function () {
return 0;
}, false), 
this.attr("_maxRecordsInDataFetchStatus", "_maxRecordsInDataFetchStatus", "_maxRecordsInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("TotalCount", "totalCountIn", "TotalCount", true, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, false), 
this.attr("_totalCountInDataFetchStatus", "_totalCountInDataFetchStatus", "_totalCountInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("ShowGoToPage", "showGoToPageIn", "ShowGoToPage", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("_showGoToPageInDataFetchStatus", "_showGoToPageInDataFetchStatus", "_showGoToPageInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false), 
this.attr("ExtendedClass", "extendedClassIn", "ExtendedClass", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("_extendedClassInDataFetchStatus", "_extendedClassInDataFetchStatus", "_extendedClassInDataFetchStatus", true, false, OS.Types.Integer, function () {
return /*Fetched*/ 1;
}, false)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {
Input_SelectedPageButton: OS.Model.ValidationWidgetRecord
};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return true;
}
});

Model.prototype.setInputs = function (inputs) {
if("StartIndex" in inputs) {
this.variables.startIndexIn = inputs.StartIndex;
if("_startIndexInDataFetchStatus" in inputs) {
this.variables._startIndexInDataFetchStatus = inputs._startIndexInDataFetchStatus;
}

}

if("MaxRecords" in inputs) {
this.variables.maxRecordsIn = inputs.MaxRecords;
if("_maxRecordsInDataFetchStatus" in inputs) {
this.variables._maxRecordsInDataFetchStatus = inputs._maxRecordsInDataFetchStatus;
}

}

if("TotalCount" in inputs) {
this.variables.totalCountIn = inputs.TotalCount;
if("_totalCountInDataFetchStatus" in inputs) {
this.variables._totalCountInDataFetchStatus = inputs._totalCountInDataFetchStatus;
}

}

if("ShowGoToPage" in inputs) {
this.variables.showGoToPageIn = inputs.ShowGoToPage;
if("_showGoToPageInDataFetchStatus" in inputs) {
this.variables._showGoToPageInDataFetchStatus = inputs._showGoToPageInDataFetchStatus;
}

}

if("ExtendedClass" in inputs) {
this.variables.extendedClassIn = inputs.ExtendedClass;
if("_extendedClassInDataFetchStatus" in inputs) {
this.variables._extendedClassInDataFetchStatus = inputs._extendedClassInDataFetchStatus;
}

}

};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model);
});
define("OutSystemsUI.Navigation.Pagination.mvc$view", ["OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "react", "OutSystems/ReactView/Main", "OutSystemsUI.Navigation.Pagination.mvc$model", "OutSystemsUI.Navigation.Pagination.mvc$controller", "OutSystems/ReactWidgets/Main", "OutSystemsUI.model$ListNavigationList", "OutSystemsUI.controller$IsPhone", "OutSystemsUI.model$ListNavigationRec"], function (OutSystems, OutSystemsUIModel, OutSystemsUIController, React, OSView, OutSystemsUI_Navigation_Pagination_mvc_model, OutSystemsUI_Navigation_Pagination_mvc_controller, OSWidgets) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Navigation.Pagination";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return OutSystemsUI_Navigation_Pagination_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return OutSystemsUI_Navigation_Pagination_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var $text = View.textWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var getTranslation = View.getTranslation;
            var _this = this;

            return React.createElement("div", this.getRootNodeProperties(), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: ("pagination " + model.variables.extendedClassIn),
visible: model.variables.isVisibleVar,
_idProps: {
service: idService,
name: "PaginationWrapper"
},
_widgetRecordProvider: widgetsRecordProvider,
style_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._extendedClassInDataFetchStatus)
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
role: "status",
"aria-live": "polite",
"aria-atomic": "true"
},
gridProperties: {
classes: "OSInline"
},
style: "pagination-counter",
visible: true,
_idProps: {
service: idService,
name: "PaginationRecords"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: ((model.variables.startIndexIn + 1)).toString(),
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._startIndexInDataFetchStatus)
}), React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-trans": OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("CIhIflibW0SNDBF1IjOlqA#Value.-1103515167.1", "6c08ff2e-126f-45fe-9737-83cf5de0970f")
},
text: [$text(getTranslation("pXwE30aZ60u1odHgwarKxA#Value", " to "))],
_idProps: {
service: idService,
uuid: "3"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Expression, {
value: model.getCachedValue(idService.getId("PostuaGEoES8eAKZ_FQhhA.Value"), function () {
return OS.BuiltinFunctions.longIntegerToText(((OS.BuiltinFunctions.integerToLongInteger((model.variables.maxRecordsIn + model.variables.startIndexIn)).gte(model.variables.totalCountIn)) ? (model.variables.totalCountIn) : (OS.BuiltinFunctions.integerToLongInteger((model.variables.maxRecordsIn + model.variables.startIndexIn)))));
}, function () {
return model.variables.maxRecordsIn;
}, function () {
return model.variables.startIndexIn;
}, function () {
return model.variables.totalCountIn;
}),
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._maxRecordsInDataFetchStatus, model.variables._startIndexInDataFetchStatus, model.variables._totalCountInDataFetchStatus)
}), React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-trans": OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("7Z+HrRYQq0+rUCxKOrfWRQ#Value.2090863669.1", "f3606a4b-4ae9-4147-bbb5-1f016314d425")
},
text: [$text(getTranslation("pi29bOzmnECCH4s0wX7adQ#Value", " of "))],
_idProps: {
service: idService,
uuid: "5"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Expression, {
value: OS.BuiltinFunctions.longIntegerToText(model.variables.totalCountIn),
_idProps: {
service: idService,
uuid: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._totalCountInDataFetchStatus)
}), React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-trans": OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("H00kRd0c+0Ga34jvJCk2sg#Value.-1808381058.1", "7daeb8e1-4b0e-4831-b7ad-c9895d4f2d60")
},
text: [$text(getTranslation("hlifhXWvEUiM2xnV5qJqWw#Value", " items"))],
_idProps: {
service: idService,
uuid: "7"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
role: "navigation",
"aria-label": OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("_I_1p+Iu2kiwtVL3GoneXQ#Value.-1003809862.1", "Pagination")
},
gridProperties: {
classes: "OSInline"
},
style: "pagination-container",
visible: true,
_idProps: {
service: idService,
name: "PaginationContainer"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Button, {
enabled: (model.variables.startIndexIn > 0),
extendedProperties: {
"aria-label": "go to previous page"
},
isDefault: false,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Navigation/Pagination/Button OnClick");
return controller.goTo$Action((model.variables.startIndexIn - model.variables.maxRecordsIn), controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "pagination-button",
visible: (model.variables.totalPagesVar > 0),
_idProps: {
service: idService,
uuid: "9"
},
_widgetRecordProvider: widgetsRecordProvider,
enabled_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._startIndexInDataFetchStatus)
}, React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.previous,
gridProperties: {
classes: "OSInline"
},
style: "pagination-previous",
_idProps: {
service: idService,
name: "Previous"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "display-flex",
visible: !(model.variables.showGoToPageIn),
_idProps: {
service: idService,
uuid: "11"
},
_widgetRecordProvider: widgetsRecordProvider,
visible_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._showGoToPageInDataFetchStatus)
}, React.createElement(OSWidgets.Button, {
enabled: true,
extendedProperties: {
"aria-label": model.getCachedValue(idService.getId("WA0Sau_9C0KH38R0j3aNBw.aria-label"), function () {
return (((model.variables.selectedPageButtonVar > 1)) ? (OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("eDZkRSqLpUiQwkEFo+1+sA#Value.-874293523.1", "go to page 1")) : (OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("eDZkRSqLpUiQwkEFo+1+sA#Value.-1981675734.1", "page 1, current page")));
}, function () {
return model.variables.selectedPageButtonVar;
})
},
isDefault: false,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Navigation/Pagination/Button OnClick");
return controller.goTo$Action(0, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: model.getCachedValue(idService.getId("WA0Sau_9C0KH38R0j3aNBw.Style"), function () {
return (((model.variables.selectedPageButtonVar > 1)) ? ("pagination-button") : ("pagination-button is--active"));
}, function () {
return model.variables.selectedPageButtonVar;
}),
visible: (model.variables.totalPagesVar >= 1),
_idProps: {
service: idService,
uuid: "12"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: "1",
_idProps: {
service: idService,
uuid: "13"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "OSInline"
},
style: "pagination-button is--ellipsis",
visible: model.getCachedValue(idService.getId("8KkkGKspkU238Co6HpOIng.Visible"), function () {
return ((model.variables.isPhoneVar) ? (((model.variables.selectedPageButtonVar > 2) && (model.variables.totalPagesVar >= 5))) : (((model.variables.selectedPageButtonVar > 3) && (model.variables.totalPagesVar >= 5))));
}, function () {
return model.variables.isPhoneVar;
}, function () {
return model.variables.selectedPageButtonVar;
}, function () {
return model.variables.totalPagesVar;
}),
_idProps: {
service: idService,
uuid: "14"
},
_widgetRecordProvider: widgetsRecordProvider
}, "..."), React.createElement(OSWidgets.List, {
animateItems: false,
extendedProperties: {
"disable-virtualization": "True"
},
mode: /*Default*/ 0,
source: model.variables.middleNavigationPagesVar,
style: "list list-group",
tag: "div",
_idProps: {
service: idService,
name: "PaginationList"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
content: new IteratorPlaceholderContent(function (idService, callContext) {
return [React.createElement(OSWidgets.Button, {
enabled: true,
extendedProperties: {
"aria-label": model.getCachedValue(idService.getId("vX3xw_o7T0iudkBQmFXZyQ.aria-label"), function () {
return (((model.variables.middleNavigationPagesVar.getCurrent(callContext.iterationContext).pageAttr === model.variables.selectedPageButtonVar)) ? (((OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("eremlT2dUUuJAvi0JY4qPA#Value.106426225.1", "page ") + (model.variables.selectedPageButtonVar).toString()) + OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("eremlT2dUUuJAvi0JY4qPA#Value.611641590.1", " current page"))) : ((OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("eremlT2dUUuJAvi0JY4qPA#Value.-1690771004.1", "go to page ") + (model.variables.middleNavigationPagesVar.getCurrent(callContext.iterationContext).pageAttr).toString())));
}, function () {
return model.variables.middleNavigationPagesVar.getCurrent(callContext.iterationContext).pageAttr;
}, function () {
return model.variables.selectedPageButtonVar;
})
},
isDefault: false,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Navigation/Pagination/Button OnClick");
return controller.goTo$Action(model.variables.middleNavigationPagesVar.getCurrent(callContext.iterationContext).startIndexAttr, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: model.getCachedValue(idService.getId("vX3xw_o7T0iudkBQmFXZyQ.Style"), function () {
return ((((model.variables.middleNavigationPagesVar.getCurrent(callContext.iterationContext).pageAttr) !== (model.variables.selectedPageButtonVar))) ? ("pagination-button") : ("pagination-button is--active"));
}, function () {
return model.variables.middleNavigationPagesVar.getCurrent(callContext.iterationContext).pageAttr;
}, function () {
return model.variables.selectedPageButtonVar;
}),
visible: model.getCachedValue(idService.getId("vX3xw_o7T0iudkBQmFXZyQ.Visible"), function () {
return (((model.variables.selectedPageButtonVar >= 3)) ? ((model.variables.middleNavigationPagesVar.getCurrentRowNumber(callContext.iterationContext) <= 3)) : (true));
}, function () {
return model.variables.selectedPageButtonVar;
}, function () {
return model.variables.middleNavigationPagesVar.getCurrentRowNumber(callContext.iterationContext);
}),
_idProps: {
service: idService,
uuid: "16"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: [asPrimitiveValue(model.variables.middleNavigationPagesVar.getCurrent(callContext.iterationContext).pageAttr)]
}, React.createElement(OSWidgets.Expression, {
value: (model.variables.middleNavigationPagesVar.getCurrent(callContext.iterationContext).pageAttr).toString(),
_idProps: {
service: idService,
uuid: "17"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
}, callContext, idService, "1")
},
_dependencies: [asPrimitiveValue(model.variables.selectedPageButtonVar)]
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "OSInline"
},
style: "pagination-button is--ellipsis hide-on-service-studio",
visible: model.getCachedValue(idService.getId("dbkcSuivRk68Set3P2Y4Ww.Visible"), function () {
return ((model.variables.isPhoneVar) ? (((model.variables.totalPagesVar > model.variables.selectedPageButtonVar) && (model.variables.totalPagesVar >= 5))) : (((model.variables.totalPagesVar > (model.variables.selectedPageButtonVar + 1)) && (model.variables.totalPagesVar >= 5))));
}, function () {
return model.variables.isPhoneVar;
}, function () {
return model.variables.totalPagesVar;
}, function () {
return model.variables.selectedPageButtonVar;
}),
_idProps: {
service: idService,
uuid: "18"
},
_widgetRecordProvider: widgetsRecordProvider
}, "..."), React.createElement(OSWidgets.Button, {
enabled: true,
extendedProperties: {
"aria-label": model.getCachedValue(idService.getId("DumQYKlLNkuDv8zwyQhghw.aria-label"), function () {
return (((model.variables.selectedPageButtonVar === model.variables.lastPageNumberVar)) ? (((OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("sj82vjeE_06ghjV7e5ZoDw#Value.106426225.1", "page ") + (model.variables.lastPageNumberVar).toString()) + OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("sj82vjeE_06ghjV7e5ZoDw#Value.-1991118687.1", ", current page, is last page"))) : (((OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("sj82vjeE_06ghjV7e5ZoDw#Value.106426225.2", "page ") + (model.variables.lastPageNumberVar).toString()) + OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("sj82vjeE_06ghjV7e5ZoDw#Value.-1429362217.1", ", is last page"))));
}, function () {
return model.variables.selectedPageButtonVar;
}, function () {
return model.variables.lastPageNumberVar;
})
},
isDefault: false,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Navigation/Pagination/Button OnClick");
return controller.goTo$Action((model.variables.totalPagesVar * model.variables.maxRecordsIn), controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: model.getCachedValue(idService.getId("DumQYKlLNkuDv8zwyQhghw.Style"), function () {
return ((((model.variables.selectedPageButtonVar) !== (model.variables.lastPageNumberVar))) ? ("pagination-button") : ("pagination-button is--active"));
}, function () {
return model.variables.selectedPageButtonVar;
}, function () {
return model.variables.lastPageNumberVar;
}),
visible: (model.variables.totalPagesVar > 3),
_idProps: {
service: idService,
uuid: "19"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Expression, {
value: (model.variables.lastPageNumberVar).toString(),
_idProps: {
service: idService,
uuid: "20"
},
_widgetRecordProvider: widgetsRecordProvider
}))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "pagination-input",
visible: model.variables.showGoToPageIn,
_idProps: {
service: idService,
uuid: "21"
},
_widgetRecordProvider: widgetsRecordProvider,
visible_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables._showGoToPageInDataFetchStatus)
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: false,
style: "wcag-hide-text ",
targetWidget: "Input_SelectedPageButton",
_idProps: {
service: idService,
uuid: "22"
},
_widgetRecordProvider: widgetsRecordProvider
}, $text(getTranslation("Ul+vX812RkazxUoAttNpIA#Value", "Insert the page number to go to..."))), React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService
},
enabled: true,
extendedEvents: {
onBlur: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Navigation/Pagination/Input_SelectedPageButton onblur");
controller.inputOnChange$Action(true, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
}
},
inputType: /*Number*/ 2,
mandatory: false,
maxLength: 0,
onChange: function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Navigation/Pagination/Input_SelectedPageButton OnChange");
controller.inputOnChange$Action(false, controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});

;
},
style: "form-control",
variable: model.createVariable(OS.Types.Integer, model.variables.goToValueVar, function (value) {
model.variables.goToValueVar = value;
}),
_idProps: {
service: idService,
name: "Input_SelectedPageButton"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "OSInline"
},
style: "pagination-counter",
visible: true,
_idProps: {
service: idService,
name: "TotalPagesCounter"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-trans": OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("HEE7sk5FOk6vxjkCkf7Wsw#Value.-34998653.1", "b207f5ee-aead-4d0c-bbbd-2bc9a6361e2c")
},
text: [$text(getTranslation("OLL7GmSLPkKBlcXr9c69fw#Value", "of "))],
_idProps: {
service: idService,
uuid: "25"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Expression, {
value: ((model.variables.totalPagesVar + 1)).toString(),
_idProps: {
service: idService,
uuid: "26"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Text, {
extendedProperties: {
"data-trans": OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("qFZglgJQN0690k+H4eaiTQ#Value.839907371.1", "04fc28b2-d8a4-409b-847f-ebf28e962f60")
},
text: [$text(getTranslation("ZJ8Y3zyBdUKQVGfPtKYJAw#Value", " pages"))],
_idProps: {
service: idService,
uuid: "27"
},
_widgetRecordProvider: widgetsRecordProvider
}))), React.createElement(OSWidgets.Button, {
enabled: (model.variables.selectedPageButtonVar < (model.variables.totalPagesVar + 1)),
extendedProperties: {
"aria-label": OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("v9IrcYA0u0u2Wp6WpKrtYg#Value.-1061341073.1", "go to next page")
},
isDefault: false,
onClick: function () {
return Promise.resolve().then(function () {
var eventHandlerContext = callContext.clone();
return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(eventHandlerContext);

OutSystemsDebugger.setThreadStartName(eventHandlerContext.id, "Navigation/Pagination/Button OnClick");
return controller.goTo$Action((model.variables.startIndexIn + model.variables.maxRecordsIn), controller.callContext(eventHandlerContext));
}, function () {
controller.popDebuggerContext(eventHandlerContext);
});
});
;
},
style: "pagination-button",
visible: (model.variables.totalPagesVar > 0),
_idProps: {
service: idService,
uuid: "28"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Placeholder, {
align: /*Default*/ 0,
content: _this.props.placeholders.next,
gridProperties: {
classes: "OSInline"
},
style: "pagination-next",
_idProps: {
service: idService,
name: "Next"
},
_widgetRecordProvider: widgetsRecordProvider
})))));
        };
        return View;
    })(OSView.BaseView.BaseWebBlock);
	
    return View;
});
define("OutSystemsUI.Navigation.Pagination.mvc$controller", ["OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.languageResources", "OutSystemsUI.Navigation.Pagination.mvc$translationsResources", "OutSystemsUI.Navigation.Pagination.mvc$debugger", "OutSystemsUI.Navigation.Pagination.mvc$controller.InputOnChange.SetListenerJS", "OutSystemsUI.Navigation.Pagination.mvc$controller.InitPagination.GetToltalPagesJS", "OutSystemsUI.Navigation.Pagination.mvc$controller.OnDestroy.removeListenersJS", "OutSystemsUI.model$ListNavigationList", "OutSystemsUI.controller$IsPhone", "OutSystemsUI.model$ListNavigationRec"], function (OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUILanguageResources, OutSystemsUI_Navigation_Pagination_mvc_TranslationsResources, OutSystemsUI_Navigation_Pagination_mvc_Debugger, OutSystemsUI_Navigation_Pagination_mvc_controller_InputOnChange_SetListenerJS, OutSystemsUI_Navigation_Pagination_mvc_controller_InitPagination_GetToltalPagesJS, OutSystemsUI_Navigation_Pagination_mvc_controller_OnDestroy_removeListenersJS) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {
goTo$Action: function (newStartIndexIn) {
newStartIndexIn = (newStartIndexIn === undefined) ? 0 : newStartIndexIn;
return controller.executeActionInsideJSNode(controller._goTo$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(newStartIndexIn, OS.Types.Integer)), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "GoTo");
},
inputOnChange$Action: function (isBlurIn) {
isBlurIn = (isBlurIn === undefined) ? false : isBlurIn;
return controller.executeActionInsideJSNode(controller._inputOnChange$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(isBlurIn, OS.Types.Boolean)), controller.callContext(), function (actionResults) {
return {};
}, function () {
return;
}, "InputOnChange");
}
};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.shouldSendClientVarsToDataSources = false;
}
Controller.prototype.translationResources = OutSystemsUI_Navigation_Pagination_mvc_TranslationsResources;
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._goTo$Action = function (newStartIndexIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("GoTo");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.Navigation.Pagination.GoTo$vars"))());
vars.value.newStartIndexInLocal = newStartIndexIn;
varBag.callContext = callContext;
varBag.vars = vars;
OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:poYTH0k2fEaGEGtg4FKYPQ:/NRWebFlows.4IyGEdDlC0yweUOrtzVtVQ/NodesShownInESpaceTree.Pk7HFiqXDkWB9B2ls9hgbg/ClientActions.poYTH0k2fEaGEGtg4FKYPQ:gsngZ7y3s32apVmdOTu4TA", "OutSystemsUI", "GoTo", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:98i9dFka+0qCFdW8A0Ex0g", callContext.id);
return OS.Flow.executeAsyncFlow(function () {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:jrcaD66sSEqe4_N9vAqhsg", callContext.id);
// Trigger Event: OnNavigate
return controller.onNavigate$Action(vars.value.newStartIndexInLocal, callContext).then(function () {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:D_fncf_3OUKvy6Kq9CEsVw", callContext.id);
// GoToValue = SelectedPageButton
model.variables.goToValueVar = model.variables.selectedPageButtonVar;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:FatnoVYEaUuBSpJdtNrkWA", callContext.id);
});
}).then(function (res) {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:poYTH0k2fEaGEGtg4FKYPQ", callContext.id);
return res;

}).catch(function (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:poYTH0k2fEaGEGtg4FKYPQ", callContext.id);
throw ex;

});
};
Controller.registerVariableGroupType("OutSystemsUI.Navigation.Pagination.GoTo$vars", [{
name: "NewStartIndex",
attrName: "newStartIndexInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
Controller.prototype._inputOnChange$Action = function (isBlurIn, callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("InputOnChange");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.Navigation.Pagination.InputOnChange$vars"))());
vars.value.isBlurInLocal = isBlurIn;
var setListenerJSResult = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.setListenerJSResult = setListenerJSResult;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:E+e9yTu2c0SWB69yzyxjMA:/NRWebFlows.4IyGEdDlC0yweUOrtzVtVQ/NodesShownInESpaceTree.Pk7HFiqXDkWB9B2ls9hgbg/ClientActions.E+e9yTu2c0SWB69yzyxjMA:CxVgtpP1vg8aCReMAEFecQ", "OutSystemsUI", "InputOnChange", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:T_HfCXWm80KASAziOYtUMg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:5A2N1__2q0GmEQS8uWTbgA", callContext.id);
setListenerJSResult.value = controller.safeExecuteJSNode(OutSystemsUI_Navigation_Pagination_mvc_controller_InputOnChange_SetListenerJS, "SetListener", "InputOnChange", {
IsBlur: OS.DataConversion.JSNodeParamConverter.to(vars.value.isBlurInLocal, OS.Types.Boolean),
Value: OS.DataConversion.JSNodeParamConverter.to(model.variables.goToValueVar, OS.Types.Integer),
TotalPages: OS.DataConversion.JSNodeParamConverter.to(model.variables.totalPagesVar, OS.Types.Integer),
MaxRecords: OS.DataConversion.JSNodeParamConverter.to(model.variables.maxRecordsIn, OS.Types.Integer),
GotoValue: OS.DataConversion.JSNodeParamConverter.to(0, OS.Types.Integer)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsUI.Navigation.Pagination.InputOnChange$setListenerJSResult"))();
jsNodeResult.gotoValueOut = OS.DataConversion.JSNodeParamConverter.from($parameters.GotoValue, OS.Types.Integer);
return jsNodeResult;
}, {
GoTo: controller.clientActionProxies.goTo$Action
}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:qaRhuBplnU2oQUED6C3d1A", callContext.id);
// GoToValue = SetListener.GotoValue
model.variables.goToValueVar = setListenerJSResult.value.gotoValueOut;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:m03AvYokuUidKIwXyzH+MA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:E+e9yTu2c0SWB69yzyxjMA", callContext.id);
}

};
Controller.registerVariableGroupType("OutSystemsUI.Navigation.Pagination.InputOnChange$vars", [{
name: "IsBlur",
attrName: "isBlurInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
Controller.registerVariableGroupType("OutSystemsUI.Navigation.Pagination.InputOnChange$setListenerJSResult", [{
name: "GotoValue",
attrName: "gotoValueOut",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
Controller.prototype._initPagination$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("InitPagination");
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.Navigation.Pagination.InitPagination$vars"))());
var getToltalPagesJSResult = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.getToltalPagesJSResult = getToltalPagesJSResult;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:lYqD4k4AFkW7Qqgmu2KANA:/NRWebFlows.4IyGEdDlC0yweUOrtzVtVQ/NodesShownInESpaceTree.Pk7HFiqXDkWB9B2ls9hgbg/ClientActions.lYqD4k4AFkW7Qqgmu2KANA:sOL5PwpeGkZ5IXuFvg94Tw", "OutSystemsUI", "InitPagination", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:nzj3ByFvn0uadAMLP9W5wA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:eq8tbYApQE6cDd+dW2k1xw", callContext.id);
getToltalPagesJSResult.value = controller.safeExecuteJSNode(OutSystemsUI_Navigation_Pagination_mvc_controller_InitPagination_GetToltalPagesJS, "GetToltalPages", "InitPagination", {
TotalCount: OS.DataConversion.JSNodeParamConverter.to(model.variables.totalCountIn, OS.Types.LongInteger),
MaxRecords: OS.DataConversion.JSNodeParamConverter.to(OS.BuiltinFunctions.integerToLongInteger(model.variables.maxRecordsIn), OS.Types.LongInteger),
TotalPages: OS.DataConversion.JSNodeParamConverter.to(0, OS.Types.Integer)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsUI.Navigation.Pagination.InitPagination$getToltalPagesJSResult"))();
jsNodeResult.totalPagesOut = OS.DataConversion.JSNodeParamConverter.from($parameters.TotalPages, OS.Types.Integer);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:KZId71+b70KwXesY4kjJ8g", callContext.id);
// SelectedPageButton = StartIndex / MaxRecords + 1
model.variables.selectedPageButtonVar = OS.BuiltinFunctions.decimalToInteger(OS.BuiltinFunctions.trunc(OS.BuiltinFunctions.integerToDecimal(model.variables.startIndexIn).div(OS.BuiltinFunctions.integerToDecimal(model.variables.maxRecordsIn)).plus(OS.BuiltinFunctions.integerToDecimal(1))));
if((OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:pXYGZIb7HU2iTMMko0fU+w", callContext.id) && OutSystemsDebugger.handleFunctionCall(function () {
return OutSystemsUIController.default.isPhone$Action(callContext).isPhoneOut;
}, OS.Types.Boolean, callContext.id))) {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:7aX5_gULbUiqMxCT3V8NfA", callContext.id);
// MaxPagesToShow = 1
vars.value.maxPagesToShowVar = 1;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:7aX5_gULbUiqMxCT3V8NfA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsPhone = True
model.variables.isPhoneVar = true;
}

// SetDefaults
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:T1UbcjcYY0eDWdHjpGixLg", callContext.id);
// TotalPages = GetToltalPages.TotalPages
model.variables.totalPagesVar = getToltalPagesJSResult.value.totalPagesOut;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:T1UbcjcYY0eDWdHjpGixLg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// LastPageNumber = GetToltalPages.TotalPages + 1
model.variables.lastPageNumberVar = (getToltalPagesJSResult.value.totalPagesOut + 1);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:T1UbcjcYY0eDWdHjpGixLg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// PagesToCreate = If
vars.value.pagesToCreateVar = (((model.variables.totalPagesVar === 4)) ? (3) : (((((model.variables.totalPagesVar - 2) > vars.value.maxPagesToShowVar)) ? (vars.value.maxPagesToShowVar) : ((((model.variables.totalPagesVar > 3)) ? ((model.variables.totalPagesVar - 2)) : (model.variables.totalPagesVar))))));
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:T1UbcjcYY0eDWdHjpGixLg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// CurrentPage = If
vars.value.currentPageVar = ((((vars.value.maxPagesToShowVar === 1) && (model.variables.totalPagesVar > 4))) ? ((((model.variables.selectedPageButtonVar <= 1)) ? (model.variables.selectedPageButtonVar) : (((((model.variables.selectedPageButtonVar + 1) <= model.variables.totalPagesVar)) ? ((model.variables.selectedPageButtonVar - 1)) : ((model.variables.totalPagesVar - vars.value.pagesToCreateVar)))))) : ((((model.variables.totalPagesVar === 3)) ? ((((model.variables.selectedPageButtonVar <= 4)) ? (1) : (((((model.variables.selectedPageButtonVar + 1) <= model.variables.totalPagesVar)) ? ((model.variables.selectedPageButtonVar - 2)) : ((model.variables.totalPagesVar - vars.value.pagesToCreateVar)))))) : ((((model.variables.selectedPageButtonVar <= 3)) ? (1) : (((((model.variables.selectedPageButtonVar + 1) <= model.variables.totalPagesVar)) ? ((model.variables.selectedPageButtonVar - 2)) : ((model.variables.totalPagesVar - vars.value.pagesToCreateVar)))))))));
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:T1UbcjcYY0eDWdHjpGixLg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// GoToValue = If
model.variables.goToValueVar = (((model.variables.startIndexIn === 0)) ? (1) : (model.variables.goToValueVar));
if((OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:vOYFs6hCbkWhpvy2itohbw", callContext.id) && model.variables.totalCountIn.equals(OS.BuiltinFunctions.integerToLongInteger(0)))) {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:J0npFGOxeEWF1ibsJy8c5g", callContext.id);
// IsVisible = False
model.variables.isVisibleVar = false;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:nxc4tj3hzUSrqo4ezgK9bQ", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:wzuidw5uu02MnEXy_r4HvA", callContext.id);
// Execute Action: ListClear
OS.SystemActions.listClear(model.variables.middleNavigationPagesVar, callContext);
// MiddleNav.Length < PagesToCreate
while ((OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:R3ISSeK9NEq0lCEGIcgkLA", callContext.id) && (model.variables.middleNavigationPagesVar.length < vars.value.pagesToCreateVar))) {
// AddPagesToList
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:dx43j+CFD0qYRmb8XAGLcw", callContext.id);
// ListNavigationPage.Page = CurrentPage + 1
vars.value.listNavigationPageVar.pageAttr = (vars.value.currentPageVar + 1);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:dx43j+CFD0qYRmb8XAGLcw", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// ListNavigationPage.StartIndex = CurrentPage * MaxRecords
vars.value.listNavigationPageVar.startIndexAttr = (vars.value.currentPageVar * model.variables.maxRecordsIn);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:4xFdO8cK20qrMP_VedBNOg", callContext.id);
// Execute Action: AppendPage
OS.SystemActions.listAppend(model.variables.middleNavigationPagesVar, vars.value.listNavigationPageVar, callContext);
// CurrentPage +=1
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:dz2O5IWwf02_OuZDhqsA4g", callContext.id);
// CurrentPage = CurrentPage + 1
vars.value.currentPageVar = (vars.value.currentPageVar + 1);
}

OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:7jJjgwowwE6wLZQB2eZzng", callContext.id);
// Execute Action: ListSort
OS.SystemActions.listSort(model.variables.middleNavigationPagesVar, function (p) {
return p.pageAttr;
}, true, callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:+ZFD+BTNlUWYD+14IZmBEw", callContext.id);
// IsVisible = True
model.variables.isVisibleVar = true;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:nxc4tj3hzUSrqo4ezgK9bQ", callContext.id);
}

} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:lYqD4k4AFkW7Qqgmu2KANA", callContext.id);
}

};
Controller.registerVariableGroupType("OutSystemsUI.Navigation.Pagination.InitPagination$vars", [{
name: "PagesToCreate",
attrName: "pagesToCreateVar",
mandatory: false,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "CurrentPage",
attrName: "currentPageVar",
mandatory: false,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "ListNavigationPage",
attrName: "listNavigationPageVar",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new OutSystemsUIModel.ListNavigationRec();
},
complexType: OutSystemsUIModel.ListNavigationRec
}, {
name: "MaxPagesToShow",
attrName: "maxPagesToShowVar",
mandatory: false,
dataType: OS.Types.Integer,
defaultValue: function () {
return 3;
}
}]);
Controller.registerVariableGroupType("OutSystemsUI.Navigation.Pagination.InitPagination$getToltalPagesJSResult", [{
name: "TotalPages",
attrName: "totalPagesOut",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
Controller.prototype._onDestroy$Action = function (callContext) {
var varBag = {};
var model = this.model;
var controller = this.controller;
var idService = this.idService;
varBag.model = model;
varBag.idService = idService;
controller.ensureControllerAlive("OnDestroy");
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:o1r1+i6XQk6qR0yaSg_WzA:/NRWebFlows.4IyGEdDlC0yweUOrtzVtVQ/NodesShownInESpaceTree.Pk7HFiqXDkWB9B2ls9hgbg/ClientActions.o1r1+i6XQk6qR0yaSg_WzA:Lhciedfq2kg+y0R4iJTOsQ", "OutSystemsUI", "OnDestroy", "NRFlows.ClientScreenActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:7PnqKfEmzkSBoEFnC_IO4w", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:w6Wy+u7Tg06wcuHSwA+qlA", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_Navigation_Pagination_mvc_controller_OnDestroy_removeListenersJS, "removeListeners", "OnDestroy", null, function ($parameters) {
}, {
InputOnChange: controller.clientActionProxies.inputOnChange$Action
}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:nnJRyBiXHE6sHOBMulo4mA", callContext.id);
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:o1r1+i6XQk6qR0yaSg_WzA", callContext.id);
}

};

Controller.prototype.goTo$Action = function (newStartIndexIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._goTo$Action, callContext, newStartIndexIn);

};
Controller.prototype.inputOnChange$Action = function (isBlurIn, callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._inputOnChange$Action, callContext, isBlurIn);

};
Controller.prototype.initPagination$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._initPagination$Action, callContext);

};
Controller.prototype.onDestroy$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onDestroy$Action, callContext);

};
Controller.prototype.onNavigate$Action = function () {
return Promise.resolve();
};

// Event Handler Actions
Controller.prototype.pushDebuggerContext = function (callContext) {
var varBag = {};
OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:4IyGEdDlC0yweUOrtzVtVQ:/NRWebFlows.4IyGEdDlC0yweUOrtzVtVQ:866OUpxPwvPxbJ1r2dn5Kg", "OutSystemsUI", "Navigation", "NRFlows.WebFlow", callContext.id, varBag);
OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:Pk7HFiqXDkWB9B2ls9hgbg:/NRWebFlows.4IyGEdDlC0yweUOrtzVtVQ/NodesShownInESpaceTree.Pk7HFiqXDkWB9B2ls9hgbg:0cOcJ40HO0JY5aHbrRdiyA", "OutSystemsUI", "Pagination", "NRNodes.WebBlock", callContext.id, varBag);
};
Controller.prototype.popDebuggerContext = function (callContext) {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:Pk7HFiqXDkWB9B2ls9hgbg", callContext.id);
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:4IyGEdDlC0yweUOrtzVtVQ", callContext.id);
};
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Navigation/Pagination On Ready");
return controller.initPagination$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Navigation/Pagination On Destroy");
return controller.onDestroy$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.onParametersChangedEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return OS.Flow.tryFinally(function () {
var varBag = {};
controller.pushDebuggerContext(callContext);

OutSystemsDebugger.setThreadStartName(callContext.id, "Navigation/Pagination On Parameters Changed");
return controller.initPagination$Action(callContext);

}, function () {
controller.popDebuggerContext(callContext);

});

};
Controller.prototype.handleError = function (ex) {
return controller.handleError(ex);
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return OutSystemsUIController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, OutSystemsUILanguageResources);
});
define("OutSystemsUI.Navigation.Pagination.mvc$controller.InputOnChange.SetListenerJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var value = $parameters.Value;
var totalPages = $parameters.TotalPages;
var keyPressed = 13; // enter-key

var checkValue = function() {
    if(value > 0 && value <= totalPages) {
    // Go to Selected Page
    value = (value - 1) * $parameters.MaxRecords;
    } else if(value > totalPages) {
        // Go to Last Page
        value = totalPages * $parameters.MaxRecords;
    } else {
        // Go to First page
        value = 0;
    }
};

var inputOnKeypress = function(e){
    if (e.keyCode === keyPressed) {
        value = $parameters.Value;
        checkValue();
        $actions.GoTo(value);
        return value;    
    }
};

if(!$parameters.IsBlur) {
    this.addEventListener('keydown', inputOnKeypress);
} else {
    checkValue();
    $actions.GoTo(value);
    return value;
}

$parameters.GotoValue = value;
};
});
define("OutSystemsUI.Navigation.Pagination.mvc$controller.InitPagination.GetToltalPagesJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var getTotalPages = $parameters.TotalCount / $parameters.MaxRecords;

if (getTotalPages == Math.floor(getTotalPages)) {
    $parameters.TotalPages = (getTotalPages - 1);
} else {
    $parameters.TotalPages = (getTotalPages);
}





};
});
define("OutSystemsUI.Navigation.Pagination.mvc$controller.OnDestroy.removeListenersJS", [], function () {
return function ($actions, $roles, $public) {
window.removeEventListener('keydown', $actions.InputOnChange); 

};
});

define("OutSystemsUI.Navigation.Pagination.mvc$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"VlELDlj2wE2ziAwQXZOIpQ": {
getter: function (varBag, idService) {
return varBag.vars.value.newStartIndexInLocal;
},
dataType: OS.Types.Integer
},
"E4rQgPUQEkO6zUvfwZt10w": {
getter: function (varBag, idService) {
return varBag.vars.value.isBlurInLocal;
},
dataType: OS.Types.Boolean
},
"5A2N1__2q0GmEQS8uWTbgA": {
getter: function (varBag, idService) {
return varBag.setListenerJSResult.value;
}
},
"YFaDm6SHcE2BqfGhund9Bw": {
getter: function (varBag, idService) {
return varBag.vars.value.pagesToCreateVar;
},
dataType: OS.Types.Integer
},
"9Y6u5k+75kmf1cBlXS8cGw": {
getter: function (varBag, idService) {
return varBag.vars.value.currentPageVar;
},
dataType: OS.Types.Integer
},
"sE9yZF0yDU+4F8BNSKzURA": {
getter: function (varBag, idService) {
return varBag.vars.value.listNavigationPageVar;
}
},
"rsa+nDQNSU2Uv7YakCUQbQ": {
getter: function (varBag, idService) {
return varBag.vars.value.maxPagesToShowVar;
},
dataType: OS.Types.Integer
},
"eq8tbYApQE6cDd+dW2k1xw": {
getter: function (varBag, idService) {
return varBag.getToltalPagesJSResult.value;
}
},
"w6Wy+u7Tg06wcuHSwA+qlA": {
getter: function (varBag, idService) {
return varBag.removeListenersJSResult.value;
}
},
"DJHtrQJmgUOejHcrwSPZHA": {
getter: function (varBag, idService) {
return varBag.model.variables.middleNavigationPagesVar;
}
},
"IfXhLXKco0qX4UP8q7IHpg": {
getter: function (varBag, idService) {
return varBag.model.variables.selectedPageButtonVar;
},
dataType: OS.Types.Integer
},
"Ni0uGC35GUu2SpN5ZrRyGA": {
getter: function (varBag, idService) {
return varBag.model.variables.totalPagesVar;
},
dataType: OS.Types.Integer
},
"qMDY_+UyqEmiovTuLQVdag": {
getter: function (varBag, idService) {
return varBag.model.variables.lastPageNumberVar;
},
dataType: OS.Types.Integer
},
"MhyEXiVQ_EWI8kwbScScTw": {
getter: function (varBag, idService) {
return varBag.model.variables.isVisibleVar;
},
dataType: OS.Types.Boolean
},
"oPQBFYdgc0SjBqgHWNPyKA": {
getter: function (varBag, idService) {
return varBag.model.variables.isPhoneVar;
},
dataType: OS.Types.Boolean
},
"hxCaZExiGUqBdlU8mUX30g": {
getter: function (varBag, idService) {
return varBag.model.variables.goToValueVar;
},
dataType: OS.Types.Integer
},
"2Ql0uDc5bU2mNH8UOgdj8A": {
getter: function (varBag, idService) {
return varBag.model.variables.startIndexIn;
},
dataType: OS.Types.Integer
},
"npTQZT+Ew0OEjCf9R6wIfA": {
getter: function (varBag, idService) {
return varBag.model.variables.maxRecordsIn;
},
dataType: OS.Types.Integer
},
"Q7wOjJRdWkWgPMx2OcbhYw": {
getter: function (varBag, idService) {
return varBag.model.variables.totalCountIn;
},
dataType: OS.Types.LongInteger
},
"5bTF51IwvkSpArCONht37Q": {
getter: function (varBag, idService) {
return varBag.model.variables.showGoToPageIn;
},
dataType: OS.Types.Boolean
},
"hxD0TR7YjUSKr2mZwBRMJA": {
getter: function (varBag, idService) {
return varBag.model.variables.extendedClassIn;
},
dataType: OS.Types.Text
},
"qNI5PWzSF0iFP6lhhL+R1A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PaginationWrapper"));
})(varBag.model, idService);
}
},
"Y4HMHvpYJkW8q20a_1rtcw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PaginationRecords"));
})(varBag.model, idService);
}
},
"1MSjoFC6J02tW3UB+d6A7A": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PaginationContainer"));
})(varBag.model, idService);
}
},
"qolA0oTM0UCWKbrVZk9DIw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Previous"));
})(varBag.model, idService);
}
},
"6Mo4csM3_EKnNU7Y4EcLyg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("PaginationList"));
})(varBag.model, idService);
}
},
"W7BoVtbEg0CMfB4S82iJvg": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Input_SelectedPageButton"));
})(varBag.model, idService);
}
},
"QIgYiB+VfkqssZpMWOxCdw": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("TotalPagesCounter"));
})(varBag.model, idService);
}
},
"xEozN1azxEy49nwFYXbnWQ": {
getter: function (varBag, idService) {
return (function (model, idService) {
return model.widgets.get(idService.getId("Next"));
})(varBag.model, idService);
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
define("OutSystemsUI.Navigation.Pagination.mvc$translationsResources", ["exports", "OutSystemsUI.Navigation.Pagination.mvc$translationsResources.pt"], function (exports, OutSystemsUI_Navigation_Pagination_mvc_translationsResources_pt) {
return {
"pt": {
"translations": OutSystemsUI_Navigation_Pagination_mvc_translationsResources_pt,
"isRTL": false
}
};
});
define("OutSystemsUI.Navigation.Pagination.mvc$translationsResources.pt", [], function () {
return {
"_I_1p+Iu2kiwtVL3GoneXQ#Value.-1003809862.1": "Paginação",
"v9IrcYA0u0u2Wp6WpKrtYg#Value.-1061341073.1": "Ir para a página seguinte",
"qFZglgJQN0690k+H4eaiTQ#Value.839907371.1": " páginas",
"ZJ8Y3zyBdUKQVGfPtKYJAw#Value": " páginas",
"HEE7sk5FOk6vxjkCkf7Wsw#Value.-34998653.1": "de ",
"OLL7GmSLPkKBlcXr9c69fw#Value": "de ",
"Ul+vX812RkazxUoAttNpIA#Value": "Insira o número da página para visualizar...",
"sj82vjeE_06ghjV7e5ZoDw#Value.106426225.1": "página",
"sj82vjeE_06ghjV7e5ZoDw#Value.106426225.2": "página",
"sj82vjeE_06ghjV7e5ZoDw#Value.-1429362217.1": ", é a última página",
"sj82vjeE_06ghjV7e5ZoDw#Value.-1991118687.1": ", página actual, é a última página",
"eremlT2dUUuJAvi0JY4qPA#Value.106426225.1": "página",
"eremlT2dUUuJAvi0JY4qPA#Value.-1690771004.1": "ir para a página",
"eremlT2dUUuJAvi0JY4qPA#Value.611641590.1": " página actual",
"eDZkRSqLpUiQwkEFo+1+sA#Value.-1981675734.1": "página 1, página actual",
"eDZkRSqLpUiQwkEFo+1+sA#Value.-874293523.1": "ir para a página 1",
"H00kRd0c+0Ga34jvJCk2sg#Value.-1808381058.1": " items",
"hlifhXWvEUiM2xnV5qJqWw#Value": " items",
"7Z+HrRYQq0+rUCxKOrfWRQ#Value.2090863669.1": " de ",
"pi29bOzmnECCH4s0wX7adQ#Value": " de ",
"CIhIflibW0SNDBF1IjOlqA#Value.-1103515167.1": " a ",
"pXwE30aZ60u1odHgwarKxA#Value": " a "
};
});
