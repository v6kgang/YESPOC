﻿define("Extension.YesBankDBModule.model$JOB_HISTORYRec", ["exports", "OutSystems/ClientRuntime/Main", "Extension.YesBankDBModule.model"], function (exports, OutSystems, Extension_YesBankDBModuleModel) {
var OS = OutSystems.Internal;
var JOB_HISTORYRec = (function (_super) {
__extends(JOB_HISTORYRec, _super);
function JOB_HISTORYRec(defaults) {
_super.apply(this, arguments);
}
JOB_HISTORYRec.attributesToDeclare = function () {
return [
this.attr("EMPLOYEE_ID", "eMPLOYEE_IDAttr", "EMPLOYEE_ID", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("START_DATE", "sTART_DATEAttr", "START_DATE", true, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("END_DATE", "eND_DATEAttr", "END_DATE", true, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("JOB_ID", "jOB_IDAttr", "JOB_ID", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("DEPARTMENT_ID", "dEPARTMENT_IDAttr", "DEPARTMENT_ID", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
JOB_HISTORYRec.init();
return JOB_HISTORYRec;
})(OS.DataTypes.GenericRecord);
Extension_YesBankDBModuleModel.JOB_HISTORYRec = JOB_HISTORYRec;

});
define("Extension.YesBankDBModule.model$JOB_HISTORYRecord", ["exports", "OutSystems/ClientRuntime/Main", "Extension.YesBankDBModule.model", "Extension.YesBankDBModule.model$JOB_HISTORYRec"], function (exports, OutSystems, Extension_YesBankDBModuleModel) {
var OS = OutSystems.Internal;
var JOB_HISTORYRecord = (function (_super) {
__extends(JOB_HISTORYRecord, _super);
function JOB_HISTORYRecord(defaults) {
_super.apply(this, arguments);
}
JOB_HISTORYRecord.attributesToDeclare = function () {
return [
this.attr("JOB_HISTORY", "jOB_HISTORYAttr", "JOB_HISTORY", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Extension_YesBankDBModuleModel.JOB_HISTORYRec());
}, true, Extension_YesBankDBModuleModel.JOB_HISTORYRec)
].concat(_super.attributesToDeclare.call(this));
};
JOB_HISTORYRecord.fromStructure = function (str) {
return new JOB_HISTORYRecord(new JOB_HISTORYRecord.RecordClass({
jOB_HISTORYAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
JOB_HISTORYRecord._isAnonymousRecord = true;
JOB_HISTORYRecord.UniqueId = "0fff4e4c-c1e2-0a57-94e7-cd5c6bd0d879";
JOB_HISTORYRecord.init();
return JOB_HISTORYRecord;
})(OS.DataTypes.GenericRecord);
Extension_YesBankDBModuleModel.JOB_HISTORYRecord = JOB_HISTORYRecord;

});
define("Extension.YesBankDBModule.model$COUNTRIESRec", ["exports", "OutSystems/ClientRuntime/Main", "Extension.YesBankDBModule.model"], function (exports, OutSystems, Extension_YesBankDBModuleModel) {
var OS = OutSystems.Internal;
var COUNTRIESRec = (function (_super) {
__extends(COUNTRIESRec, _super);
function COUNTRIESRec(defaults) {
_super.apply(this, arguments);
}
COUNTRIESRec.attributesToDeclare = function () {
return [
this.attr("COUNTRY_ID", "cOUNTRY_IDAttr", "COUNTRY_ID", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("COUNTRY_NAME", "cOUNTRY_NAMEAttr", "COUNTRY_NAME", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("REGION_ID", "rEGION_IDAttr", "REGION_ID", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
COUNTRIESRec.init();
return COUNTRIESRec;
})(OS.DataTypes.GenericRecord);
Extension_YesBankDBModuleModel.COUNTRIESRec = COUNTRIESRec;

});
define("Extension.YesBankDBModule.model$COUNTRIESRecord", ["exports", "OutSystems/ClientRuntime/Main", "Extension.YesBankDBModule.model", "Extension.YesBankDBModule.model$COUNTRIESRec"], function (exports, OutSystems, Extension_YesBankDBModuleModel) {
var OS = OutSystems.Internal;
var COUNTRIESRecord = (function (_super) {
__extends(COUNTRIESRecord, _super);
function COUNTRIESRecord(defaults) {
_super.apply(this, arguments);
}
COUNTRIESRecord.attributesToDeclare = function () {
return [
this.attr("COUNTRIES", "cOUNTRIESAttr", "COUNTRIES", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Extension_YesBankDBModuleModel.COUNTRIESRec());
}, true, Extension_YesBankDBModuleModel.COUNTRIESRec)
].concat(_super.attributesToDeclare.call(this));
};
COUNTRIESRecord.fromStructure = function (str) {
return new COUNTRIESRecord(new COUNTRIESRecord.RecordClass({
cOUNTRIESAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
COUNTRIESRecord._isAnonymousRecord = true;
COUNTRIESRecord.UniqueId = "11777e27-4f74-49e4-27a4-6c1fcafabdb8";
COUNTRIESRecord.init();
return COUNTRIESRecord;
})(OS.DataTypes.GenericRecord);
Extension_YesBankDBModuleModel.COUNTRIESRecord = COUNTRIESRecord;

});
define("Extension.YesBankDBModule.model$EMPLOYEESRec", ["exports", "OutSystems/ClientRuntime/Main", "Extension.YesBankDBModule.model"], function (exports, OutSystems, Extension_YesBankDBModuleModel) {
var OS = OutSystems.Internal;
var EMPLOYEESRec = (function (_super) {
__extends(EMPLOYEESRec, _super);
function EMPLOYEESRec(defaults) {
_super.apply(this, arguments);
}
EMPLOYEESRec.attributesToDeclare = function () {
return [
this.attr("EMPLOYEE_ID", "eMPLOYEE_IDAttr", "EMPLOYEE_ID", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("FIRST_NAME", "fIRST_NAMEAttr", "FIRST_NAME", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("LAST_NAME", "lAST_NAMEAttr", "LAST_NAME", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("EMAIL", "eMAILAttr", "EMAIL", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("PHONE_NUMBER", "pHONE_NUMBERAttr", "PHONE_NUMBER", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("HIRE_DATE", "hIRE_DATEAttr", "HIRE_DATE", true, false, OS.Types.DateTime, function () {
return OS.DataTypes.DateTime.defaultValue;
}, true), 
this.attr("JOB_ID", "jOB_IDAttr", "JOB_ID", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("SALARY", "sALARYAttr", "SALARY", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("COMMISSION_PCT", "cOMMISSION_PCTAttr", "COMMISSION_PCT", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("MANAGER_ID", "mANAGER_IDAttr", "MANAGER_ID", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("DEPARTMENT_ID", "dEPARTMENT_IDAttr", "DEPARTMENT_ID", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
EMPLOYEESRec.init();
return EMPLOYEESRec;
})(OS.DataTypes.GenericRecord);
Extension_YesBankDBModuleModel.EMPLOYEESRec = EMPLOYEESRec;

});
define("Extension.YesBankDBModule.model$EMPLOYEESRecord", ["exports", "OutSystems/ClientRuntime/Main", "Extension.YesBankDBModule.model", "Extension.YesBankDBModule.model$EMPLOYEESRec"], function (exports, OutSystems, Extension_YesBankDBModuleModel) {
var OS = OutSystems.Internal;
var EMPLOYEESRecord = (function (_super) {
__extends(EMPLOYEESRecord, _super);
function EMPLOYEESRecord(defaults) {
_super.apply(this, arguments);
}
EMPLOYEESRecord.attributesToDeclare = function () {
return [
this.attr("EMPLOYEES", "eMPLOYEESAttr", "EMPLOYEES", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Extension_YesBankDBModuleModel.EMPLOYEESRec());
}, true, Extension_YesBankDBModuleModel.EMPLOYEESRec)
].concat(_super.attributesToDeclare.call(this));
};
EMPLOYEESRecord.fromStructure = function (str) {
return new EMPLOYEESRecord(new EMPLOYEESRecord.RecordClass({
eMPLOYEESAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
EMPLOYEESRecord._isAnonymousRecord = true;
EMPLOYEESRecord.UniqueId = "134d2045-fccc-19f1-a9ea-7c21636be138";
EMPLOYEESRecord.init();
return EMPLOYEESRecord;
})(OS.DataTypes.GenericRecord);
Extension_YesBankDBModuleModel.EMPLOYEESRecord = EMPLOYEESRecord;

});
define("Extension.YesBankDBModule.model$LOCATIONSRec", ["exports", "OutSystems/ClientRuntime/Main", "Extension.YesBankDBModule.model"], function (exports, OutSystems, Extension_YesBankDBModuleModel) {
var OS = OutSystems.Internal;
var LOCATIONSRec = (function (_super) {
__extends(LOCATIONSRec, _super);
function LOCATIONSRec(defaults) {
_super.apply(this, arguments);
}
LOCATIONSRec.attributesToDeclare = function () {
return [
this.attr("LOCATION_ID", "lOCATION_IDAttr", "LOCATION_ID", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("STREET_ADDRESS", "sTREET_ADDRESSAttr", "STREET_ADDRESS", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("POSTAL_CODE", "pOSTAL_CODEAttr", "POSTAL_CODE", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CITY", "cITYAttr", "CITY", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("STATE_PROVINCE", "sTATE_PROVINCEAttr", "STATE_PROVINCE", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("COUNTRY_ID", "cOUNTRY_IDAttr", "COUNTRY_ID", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
LOCATIONSRec.init();
return LOCATIONSRec;
})(OS.DataTypes.GenericRecord);
Extension_YesBankDBModuleModel.LOCATIONSRec = LOCATIONSRec;

});
define("Extension.YesBankDBModule.model$LOCATIONSRecord", ["exports", "OutSystems/ClientRuntime/Main", "Extension.YesBankDBModule.model", "Extension.YesBankDBModule.model$LOCATIONSRec"], function (exports, OutSystems, Extension_YesBankDBModuleModel) {
var OS = OutSystems.Internal;
var LOCATIONSRecord = (function (_super) {
__extends(LOCATIONSRecord, _super);
function LOCATIONSRecord(defaults) {
_super.apply(this, arguments);
}
LOCATIONSRecord.attributesToDeclare = function () {
return [
this.attr("LOCATIONS", "lOCATIONSAttr", "LOCATIONS", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Extension_YesBankDBModuleModel.LOCATIONSRec());
}, true, Extension_YesBankDBModuleModel.LOCATIONSRec)
].concat(_super.attributesToDeclare.call(this));
};
LOCATIONSRecord.fromStructure = function (str) {
return new LOCATIONSRecord(new LOCATIONSRecord.RecordClass({
lOCATIONSAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
LOCATIONSRecord._isAnonymousRecord = true;
LOCATIONSRecord.UniqueId = "5cd171f9-c81e-4c25-29c3-32aa2a618b56";
LOCATIONSRecord.init();
return LOCATIONSRecord;
})(OS.DataTypes.GenericRecord);
Extension_YesBankDBModuleModel.LOCATIONSRecord = LOCATIONSRecord;

});
define("Extension.YesBankDBModule.model$LOCATIONSRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Extension.YesBankDBModule.model", "Extension.YesBankDBModule.model$LOCATIONSRecord"], function (exports, OutSystems, Extension_YesBankDBModuleModel) {
var OS = OutSystems.Internal;
var LOCATIONSRecordList = (function (_super) {
__extends(LOCATIONSRecordList, _super);
function LOCATIONSRecordList(defaults) {
_super.apply(this, arguments);
}
LOCATIONSRecordList.itemType = Extension_YesBankDBModuleModel.LOCATIONSRecord;
return LOCATIONSRecordList;
})(OS.DataTypes.GenericRecordList);
Extension_YesBankDBModuleModel.LOCATIONSRecordList = LOCATIONSRecordList;

});
define("Extension.YesBankDBModule.model$EMPLOYEESRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Extension.YesBankDBModule.model", "Extension.YesBankDBModule.model$EMPLOYEESRecord"], function (exports, OutSystems, Extension_YesBankDBModuleModel) {
var OS = OutSystems.Internal;
var EMPLOYEESRecordList = (function (_super) {
__extends(EMPLOYEESRecordList, _super);
function EMPLOYEESRecordList(defaults) {
_super.apply(this, arguments);
}
EMPLOYEESRecordList.itemType = Extension_YesBankDBModuleModel.EMPLOYEESRecord;
return EMPLOYEESRecordList;
})(OS.DataTypes.GenericRecordList);
Extension_YesBankDBModuleModel.EMPLOYEESRecordList = EMPLOYEESRecordList;

});
define("Extension.YesBankDBModule.model$EMP_DETAILS_VIEWRec", ["exports", "OutSystems/ClientRuntime/Main", "Extension.YesBankDBModule.model"], function (exports, OutSystems, Extension_YesBankDBModuleModel) {
var OS = OutSystems.Internal;
var EMP_DETAILS_VIEWRec = (function (_super) {
__extends(EMP_DETAILS_VIEWRec, _super);
function EMP_DETAILS_VIEWRec(defaults) {
_super.apply(this, arguments);
}
EMP_DETAILS_VIEWRec.attributesToDeclare = function () {
return [
this.attr("EMPLOYEE_ID", "eMPLOYEE_IDAttr", "EMPLOYEE_ID", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("JOB_ID", "jOB_IDAttr", "JOB_ID", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MANAGER_ID", "mANAGER_IDAttr", "MANAGER_ID", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("DEPARTMENT_ID", "dEPARTMENT_IDAttr", "DEPARTMENT_ID", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("LOCATION_ID", "lOCATION_IDAttr", "LOCATION_ID", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("COUNTRY_ID", "cOUNTRY_IDAttr", "COUNTRY_ID", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("FIRST_NAME", "fIRST_NAMEAttr", "FIRST_NAME", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("LAST_NAME", "lAST_NAMEAttr", "LAST_NAME", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("SALARY", "sALARYAttr", "SALARY", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("COMMISSION_PCT", "cOMMISSION_PCTAttr", "COMMISSION_PCT", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("DEPARTMENT_NAME", "dEPARTMENT_NAMEAttr", "DEPARTMENT_NAME", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("JOB_TITLE", "jOB_TITLEAttr", "JOB_TITLE", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("CITY", "cITYAttr", "CITY", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("STATE_PROVINCE", "sTATE_PROVINCEAttr", "STATE_PROVINCE", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("COUNTRY_NAME", "cOUNTRY_NAMEAttr", "COUNTRY_NAME", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("REGION_NAME", "rEGION_NAMEAttr", "REGION_NAME", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
EMP_DETAILS_VIEWRec.init();
return EMP_DETAILS_VIEWRec;
})(OS.DataTypes.GenericRecord);
Extension_YesBankDBModuleModel.EMP_DETAILS_VIEWRec = EMP_DETAILS_VIEWRec;

});
define("Extension.YesBankDBModule.model$EMP_DETAILS_VIEWRecord", ["exports", "OutSystems/ClientRuntime/Main", "Extension.YesBankDBModule.model", "Extension.YesBankDBModule.model$EMP_DETAILS_VIEWRec"], function (exports, OutSystems, Extension_YesBankDBModuleModel) {
var OS = OutSystems.Internal;
var EMP_DETAILS_VIEWRecord = (function (_super) {
__extends(EMP_DETAILS_VIEWRecord, _super);
function EMP_DETAILS_VIEWRecord(defaults) {
_super.apply(this, arguments);
}
EMP_DETAILS_VIEWRecord.attributesToDeclare = function () {
return [
this.attr("EMP_DETAILS_VIEW", "eMP_DETAILS_VIEWAttr", "EMP_DETAILS_VIEW", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Extension_YesBankDBModuleModel.EMP_DETAILS_VIEWRec());
}, true, Extension_YesBankDBModuleModel.EMP_DETAILS_VIEWRec)
].concat(_super.attributesToDeclare.call(this));
};
EMP_DETAILS_VIEWRecord.fromStructure = function (str) {
return new EMP_DETAILS_VIEWRecord(new EMP_DETAILS_VIEWRecord.RecordClass({
eMP_DETAILS_VIEWAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
EMP_DETAILS_VIEWRecord._isAnonymousRecord = true;
EMP_DETAILS_VIEWRecord.UniqueId = "a783c91f-5e27-ca60-3096-a8fb7c37617e";
EMP_DETAILS_VIEWRecord.init();
return EMP_DETAILS_VIEWRecord;
})(OS.DataTypes.GenericRecord);
Extension_YesBankDBModuleModel.EMP_DETAILS_VIEWRecord = EMP_DETAILS_VIEWRecord;

});
define("Extension.YesBankDBModule.model$EMP_DETAILS_VIEWRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Extension.YesBankDBModule.model", "Extension.YesBankDBModule.model$EMP_DETAILS_VIEWRecord"], function (exports, OutSystems, Extension_YesBankDBModuleModel) {
var OS = OutSystems.Internal;
var EMP_DETAILS_VIEWRecordList = (function (_super) {
__extends(EMP_DETAILS_VIEWRecordList, _super);
function EMP_DETAILS_VIEWRecordList(defaults) {
_super.apply(this, arguments);
}
EMP_DETAILS_VIEWRecordList.itemType = Extension_YesBankDBModuleModel.EMP_DETAILS_VIEWRecord;
return EMP_DETAILS_VIEWRecordList;
})(OS.DataTypes.GenericRecordList);
Extension_YesBankDBModuleModel.EMP_DETAILS_VIEWRecordList = EMP_DETAILS_VIEWRecordList;

});
define("Extension.YesBankDBModule.model$DEPARTMENTSRec", ["exports", "OutSystems/ClientRuntime/Main", "Extension.YesBankDBModule.model"], function (exports, OutSystems, Extension_YesBankDBModuleModel) {
var OS = OutSystems.Internal;
var DEPARTMENTSRec = (function (_super) {
__extends(DEPARTMENTSRec, _super);
function DEPARTMENTSRec(defaults) {
_super.apply(this, arguments);
}
DEPARTMENTSRec.attributesToDeclare = function () {
return [
this.attr("DEPARTMENT_ID", "dEPARTMENT_IDAttr", "DEPARTMENT_ID", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("DEPARTMENT_NAME", "dEPARTMENT_NAMEAttr", "DEPARTMENT_NAME", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MANAGER_ID", "mANAGER_IDAttr", "MANAGER_ID", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("LOCATION_ID", "lOCATION_IDAttr", "LOCATION_ID", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DEPARTMENTSRec.init();
return DEPARTMENTSRec;
})(OS.DataTypes.GenericRecord);
Extension_YesBankDBModuleModel.DEPARTMENTSRec = DEPARTMENTSRec;

});
define("Extension.YesBankDBModule.model$REGIONSRec", ["exports", "OutSystems/ClientRuntime/Main", "Extension.YesBankDBModule.model"], function (exports, OutSystems, Extension_YesBankDBModuleModel) {
var OS = OutSystems.Internal;
var REGIONSRec = (function (_super) {
__extends(REGIONSRec, _super);
function REGIONSRec(defaults) {
_super.apply(this, arguments);
}
REGIONSRec.attributesToDeclare = function () {
return [
this.attr("REGION_ID", "rEGION_IDAttr", "REGION_ID", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("REGION_NAME", "rEGION_NAMEAttr", "REGION_NAME", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
REGIONSRec.init();
return REGIONSRec;
})(OS.DataTypes.GenericRecord);
Extension_YesBankDBModuleModel.REGIONSRec = REGIONSRec;

});
define("Extension.YesBankDBModule.model$DEPARTMENTSRecord", ["exports", "OutSystems/ClientRuntime/Main", "Extension.YesBankDBModule.model", "Extension.YesBankDBModule.model$DEPARTMENTSRec"], function (exports, OutSystems, Extension_YesBankDBModuleModel) {
var OS = OutSystems.Internal;
var DEPARTMENTSRecord = (function (_super) {
__extends(DEPARTMENTSRecord, _super);
function DEPARTMENTSRecord(defaults) {
_super.apply(this, arguments);
}
DEPARTMENTSRecord.attributesToDeclare = function () {
return [
this.attr("DEPARTMENTS", "dEPARTMENTSAttr", "DEPARTMENTS", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Extension_YesBankDBModuleModel.DEPARTMENTSRec());
}, true, Extension_YesBankDBModuleModel.DEPARTMENTSRec)
].concat(_super.attributesToDeclare.call(this));
};
DEPARTMENTSRecord.fromStructure = function (str) {
return new DEPARTMENTSRecord(new DEPARTMENTSRecord.RecordClass({
dEPARTMENTSAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DEPARTMENTSRecord._isAnonymousRecord = true;
DEPARTMENTSRecord.UniqueId = "7c7c615c-42c3-5488-c86f-8fdc81bb7c6b";
DEPARTMENTSRecord.init();
return DEPARTMENTSRecord;
})(OS.DataTypes.GenericRecord);
Extension_YesBankDBModuleModel.DEPARTMENTSRecord = DEPARTMENTSRecord;

});
define("Extension.YesBankDBModule.model$DEPARTMENTSRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Extension.YesBankDBModule.model", "Extension.YesBankDBModule.model$DEPARTMENTSRecord"], function (exports, OutSystems, Extension_YesBankDBModuleModel) {
var OS = OutSystems.Internal;
var DEPARTMENTSRecordList = (function (_super) {
__extends(DEPARTMENTSRecordList, _super);
function DEPARTMENTSRecordList(defaults) {
_super.apply(this, arguments);
}
DEPARTMENTSRecordList.itemType = Extension_YesBankDBModuleModel.DEPARTMENTSRecord;
return DEPARTMENTSRecordList;
})(OS.DataTypes.GenericRecordList);
Extension_YesBankDBModuleModel.DEPARTMENTSRecordList = DEPARTMENTSRecordList;

});
define("Extension.YesBankDBModule.model$JOBSRec", ["exports", "OutSystems/ClientRuntime/Main", "Extension.YesBankDBModule.model"], function (exports, OutSystems, Extension_YesBankDBModuleModel) {
var OS = OutSystems.Internal;
var JOBSRec = (function (_super) {
__extends(JOBSRec, _super);
function JOBSRec(defaults) {
_super.apply(this, arguments);
}
JOBSRec.attributesToDeclare = function () {
return [
this.attr("JOB_ID", "jOB_IDAttr", "JOB_ID", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("JOB_TITLE", "jOB_TITLEAttr", "JOB_TITLE", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("MIN_SALARY", "mIN_SALARYAttr", "MIN_SALARY", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("MAX_SALARY", "mAX_SALARYAttr", "MAX_SALARY", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
JOBSRec.init();
return JOBSRec;
})(OS.DataTypes.GenericRecord);
Extension_YesBankDBModuleModel.JOBSRec = JOBSRec;

});
define("Extension.YesBankDBModule.model$JOBSRecord", ["exports", "OutSystems/ClientRuntime/Main", "Extension.YesBankDBModule.model", "Extension.YesBankDBModule.model$JOBSRec"], function (exports, OutSystems, Extension_YesBankDBModuleModel) {
var OS = OutSystems.Internal;
var JOBSRecord = (function (_super) {
__extends(JOBSRecord, _super);
function JOBSRecord(defaults) {
_super.apply(this, arguments);
}
JOBSRecord.attributesToDeclare = function () {
return [
this.attr("JOBS", "jOBSAttr", "JOBS", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Extension_YesBankDBModuleModel.JOBSRec());
}, true, Extension_YesBankDBModuleModel.JOBSRec)
].concat(_super.attributesToDeclare.call(this));
};
JOBSRecord.fromStructure = function (str) {
return new JOBSRecord(new JOBSRecord.RecordClass({
jOBSAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
JOBSRecord._isAnonymousRecord = true;
JOBSRecord.UniqueId = "5e25510d-409e-dcb3-76a5-67aad0eb7c16";
JOBSRecord.init();
return JOBSRecord;
})(OS.DataTypes.GenericRecord);
Extension_YesBankDBModuleModel.JOBSRecord = JOBSRecord;

});
define("Extension.YesBankDBModule.model$JOBSRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Extension.YesBankDBModule.model", "Extension.YesBankDBModule.model$JOBSRecord"], function (exports, OutSystems, Extension_YesBankDBModuleModel) {
var OS = OutSystems.Internal;
var JOBSRecordList = (function (_super) {
__extends(JOBSRecordList, _super);
function JOBSRecordList(defaults) {
_super.apply(this, arguments);
}
JOBSRecordList.itemType = Extension_YesBankDBModuleModel.JOBSRecord;
return JOBSRecordList;
})(OS.DataTypes.GenericRecordList);
Extension_YesBankDBModuleModel.JOBSRecordList = JOBSRecordList;

});
define("Extension.YesBankDBModule.model$REGIONSRecord", ["exports", "OutSystems/ClientRuntime/Main", "Extension.YesBankDBModule.model", "Extension.YesBankDBModule.model$REGIONSRec"], function (exports, OutSystems, Extension_YesBankDBModuleModel) {
var OS = OutSystems.Internal;
var REGIONSRecord = (function (_super) {
__extends(REGIONSRecord, _super);
function REGIONSRecord(defaults) {
_super.apply(this, arguments);
}
REGIONSRecord.attributesToDeclare = function () {
return [
this.attr("REGIONS", "rEGIONSAttr", "REGIONS", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new Extension_YesBankDBModuleModel.REGIONSRec());
}, true, Extension_YesBankDBModuleModel.REGIONSRec)
].concat(_super.attributesToDeclare.call(this));
};
REGIONSRecord.fromStructure = function (str) {
return new REGIONSRecord(new REGIONSRecord.RecordClass({
rEGIONSAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
REGIONSRecord._isAnonymousRecord = true;
REGIONSRecord.UniqueId = "6a3eba57-d106-cf89-9ea5-620bae7eb448";
REGIONSRecord.init();
return REGIONSRecord;
})(OS.DataTypes.GenericRecord);
Extension_YesBankDBModuleModel.REGIONSRecord = REGIONSRecord;

});
define("Extension.YesBankDBModule.model$JOB_HISTORYRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Extension.YesBankDBModule.model", "Extension.YesBankDBModule.model$JOB_HISTORYRecord"], function (exports, OutSystems, Extension_YesBankDBModuleModel) {
var OS = OutSystems.Internal;
var JOB_HISTORYRecordList = (function (_super) {
__extends(JOB_HISTORYRecordList, _super);
function JOB_HISTORYRecordList(defaults) {
_super.apply(this, arguments);
}
JOB_HISTORYRecordList.itemType = Extension_YesBankDBModuleModel.JOB_HISTORYRecord;
return JOB_HISTORYRecordList;
})(OS.DataTypes.GenericRecordList);
Extension_YesBankDBModuleModel.JOB_HISTORYRecordList = JOB_HISTORYRecordList;

});
define("Extension.YesBankDBModule.model$COUNTRIESRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Extension.YesBankDBModule.model", "Extension.YesBankDBModule.model$COUNTRIESRecord"], function (exports, OutSystems, Extension_YesBankDBModuleModel) {
var OS = OutSystems.Internal;
var COUNTRIESRecordList = (function (_super) {
__extends(COUNTRIESRecordList, _super);
function COUNTRIESRecordList(defaults) {
_super.apply(this, arguments);
}
COUNTRIESRecordList.itemType = Extension_YesBankDBModuleModel.COUNTRIESRecord;
return COUNTRIESRecordList;
})(OS.DataTypes.GenericRecordList);
Extension_YesBankDBModuleModel.COUNTRIESRecordList = COUNTRIESRecordList;

});
define("Extension.YesBankDBModule.model$REGIONSRecordList", ["exports", "OutSystems/ClientRuntime/Main", "Extension.YesBankDBModule.model", "Extension.YesBankDBModule.model$REGIONSRecord"], function (exports, OutSystems, Extension_YesBankDBModuleModel) {
var OS = OutSystems.Internal;
var REGIONSRecordList = (function (_super) {
__extends(REGIONSRecordList, _super);
function REGIONSRecordList(defaults) {
_super.apply(this, arguments);
}
REGIONSRecordList.itemType = Extension_YesBankDBModuleModel.REGIONSRecord;
return REGIONSRecordList;
})(OS.DataTypes.GenericRecordList);
Extension_YesBankDBModuleModel.REGIONSRecordList = REGIONSRecordList;

});
define("Extension.YesBankDBModule.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var Extension_YesBankDBModuleModel = exports;
});
