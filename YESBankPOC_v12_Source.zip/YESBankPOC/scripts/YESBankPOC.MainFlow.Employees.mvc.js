﻿define("YESBankPOC.MainFlow.Employees.mvc$model",["OutSystems/ClientRuntime/Main", "YESBankPOC.model", "YESBankPOC.model$EMPLOYEESRecordList"], function(OutSystems, YESBankPOCModel) {
	var OS = OutSystems.Internal;
	var GetEmployeesAggrRec = (function(_super) {
		__extends(GetEmployeesAggrRec, _super);
		function GetEmployeesAggrRec(defaults) {
			_super.apply(this, arguments);
		}
		GetEmployeesAggrRec.RecordListType = YESBankPOCModel.EMPLOYEESRecordList;
		GetEmployeesAggrRec.init();
		return GetEmployeesAggrRec;
	}
	) (OS.Model.AggregateRecord);


	var VariablesRecord = (function(_super) {
		__extends(VariablesRecord, _super);
		function VariablesRecord(defaults) {
			_super.apply(this, arguments);
		}
		VariablesRecord.attributesToDeclare = function() {
			return[
			this.attr("SearchKeyword", "searchKeywordVar", "SearchKeyword", true, false, OS.Types.Text, function() {
				return "";
			}
			, false),
			this.attr("StartIndex", "startIndexVar", "StartIndex", true, false, OS.Types.Integer, function() {
				return 0;
			}
			, false),
			this.attr("MaxRecords", "maxRecordsVar", "MaxRecords", true, false, OS.Types.Integer, function() {
				return 10;
			}
			, false),
			this.attr("TableSort", "tableSortVar", "TableSort", true, false, OS.Types.Text, function() {
				return "";
			}
			, false),
			this.attr("GetEmployees", "getEmployeesAggr", "getEmployeesAggr", true, true, OS.Types.Record, function() {
				return OS.DataTypes.ImmutableBase.getData(new GetEmployeesAggrRec());
			}
			, true, GetEmployeesAggrRec)
			] .concat(_super.attributesToDeclare.call(this));
		};
		VariablesRecord.init();
		return VariablesRecord;
	}
	) (OS.DataTypes.GenericRecord);
	var WidgetsRecord = (function(_super) {
		__extends(WidgetsRecord, _super);
		function WidgetsRecord() {
			_super.apply(this, arguments);
		}
		WidgetsRecord.getWidgetsType = function() {
			return {
				Input_TextVar: OS.Model.ValidationWidgetRecord
			};
		};

		return WidgetsRecord;
	}
	) (OS.Model.BaseWidgetRecordMap);
	var Model = (function(_super) {
		__extends(Model, _super);
		function Model() {
			_super.apply(this, arguments);
		}
		Model.getVariablesRecordConstructor = function() {
			return VariablesRecord;
		};
		Model.getWidgetsRecordConstructor = function() {
			return WidgetsRecord;
		};
		Object.defineProperty(Model, "hasValidationWidgets", {
			enumerable: true,
			configurable: true,
			get: function() {
				return true;
			}
		}
		);

		Model.prototype.setInputs = function(inputs) {
		};
		return Model;
	}
	) (OS.Model.BaseViewModel);
	return new OS.Model.ModelFactory(Model);
});
define("YESBankPOC.MainFlow.Employees.mvc$view",["OutSystems/ClientRuntime/Main", "YESBankPOC.model", "YESBankPOC.controller", "react", "OutSystems/ReactView/Main", "YESBankPOC.MainFlow.Employees.mvc$model", "YESBankPOC.MainFlow.Employees.mvc$controller", "YESBankPOC.clientVariables", "YESBankPOC.Layouts.LayoutTopMenu.mvc$view", "OutSystems/ReactWidgets/Main", "OutSystemsUI.Interaction.Search.mvc$view", "OutSystemsUI.Navigation.Pagination.mvc$view", "YESBankPOC.Common.Menu.mvc$view", "YESBankPOC.model$EMPLOYEESRecordList"], function(OutSystems, YESBankPOCModel, YESBankPOCController, React, OSView, YESBankPOC_MainFlow_Employees_mvc_model, YESBankPOC_MainFlow_Employees_mvc_controller, YESBankPOCClientVariables, YESBankPOC_Layouts_LayoutTopMenu_mvc_view, OSWidgets, OutSystemsUI_Interaction_Search_mvc_view, OutSystemsUI_Navigation_Pagination_mvc_view, YESBankPOC_Common_Menu_mvc_view) {
	var OS = OutSystems.Internal;
	var PlaceholderContent = OSView.Widget.PlaceholderContent;
	var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


	var View = (function(_super) {
		__extends(View, _super);
		function View() {
			try {
				this.initialize.apply(this, arguments);
			} catch (error) {
				View.handleError(error);
				throw error;
			}
		}
		View.prototype.initialize = function() {
			_super.apply(this, arguments);
		};
		View.displayName = "MainFlow.Employees";
		View.getCssDependencies = function() {
			return["css/OutSystemsReactWidgets.css", "css/OutSystemsUI.OutSystemsUI.css", "css/YESBankPOC.YESBankPOC.css", "css/YESBankPOC.YESBankPOC.extra.css"];
		};
		View.getJsDependencies = function() {
			return[];
		};
		View.getBlocks = function() {
			return[YESBankPOC_Layouts_LayoutTopMenu_mvc_view, OutSystemsUI_Interaction_Search_mvc_view, OutSystemsUI_Navigation_Pagination_mvc_view, YESBankPOC_Common_Menu_mvc_view];
		};
		Object.defineProperty(View.prototype, "modelFactory", {
			get: function() {
				return YESBankPOC_MainFlow_Employees_mvc_model;
			}
			,
			enumerable: true,
			configurable: true
		});
		Object.defineProperty(View.prototype, "controllerFactory", {
			get: function() {
				return YESBankPOC_MainFlow_Employees_mvc_controller;
			}
			,
			enumerable: true,
			configurable: true
		});
		Object.defineProperty(View.prototype, "title", {
			get: function() {
				return "Employees";
			}
			,
			enumerable: true,
			configurable: true
		});
		View.prototype.internalRender = function() {
			var model = this.model;
			var controller = this.controller;
			var idService = this.idService;
			var validationService = controller.validationService;
			var widgetsRecordProvider = this.widgetsRecordProvider;
			var callContext = controller.callContext();
			var $if = View.ifWidget;
			var $text = View.textWidget;
			var asPrimitiveValue = View.asPrimitiveValue;
			var getTranslation = View.getTranslation;
			var _this = this;

			return React.createElement("div", this.getRootNodeProperties(), React.createElement(YESBankPOC_Layouts_LayoutTopMenu_mvc_view, {
				inputs: {}
				,
				events: {
					_handleError: function(ex) {
						controller.handleError(ex);
					}
				}
				,
				_validationProps: {
					validationService: validationService
				}
				,
				_idProps: {
					service: idService,
					uuid: "0",
					alias: "1"
				}
				,
				_widgetRecordProvider: widgetsRecordProvider,
				placeholders: {
					breadcrumbs: PlaceholderContent.Empty,
					title: new PlaceholderContent(function() {
						return[React.createElement(OSWidgets.AdvancedHtml, {
							tag: "h1",
							_idProps: {
								service: idService,
								name: "Screen_Title"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider
						}
						, "Employee List")];
					}),
					actions: new PlaceholderContent(function() {
						return[React.createElement(OSWidgets.Container, {
							align:/*Default*/ 0,
							animate: false,
							gridProperties: {
								classes: "ThemeGrid_Width4"
							}
							,
							visible: true,
							_idProps: {
								service: idService,
								uuid: "2"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider
						}
						, React.createElement(OutSystemsUI_Interaction_Search_mvc_view, {
							inputs: {}
							,
							events: {
								_handleError: function(ex) {
									controller.handleError(ex);
								}
							}
							,
							_validationProps: {
								validationService: validationService
							}
							,
							_idProps: {
								service: idService,
								uuid: "3",
								alias: "2"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider,
							placeholders: {
								input: new PlaceholderContent(function() {
									return[React.createElement(OSWidgets.Input, {
										_validationProps: {
											validationService: validationService
										}
										,
										enabled: true,
										extendedProperties: {
											title: "Search"
										}
										,
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										inputType:/*Search*/ 8,
										mandatory: false,
										maxLength: 50,
										onChange: function() {
											return Promise.resolve().then(function() {
												var eventHandlerContext = callContext.clone();
												controller.onSearch$Action(controller.callContext(eventHandlerContext));
											});
											;
										}
										,
										prompt: "Search",
										style: "form-control",
										variable: model.createVariable(OS.Types.Text, model.variables.searchKeywordVar, function(value) {
											model.variables.searchKeywordVar = value;
										}),
										_idProps: {
											service: idService,
											name: "Input_TextVar"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									})];
								})
							}
							,
							_dependencies:[asPrimitiveValue(model.variables.searchKeywordVar)]
						})), React.createElement(OSWidgets.Button, {
							enabled: true,
							gridProperties: {
								classes: "ThemeGrid_MarginGutter",
								width: "150px"
							}
							,
							isDefault: false,
							onClick: function() {
								OS.Navigation.navigateTo(OS.Navigation.generateScreenURL("YESBankPOC", "EmployeeDetail", {
									EmployeeId: OS.DataConversion.ServerDataConverter.to(OS.BuiltinFunctions.nullIdentifier(), OS.Types.Integer)
								}), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default));
							}
							,
							style: "btn btn-primary",
							visible: true,
							_idProps: {
								service: idService,
								uuid: "5"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider
						}
						, "Add Employee", React.createElement(OSWidgets.Icon, {
							extendedProperties: {
								style: "padding: 0px 0px 0px 8px;"
							}
							,
							gridProperties: {
								classes: "ThemeGrid_MarginGutter"
							}
							,
							icon: "plus",
							iconSize:/*FontSize*/ 0,
							style: "icon",
							visible: true,
							_idProps: {
								service: idService,
								uuid: "6"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider
						}))];
					}),
					mainContent: new PlaceholderContent(function() {
						return[React.createElement(OSWidgets.TableRecords, {
							onSort: function(clickedColumnIn) {
								return Promise.resolve().then(function() {
									var eventHandlerContext = callContext.clone();
									controller.onSort$Action(clickedColumnIn, controller.callContext(eventHandlerContext));
								});
								;
							}
							,
							showHeader: true,
							source: model.variables.getEmployeesAggr.listOut,
							style: "table",
							styleHeader: "table-header",
							styleRow: "table-row",
							_idProps: {
								service: idService,
								uuid: "7"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider,
							source_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getEmployeesAggr.dataFetchStatusAttr),
							placeholders: {
								headerRow: new PlaceholderContent(function() {
									return[React.createElement(OSWidgets.HeaderCell, {
										sortAttribute: "EMPLOYEES.FIRST_NAME",
										_idProps: {
											service: idService,
											uuid: "8"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										_dependencies:[]
									}
									, "FIRST_NAME"), React.createElement(OSWidgets.HeaderCell, {
										sortAttribute: "EMPLOYEES.LAST_NAME",
										_idProps: {
											service: idService,
											uuid: "9"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										_dependencies:[]
									}
									, "LAST_NAME"), React.createElement(OSWidgets.HeaderCell, {
										sortAttribute: "EMPLOYEES.EMAIL",
										_idProps: {
											service: idService,
											uuid: "10"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										_dependencies:[]
									}
									, "EMAIL"), React.createElement(OSWidgets.HeaderCell, {
										sortAttribute: "EMPLOYEES.PHONE_NUMBER",
										_idProps: {
											service: idService,
											uuid: "11"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										_dependencies:[]
									}
									, "PHONE_NUMBER"), React.createElement(OSWidgets.HeaderCell, {
										_idProps: {
											service: idService,
											uuid: "12"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										_dependencies:[]
									})];
								}),
								row: new IteratorPlaceholderContent(function(idService, callContext) {
									return[React.createElement(OSWidgets.RowCell, {
										_idProps: {
											service: idService,
											uuid: "13"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										_dependencies:[asPrimitiveValue(model.variables.getEmployeesAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getEmployeesAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.fIRST_NAMEAttr)]
									}
									, React.createElement(OSWidgets.Link, {
										enabled: true,
										transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default),
										url: OS.Navigation.generateScreenURL("YESBankPOC", "EmployeeDetail", {
											EmployeeId: OS.DataConversion.ServerDataConverter.to(model.variables.getEmployeesAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.eMPLOYEE_IDAttr, OS.Types.Integer)
										}),
										visible: true,
										_idProps: {
											service: idService,
											uuid: "14"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, React.createElement(OSWidgets.Expression, {
										value: model.variables.getEmployeesAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.fIRST_NAMEAttr,
										_idProps: {
											service: idService,
											uuid: "15"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getEmployeesAggr.dataFetchStatusAttr)
									}))), React.createElement(OSWidgets.RowCell, {
										_idProps: {
											service: idService,
											uuid: "16"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										_dependencies:[asPrimitiveValue(model.variables.getEmployeesAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getEmployeesAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.lAST_NAMEAttr)]
									}
									, React.createElement(OSWidgets.Expression, {
										value: model.variables.getEmployeesAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.lAST_NAMEAttr,
										_idProps: {
											service: idService,
											uuid: "17"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getEmployeesAggr.dataFetchStatusAttr)
									})), React.createElement(OSWidgets.RowCell, {
										_idProps: {
											service: idService,
											uuid: "18"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										_dependencies:[asPrimitiveValue(model.variables.getEmployeesAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getEmployeesAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.eMAILAttr)]
									}
									, React.createElement(OSWidgets.Expression, {
										value: model.variables.getEmployeesAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.eMAILAttr,
										_idProps: {
											service: idService,
											uuid: "19"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getEmployeesAggr.dataFetchStatusAttr)
									})), React.createElement(OSWidgets.RowCell, {
										_idProps: {
											service: idService,
											uuid: "20"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										_dependencies:[asPrimitiveValue(model.variables.getEmployeesAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getEmployeesAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.pHONE_NUMBERAttr)]
									}
									, React.createElement(OSWidgets.Expression, {
										value: model.variables.getEmployeesAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.pHONE_NUMBERAttr,
										_idProps: {
											service: idService,
											uuid: "21"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										value_dataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getEmployeesAggr.dataFetchStatusAttr)
									})), React.createElement(OSWidgets.RowCell, {
										_idProps: {
											service: idService,
											uuid: "22"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										_dependencies:[]
									}
									, React.createElement(OSWidgets.Link, {
										enabled: true,
										transition: OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Default),
										url: OS.Navigation.generateScreenURL("YESBankPOC", "EmployeeDetail", {
											EmployeeId: OS.DataConversion.ServerDataConverter.to(model.variables.getEmployeesAggr.listOut.getCurrent(callContext.iterationContext).eMPLOYEESAttr.eMPLOYEE_IDAttr, OS.Types.Integer)
										}),
										visible: true,
										_idProps: {
											service: idService,
											uuid: "23"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, React.createElement(OSWidgets.Icon, {
										icon: "pencil-square-o",
										iconSize:/*Twotimes*/ 1,
										style: "icon",
										visible: true,
										_idProps: {
											service: idService,
											uuid: "24"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									})))];
								}
								, callContext, idService, "1_0")
							}
							,
							_dependencies:[asPrimitiveValue(model.variables.getEmployeesAggr.dataFetchStatusAttr)]
						}), React.createElement(OSWidgets.Container, {
							align:/*Default*/ 0,
							animate: false,
							visible: true,
							_idProps: {
								service: idService,
								name: "IsTableLoadingOrEmpty"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider
						}
						, $if((model.variables.getEmployeesAggr.isDataFetchedAttr && model.variables.getEmployeesAggr.listOut.isEmpty), false, this, function() {
							return[React.createElement(OSWidgets.Container, {
								align:/*Default*/ 0,
								animate: false,
								style: "table-empty",
								visible: true,
								_idProps: {
									service: idService,
									uuid: "26"
								}
								,
								_widgetRecordProvider: widgetsRecordProvider
							}
							, React.createElement(OSWidgets.Text, {
								extendedProperties: {
									role: "status"
								}
								,
								text:["No items to show..."],
								_idProps: {
									service: idService,
									uuid: "27"
								}
								,
								_widgetRecordProvider: widgetsRecordProvider
							}))];
						}
						, function() {
							return[$if(!(model.variables.getEmployeesAggr.isDataFetchedAttr), false, this, function() {
								return[React.createElement(OSWidgets.Container, {
									align:/*Default*/ 0,
									animate: false,
									style: "list-updating",
									visible: true,
									_idProps: {
										service: idService,
										uuid: "28"
									}
									,
									_widgetRecordProvider: widgetsRecordProvider
								})];
							}
							, function() {
								return[];
							})];
						})), React.createElement(OutSystemsUI_Navigation_Pagination_mvc_view, {
							inputs: {
								TotalCount: model.variables.getEmployeesAggr.countOut,
								_totalCountInDataFetchStatus: OS.Model.calculateDataFetchStatus(model.variables.getEmployeesAggr.dataFetchStatusAttr),
								StartIndex: model.variables.startIndexVar,
								MaxRecords: model.variables.maxRecordsVar
							}
							,
							events: {
								_handleError: function(ex) {
									controller.handleError(ex);
								}
								,
								onNavigate$Action: function(newStartIndexIn) {
									return Promise.resolve().then(function() {
										var eventHandlerContext = callContext.clone();
										controller.onPaginationNavigate$Action(newStartIndexIn, controller.callContext(eventHandlerContext));
									});
									;
								}
							}
							,
							_validationProps: {
								validationService: validationService
							}
							,
							_idProps: {
								service: idService,
								uuid: "29",
								alias: "3"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider,
							placeholders: {
								previous: new PlaceholderContent(function() {
									return[React.createElement(OSWidgets.Icon, {
										icon: "angle-left",
										iconSize:/*FontSize*/ 0,
										style: "icon",
										visible: true,
										_idProps: {
											service: idService,
											uuid: "30"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									})];
								}),
								next: new PlaceholderContent(function() {
									return[React.createElement(OSWidgets.Icon, {
										icon: "angle-right",
										iconSize:/*FontSize*/ 0,
										style: "icon",
										visible: true,
										_idProps: {
											service: idService,
											uuid: "31"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									})];
								})
							}
							,
							_dependencies:[]
						})];
					}),
					footer: PlaceholderContent.Empty,
					header: new PlaceholderContent(function() {
						return[React.createElement(YESBankPOC_Common_Menu_mvc_view, {
							inputs: {}
							,
							events: {
								_handleError: function(ex) {
									controller.handleError(ex);
								}
							}
							,
							_validationProps: {
								validationService: validationService
							}
							,
							_idProps: {
								service: idService,
								uuid: "32",
								alias: "4"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider,
							_dependencies:[]
						})];
					})
				}
				,
				_dependencies:[asPrimitiveValue(model.variables.maxRecordsVar), asPrimitiveValue(model.variables.startIndexVar), asPrimitiveValue(model.variables.getEmployeesAggr.dataFetchStatusAttr), asPrimitiveValue(model.variables.getEmployeesAggr.countOut), asPrimitiveValue(model.variables.getEmployeesAggr.isDataFetchedAttr), asPrimitiveValue(model.variables.getEmployeesAggr.listOut), asPrimitiveValue(model.variables.searchKeywordVar)]
			}));
		};
		return View;
	})(OSView.BaseView.BaseWebScreen);

	return View;
});
define("YESBankPOC.MainFlow.Employees.mvc$controller",["OutSystems/ClientRuntime/Main", "YESBankPOC.model", "YESBankPOC.controller", "YESBankPOC.languageResources", "YESBankPOC.clientVariables", "YESBankPOC.MainFlow.controller", "YESBankPOC.model$EMPLOYEESRecordList"], function(OutSystems, YESBankPOCModel, YESBankPOCController, YESBankPOCLanguageResources, YESBankPOCClientVariables, YESBankPOC_MainFlowController) {
	var OS = OutSystems.Internal;
	var Controller = (function(_super) {
		__extends(Controller, _super);
		function Controller() {
			_super.apply(this, arguments);
			var controller = this.controller;
			this.clientActionProxies = {};
			this.dataFetchDependenciesOriginal = {
				getEmployees$AggrRefresh: 0
			};
			this.dataFetchDependentsGraph = {
				getEmployees$AggrRefresh:[]
			};
			this.shouldSendClientVarsToDataSources = false;
		}
		// Server Actions

		// Aggregates and Data Actions
		Controller.prototype.getEmployees$AggrRefresh = function(maxRecords, startIndex, callContext) {
			var model = this.model;
			var controller = this.controller;
			var callContext = controller.callContext(callContext);
			return controller.callAggregateWithStartIndexAndClientVars("ScreenDataSetGetEmployees", "screenservices/YESBankPOC/MainFlow/Employees/ScreenDataSetGetEmployees", "7Z4_hrwO9Jtrd+9OGbPh+w", maxRecords, startIndex, function(b) {
				model.variables.getEmployeesAggr.dataFetchStatusAttr = b;
			}
			, function(json) {
				model.variables.getEmployeesAggr.replaceWith(OS.DataConversion.ServerDataConverter.from(json, model.variables.getEmployeesAggr.constructor));
			}
			, undefined, undefined, undefined, callContext, undefined, false);
		};

		Controller.prototype.dataFetchActionNames =["getEmployees$AggrRefresh"];
		// Client Actions
		Controller.prototype._onSort$Action = function(sortByIn, callContext) {
			var model = this.model;
			var controller = this.controller;
			var idService = this.idService;
			controller.ensureControllerAlive("OnSort");
			callContext = controller.callContext(callContext);
			var vars = new OS.DataTypes.VariableHolder(new(controller.constructor.getVariableGroupType("YESBankPOC.MainFlow.Employees.OnSort$vars")) ());
			vars.value.sortByInLocal = sortByIn;
			return OS.Flow.executeAsyncFlow(function() {
				if ((((model.variables.tableSortVar === vars.value.sortByInLocal) && ((vars.value.sortByInLocal) !==(""))))) {
					// TableSort2 += DESC
					// TableSort = SortBy + " DESC"
					model.variables.tableSortVar = (vars.value.sortByInLocal + " DESC");
				} else {
					// TableSort = SortBy
					// TableSort = SortBy
					model.variables.tableSortVar = vars.value.sortByInLocal;
				}

				// StartIndex = 0
				// StartIndex = 0
				model.variables.startIndexVar = 0;
				// Refresh Query: GetEmployees
				var result = controller.getEmployees$AggrRefresh(model.variables.maxRecordsVar, model.variables.startIndexVar, callContext);
				model.flush();
				return result;
			}
			);
		};
		Controller.registerVariableGroupType("YESBankPOC.MainFlow.Employees.OnSort$vars",[ {
			name: "SortBy",
			attrName: "sortByInLocal",
			mandatory: true,
			dataType: OS.Types.Text,
			defaultValue: function() {
				return "";
			}
		}
		]);
		Controller.prototype._onPaginationNavigate$Action = function(newStartIndexIn, callContext) {
			var model = this.model;
			var controller = this.controller;
			var idService = this.idService;
			controller.ensureControllerAlive("OnPaginationNavigate");
			callContext = controller.callContext(callContext);
			var vars = new OS.DataTypes.VariableHolder(new(controller.constructor.getVariableGroupType("YESBankPOC.MainFlow.Employees.OnPaginationNavigate$vars")) ());
			vars.value.newStartIndexInLocal = newStartIndexIn;
			return OS.Flow.executeAsyncFlow(function() {
				// StartIndex = NewStartIndex
				// StartIndex = NewStartIndex
				model.variables.startIndexVar = vars.value.newStartIndexInLocal;
				// Refresh Query: GetEmployees
				var result = controller.getEmployees$AggrRefresh(model.variables.maxRecordsVar, model.variables.startIndexVar, callContext);
				model.flush();
				return result;
			}
			);
		};
		Controller.registerVariableGroupType("YESBankPOC.MainFlow.Employees.OnPaginationNavigate$vars",[ {
			name: "NewStartIndex",
			attrName: "newStartIndexInLocal",
			mandatory: true,
			dataType: OS.Types.Integer,
			defaultValue: function() {
				return 0;
			}
		}
		]);
		Controller.prototype._onSearch$Action = function(callContext) {
			var model = this.model;
			var controller = this.controller;
			var idService = this.idService;
			controller.ensureControllerAlive("OnSearch");
			callContext = controller.callContext(callContext);
			return OS.Flow.executeAsyncFlow(function() {
				// StartIndex = 0
				// StartIndex = 0
				model.variables.startIndexVar = 0;
				// Refresh Query: GetEmployees
				var result = controller.getEmployees$AggrRefresh(model.variables.maxRecordsVar, model.variables.startIndexVar, callContext);
				model.flush();
				return result;
			}
			);
		};

		Controller.prototype.onSort$Action = function(sortByIn, callContext) {
			var controller = this.controller;
			return controller.safeExecuteClientAction(controller._onSort$Action, callContext, sortByIn);

		};
		Controller.prototype.onPaginationNavigate$Action = function(newStartIndexIn, callContext) {
			var controller = this.controller;
			return controller.safeExecuteClientAction(controller._onPaginationNavigate$Action, callContext, newStartIndexIn);

		};
		Controller.prototype.onSearch$Action = function(callContext) {
			var controller = this.controller;
			return controller.safeExecuteClientAction(controller._onSearch$Action, callContext);

		};

		// Event Handler Actions
		Controller.prototype.onInitializeEventHandler = null;
		Controller.prototype.onReadyEventHandler = null;
		Controller.prototype.onRenderEventHandler = null;
		Controller.prototype.onDestroyEventHandler = null;
		Controller.prototype.onParametersChangedEventHandler = null;
		Controller.prototype.handleError = function(ex) {
			return YESBankPOC_MainFlowController.default.handleError(ex, this.callContext());
		};
		Controller.checkPermissions = function() {
		};
		Controller.prototype.getDefaultTimeout = function() {
			return YESBankPOCController.default.defaultTimeout;
		};
		return Controller;
	}
	) (OS.Controller.BaseViewController);
	return new OS.Controller.ControllerFactory(Controller, YESBankPOCLanguageResources);
});

