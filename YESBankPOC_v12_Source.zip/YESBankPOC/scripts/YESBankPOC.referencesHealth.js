﻿define("YESBankPOC.referencesHealth$OutSystemsCharts",[], function() {
	// Reference to producer 'OutSystemsCharts' is OK.
});
define("YESBankPOC.referencesHealth$OutSystemsMaps",[], function() {
	// Reference to producer 'OutSystemsMaps' is OK.
});
define("YESBankPOC.referencesHealth$OutSystemsSampleDataDB",[], function() {
	// Reference to producer 'OutSystemsSampleDataDB' is OK.
});
define("YESBankPOC.referencesHealth$OutSystemsUI",[], function() {
	// Reference to producer 'OutSystemsUI' is OK.
});
define("YESBankPOC.referencesHealth$ServiceCenter",[], function() {
	// Reference to producer 'ServiceCenter' is OK.
});
define("YESBankPOC.referencesHealth$Users",[], function() {
	// Reference to producer 'Users' is OK.
});
define("YESBankPOC.referencesHealth$YesBankDBModule",[], function() {
	// Reference to producer 'YesBankDBModule' is OK.
});
define("YESBankPOC.referencesHealth",[], function() {
});
