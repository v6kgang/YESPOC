﻿define("OutSystemsCharts.referencesHealth$ServiceCenter", [], function () {
// Reference to producer 'ServiceCenter' is OK.
});
define("OutSystemsCharts.referencesHealth$Users", [], function () {
// Reference to producer 'Users' is OK.
});
define("OutSystemsCharts.referencesHealth", [], function () {
});
