﻿define("YESBankPOC.Common.Login.mvc$model",["OutSystems/ClientRuntime/Main", "YESBankPOC.model", "OutSystemsUI.controller", "OutSystemsUI.controller$FeedbackMessageClose", "YESBankPOC.referencesHealth", "YESBankPOC.referencesHealth$OutSystemsUI"], function(OutSystems, YESBankPOCModel, OutSystemsUIController) {
	var OS = OutSystems.Internal;


	var VariablesRecord = (function(_super) {
		__extends(VariablesRecord, _super);
		function VariablesRecord(defaults) {
			_super.apply(this, arguments);
		}
		VariablesRecord.attributesToDeclare = function() {
			return[
			this.attr("Username", "usernameVar", "Username", true, false, OS.Types.Text, function() {
				return "";
			}
			, false),
			this.attr("Password", "passwordVar", "Password", true, false, OS.Types.Text, function() {
				return "";
			}
			, false),
			this.attr("IsExecuting", "isExecutingVar", "IsExecuting", true, false, OS.Types.Boolean, function() {
				return false;
			}
			, false),
			this.attr("Remember", "rememberVar", "Remember", true, false, OS.Types.Boolean, function() {
				return false;
			}
			, false)
			] .concat(_super.attributesToDeclare.call(this));
		};
		VariablesRecord.init();
		return VariablesRecord;
	}
	) (OS.DataTypes.GenericRecord);
	var WidgetsRecord = (function(_super) {
		__extends(WidgetsRecord, _super);
		function WidgetsRecord() {
			_super.apply(this, arguments);
		}
		WidgetsRecord.getWidgetsType = function() {
			return {
				LoginForm: OS.Model.ValidationWidgetRecord,
				Input_UsernameVal: OS.Model.ValidationWidgetRecord,
				Input_PasswordVal: OS.Model.ValidationWidgetRecord,
				Checkbox1: OS.Model.ValidationWidgetRecord
			};
		};

		return WidgetsRecord;
	}
	) (OS.Model.BaseWidgetRecordMap);
	var Model = (function(_super) {
		__extends(Model, _super);
		function Model() {
			_super.apply(this, arguments);
		}
		Model.getVariablesRecordConstructor = function() {
			return VariablesRecord;
		};
		Model.getWidgetsRecordConstructor = function() {
			return WidgetsRecord;
		};
		Object.defineProperty(Model, "hasValidationWidgets", {
			enumerable: true,
			configurable: true,
			get: function() {
				return true;
			}
		}
		);

		Model.prototype.setInputs = function(inputs) {
		};
		return Model;
	}
	) (OS.Model.BaseViewModel);
	return new OS.Model.ModelFactory(Model);
});
define("YESBankPOC.Common.Login.mvc$view",["OutSystems/ClientRuntime/Main", "YESBankPOC.model", "YESBankPOC.controller", "OutSystemsUI.controller", "react", "OutSystems/ReactView/Main", "YESBankPOC.Common.Login.mvc$model", "YESBankPOC.Common.Login.mvc$controller", "YESBankPOC.clientVariables", "YESBankPOC.Layouts.LayoutBlank.mvc$view", "OutSystems/ReactWidgets/Main", "OutSystemsUI.Interaction.AnimatedLabel.mvc$view", "OutSystemsUI.Adaptive.Columns2.mvc$view", "OutSystemsUI.Utilities.AlignCenter.mvc$view", "OutSystemsUI.Utilities.ButtonLoading.mvc$view", "OutSystemsUI.controller$FeedbackMessageClose", "YESBankPOC.referencesHealth", "YESBankPOC.referencesHealth$OutSystemsUI"], function(OutSystems, YESBankPOCModel, YESBankPOCController, OutSystemsUIController, React, OSView, YESBankPOC_Common_Login_mvc_model, YESBankPOC_Common_Login_mvc_controller, YESBankPOCClientVariables, YESBankPOC_Layouts_LayoutBlank_mvc_view, OSWidgets, OutSystemsUI_Interaction_AnimatedLabel_mvc_view, OutSystemsUI_Adaptive_Columns2_mvc_view, OutSystemsUI_Utilities_AlignCenter_mvc_view, OutSystemsUI_Utilities_ButtonLoading_mvc_view) {
	var OS = OutSystems.Internal;
	var PlaceholderContent = OSView.Widget.PlaceholderContent;
	var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


	var View = (function(_super) {
		__extends(View, _super);
		function View() {
			try {
				this.initialize.apply(this, arguments);
			} catch (error) {
				View.handleError(error);
				throw error;
			}
		}
		View.prototype.initialize = function() {
			_super.apply(this, arguments);
		};
		View.displayName = "Common.Login";
		View.getCssDependencies = function() {
			return["css/OutSystemsReactWidgets.css", "css/OutSystemsUI.OutSystemsUI.css", "css/YESBankPOC.YESBankPOC.css", "css/YESBankPOC.YESBankPOC.extra.css"];
		};
		View.getJsDependencies = function() {
			return[];
		};
		View.getBlocks = function() {
			return[YESBankPOC_Layouts_LayoutBlank_mvc_view, OutSystemsUI_Interaction_AnimatedLabel_mvc_view, OutSystemsUI_Adaptive_Columns2_mvc_view, OutSystemsUI_Utilities_AlignCenter_mvc_view, OutSystemsUI_Utilities_ButtonLoading_mvc_view];
		};
		Object.defineProperty(View.prototype, "modelFactory", {
			get: function() {
				return YESBankPOC_Common_Login_mvc_model;
			}
			,
			enumerable: true,
			configurable: true
		});
		Object.defineProperty(View.prototype, "controllerFactory", {
			get: function() {
				return YESBankPOC_Common_Login_mvc_controller;
			}
			,
			enumerable: true,
			configurable: true
		});
		Object.defineProperty(View.prototype, "title", {
			get: function() {
				return "Login";
			}
			,
			enumerable: true,
			configurable: true
		});
		View.prototype.internalRender = function() {
			var model = this.model;
			var controller = this.controller;
			var idService = this.idService;
			var validationService = controller.validationService;
			var widgetsRecordProvider = this.widgetsRecordProvider;
			var callContext = controller.callContext();
			var $if = View.ifWidget;
			var $text = View.textWidget;
			var asPrimitiveValue = View.asPrimitiveValue;
			var getTranslation = View.getTranslation;
			var _this = this;

			return React.createElement("div", this.getRootNodeProperties(), React.createElement(YESBankPOC_Layouts_LayoutBlank_mvc_view, {
				inputs: {}
				,
				events: {
					_handleError: function(ex) {
						controller.handleError(ex);
					}
				}
				,
				_validationProps: {
					validationService: validationService
				}
				,
				_idProps: {
					service: idService,
					uuid: "0",
					alias: "1"
				}
				,
				_widgetRecordProvider: widgetsRecordProvider,
				placeholders: {
					content: new PlaceholderContent(function() {
						return[React.createElement(OSWidgets.Container, {
							align:/*Default*/ 0,
							animate: false,
							style: "login-screen",
							visible: true,
							_idProps: {
								service: idService,
								uuid: "1"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider
						}
						, React.createElement(OSWidgets.Form, {
							_validationProps: {
								validationService: validationService
							}
							,
							style: "login-form",
							_idProps: {
								service: idService,
								name: "LoginForm"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider
						}
						, React.createElement(OSWidgets.Container, {
							align:/*Default*/ 0,
							animate: false,
							extendedProperties: {
								style: "text-align: center;"
							}
							,
							style: "login-logo",
							visible: true,
							_idProps: {
								service: idService,
								uuid: "3"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider
						}
						, React.createElement(OSWidgets.Container, {
							align:/*Default*/ 0,
							animate: false,
							extendedProperties: {
								style: "text-align: center;"
							}
							,
							visible: true,
							_idProps: {
								service: idService,
								uuid: "4"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider
						}
						, React.createElement(OSWidgets.Image, {
							extendedProperties: {
								alt: "",
								style: "height: 100px;"
							}
							,
							image: OS.Navigation.VersionedURL.getVersionedUrl("img/YESBankPOC.Logo.png"),
							type:/*Static*/ 0,
							_idProps: {
								service: idService,
								uuid: "5"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider
						})), React.createElement(OSWidgets.AdvancedHtml, {
							extendedProperties: {
								className: "margin-top-base"
							}
							,
							tag: "h1",
							_idProps: {
								service: idService,
								uuid: "6"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider
						}
						, React.createElement(OSWidgets.Expression, {
							style: "heading5 text-neutral-8",
							value: model.getCachedValue(idService.getId("W_dEYU6Bmk+4UQuieAPFpg.Value"), function() {
								return OS.BuiltinFunctions.getEntryEspaceName();
							}),
							_idProps: {
								service: idService,
								uuid: "7"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider
						}))), React.createElement(OSWidgets.Container, {
							align:/*Default*/ 0,
							animate: false,
							style: "login-inputs margin-top-m",
							visible: true,
							_idProps: {
								service: idService,
								uuid: "8"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider
						}
						, React.createElement(OSWidgets.Container, {
							align:/*Default*/ 0,
							animate: false,
							visible: true,
							_idProps: {
								service: idService,
								uuid: "9"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider
						}
						, React.createElement(OutSystemsUI_Interaction_AnimatedLabel_mvc_view, {
							inputs: {}
							,
							events: {
								_handleError: function(ex) {
									controller.handleError(ex);
								}
							}
							,
							_validationProps: {
								validationService: validationService,
								validationParentId: idService.getId("LoginForm")
							}
							,
							_idProps: {
								service: idService,
								uuid: "10",
								alias: "2"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider,
							placeholders: {
								label: new PlaceholderContent(function() {
									return[React.createElement(OSWidgets.Label, {
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										mandatory: true,
										targetWidget: "Input_UsernameVal",
										_idProps: {
											service: idService,
											uuid: "11"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, "Username")];
								}),
								input: new PlaceholderContent(function() {
									return[React.createElement(OSWidgets.Input, {
										_validationProps: {
											validationService: validationService,
											validationParentId: idService.getId("LoginForm")
										}
										,
										enabled: true,
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										inputType:/*Text*/ 0,
										mandatory: true,
										maxLength: 250,
										style: "form-control",
										variable: model.createVariable(OS.Types.Text, model.variables.usernameVar, function(value) {
											model.variables.usernameVar = value;
										}),
										_idProps: {
											service: idService,
											name: "Input_UsernameVal"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									})];
								})
							}
							,
							_dependencies:[asPrimitiveValue(model.variables.usernameVar)]
						})), React.createElement(OSWidgets.Container, {
							align:/*Default*/ 0,
							animate: false,
							style: "margin-top-base",
							visible: true,
							_idProps: {
								service: idService,
								uuid: "13"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider
						}
						, React.createElement(OutSystemsUI_Interaction_AnimatedLabel_mvc_view, {
							inputs: {}
							,
							events: {
								_handleError: function(ex) {
									controller.handleError(ex);
								}
							}
							,
							_validationProps: {
								validationService: validationService,
								validationParentId: idService.getId("LoginForm")
							}
							,
							_idProps: {
								service: idService,
								uuid: "14",
								alias: "3"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider,
							placeholders: {
								label: new PlaceholderContent(function() {
									return[React.createElement(OSWidgets.Label, {
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										mandatory: true,
										targetWidget: "Input_PasswordVal",
										_idProps: {
											service: idService,
											uuid: "15"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, "Password")];
								}),
								input: new PlaceholderContent(function() {
									return[React.createElement(OSWidgets.Input, {
										_validationProps: {
											validationService: validationService,
											validationParentId: idService.getId("LoginForm")
										}
										,
										enabled: true,
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										inputType:/*Password*/ 1,
										mandatory: true,
										maxLength: 0,
										style: "form-control login-password",
										variable: model.createVariable(OS.Types.Text, model.variables.passwordVar, function(value) {
											model.variables.passwordVar = value;
										}),
										_idProps: {
											service: idService,
											name: "Input_PasswordVal"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									})];
								})
							}
							,
							_dependencies:[asPrimitiveValue(model.variables.passwordVar)]
						})), React.createElement(OSWidgets.Container, {
							align:/*Default*/ 0,
							animate: false,
							style: "margin-top-l",
							visible: true,
							_idProps: {
								service: idService,
								uuid: "17"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider
						}
						, React.createElement(OutSystemsUI_Adaptive_Columns2_mvc_view, {
							inputs: {}
							,
							events: {
								_handleError: function(ex) {
									controller.handleError(ex);
								}
							}
							,
							_validationProps: {
								validationService: validationService,
								validationParentId: idService.getId("LoginForm")
							}
							,
							_idProps: {
								service: idService,
								uuid: "18",
								alias: "4"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider,
							placeholders: {
								column1: new PlaceholderContent(function() {
									return[React.createElement(OutSystemsUI_Utilities_AlignCenter_mvc_view, {
										inputs: {}
										,
										events: {
											_handleError: function(ex) {
												controller.handleError(ex);
											}
										}
										,
										_validationProps: {
											validationService: validationService,
											validationParentId: idService.getId("LoginForm")
										}
										,
										_idProps: {
											service: idService,
											uuid: "19",
											alias: "5"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider,
										placeholders: {
											content: new PlaceholderContent(function() {
												return[React.createElement(OSWidgets.Checkbox, {
													_validationProps: {
														validationService: validationService,
														validationParentId: idService.getId("LoginForm")
													}
													,
													enabled: true,
													extendedProperties: {
														 "aria-label": "Remember me the password"
													}
													,
													style: "checkbox",
													variable: model.createVariable(OS.Types.Boolean, model.variables.rememberVar, function(value) {
														model.variables.rememberVar = value;
													}),
													_idProps: {
														service: idService,
														name: "Checkbox1"
													}
													,
													_widgetRecordProvider: widgetsRecordProvider
												}), React.createElement(OSWidgets.Label, {
													gridProperties: {
														classes: "OSFillParent"
													}
													,
													style: "font-size-s margin-left-s",
													targetWidget: "Checkbox1",
													_idProps: {
														service: idService,
														uuid: "21"
													}
													,
													_widgetRecordProvider: widgetsRecordProvider
												}
												, "Remember me")];
											})
										}
										,
										_dependencies:[asPrimitiveValue(model.variables.rememberVar)]
									})];
								}),
								column2: new PlaceholderContent(function() {
									return[React.createElement(OSWidgets.Container, {
										align:/*Default*/ 0,
										animate: false,
										extendedProperties: {
											style: "text-align: right;"
										}
										,
										visible: true,
										_idProps: {
											service: idService,
											uuid: "22"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, React.createElement(OSWidgets.Link, {
										enabled: true,
										extendedProperties: {
											 "aria-label": "Forgot password? Click here to recover it"
										}
										,
										onClick: function() {
											var eventHandlerContext = callContext.clone();
											controller.forgotPassword$Action(controller.callContext(eventHandlerContext));

											;
										}
										,
										visible: true,
										_idProps: {
											service: idService,
											uuid: "23"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, "Forgot password?"))];
								})
							}
							,
							_dependencies:[asPrimitiveValue(model.variables.rememberVar)]
						}))), React.createElement(OSWidgets.Container, {
							align:/*Default*/ 0,
							animate: false,
							style: "login-button margin-top-l",
							visible: true,
							_idProps: {
								service: idService,
								uuid: "24"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider
						}
						, React.createElement(OutSystemsUI_Utilities_ButtonLoading_mvc_view, {
							inputs: {
								ExtendedClass: "full-width",
								IsLoading: model.variables.isExecutingVar
							}
							,
							events: {
								_handleError: function(ex) {
									controller.handleError(ex);
								}
							}
							,
							_validationProps: {
								validationService: validationService,
								validationParentId: idService.getId("LoginForm")
							}
							,
							_idProps: {
								service: idService,
								uuid: "25",
								alias: "6"
							}
							,
							_widgetRecordProvider: widgetsRecordProvider,
							placeholders: {
								button: new PlaceholderContent(function() {
									return[React.createElement(OSWidgets.Button, {
										enabled: true,
										gridProperties: {
											classes: "OSFillParent"
										}
										,
										isDefault: true,
										onClick: function() {
											_this.validateWidget(idService.getId("LoginForm"));
											return Promise.resolve().then(function() {
												var eventHandlerContext = callContext.clone();
												controller.login$Action(controller.callContext(eventHandlerContext));
											});

											;
										}
										,
										style: "btn btn-primary btn-large",
										visible: true,
										_idProps: {
											service: idService,
											uuid: "26"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, React.createElement(OSWidgets.Container, {
										align:/*Default*/ 0,
										animate: false,
										gridProperties: {
											classes: "OSInline"
										}
										,
										style: "btn-loading margin-right-s",
										visible: true,
										_idProps: {
											service: idService,
											uuid: "27"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, React.createElement(OSWidgets.Container, {
										align:/*Default*/ 0,
										animate: false,
										extendedProperties: {
											 "aria-hidden": "true"
										}
										,
										style: "loading-spinner",
										visible: true,
										_idProps: {
											service: idService,
											uuid: "28"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									})), React.createElement(OSWidgets.Container, {
										align:/*Default*/ 0,
										animate: false,
										gridProperties: {
											classes: "OSInline"
										}
										,
										style: "btn-label",
										visible: true,
										_idProps: {
											service: idService,
											uuid: "29"
										}
										,
										_widgetRecordProvider: widgetsRecordProvider
									}
									, "Login"))];
								})
							}
							,
							_dependencies:[]
						}))))];
					})
				}
				,
				_dependencies:[asPrimitiveValue(model.variables.isExecutingVar), asPrimitiveValue(model.variables.rememberVar), asPrimitiveValue(model.variables.passwordVar), asPrimitiveValue(model.variables.usernameVar)]
			}));
		};
		return View;
	})(OSView.BaseView.BaseWebScreen);

	return View;
});
define("YESBankPOC.Common.Login.mvc$controller",["OutSystems/ClientRuntime/Main", "YESBankPOC.model", "YESBankPOC.controller", "OutSystemsUI.controller", "YESBankPOC.languageResources", "YESBankPOC.clientVariables", "YESBankPOC.Common.controller", "OutSystemsUI.controller$FeedbackMessageClose", "YESBankPOC.referencesHealth", "YESBankPOC.referencesHealth$OutSystemsUI"], function(OutSystems, YESBankPOCModel, YESBankPOCController, OutSystemsUIController, YESBankPOCLanguageResources, YESBankPOCClientVariables, YESBankPOC_CommonController) {
	var OS = OutSystems.Internal;
	var Controller = (function(_super) {
		__extends(Controller, _super);
		function Controller() {
			_super.apply(this, arguments);
			var controller = this.controller;
			this.clientActionProxies = {};
			this.dataFetchDependenciesOriginal = {};
			this.dataFetchDependentsGraph = {};
			this.shouldSendClientVarsToDataSources = false;
		}
		// Server Actions
		Controller.prototype.doLogin$ServerAction = function(usernameIn, passwordIn, rememberLoginIn, callContext) {
			var controller = this.controller;
			var inputs = {
				Username: OS.DataConversion.ServerDataConverter.to(usernameIn, OS.Types.Text),
				Password: OS.DataConversion.ServerDataConverter.to(passwordIn, OS.Types.Text),
				RememberLogin: OS.DataConversion.ServerDataConverter.to(rememberLoginIn, OS.Types.Boolean)
			};
			return controller.callServerAction("DoLogin", "screenservices/YESBankPOC/Common/Login/ActionDoLogin", "h2Av296a8uiyCqJ3GG4paA", inputs, controller.callContext(callContext), undefined, undefined, false).then(function(outputs) {
			}
			);
		};

		// Aggregates and Data Actions

		Controller.prototype.dataFetchActionNames =[];
		// Client Actions
		Controller.prototype._forgotPassword$Action = function(callContext) {
			var model = this.model;
			var controller = this.controller;
			var idService = this.idService;
			controller.ensureControllerAlive("ForgotPassword");
			callContext = controller.callContext(callContext);
		};
		Controller.prototype._login$Action = function(callContext) {
			var model = this.model;
			var controller = this.controller;
			var idService = this.idService;
			controller.ensureControllerAlive("Login");
			callContext = controller.callContext(callContext);
			var allExceptionsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
			return OS.Flow.executeAsyncFlow(function() {
				// IsExecuting = True
				model.variables.isExecutingVar = true;
				// Execute Action: DoLogin
				model.flush();
				return controller.doLogin$ServerAction(model.variables.usernameVar, model.variables.passwordVar, model.variables.rememberVar, callContext).then(function() {
					// Execute Action: FeedbackMessageClose
					OutSystemsUIController.default.feedbackMessageClose$Action(callContext);
					// Destination: /YESBankPOC/
					return OS.Flow.returnAsync(OS.Navigation.navigateTo(OS.Navigation.generateScreenURL((((YESBankPOCClientVariables.getLastURL() === "")) ?(OS.BuiltinFunctions.getOwnerURLPath()):(YESBankPOCClientVariables.getLastURL())), {}
					), OS.Transitions.createTransition(OS.Transitions.TransitionAnimation.Fade), callContext, true));
				}
				);
			}
			).catch(function(ex) {
				OS.Logger.trace("Login.Login", OS.Exceptions.getMessage(ex), ex.name);
				// Handle Error: AllExceptions
				if (!(OS.Exceptions.isSystem(ex))) {
					OS.Logger.error(null, ex);
					allExceptionsVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
					return OS.Flow.executeAsyncFlow(function() {
						// IsExecuting = False
						model.variables.isExecutingVar = false;
						OS.FeedbackMessageService.showFeedbackMessage(allExceptionsVar.value.exceptionMessageAttr,/*Error*/ 3);
						return OS.Flow.returnAsync();

					}
					);
				}

				throw ex;
			}
			);
		};
		Controller.prototype._onInitialize$Action = function(callContext) {
			var model = this.model;
			var controller = this.controller;
			var idService = this.idService;
			controller.ensureControllerAlive("OnInitialize");
			callContext = controller.callContext(callContext);
			// IsExecuting = False
			model.variables.isExecutingVar = false;
		};

		Controller.prototype.forgotPassword$Action = function(callContext) {
			var controller = this.controller;
			return controller.safeExecuteClientAction(controller._forgotPassword$Action, callContext);

		};
		Controller.prototype.login$Action = function(callContext) {
			var controller = this.controller;
			return controller.safeExecuteClientAction(controller._login$Action, callContext);

		};
		Controller.prototype.onInitialize$Action = function(callContext) {
			var controller = this.controller;
			return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

		};

		// Event Handler Actions
		Controller.prototype.onInitializeEventHandler = function(callContext) {
			var controller = this.controller;
			var model = this.model;
			var idService = this.idService;

			return controller.onInitialize$Action(callContext);

		};
		Controller.prototype.onReadyEventHandler = null;
		Controller.prototype.onRenderEventHandler = null;
		Controller.prototype.onDestroyEventHandler = null;
		Controller.prototype.onParametersChangedEventHandler = null;
		Controller.prototype.handleError = function(ex) {
			return YESBankPOC_CommonController.default.handleError(ex, this.callContext());
		};
		Controller.checkPermissions = function() {
		};
		Controller.prototype.getDefaultTimeout = function() {
			return YESBankPOCController.default.defaultTimeout;
		};
		return Controller;
	}
	) (OS.Controller.BaseViewController);
	return new OS.Controller.ControllerFactory(Controller, YESBankPOCLanguageResources);
});

