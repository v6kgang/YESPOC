﻿define("YESBankPOC.Common.MenuIcon.mvc$model",["OutSystems/ClientRuntime/Main", "YESBankPOC.model", "OutSystemsUI.controller", "OutSystemsUI.controller$SetMenuIconListeners", "YESBankPOC.referencesHealth", "YESBankPOC.referencesHealth$OutSystemsUI", "OutSystemsUI.controller$ToggleSideMenu"], function(OutSystems, YESBankPOCModel, OutSystemsUIController) {
	var OS = OutSystems.Internal;


	var VariablesRecord = (function(_super) {
		__extends(VariablesRecord, _super);
		function VariablesRecord(defaults) {
			_super.apply(this, arguments);
		}
		VariablesRecord.attributesToDeclare = function() {
			return[] .concat(_super.attributesToDeclare.call(this));
		};
		VariablesRecord.init();
		return VariablesRecord;
	}
	) (OS.DataTypes.GenericRecord);
	var WidgetsRecord = (function(_super) {
		__extends(WidgetsRecord, _super);
		function WidgetsRecord() {
			_super.apply(this, arguments);
		}
		WidgetsRecord.getWidgetsType = function() {
			return {};
		};

		return WidgetsRecord;
	}
	) (OS.Model.BaseWidgetRecordMap);
	var Model = (function(_super) {
		__extends(Model, _super);
		function Model() {
			_super.apply(this, arguments);
		}
		Model.getVariablesRecordConstructor = function() {
			return VariablesRecord;
		};
		Model.getWidgetsRecordConstructor = function() {
			return WidgetsRecord;
		};
		Object.defineProperty(Model, "hasValidationWidgets", {
			enumerable: true,
			configurable: true,
			get: function() {
				return false;
			}
		}
		);

		Model.prototype.setInputs = function(inputs) {
		};
		return Model;
	}
	) (OS.Model.VariablelessViewModel);
	return new OS.Model.ModelFactory(Model);
});
define("YESBankPOC.Common.MenuIcon.mvc$view",["OutSystems/ClientRuntime/Main", "YESBankPOC.model", "YESBankPOC.controller", "OutSystemsUI.controller", "react", "OutSystems/ReactView/Main", "YESBankPOC.Common.MenuIcon.mvc$model", "YESBankPOC.Common.MenuIcon.mvc$controller", "YESBankPOC.clientVariables", "OutSystems/ReactWidgets/Main", "OutSystemsUI.controller$SetMenuIconListeners", "YESBankPOC.referencesHealth", "YESBankPOC.referencesHealth$OutSystemsUI", "OutSystemsUI.controller$ToggleSideMenu"], function(OutSystems, YESBankPOCModel, YESBankPOCController, OutSystemsUIController, React, OSView, YESBankPOC_Common_MenuIcon_mvc_model, YESBankPOC_Common_MenuIcon_mvc_controller, YESBankPOCClientVariables, OSWidgets) {
	var OS = OutSystems.Internal;
	var PlaceholderContent = OSView.Widget.PlaceholderContent;
	var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


	var View = (function(_super) {
		__extends(View, _super);
		function View() {
			try {
				this.initialize.apply(this, arguments);
			} catch (error) {
				View.handleError(error);
				throw error;
			}
		}
		View.prototype.initialize = function() {
			_super.apply(this, arguments);
		};
		View.displayName = "Common.MenuIcon";
		View.getCssDependencies = function() {
			return["css/OutSystemsReactWidgets.css"];
		};
		View.getJsDependencies = function() {
			return[];
		};
		View.getBlocks = function() {
			return[];
		};
		Object.defineProperty(View.prototype, "modelFactory", {
			get: function() {
				return YESBankPOC_Common_MenuIcon_mvc_model;
			}
			,
			enumerable: true,
			configurable: true
		});
		Object.defineProperty(View.prototype, "controllerFactory", {
			get: function() {
				return YESBankPOC_Common_MenuIcon_mvc_controller;
			}
			,
			enumerable: true,
			configurable: true
		});
		Object.defineProperty(View.prototype, "title", {
			get: function() {
				return "";
			}
			,
			enumerable: true,
			configurable: true
		});
		View.prototype.internalRender = function() {
			var model = this.model;
			var controller = this.controller;
			var idService = this.idService;
			var validationService = controller.validationService;
			var widgetsRecordProvider = this.widgetsRecordProvider;
			var callContext = controller.callContext();
			var $if = View.ifWidget;
			var $text = View.textWidget;
			var asPrimitiveValue = View.asPrimitiveValue;
			var getTranslation = View.getTranslation;
			var _this = this;

			return React.createElement("div", this.getRootNodeProperties(), React.createElement(OSWidgets.Container, {
				align:/*Default*/ 0,
				animate: false,
				extendedEvents: {
					onClick: function() {
						var eventHandlerContext = callContext.clone();
						controller.onClick$Action(controller.callContext(eventHandlerContext));

						;
					}
				}
				,
				extendedProperties: {
					 "aria-label": "Toggle the Menu",
					role: "button",
					tabIndex: "0",
					 "aria-haspopup": "true"
				}
				,
				style: "menu-icon",
				visible: true,
				_idProps: {
					service: idService,
					uuid: "0"
				}
				,
				_widgetRecordProvider: widgetsRecordProvider
			}
			, React.createElement(OSWidgets.Container, {
				align:/*Default*/ 0,
				animate: false,
				extendedProperties: {
					 "aria-hidden": "true"
				}
				,
				style: "menu-icon-line",
				visible: true,
				_idProps: {
					service: idService,
					uuid: "1"
				}
				,
				_widgetRecordProvider: widgetsRecordProvider
			}), React.createElement(OSWidgets.Container, {
				align:/*Default*/ 0,
				animate: false,
				extendedProperties: {
					 "aria-hidden": "true"
				}
				,
				style: "menu-icon-line",
				visible: true,
				_idProps: {
					service: idService,
					uuid: "2"
				}
				,
				_widgetRecordProvider: widgetsRecordProvider
			}), React.createElement(OSWidgets.Container, {
				align:/*Default*/ 0,
				animate: false,
				extendedProperties: {
					 "aria-hidden": "true"
				}
				,
				style: "menu-icon-line",
				visible: true,
				_idProps: {
					service: idService,
					uuid: "3"
				}
				,
				_widgetRecordProvider: widgetsRecordProvider
			})));
		};
		return View;
	})(OSView.BaseView.BaseWebBlock);

	return View;
});
define("YESBankPOC.Common.MenuIcon.mvc$controller",["OutSystems/ClientRuntime/Main", "YESBankPOC.model", "YESBankPOC.controller", "OutSystemsUI.controller", "YESBankPOC.languageResources", "YESBankPOC.clientVariables", "OutSystemsUI.controller$SetMenuIconListeners", "YESBankPOC.referencesHealth", "YESBankPOC.referencesHealth$OutSystemsUI", "OutSystemsUI.controller$ToggleSideMenu"], function(OutSystems, YESBankPOCModel, YESBankPOCController, OutSystemsUIController, YESBankPOCLanguageResources, YESBankPOCClientVariables) {
	var OS = OutSystems.Internal;
	var Controller = (function(_super) {
		__extends(Controller, _super);
		function Controller() {
			_super.apply(this, arguments);
			var controller = this.controller;
			this.clientActionProxies = {};
			this.dataFetchDependenciesOriginal = {};
			this.dataFetchDependentsGraph = {};
			this.shouldSendClientVarsToDataSources = false;
		}
		// Server Actions

		// Aggregates and Data Actions

		Controller.prototype.dataFetchActionNames =[];
		// Client Actions
		Controller.prototype._onReady$Action = function(callContext) {
			var model = this.model;
			var controller = this.controller;
			var idService = this.idService;
			controller.ensureControllerAlive("OnReady");
			callContext = controller.callContext(callContext);
			// Execute Action: SetMenuIconListeners
			OutSystemsUIController.default.setMenuIconListeners$Action(callContext);
		};
		Controller.prototype._onClick$Action = function(callContext) {
			var model = this.model;
			var controller = this.controller;
			var idService = this.idService;
			controller.ensureControllerAlive("OnClick");
			callContext = controller.callContext(callContext);
			// Execute Action: ToggleSideMenu
			OutSystemsUIController.default.toggleSideMenu$Action(callContext);
		};

		Controller.prototype.onReady$Action = function(callContext) {
			var controller = this.controller;
			return controller.safeExecuteClientAction(controller._onReady$Action, callContext);

		};
		Controller.prototype.onClick$Action = function(callContext) {
			var controller = this.controller;
			return controller.safeExecuteClientAction(controller._onClick$Action, callContext);

		};

		// Event Handler Actions
		Controller.prototype.onInitializeEventHandler = null;
		Controller.prototype.onReadyEventHandler = function(callContext) {
			var controller = this.controller;
			var model = this.model;
			var idService = this.idService;

			return controller.onReady$Action(callContext);

		};
		Controller.prototype.onRenderEventHandler = null;
		Controller.prototype.onDestroyEventHandler = null;
		Controller.prototype.onParametersChangedEventHandler = function(callContext) {
			var controller = this.controller;
			var model = this.model;
			var idService = this.idService;

			return controller.onReady$Action(callContext);

		};
		Controller.prototype.handleError = function(ex) {
			return controller.handleError(ex);
		};
		Controller.checkPermissions = function() {
		};
		Controller.prototype.getDefaultTimeout = function() {
			return YESBankPOCController.default.defaultTimeout;
		};
		return Controller;
	}
	) (OS.Controller.BaseViewController);
	return new OS.Controller.ControllerFactory(Controller, YESBankPOCLanguageResources);
});

