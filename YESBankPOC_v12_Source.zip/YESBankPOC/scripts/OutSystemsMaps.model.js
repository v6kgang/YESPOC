﻿define("OutSystemsMaps.model$OptionalStaticMapConfigsRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var OptionalStaticMapConfigsRec = (function (_super) {
__extends(OptionalStaticMapConfigsRec, _super);
function OptionalStaticMapConfigsRec(defaults) {
_super.apply(this, arguments);
}
OptionalStaticMapConfigsRec.attributesToDeclare = function () {
return [
this.attr("Zoom", "zoomAttr", "Zoom", false, false, OS.Types.Integer, function () {
return OutSystemsMapsModel.staticEntities.zoom.auto;
}, true), 
this.attr("Type", "typeAttr", "Type", false, false, OS.Types.Text, function () {
return OutSystemsMapsModel.staticEntities.type.roadmap;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
OptionalStaticMapConfigsRec.init();
return OptionalStaticMapConfigsRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.OptionalStaticMapConfigsRec = OptionalStaticMapConfigsRec;

});
define("OutSystemsMaps.model$OptionalStaticMapConfigsRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$OptionalStaticMapConfigsRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var OptionalStaticMapConfigsRecord = (function (_super) {
__extends(OptionalStaticMapConfigsRecord, _super);
function OptionalStaticMapConfigsRecord(defaults) {
_super.apply(this, arguments);
}
OptionalStaticMapConfigsRecord.attributesToDeclare = function () {
return [
this.attr("OptionalStaticMapConfigs", "optionalStaticMapConfigsAttr", "OptionalStaticMapConfigs", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.OptionalStaticMapConfigsRec());
}, true, OutSystemsMapsModel.OptionalStaticMapConfigsRec)
].concat(_super.attributesToDeclare.call(this));
};
OptionalStaticMapConfigsRecord.fromStructure = function (str) {
return new OptionalStaticMapConfigsRecord(new OptionalStaticMapConfigsRecord.RecordClass({
optionalStaticMapConfigsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
OptionalStaticMapConfigsRecord._isAnonymousRecord = true;
OptionalStaticMapConfigsRecord.UniqueId = "003de765-2ef7-0684-ee40-ecb9c31ff117";
OptionalStaticMapConfigsRecord.init();
return OptionalStaticMapConfigsRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.OptionalStaticMapConfigsRecord = OptionalStaticMapConfigsRecord;

});
define("OutSystemsMaps.model$StrokeRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var StrokeRec = (function (_super) {
__extends(StrokeRec, _super);
function StrokeRec(defaults) {
_super.apply(this, arguments);
}
StrokeRec.attributesToDeclare = function () {
return [
this.attr("Color", "colorAttr", "Color", false, false, OS.Types.Text, function () {
return "#000000";
}, true), 
this.attr("Opacity", "opacityAttr", "Opacity", false, false, OS.Types.Decimal, function () {
return OS.BuiltinFunctions.integerToDecimal(1);
}, true), 
this.attr("Weight", "weightAttr", "Weight", false, false, OS.Types.Integer, function () {
return 2;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
StrokeRec.init();
return StrokeRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.StrokeRec = StrokeRec;

});
define("OutSystemsMaps.model$StrokeRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$StrokeRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var StrokeRecord = (function (_super) {
__extends(StrokeRecord, _super);
function StrokeRecord(defaults) {
_super.apply(this, arguments);
}
StrokeRecord.attributesToDeclare = function () {
return [
this.attr("Stroke", "strokeAttr", "Stroke", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.StrokeRec());
}, true, OutSystemsMapsModel.StrokeRec)
].concat(_super.attributesToDeclare.call(this));
};
StrokeRecord.fromStructure = function (str) {
return new StrokeRecord(new StrokeRecord.RecordClass({
strokeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
StrokeRecord._isAnonymousRecord = true;
StrokeRecord.UniqueId = "80cb2a44-51da-1d8d-8f25-a688259024cd";
StrokeRecord.init();
return StrokeRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.StrokeRecord = StrokeRecord;

});
define("OutSystemsMaps.model$StrokeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$StrokeRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var StrokeRecordList = (function (_super) {
__extends(StrokeRecordList, _super);
function StrokeRecordList(defaults) {
_super.apply(this, arguments);
}
StrokeRecordList.itemType = OutSystemsMapsModel.StrokeRecord;
return StrokeRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.StrokeRecordList = StrokeRecordList;

});
define("OutSystemsMaps.model$Internal_to_provider_shape_configsRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var Internal_to_provider_shape_configsRec = (function (_super) {
__extends(Internal_to_provider_shape_configsRec, _super);
function Internal_to_provider_shape_configsRec(defaults) {
_super.apply(this, arguments);
}
Internal_to_provider_shape_configsRec.attributesToDeclare = function () {
return [
this.attr("locations", "locationsAttr", "locations", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("allowDrag", "allowDragAttr", "allowDrag", true, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("allowEdit", "allowEditAttr", "allowEdit", true, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("strokeColor", "strokeColorAttr", "strokeColor", true, false, OS.Types.Text, function () {
return "#000000";
}, true), 
this.attr("strokeOpacity", "strokeOpacityAttr", "strokeOpacity", true, false, OS.Types.Decimal, function () {
return OS.BuiltinFunctions.integerToDecimal(1);
}, true), 
this.attr("strokeWeight", "strokeWeightAttr", "strokeWeight", true, false, OS.Types.Integer, function () {
return 2;
}, true), 
this.attr("fillColor", "fillColorAttr", "fillColor", true, false, OS.Types.Text, function () {
return "#000000";
}, true), 
this.attr("fillOpacity", "fillOpacityAttr", "fillOpacity", true, false, OS.Types.Decimal, function () {
return OS.BuiltinFunctions.integerToDecimal(1);
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Internal_to_provider_shape_configsRec.init();
return Internal_to_provider_shape_configsRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.Internal_to_provider_shape_configsRec = Internal_to_provider_shape_configsRec;

});
define("OutSystemsMaps.model$Internal_to_provider_shape_configsRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$Internal_to_provider_shape_configsRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var Internal_to_provider_shape_configsRecord = (function (_super) {
__extends(Internal_to_provider_shape_configsRecord, _super);
function Internal_to_provider_shape_configsRecord(defaults) {
_super.apply(this, arguments);
}
Internal_to_provider_shape_configsRecord.attributesToDeclare = function () {
return [
this.attr("Internal_to_provider_shape_configs", "internal_to_provider_shape_configsAttr", "Internal_to_provider_shape_configs", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.Internal_to_provider_shape_configsRec());
}, true, OutSystemsMapsModel.Internal_to_provider_shape_configsRec)
].concat(_super.attributesToDeclare.call(this));
};
Internal_to_provider_shape_configsRecord.fromStructure = function (str) {
return new Internal_to_provider_shape_configsRecord(new Internal_to_provider_shape_configsRecord.RecordClass({
internal_to_provider_shape_configsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
Internal_to_provider_shape_configsRecord._isAnonymousRecord = true;
Internal_to_provider_shape_configsRecord.UniqueId = "d566c0a2-7b89-28cd-9ecc-06f062d869f4";
Internal_to_provider_shape_configsRecord.init();
return Internal_to_provider_shape_configsRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.Internal_to_provider_shape_configsRecord = Internal_to_provider_shape_configsRecord;

});
define("OutSystemsMaps.model$Internal_to_provider_shape_configsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$Internal_to_provider_shape_configsRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var Internal_to_provider_shape_configsRecordList = (function (_super) {
__extends(Internal_to_provider_shape_configsRecordList, _super);
function Internal_to_provider_shape_configsRecordList(defaults) {
_super.apply(this, arguments);
}
Internal_to_provider_shape_configsRecordList.itemType = OutSystemsMapsModel.Internal_to_provider_shape_configsRecord;
return Internal_to_provider_shape_configsRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.Internal_to_provider_shape_configsRecordList = Internal_to_provider_shape_configsRecordList;

});
define("OutSystemsMaps.model$Internal_to_provider_shape_configsList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$Internal_to_provider_shape_configsRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var Internal_to_provider_shape_configsList = (function (_super) {
__extends(Internal_to_provider_shape_configsList, _super);
function Internal_to_provider_shape_configsList(defaults) {
_super.apply(this, arguments);
}
Internal_to_provider_shape_configsList.itemType = OutSystemsMapsModel.Internal_to_provider_shape_configsRec;
return Internal_to_provider_shape_configsList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.Internal_to_provider_shape_configsList = Internal_to_provider_shape_configsList;

});
define("OutSystemsMaps.model$StyleRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var StyleRec = (function (_super) {
__extends(StyleRec, _super);
function StyleRec(defaults) {
_super.apply(this, arguments);
}
StyleRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Style", "styleAttr", "Style", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("URLStyle", "uRLStyleAttr", "URLStyle", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
StyleRec.init();
return StyleRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.StyleRec = StyleRec;

});
define("OutSystemsMaps.model$StyleList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$StyleRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var StyleList = (function (_super) {
__extends(StyleList, _super);
function StyleList(defaults) {
_super.apply(this, arguments);
}
StyleList.itemType = OutSystemsMapsModel.StyleRec;
return StyleList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.StyleList = StyleList;

});
define("OutSystemsMaps.model$ErrorMessageRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var ErrorMessageRec = (function (_super) {
__extends(ErrorMessageRec, _super);
function ErrorMessageRec(defaults) {
_super.apply(this, arguments);
}
ErrorMessageRec.attributesToDeclare = function () {
return [
this.attr("Code", "codeAttr", "code", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Message", "messageAttr", "message", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ErrorMessageRec.init();
return ErrorMessageRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.ErrorMessageRec = ErrorMessageRec;

});
define("OutSystemsMaps.model$ErrorMessageRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$ErrorMessageRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var ErrorMessageRecord = (function (_super) {
__extends(ErrorMessageRecord, _super);
function ErrorMessageRecord(defaults) {
_super.apply(this, arguments);
}
ErrorMessageRecord.attributesToDeclare = function () {
return [
this.attr("ErrorMessage", "errorMessageAttr", "ErrorMessage", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.ErrorMessageRec());
}, true, OutSystemsMapsModel.ErrorMessageRec)
].concat(_super.attributesToDeclare.call(this));
};
ErrorMessageRecord.fromStructure = function (str) {
return new ErrorMessageRecord(new ErrorMessageRecord.RecordClass({
errorMessageAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ErrorMessageRecord._isAnonymousRecord = true;
ErrorMessageRecord.UniqueId = "098b5b5f-4bf1-9fe0-ddbe-136503d3bd5a";
ErrorMessageRecord.init();
return ErrorMessageRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.ErrorMessageRecord = ErrorMessageRecord;

});
define("OutSystemsMaps.model$ErrorMessageRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$ErrorMessageRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var ErrorMessageRecordList = (function (_super) {
__extends(ErrorMessageRecordList, _super);
function ErrorMessageRecordList(defaults) {
_super.apply(this, arguments);
}
ErrorMessageRecordList.itemType = OutSystemsMapsModel.ErrorMessageRecord;
return ErrorMessageRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.ErrorMessageRecordList = ErrorMessageRecordList;

});
define("OutSystemsMaps.model$ShapeEventTriggeredRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var ShapeEventTriggeredRec = (function (_super) {
__extends(ShapeEventTriggeredRec, _super);
function ShapeEventTriggeredRec(defaults) {
_super.apply(this, arguments);
}
ShapeEventTriggeredRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ShapeEventTriggeredRec.fromStructure = function (str) {
return new ShapeEventTriggeredRec(new ShapeEventTriggeredRec.RecordClass({
idAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ShapeEventTriggeredRec.init();
return ShapeEventTriggeredRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.ShapeEventTriggeredRec = ShapeEventTriggeredRec;

});
define("OutSystemsMaps.model$ShapeEventTriggeredRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$ShapeEventTriggeredRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var ShapeEventTriggeredRecord = (function (_super) {
__extends(ShapeEventTriggeredRecord, _super);
function ShapeEventTriggeredRecord(defaults) {
_super.apply(this, arguments);
}
ShapeEventTriggeredRecord.attributesToDeclare = function () {
return [
this.attr("ShapeEventTriggered", "shapeEventTriggeredAttr", "ShapeEventTriggered", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.ShapeEventTriggeredRec());
}, true, OutSystemsMapsModel.ShapeEventTriggeredRec)
].concat(_super.attributesToDeclare.call(this));
};
ShapeEventTriggeredRecord.fromStructure = function (str) {
return new ShapeEventTriggeredRecord(new ShapeEventTriggeredRecord.RecordClass({
shapeEventTriggeredAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ShapeEventTriggeredRecord._isAnonymousRecord = true;
ShapeEventTriggeredRecord.UniqueId = "098c4690-6c1c-0c7e-7b39-f1210fb64f78";
ShapeEventTriggeredRecord.init();
return ShapeEventTriggeredRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.ShapeEventTriggeredRecord = ShapeEventTriggeredRecord;

});
define("OutSystemsMaps.model$MarkerTypeRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var MarkerTypeRec = (function (_super) {
__extends(MarkerTypeRec, _super);
function MarkerTypeRec(defaults) {
_super.apply(this, arguments);
}
MarkerTypeRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
MarkerTypeRec.fromStructure = function (str) {
return new MarkerTypeRec(new MarkerTypeRec.RecordClass({
idAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MarkerTypeRec.init();
return MarkerTypeRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.MarkerTypeRec = MarkerTypeRec;

});
define("OutSystemsMaps.model$MarkerTypeRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$MarkerTypeRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var MarkerTypeRecord = (function (_super) {
__extends(MarkerTypeRecord, _super);
function MarkerTypeRecord(defaults) {
_super.apply(this, arguments);
}
MarkerTypeRecord.attributesToDeclare = function () {
return [
this.attr("MarkerType", "markerTypeAttr", "MarkerType", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.MarkerTypeRec());
}, true, OutSystemsMapsModel.MarkerTypeRec)
].concat(_super.attributesToDeclare.call(this));
};
MarkerTypeRecord.fromStructure = function (str) {
return new MarkerTypeRecord(new MarkerTypeRecord.RecordClass({
markerTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MarkerTypeRecord._isAnonymousRecord = true;
MarkerTypeRecord.UniqueId = "0b102c45-3446-be3e-bcb7-93be90d6b209";
MarkerTypeRecord.init();
return MarkerTypeRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.MarkerTypeRecord = MarkerTypeRecord;

});
define("OutSystemsMaps.model$MapTypeRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var MapTypeRec = (function (_super) {
__extends(MapTypeRec, _super);
function MapTypeRec(defaults) {
_super.apply(this, arguments);
}
MapTypeRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
MapTypeRec.fromStructure = function (str) {
return new MapTypeRec(new MapTypeRec.RecordClass({
idAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MapTypeRec.init();
return MapTypeRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.MapTypeRec = MapTypeRec;

});
define("OutSystemsMaps.model$CoordinatesRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var CoordinatesRec = (function (_super) {
__extends(CoordinatesRec, _super);
function CoordinatesRec(defaults) {
_super.apply(this, arguments);
}
CoordinatesRec.attributesToDeclare = function () {
return [
this.attr("Lat", "latAttr", "Lat", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("Lng", "lngAttr", "Lng", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
CoordinatesRec.init();
return CoordinatesRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.CoordinatesRec = CoordinatesRec;

});
define("OutSystemsMaps.model$LogTypeRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var LogTypeRec = (function (_super) {
__extends(LogTypeRec, _super);
function LogTypeRec(defaults) {
_super.apply(this, arguments);
}
LogTypeRec.attributesToDeclare = function () {
return [
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
LogTypeRec.init();
return LogTypeRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.LogTypeRec = LogTypeRec;

});
define("OutSystemsMaps.model$FillRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var FillRec = (function (_super) {
__extends(FillRec, _super);
function FillRec(defaults) {
_super.apply(this, arguments);
}
FillRec.attributesToDeclare = function () {
return [
this.attr("Color", "colorAttr", "Color", false, false, OS.Types.Text, function () {
return "#000000";
}, true), 
this.attr("Opacity", "opacityAttr", "Opacity", false, false, OS.Types.Decimal, function () {
return OS.BuiltinFunctions.integerToDecimal(1);
}, true)
].concat(_super.attributesToDeclare.call(this));
};
FillRec.init();
return FillRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.FillRec = FillRec;

});
define("OutSystemsMaps.model$OptionalShapeConfigsRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$StrokeRec", "OutSystemsMaps.model$FillRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var OptionalShapeConfigsRec = (function (_super) {
__extends(OptionalShapeConfigsRec, _super);
function OptionalShapeConfigsRec(defaults) {
_super.apply(this, arguments);
}
OptionalShapeConfigsRec.attributesToDeclare = function () {
return [
this.attr("AllowDrag", "allowDragAttr", "AllowDrag", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("AllowEdit", "allowEditAttr", "AllowEdit", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("Stroke", "strokeAttr", "Stroke", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.StrokeRec());
}, true, OutSystemsMapsModel.StrokeRec), 
this.attr("Fill", "fillAttr", "Fill", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.FillRec());
}, true, OutSystemsMapsModel.FillRec)
].concat(_super.attributesToDeclare.call(this));
};
OptionalShapeConfigsRec.init();
return OptionalShapeConfigsRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.OptionalShapeConfigsRec = OptionalShapeConfigsRec;

});
define("OutSystemsMaps.model$OptionalShapeConfigsRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$OptionalShapeConfigsRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var OptionalShapeConfigsRecord = (function (_super) {
__extends(OptionalShapeConfigsRecord, _super);
function OptionalShapeConfigsRecord(defaults) {
_super.apply(this, arguments);
}
OptionalShapeConfigsRecord.attributesToDeclare = function () {
return [
this.attr("OptionalShapeConfigs", "optionalShapeConfigsAttr", "OptionalShapeConfigs", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.OptionalShapeConfigsRec());
}, true, OutSystemsMapsModel.OptionalShapeConfigsRec)
].concat(_super.attributesToDeclare.call(this));
};
OptionalShapeConfigsRecord.fromStructure = function (str) {
return new OptionalShapeConfigsRecord(new OptionalShapeConfigsRecord.RecordClass({
optionalShapeConfigsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
OptionalShapeConfigsRecord._isAnonymousRecord = true;
OptionalShapeConfigsRecord.UniqueId = "f413938d-99b2-f109-b9b5-1d646a4937af";
OptionalShapeConfigsRecord.init();
return OptionalShapeConfigsRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.OptionalShapeConfigsRecord = OptionalShapeConfigsRecord;

});
define("OutSystemsMaps.model$OptionalShapeConfigsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$OptionalShapeConfigsRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var OptionalShapeConfigsRecordList = (function (_super) {
__extends(OptionalShapeConfigsRecordList, _super);
function OptionalShapeConfigsRecordList(defaults) {
_super.apply(this, arguments);
}
OptionalShapeConfigsRecordList.itemType = OutSystemsMapsModel.OptionalShapeConfigsRecord;
return OptionalShapeConfigsRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.OptionalShapeConfigsRecordList = OptionalShapeConfigsRecordList;

});
define("OutSystemsMaps.model$ErrorMessageList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$ErrorMessageRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var ErrorMessageList = (function (_super) {
__extends(ErrorMessageList, _super);
function ErrorMessageList(defaults) {
_super.apply(this, arguments);
}
ErrorMessageList.itemType = OutSystemsMapsModel.ErrorMessageRec;
return ErrorMessageList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.ErrorMessageList = ErrorMessageList;

});
define("OutSystemsMaps.model$Internal_to_provider_marker_configsRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var Internal_to_provider_marker_configsRec = (function (_super) {
__extends(Internal_to_provider_marker_configsRec, _super);
function Internal_to_provider_marker_configsRec(defaults) {
_super.apply(this, arguments);
}
Internal_to_provider_marker_configsRec.attributesToDeclare = function () {
return [
this.attr("location", "locationAttr", "location", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("iconUrl", "iconUrlAttr", "iconUrl", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("title", "titleAttr", "title", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("allowDrag", "allowDragAttr", "allowDrag", true, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Internal_to_provider_marker_configsRec.init();
return Internal_to_provider_marker_configsRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.Internal_to_provider_marker_configsRec = Internal_to_provider_marker_configsRec;

});
define("OutSystemsMaps.model$Internal__Marker_ConfigsRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$Internal_to_provider_marker_configsRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var Internal__Marker_ConfigsRec = (function (_super) {
__extends(Internal__Marker_ConfigsRec, _super);
function Internal__Marker_ConfigsRec(defaults) {
_super.apply(this, arguments);
}
Internal__Marker_ConfigsRec.attributesToDeclare = function () {
return [
this.attr("Internal_to_provider_marker_configs", "internal_to_provider_marker_configsAttr", "Internal_to_provider_marker_configs", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.Internal_to_provider_marker_configsRec());
}, true, OutSystemsMapsModel.Internal_to_provider_marker_configsRec), 
this.attr("UniqueId", "uniqueIdAttr", "UniqueId", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Internal__Marker_ConfigsRec.init();
return Internal__Marker_ConfigsRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.Internal__Marker_ConfigsRec = Internal__Marker_ConfigsRec;

});
define("OutSystemsMaps.model$Internal__Marker_ConfigsList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$Internal__Marker_ConfigsRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var Internal__Marker_ConfigsList = (function (_super) {
__extends(Internal__Marker_ConfigsList, _super);
function Internal__Marker_ConfigsList(defaults) {
_super.apply(this, arguments);
}
Internal__Marker_ConfigsList.itemType = OutSystemsMapsModel.Internal__Marker_ConfigsRec;
return Internal__Marker_ConfigsList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.Internal__Marker_ConfigsList = Internal__Marker_ConfigsList;

});
define("OutSystemsMaps.model$MarkerEventRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var MarkerEventRec = (function (_super) {
__extends(MarkerEventRec, _super);
function MarkerEventRec(defaults) {
_super.apply(this, arguments);
}
MarkerEventRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
MarkerEventRec.fromStructure = function (str) {
return new MarkerEventRec(new MarkerEventRec.RecordClass({
idAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MarkerEventRec.init();
return MarkerEventRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.MarkerEventRec = MarkerEventRec;

});
define("OutSystemsMaps.model$MarkerEventList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$MarkerEventRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var MarkerEventList = (function (_super) {
__extends(MarkerEventList, _super);
function MarkerEventList(defaults) {
_super.apply(this, arguments);
}
MarkerEventList.itemType = OutSystemsMapsModel.MarkerEventRec;
return MarkerEventList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.MarkerEventList = MarkerEventList;

});
define("OutSystemsMaps.model$FillRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$FillRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var FillRecord = (function (_super) {
__extends(FillRecord, _super);
function FillRecord(defaults) {
_super.apply(this, arguments);
}
FillRecord.attributesToDeclare = function () {
return [
this.attr("Fill", "fillAttr", "Fill", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.FillRec());
}, true, OutSystemsMapsModel.FillRec)
].concat(_super.attributesToDeclare.call(this));
};
FillRecord.fromStructure = function (str) {
return new FillRecord(new FillRecord.RecordClass({
fillAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
FillRecord._isAnonymousRecord = true;
FillRecord.UniqueId = "1b25d6a0-78a2-b54d-c46a-cf86c7e61fc3";
FillRecord.init();
return FillRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.FillRecord = FillRecord;

});
define("OutSystemsMaps.model$MarkerTypeList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$MarkerTypeRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var MarkerTypeList = (function (_super) {
__extends(MarkerTypeList, _super);
function MarkerTypeList(defaults) {
_super.apply(this, arguments);
}
MarkerTypeList.itemType = OutSystemsMapsModel.MarkerTypeRec;
return MarkerTypeList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.MarkerTypeList = MarkerTypeList;

});
define("OutSystemsMaps.model$StyleRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$StyleRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var StyleRecord = (function (_super) {
__extends(StyleRecord, _super);
function StyleRecord(defaults) {
_super.apply(this, arguments);
}
StyleRecord.attributesToDeclare = function () {
return [
this.attr("Style", "styleAttr", "Style", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.StyleRec());
}, true, OutSystemsMapsModel.StyleRec)
].concat(_super.attributesToDeclare.call(this));
};
StyleRecord.fromStructure = function (str) {
return new StyleRecord(new StyleRecord.RecordClass({
styleAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
StyleRecord._isAnonymousRecord = true;
StyleRecord.UniqueId = "97843bcb-5214-6db1-681d-fc816cff70a0";
StyleRecord.init();
return StyleRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.StyleRecord = StyleRecord;

});
define("OutSystemsMaps.model$StyleRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$StyleRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var StyleRecordList = (function (_super) {
__extends(StyleRecordList, _super);
function StyleRecordList(defaults) {
_super.apply(this, arguments);
}
StyleRecordList.itemType = OutSystemsMapsModel.StyleRecord;
return StyleRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.StyleRecordList = StyleRecordList;

});
define("OutSystemsMaps.model$MarkerTypeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$MarkerTypeRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var MarkerTypeRecordList = (function (_super) {
__extends(MarkerTypeRecordList, _super);
function MarkerTypeRecordList(defaults) {
_super.apply(this, arguments);
}
MarkerTypeRecordList.itemType = OutSystemsMapsModel.MarkerTypeRecord;
return MarkerTypeRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.MarkerTypeRecordList = MarkerTypeRecordList;

});
define("OutSystemsMaps.model$OffsetRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var OffsetRec = (function (_super) {
__extends(OffsetRec, _super);
function OffsetRec(defaults) {
_super.apply(this, arguments);
}
OffsetRec.attributesToDeclare = function () {
return [
this.attr("OffsetX", "offsetXAttr", "offsetX", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("OffsetY", "offsetYAttr", "offsetY", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
OffsetRec.init();
return OffsetRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.OffsetRec = OffsetRec;

});
define("OutSystemsMaps.model$Internal_to_provider_configsRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$OffsetRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var Internal_to_provider_configsRec = (function (_super) {
__extends(Internal_to_provider_configsRec, _super);
function Internal_to_provider_configsRec(defaults) {
_super.apply(this, arguments);
}
Internal_to_provider_configsRec.attributesToDeclare = function () {
return [
this.attr("advancedFormat", "advancedFormatAttr", "advancedFormat", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("apiKey", "apiKeyAttr", "apiKey", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("center", "centerAttr", "center", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("height", "heightAttr", "height", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("offset", "offsetAttr", "offset", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.OffsetRec());
}, true, OutSystemsMapsModel.OffsetRec), 
this.attr("showTraffic", "showTrafficAttr", "showTraffic", true, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("staticMap", "staticMapAttr", "staticMap", true, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("style", "styleAttr", "style", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("type", "typeAttr", "type", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("zoom", "zoomAttr", "zoom", true, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Internal_to_provider_configsRec.init();
return Internal_to_provider_configsRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.Internal_to_provider_configsRec = Internal_to_provider_configsRec;

});
define("OutSystemsMaps.model$Internal_to_provider_configsRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$Internal_to_provider_configsRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var Internal_to_provider_configsRecord = (function (_super) {
__extends(Internal_to_provider_configsRecord, _super);
function Internal_to_provider_configsRecord(defaults) {
_super.apply(this, arguments);
}
Internal_to_provider_configsRecord.attributesToDeclare = function () {
return [
this.attr("Internal_to_provider_configs", "internal_to_provider_configsAttr", "Internal_to_provider_configs", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.Internal_to_provider_configsRec());
}, true, OutSystemsMapsModel.Internal_to_provider_configsRec)
].concat(_super.attributesToDeclare.call(this));
};
Internal_to_provider_configsRecord.fromStructure = function (str) {
return new Internal_to_provider_configsRecord(new Internal_to_provider_configsRecord.RecordClass({
internal_to_provider_configsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
Internal_to_provider_configsRecord._isAnonymousRecord = true;
Internal_to_provider_configsRecord.UniqueId = "3f581e27-c2f7-2d4f-78b5-674dc475102b";
Internal_to_provider_configsRecord.init();
return Internal_to_provider_configsRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.Internal_to_provider_configsRecord = Internal_to_provider_configsRecord;

});
define("OutSystemsMaps.model$Internal_to_provider_configsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$Internal_to_provider_configsRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var Internal_to_provider_configsRecordList = (function (_super) {
__extends(Internal_to_provider_configsRecordList, _super);
function Internal_to_provider_configsRecordList(defaults) {
_super.apply(this, arguments);
}
Internal_to_provider_configsRecordList.itemType = OutSystemsMapsModel.Internal_to_provider_configsRecord;
return Internal_to_provider_configsRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.Internal_to_provider_configsRecordList = Internal_to_provider_configsRecordList;

});
define("OutSystemsMaps.model$MapEventRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var MapEventRec = (function (_super) {
__extends(MapEventRec, _super);
function MapEventRec(defaults) {
_super.apply(this, arguments);
}
MapEventRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
MapEventRec.fromStructure = function (str) {
return new MapEventRec(new MapEventRec.RecordClass({
idAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MapEventRec.init();
return MapEventRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.MapEventRec = MapEventRec;

});
define("OutSystemsMaps.model$MapEventRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$MapEventRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var MapEventRecord = (function (_super) {
__extends(MapEventRecord, _super);
function MapEventRecord(defaults) {
_super.apply(this, arguments);
}
MapEventRecord.attributesToDeclare = function () {
return [
this.attr("MapEvent", "mapEventAttr", "MapEvent", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.MapEventRec());
}, true, OutSystemsMapsModel.MapEventRec)
].concat(_super.attributesToDeclare.call(this));
};
MapEventRecord.fromStructure = function (str) {
return new MapEventRecord(new MapEventRecord.RecordClass({
mapEventAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MapEventRecord._isAnonymousRecord = true;
MapEventRecord.UniqueId = "227974ef-92f7-b64b-18b9-5570fef9abe3";
MapEventRecord.init();
return MapEventRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.MapEventRecord = MapEventRecord;

});
define("OutSystemsMaps.model$Internal_to_provider_configsList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$Internal_to_provider_configsRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var Internal_to_provider_configsList = (function (_super) {
__extends(Internal_to_provider_configsList, _super);
function Internal_to_provider_configsList(defaults) {
_super.apply(this, arguments);
}
Internal_to_provider_configsList.itemType = OutSystemsMapsModel.Internal_to_provider_configsRec;
return Internal_to_provider_configsList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.Internal_to_provider_configsList = Internal_to_provider_configsList;

});
define("OutSystemsMaps.model$DirectionLegsRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$CoordinatesRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var DirectionLegsRec = (function (_super) {
__extends(DirectionLegsRec, _super);
function DirectionLegsRec(defaults) {
_super.apply(this, arguments);
}
DirectionLegsRec.attributesToDeclare = function () {
return [
this.attr("Origin", "originAttr", "origin", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.CoordinatesRec());
}, true, OutSystemsMapsModel.CoordinatesRec), 
this.attr("Destination", "destinationAttr", "destination", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.CoordinatesRec());
}, true, OutSystemsMapsModel.CoordinatesRec), 
this.attr("Distance", "distanceAttr", "distance", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Duration", "durationAttr", "duration", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DirectionLegsRec.init();
return DirectionLegsRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.DirectionLegsRec = DirectionLegsRec;

});
define("OutSystemsMaps.model$DirectionLegsList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$DirectionLegsRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var DirectionLegsList = (function (_super) {
__extends(DirectionLegsList, _super);
function DirectionLegsList(defaults) {
_super.apply(this, arguments);
}
DirectionLegsList.itemType = OutSystemsMapsModel.DirectionLegsRec;
return DirectionLegsList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.DirectionLegsList = DirectionLegsList;

});
define("OutSystemsMaps.model$OptionalPolylineConfigsRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$StrokeRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var OptionalPolylineConfigsRec = (function (_super) {
__extends(OptionalPolylineConfigsRec, _super);
function OptionalPolylineConfigsRec(defaults) {
_super.apply(this, arguments);
}
OptionalPolylineConfigsRec.attributesToDeclare = function () {
return [
this.attr("AllowDrag", "allowDragAttr", "AllowDrag", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("AllowEdit", "allowEditAttr", "AllowEdit", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("Stroke", "strokeAttr", "Stroke", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.StrokeRec());
}, true, OutSystemsMapsModel.StrokeRec)
].concat(_super.attributesToDeclare.call(this));
};
OptionalPolylineConfigsRec.init();
return OptionalPolylineConfigsRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.OptionalPolylineConfigsRec = OptionalPolylineConfigsRec;

});
define("OutSystemsMaps.model$OptionalPolylineConfigsRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$OptionalPolylineConfigsRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var OptionalPolylineConfigsRecord = (function (_super) {
__extends(OptionalPolylineConfigsRecord, _super);
function OptionalPolylineConfigsRecord(defaults) {
_super.apply(this, arguments);
}
OptionalPolylineConfigsRecord.attributesToDeclare = function () {
return [
this.attr("OptionalPolylineConfigs", "optionalPolylineConfigsAttr", "OptionalPolylineConfigs", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.OptionalPolylineConfigsRec());
}, true, OutSystemsMapsModel.OptionalPolylineConfigsRec)
].concat(_super.attributesToDeclare.call(this));
};
OptionalPolylineConfigsRecord.fromStructure = function (str) {
return new OptionalPolylineConfigsRecord(new OptionalPolylineConfigsRecord.RecordClass({
optionalPolylineConfigsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
OptionalPolylineConfigsRecord._isAnonymousRecord = true;
OptionalPolylineConfigsRecord.UniqueId = "3836c649-4dc0-1a6d-ca1b-f0597beb32bb";
OptionalPolylineConfigsRecord.init();
return OptionalPolylineConfigsRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.OptionalPolylineConfigsRecord = OptionalPolylineConfigsRecord;

});
define("OutSystemsMaps.model$OptionalPolylineConfigsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$OptionalPolylineConfigsRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var OptionalPolylineConfigsRecordList = (function (_super) {
__extends(OptionalPolylineConfigsRecordList, _super);
function OptionalPolylineConfigsRecordList(defaults) {
_super.apply(this, arguments);
}
OptionalPolylineConfigsRecordList.itemType = OutSystemsMapsModel.OptionalPolylineConfigsRecord;
return OptionalPolylineConfigsRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.OptionalPolylineConfigsRecordList = OptionalPolylineConfigsRecordList;

});
define("OutSystemsMaps.model$MapEventTriggeredRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var MapEventTriggeredRec = (function (_super) {
__extends(MapEventTriggeredRec, _super);
function MapEventTriggeredRec(defaults) {
_super.apply(this, arguments);
}
MapEventTriggeredRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
MapEventTriggeredRec.fromStructure = function (str) {
return new MapEventTriggeredRec(new MapEventTriggeredRec.RecordClass({
idAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MapEventTriggeredRec.init();
return MapEventTriggeredRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.MapEventTriggeredRec = MapEventTriggeredRec;

});
define("OutSystemsMaps.model$MarkerEventRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$MarkerEventRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var MarkerEventRecord = (function (_super) {
__extends(MarkerEventRecord, _super);
function MarkerEventRecord(defaults) {
_super.apply(this, arguments);
}
MarkerEventRecord.attributesToDeclare = function () {
return [
this.attr("MarkerEvent", "markerEventAttr", "MarkerEvent", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.MarkerEventRec());
}, true, OutSystemsMapsModel.MarkerEventRec)
].concat(_super.attributesToDeclare.call(this));
};
MarkerEventRecord.fromStructure = function (str) {
return new MarkerEventRecord(new MarkerEventRecord.RecordClass({
markerEventAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MarkerEventRecord._isAnonymousRecord = true;
MarkerEventRecord.UniqueId = "2d18bab1-b72b-271d-c15d-da249e871290";
MarkerEventRecord.init();
return MarkerEventRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.MarkerEventRecord = MarkerEventRecord;

});
define("OutSystemsMaps.model$StaticMarkerRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var StaticMarkerRec = (function (_super) {
__extends(StaticMarkerRec, _super);
function StaticMarkerRec(defaults) {
_super.apply(this, arguments);
}
StaticMarkerRec.attributesToDeclare = function () {
return [
this.attr("Location", "locationAttr", "location", false, false, OS.Types.Text, function () {
return "42.3517926,-71.0467845";
}, true), 
this.attr("IconURL", "iconURLAttr", "iconUrl", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AdvancedFormat", "advancedFormatAttr", "advancedFormat", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
StaticMarkerRec.init();
return StaticMarkerRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.StaticMarkerRec = StaticMarkerRec;

});
define("OutSystemsMaps.model$StaticMarkerRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$StaticMarkerRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var StaticMarkerRecord = (function (_super) {
__extends(StaticMarkerRecord, _super);
function StaticMarkerRecord(defaults) {
_super.apply(this, arguments);
}
StaticMarkerRecord.attributesToDeclare = function () {
return [
this.attr("StaticMarker", "staticMarkerAttr", "StaticMarker", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.StaticMarkerRec());
}, true, OutSystemsMapsModel.StaticMarkerRec)
].concat(_super.attributesToDeclare.call(this));
};
StaticMarkerRecord.fromStructure = function (str) {
return new StaticMarkerRecord(new StaticMarkerRecord.RecordClass({
staticMarkerAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
StaticMarkerRecord._isAnonymousRecord = true;
StaticMarkerRecord.UniqueId = "2e794e99-5064-8fb7-8174-0aa3223ba10d";
StaticMarkerRecord.init();
return StaticMarkerRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.StaticMarkerRecord = StaticMarkerRecord;

});
define("OutSystemsMaps.model$Internal_Shape_ConfigsRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$Internal_to_provider_shape_configsRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var Internal_Shape_ConfigsRec = (function (_super) {
__extends(Internal_Shape_ConfigsRec, _super);
function Internal_Shape_ConfigsRec(defaults) {
_super.apply(this, arguments);
}
Internal_Shape_ConfigsRec.attributesToDeclare = function () {
return [
this.attr("Internal_to_provider_shape_configs", "internal_to_provider_shape_configsAttr", "Internal_to_provider_shape_configs", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.Internal_to_provider_shape_configsRec());
}, true, OutSystemsMapsModel.Internal_to_provider_shape_configsRec), 
this.attr("UniqueId", "uniqueIdAttr", "UniqueId", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Internal_Shape_ConfigsRec.init();
return Internal_Shape_ConfigsRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.Internal_Shape_ConfigsRec = Internal_Shape_ConfigsRec;

});
define("OutSystemsMaps.model$ShapeTypeRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var ShapeTypeRec = (function (_super) {
__extends(ShapeTypeRec, _super);
function ShapeTypeRec(defaults) {
_super.apply(this, arguments);
}
ShapeTypeRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ShapeTypeRec.fromStructure = function (str) {
return new ShapeTypeRec(new ShapeTypeRec.RecordClass({
idAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ShapeTypeRec.init();
return ShapeTypeRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.ShapeTypeRec = ShapeTypeRec;

});
define("OutSystemsMaps.model$ShapeTypeRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$ShapeTypeRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var ShapeTypeRecord = (function (_super) {
__extends(ShapeTypeRecord, _super);
function ShapeTypeRecord(defaults) {
_super.apply(this, arguments);
}
ShapeTypeRecord.attributesToDeclare = function () {
return [
this.attr("ShapeType", "shapeTypeAttr", "ShapeType", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.ShapeTypeRec());
}, true, OutSystemsMapsModel.ShapeTypeRec)
].concat(_super.attributesToDeclare.call(this));
};
ShapeTypeRecord.fromStructure = function (str) {
return new ShapeTypeRecord(new ShapeTypeRecord.RecordClass({
shapeTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ShapeTypeRecord._isAnonymousRecord = true;
ShapeTypeRecord.UniqueId = "3201d138-4957-542d-ebf3-cb5808f51144";
ShapeTypeRecord.init();
return ShapeTypeRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.ShapeTypeRecord = ShapeTypeRecord;

});
define("OutSystemsMaps.model$ZoomRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var ZoomRec = (function (_super) {
__extends(ZoomRec, _super);
function ZoomRec(defaults) {
_super.apply(this, arguments);
}
ZoomRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Label", "labelAttr", "Label", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Zoom", "zoomAttr", "Zoom", true, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ZoomRec.init();
return ZoomRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.ZoomRec = ZoomRec;

});
define("OutSystemsMaps.model$ZoomList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$ZoomRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var ZoomList = (function (_super) {
__extends(ZoomList, _super);
function ZoomList(defaults) {
_super.apply(this, arguments);
}
ZoomList.itemType = OutSystemsMapsModel.ZoomRec;
return ZoomList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.ZoomList = ZoomList;

});
define("OutSystemsMaps.model$MapErrorsRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var MapErrorsRec = (function (_super) {
__extends(MapErrorsRec, _super);
function MapErrorsRec(defaults) {
_super.apply(this, arguments);
}
MapErrorsRec.attributesToDeclare = function () {
return [
this.attr("Code", "codeAttr", "Code", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Message", "messageAttr", "Message", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
MapErrorsRec.init();
return MapErrorsRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.MapErrorsRec = MapErrorsRec;

});
define("OutSystemsMaps.model$MapErrorsList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$MapErrorsRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var MapErrorsList = (function (_super) {
__extends(MapErrorsList, _super);
function MapErrorsList(defaults) {
_super.apply(this, arguments);
}
MapErrorsList.itemType = OutSystemsMapsModel.MapErrorsRec;
return MapErrorsList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.MapErrorsList = MapErrorsList;

});
define("OutSystemsMaps.model$OffsetRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$OffsetRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var OffsetRecord = (function (_super) {
__extends(OffsetRecord, _super);
function OffsetRecord(defaults) {
_super.apply(this, arguments);
}
OffsetRecord.attributesToDeclare = function () {
return [
this.attr("Offset", "offsetAttr", "Offset", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.OffsetRec());
}, true, OutSystemsMapsModel.OffsetRec)
].concat(_super.attributesToDeclare.call(this));
};
OffsetRecord.fromStructure = function (str) {
return new OffsetRecord(new OffsetRecord.RecordClass({
offsetAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
OffsetRecord._isAnonymousRecord = true;
OffsetRecord.UniqueId = "a3e0d021-78b0-78a9-60ae-427dd1751cbc";
OffsetRecord.init();
return OffsetRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.OffsetRecord = OffsetRecord;

});
define("OutSystemsMaps.model$OffsetRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$OffsetRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var OffsetRecordList = (function (_super) {
__extends(OffsetRecordList, _super);
function OffsetRecordList(defaults) {
_super.apply(this, arguments);
}
OffsetRecordList.itemType = OutSystemsMapsModel.OffsetRecord;
return OffsetRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.OffsetRecordList = OffsetRecordList;

});
define("OutSystemsMaps.model$Internal__Marker_ConfigsRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$Internal__Marker_ConfigsRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var Internal__Marker_ConfigsRecord = (function (_super) {
__extends(Internal__Marker_ConfigsRecord, _super);
function Internal__Marker_ConfigsRecord(defaults) {
_super.apply(this, arguments);
}
Internal__Marker_ConfigsRecord.attributesToDeclare = function () {
return [
this.attr("Internal__Marker_Configs", "internal__Marker_ConfigsAttr", "Internal__Marker_Configs", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.Internal__Marker_ConfigsRec());
}, true, OutSystemsMapsModel.Internal__Marker_ConfigsRec)
].concat(_super.attributesToDeclare.call(this));
};
Internal__Marker_ConfigsRecord.fromStructure = function (str) {
return new Internal__Marker_ConfigsRecord(new Internal__Marker_ConfigsRecord.RecordClass({
internal__Marker_ConfigsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
Internal__Marker_ConfigsRecord._isAnonymousRecord = true;
Internal__Marker_ConfigsRecord.UniqueId = "7f3fab59-9cac-29ad-b40d-23996cbe5a3b";
Internal__Marker_ConfigsRecord.init();
return Internal__Marker_ConfigsRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.Internal__Marker_ConfigsRecord = Internal__Marker_ConfigsRecord;

});
define("OutSystemsMaps.model$Internal__Marker_ConfigsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$Internal__Marker_ConfigsRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var Internal__Marker_ConfigsRecordList = (function (_super) {
__extends(Internal__Marker_ConfigsRecordList, _super);
function Internal__Marker_ConfigsRecordList(defaults) {
_super.apply(this, arguments);
}
Internal__Marker_ConfigsRecordList.itemType = OutSystemsMapsModel.Internal__Marker_ConfigsRecord;
return Internal__Marker_ConfigsRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.Internal__Marker_ConfigsRecordList = Internal__Marker_ConfigsRecordList;

});
define("OutSystemsMaps.model$MapErrorsRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$MapErrorsRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var MapErrorsRecord = (function (_super) {
__extends(MapErrorsRecord, _super);
function MapErrorsRecord(defaults) {
_super.apply(this, arguments);
}
MapErrorsRecord.attributesToDeclare = function () {
return [
this.attr("MapErrors", "mapErrorsAttr", "MapErrors", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.MapErrorsRec());
}, true, OutSystemsMapsModel.MapErrorsRec)
].concat(_super.attributesToDeclare.call(this));
};
MapErrorsRecord.fromStructure = function (str) {
return new MapErrorsRecord(new MapErrorsRecord.RecordClass({
mapErrorsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MapErrorsRecord._isAnonymousRecord = true;
MapErrorsRecord.UniqueId = "3d151c63-adf1-37bd-3c85-eaa462bbbe0c";
MapErrorsRecord.init();
return MapErrorsRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.MapErrorsRecord = MapErrorsRecord;

});
define("OutSystemsMaps.model$PopupEventRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var PopupEventRec = (function (_super) {
__extends(PopupEventRec, _super);
function PopupEventRec(defaults) {
_super.apply(this, arguments);
}
PopupEventRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PopupEventRec.fromStructure = function (str) {
return new PopupEventRec(new PopupEventRec.RecordClass({
idAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PopupEventRec.init();
return PopupEventRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.PopupEventRec = PopupEventRec;

});
define("OutSystemsMaps.model$PopupEventList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$PopupEventRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var PopupEventList = (function (_super) {
__extends(PopupEventList, _super);
function PopupEventList(defaults) {
_super.apply(this, arguments);
}
PopupEventList.itemType = OutSystemsMapsModel.PopupEventRec;
return PopupEventList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.PopupEventList = PopupEventList;

});
define("OutSystemsMaps.model$PopupEventRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$PopupEventRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var PopupEventRecord = (function (_super) {
__extends(PopupEventRecord, _super);
function PopupEventRecord(defaults) {
_super.apply(this, arguments);
}
PopupEventRecord.attributesToDeclare = function () {
return [
this.attr("PopupEvent", "popupEventAttr", "PopupEvent", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.PopupEventRec());
}, true, OutSystemsMapsModel.PopupEventRec)
].concat(_super.attributesToDeclare.call(this));
};
PopupEventRecord.fromStructure = function (str) {
return new PopupEventRecord(new PopupEventRecord.RecordClass({
popupEventAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PopupEventRecord._isAnonymousRecord = true;
PopupEventRecord.UniqueId = "b426a0d7-aa8f-7cff-1977-eb04da864b0f";
PopupEventRecord.init();
return PopupEventRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.PopupEventRecord = PopupEventRecord;

});
define("OutSystemsMaps.model$PopupEventRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$PopupEventRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var PopupEventRecordList = (function (_super) {
__extends(PopupEventRecordList, _super);
function PopupEventRecordList(defaults) {
_super.apply(this, arguments);
}
PopupEventRecordList.itemType = OutSystemsMapsModel.PopupEventRecord;
return PopupEventRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.PopupEventRecordList = PopupEventRecordList;

});
define("OutSystemsMaps.model$Internal_Shape_ConfigsList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$Internal_Shape_ConfigsRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var Internal_Shape_ConfigsList = (function (_super) {
__extends(Internal_Shape_ConfigsList, _super);
function Internal_Shape_ConfigsList(defaults) {
_super.apply(this, arguments);
}
Internal_Shape_ConfigsList.itemType = OutSystemsMapsModel.Internal_Shape_ConfigsRec;
return Internal_Shape_ConfigsList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.Internal_Shape_ConfigsList = Internal_Shape_ConfigsList;

});
define("OutSystemsMaps.model$ShapeEventTriggeredRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$ShapeEventTriggeredRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var ShapeEventTriggeredRecordList = (function (_super) {
__extends(ShapeEventTriggeredRecordList, _super);
function ShapeEventTriggeredRecordList(defaults) {
_super.apply(this, arguments);
}
ShapeEventTriggeredRecordList.itemType = OutSystemsMapsModel.ShapeEventTriggeredRecord;
return ShapeEventTriggeredRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.ShapeEventTriggeredRecordList = ShapeEventTriggeredRecordList;

});
define("OutSystemsMaps.model$OptionalPolygonConfigsRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$StrokeRec", "OutSystemsMaps.model$FillRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var OptionalPolygonConfigsRec = (function (_super) {
__extends(OptionalPolygonConfigsRec, _super);
function OptionalPolygonConfigsRec(defaults) {
_super.apply(this, arguments);
}
OptionalPolygonConfigsRec.attributesToDeclare = function () {
return [
this.attr("AllowDrag", "allowDragAttr", "AllowDrag", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("AllowEdit", "allowEditAttr", "AllowEdit", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("Stroke", "strokeAttr", "Stroke", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.StrokeRec());
}, true, OutSystemsMapsModel.StrokeRec), 
this.attr("Fill", "fillAttr", "Fill", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.FillRec());
}, true, OutSystemsMapsModel.FillRec)
].concat(_super.attributesToDeclare.call(this));
};
OptionalPolygonConfigsRec.init();
return OptionalPolygonConfigsRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.OptionalPolygonConfigsRec = OptionalPolygonConfigsRec;

});
define("OutSystemsMaps.model$OptionalPolygonConfigsRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$OptionalPolygonConfigsRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var OptionalPolygonConfigsRecord = (function (_super) {
__extends(OptionalPolygonConfigsRecord, _super);
function OptionalPolygonConfigsRecord(defaults) {
_super.apply(this, arguments);
}
OptionalPolygonConfigsRecord.attributesToDeclare = function () {
return [
this.attr("OptionalPolygonConfigs", "optionalPolygonConfigsAttr", "OptionalPolygonConfigs", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.OptionalPolygonConfigsRec());
}, true, OutSystemsMapsModel.OptionalPolygonConfigsRec)
].concat(_super.attributesToDeclare.call(this));
};
OptionalPolygonConfigsRecord.fromStructure = function (str) {
return new OptionalPolygonConfigsRecord(new OptionalPolygonConfigsRecord.RecordClass({
optionalPolygonConfigsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
OptionalPolygonConfigsRecord._isAnonymousRecord = true;
OptionalPolygonConfigsRecord.UniqueId = "48d7c166-849f-4c26-288a-543a51543b8d";
OptionalPolygonConfigsRecord.init();
return OptionalPolygonConfigsRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.OptionalPolygonConfigsRecord = OptionalPolygonConfigsRecord;

});
define("OutSystemsMaps.model$ShapeEventTriggeredList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$ShapeEventTriggeredRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var ShapeEventTriggeredList = (function (_super) {
__extends(ShapeEventTriggeredList, _super);
function ShapeEventTriggeredList(defaults) {
_super.apply(this, arguments);
}
ShapeEventTriggeredList.itemType = OutSystemsMapsModel.ShapeEventTriggeredRec;
return ShapeEventTriggeredList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.ShapeEventTriggeredList = ShapeEventTriggeredList;

});
define("OutSystemsMaps.model$DirectionLegsRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$DirectionLegsRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var DirectionLegsRecord = (function (_super) {
__extends(DirectionLegsRecord, _super);
function DirectionLegsRecord(defaults) {
_super.apply(this, arguments);
}
DirectionLegsRecord.attributesToDeclare = function () {
return [
this.attr("DirectionLegs", "directionLegsAttr", "DirectionLegs", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.DirectionLegsRec());
}, true, OutSystemsMapsModel.DirectionLegsRec)
].concat(_super.attributesToDeclare.call(this));
};
DirectionLegsRecord.fromStructure = function (str) {
return new DirectionLegsRecord(new DirectionLegsRecord.RecordClass({
directionLegsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DirectionLegsRecord._isAnonymousRecord = true;
DirectionLegsRecord.UniqueId = "ee9e4164-abf6-fbb7-5ace-cf37ce2b6aee";
DirectionLegsRecord.init();
return DirectionLegsRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.DirectionLegsRecord = DirectionLegsRecord;

});
define("OutSystemsMaps.model$DirectionLegsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$DirectionLegsRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var DirectionLegsRecordList = (function (_super) {
__extends(DirectionLegsRecordList, _super);
function DirectionLegsRecordList(defaults) {
_super.apply(this, arguments);
}
DirectionLegsRecordList.itemType = OutSystemsMapsModel.DirectionLegsRecord;
return DirectionLegsRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.DirectionLegsRecordList = DirectionLegsRecordList;

});
define("OutSystemsMaps.model$MapEventTriggeredRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$MapEventTriggeredRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var MapEventTriggeredRecord = (function (_super) {
__extends(MapEventTriggeredRecord, _super);
function MapEventTriggeredRecord(defaults) {
_super.apply(this, arguments);
}
MapEventTriggeredRecord.attributesToDeclare = function () {
return [
this.attr("MapEventTriggered", "mapEventTriggeredAttr", "MapEventTriggered", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.MapEventTriggeredRec());
}, true, OutSystemsMapsModel.MapEventTriggeredRec)
].concat(_super.attributesToDeclare.call(this));
};
MapEventTriggeredRecord.fromStructure = function (str) {
return new MapEventTriggeredRecord(new MapEventTriggeredRecord.RecordClass({
mapEventTriggeredAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MapEventTriggeredRecord._isAnonymousRecord = true;
MapEventTriggeredRecord.UniqueId = "bf75694d-8016-6881-34fa-555a2fd4f5d7";
MapEventTriggeredRecord.init();
return MapEventTriggeredRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.MapEventTriggeredRecord = MapEventTriggeredRecord;

});
define("OutSystemsMaps.model$MapEventTriggeredRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$MapEventTriggeredRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var MapEventTriggeredRecordList = (function (_super) {
__extends(MapEventTriggeredRecordList, _super);
function MapEventTriggeredRecordList(defaults) {
_super.apply(this, arguments);
}
MapEventTriggeredRecordList.itemType = OutSystemsMapsModel.MapEventTriggeredRecord;
return MapEventTriggeredRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.MapEventTriggeredRecordList = MapEventTriggeredRecordList;

});
define("OutSystemsMaps.model$CoordinatesRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$CoordinatesRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var CoordinatesRecord = (function (_super) {
__extends(CoordinatesRecord, _super);
function CoordinatesRecord(defaults) {
_super.apply(this, arguments);
}
CoordinatesRecord.attributesToDeclare = function () {
return [
this.attr("Coordinates", "coordinatesAttr", "Coordinates", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.CoordinatesRec());
}, true, OutSystemsMapsModel.CoordinatesRec)
].concat(_super.attributesToDeclare.call(this));
};
CoordinatesRecord.fromStructure = function (str) {
return new CoordinatesRecord(new CoordinatesRecord.RecordClass({
coordinatesAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
CoordinatesRecord._isAnonymousRecord = true;
CoordinatesRecord.UniqueId = "e3355f6b-7ba3-051c-4a4a-9a00634d68d0";
CoordinatesRecord.init();
return CoordinatesRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.CoordinatesRecord = CoordinatesRecord;

});
define("OutSystemsMaps.model$CoordinatesRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$CoordinatesRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var CoordinatesRecordList = (function (_super) {
__extends(CoordinatesRecordList, _super);
function CoordinatesRecordList(defaults) {
_super.apply(this, arguments);
}
CoordinatesRecordList.itemType = OutSystemsMapsModel.CoordinatesRecord;
return CoordinatesRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.CoordinatesRecordList = CoordinatesRecordList;

});
define("OutSystemsMaps.model$MapTypeRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$MapTypeRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var MapTypeRecord = (function (_super) {
__extends(MapTypeRecord, _super);
function MapTypeRecord(defaults) {
_super.apply(this, arguments);
}
MapTypeRecord.attributesToDeclare = function () {
return [
this.attr("MapType", "mapTypeAttr", "MapType", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.MapTypeRec());
}, true, OutSystemsMapsModel.MapTypeRec)
].concat(_super.attributesToDeclare.call(this));
};
MapTypeRecord.fromStructure = function (str) {
return new MapTypeRecord(new MapTypeRecord.RecordClass({
mapTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MapTypeRecord._isAnonymousRecord = true;
MapTypeRecord.UniqueId = "992836b5-ddde-04d0-d91f-0c87e7233524";
MapTypeRecord.init();
return MapTypeRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.MapTypeRecord = MapTypeRecord;

});
define("OutSystemsMaps.model$MapTypeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$MapTypeRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var MapTypeRecordList = (function (_super) {
__extends(MapTypeRecordList, _super);
function MapTypeRecordList(defaults) {
_super.apply(this, arguments);
}
MapTypeRecordList.itemType = OutSystemsMapsModel.MapTypeRecord;
return MapTypeRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.MapTypeRecordList = MapTypeRecordList;

});
define("OutSystemsMaps.model$OptionalPolygonConfigsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$OptionalPolygonConfigsRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var OptionalPolygonConfigsRecordList = (function (_super) {
__extends(OptionalPolygonConfigsRecordList, _super);
function OptionalPolygonConfigsRecordList(defaults) {
_super.apply(this, arguments);
}
OptionalPolygonConfigsRecordList.itemType = OutSystemsMapsModel.OptionalPolygonConfigsRecord;
return OptionalPolygonConfigsRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.OptionalPolygonConfigsRecordList = OptionalPolygonConfigsRecordList;

});
define("OutSystemsMaps.model$MarkerRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var MarkerRec = (function (_super) {
__extends(MarkerRec, _super);
function MarkerRec(defaults) {
_super.apply(this, arguments);
}
MarkerRec.attributesToDeclare = function () {
return [
this.attr("Location", "locationAttr", "location", false, false, OS.Types.Text, function () {
return "42.3517926,-71.0467845";
}, true), 
this.attr("IconURL", "iconURLAttr", "iconUrl", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AdvancedFormat", "advancedFormatAttr", "advancedFormat", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
MarkerRec.init();
return MarkerRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.MarkerRec = MarkerRec;

});
define("OutSystemsMaps.model$OptionalPopupMarkerConfigsRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var OptionalPopupMarkerConfigsRec = (function (_super) {
__extends(OptionalPopupMarkerConfigsRec, _super);
function OptionalPopupMarkerConfigsRec(defaults) {
_super.apply(this, arguments);
}
OptionalPopupMarkerConfigsRec.attributesToDeclare = function () {
return [
this.attr("IconURL", "iconURLAttr", "IconURL", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Title", "titleAttr", "Title", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AllowDrag", "allowDragAttr", "AllowDrag", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
OptionalPopupMarkerConfigsRec.init();
return OptionalPopupMarkerConfigsRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.OptionalPopupMarkerConfigsRec = OptionalPopupMarkerConfigsRec;

});
define("OutSystemsMaps.model$OptionalPopupMarkerConfigsRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$OptionalPopupMarkerConfigsRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var OptionalPopupMarkerConfigsRecord = (function (_super) {
__extends(OptionalPopupMarkerConfigsRecord, _super);
function OptionalPopupMarkerConfigsRecord(defaults) {
_super.apply(this, arguments);
}
OptionalPopupMarkerConfigsRecord.attributesToDeclare = function () {
return [
this.attr("OptionalPopupMarkerConfigs", "optionalPopupMarkerConfigsAttr", "OptionalPopupMarkerConfigs", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.OptionalPopupMarkerConfigsRec());
}, true, OutSystemsMapsModel.OptionalPopupMarkerConfigsRec)
].concat(_super.attributesToDeclare.call(this));
};
OptionalPopupMarkerConfigsRecord.fromStructure = function (str) {
return new OptionalPopupMarkerConfigsRecord(new OptionalPopupMarkerConfigsRecord.RecordClass({
optionalPopupMarkerConfigsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
OptionalPopupMarkerConfigsRecord._isAnonymousRecord = true;
OptionalPopupMarkerConfigsRecord.UniqueId = "dfb836f4-67b0-0be2-b3ce-838401b340cc";
OptionalPopupMarkerConfigsRecord.init();
return OptionalPopupMarkerConfigsRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.OptionalPopupMarkerConfigsRecord = OptionalPopupMarkerConfigsRecord;

});
define("OutSystemsMaps.model$OptionalPopupMarkerConfigsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$OptionalPopupMarkerConfigsRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var OptionalPopupMarkerConfigsRecordList = (function (_super) {
__extends(OptionalPopupMarkerConfigsRecordList, _super);
function OptionalPopupMarkerConfigsRecordList(defaults) {
_super.apply(this, arguments);
}
OptionalPopupMarkerConfigsRecordList.itemType = OutSystemsMapsModel.OptionalPopupMarkerConfigsRecord;
return OptionalPopupMarkerConfigsRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.OptionalPopupMarkerConfigsRecordList = OptionalPopupMarkerConfigsRecordList;

});
define("OutSystemsMaps.model$OptionalStaticMapConfigsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$OptionalStaticMapConfigsRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var OptionalStaticMapConfigsRecordList = (function (_super) {
__extends(OptionalStaticMapConfigsRecordList, _super);
function OptionalStaticMapConfigsRecordList(defaults) {
_super.apply(this, arguments);
}
OptionalStaticMapConfigsRecordList.itemType = OutSystemsMapsModel.OptionalStaticMapConfigsRecord;
return OptionalStaticMapConfigsRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.OptionalStaticMapConfigsRecordList = OptionalStaticMapConfigsRecordList;

});
define("OutSystemsMaps.model$Internal_to_provider_marker_configsList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$Internal_to_provider_marker_configsRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var Internal_to_provider_marker_configsList = (function (_super) {
__extends(Internal_to_provider_marker_configsList, _super);
function Internal_to_provider_marker_configsList(defaults) {
_super.apply(this, arguments);
}
Internal_to_provider_marker_configsList.itemType = OutSystemsMapsModel.Internal_to_provider_marker_configsRec;
return Internal_to_provider_marker_configsList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.Internal_to_provider_marker_configsList = Internal_to_provider_marker_configsList;

});
define("OutSystemsMaps.model$MapErrorsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$MapErrorsRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var MapErrorsRecordList = (function (_super) {
__extends(MapErrorsRecordList, _super);
function MapErrorsRecordList(defaults) {
_super.apply(this, arguments);
}
MapErrorsRecordList.itemType = OutSystemsMapsModel.MapErrorsRecord;
return MapErrorsRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.MapErrorsRecordList = MapErrorsRecordList;

});
define("OutSystemsMaps.model$VerbosityRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var VerbosityRec = (function (_super) {
__extends(VerbosityRec, _super);
function VerbosityRec(defaults) {
_super.apply(this, arguments);
}
VerbosityRec.attributesToDeclare = function () {
return [
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
VerbosityRec.init();
return VerbosityRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.VerbosityRec = VerbosityRec;

});
define("OutSystemsMaps.model$VerbosityRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$VerbosityRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var VerbosityRecord = (function (_super) {
__extends(VerbosityRecord, _super);
function VerbosityRecord(defaults) {
_super.apply(this, arguments);
}
VerbosityRecord.attributesToDeclare = function () {
return [
this.attr("Verbosity", "verbosityAttr", "Verbosity", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.VerbosityRec());
}, true, OutSystemsMapsModel.VerbosityRec)
].concat(_super.attributesToDeclare.call(this));
};
VerbosityRecord.fromStructure = function (str) {
return new VerbosityRecord(new VerbosityRecord.RecordClass({
verbosityAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
VerbosityRecord._isAnonymousRecord = true;
VerbosityRecord.UniqueId = "a9d171af-5978-fe3e-4b7e-f9f38c0c5a39";
VerbosityRecord.init();
return VerbosityRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.VerbosityRecord = VerbosityRecord;

});
define("OutSystemsMaps.model$VerbosityRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$VerbosityRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var VerbosityRecordList = (function (_super) {
__extends(VerbosityRecordList, _super);
function VerbosityRecordList(defaults) {
_super.apply(this, arguments);
}
VerbosityRecordList.itemType = OutSystemsMapsModel.VerbosityRecord;
return VerbosityRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.VerbosityRecordList = VerbosityRecordList;

});
define("OutSystemsMaps.model$OptionalStaticMapConfigsList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$OptionalStaticMapConfigsRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var OptionalStaticMapConfigsList = (function (_super) {
__extends(OptionalStaticMapConfigsList, _super);
function OptionalStaticMapConfigsList(defaults) {
_super.apply(this, arguments);
}
OptionalStaticMapConfigsList.itemType = OutSystemsMapsModel.OptionalStaticMapConfigsRec;
return OptionalStaticMapConfigsList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.OptionalStaticMapConfigsList = OptionalStaticMapConfigsList;

});
define("OutSystemsMaps.model$LogTypeRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$LogTypeRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var LogTypeRecord = (function (_super) {
__extends(LogTypeRecord, _super);
function LogTypeRecord(defaults) {
_super.apply(this, arguments);
}
LogTypeRecord.attributesToDeclare = function () {
return [
this.attr("LogType", "logTypeAttr", "LogType", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.LogTypeRec());
}, true, OutSystemsMapsModel.LogTypeRec)
].concat(_super.attributesToDeclare.call(this));
};
LogTypeRecord.fromStructure = function (str) {
return new LogTypeRecord(new LogTypeRecord.RecordClass({
logTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
LogTypeRecord._isAnonymousRecord = true;
LogTypeRecord.UniqueId = "6633adb4-8f34-6ff9-1476-37b286666408";
LogTypeRecord.init();
return LogTypeRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.LogTypeRecord = LogTypeRecord;

});
define("OutSystemsMaps.model$TravelModeRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var TravelModeRec = (function (_super) {
__extends(TravelModeRec, _super);
function TravelModeRec(defaults) {
_super.apply(this, arguments);
}
TravelModeRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
TravelModeRec.fromStructure = function (str) {
return new TravelModeRec(new TravelModeRec.RecordClass({
idAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
TravelModeRec.init();
return TravelModeRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.TravelModeRec = TravelModeRec;

});
define("OutSystemsMaps.model$LogTypeList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$LogTypeRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var LogTypeList = (function (_super) {
__extends(LogTypeList, _super);
function LogTypeList(defaults) {
_super.apply(this, arguments);
}
LogTypeList.itemType = OutSystemsMapsModel.LogTypeRec;
return LogTypeList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.LogTypeList = LogTypeList;

});
define("OutSystemsMaps.model$MapEventList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$MapEventRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var MapEventList = (function (_super) {
__extends(MapEventList, _super);
function MapEventList(defaults) {
_super.apply(this, arguments);
}
MapEventList.itemType = OutSystemsMapsModel.MapEventRec;
return MapEventList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.MapEventList = MapEventList;

});
define("OutSystemsMaps.model$Internal_Shape_ConfigsRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$Internal_Shape_ConfigsRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var Internal_Shape_ConfigsRecord = (function (_super) {
__extends(Internal_Shape_ConfigsRecord, _super);
function Internal_Shape_ConfigsRecord(defaults) {
_super.apply(this, arguments);
}
Internal_Shape_ConfigsRecord.attributesToDeclare = function () {
return [
this.attr("Internal_Shape_Configs", "internal_Shape_ConfigsAttr", "Internal_Shape_Configs", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.Internal_Shape_ConfigsRec());
}, true, OutSystemsMapsModel.Internal_Shape_ConfigsRec)
].concat(_super.attributesToDeclare.call(this));
};
Internal_Shape_ConfigsRecord.fromStructure = function (str) {
return new Internal_Shape_ConfigsRecord(new Internal_Shape_ConfigsRecord.RecordClass({
internal_Shape_ConfigsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
Internal_Shape_ConfigsRecord._isAnonymousRecord = true;
Internal_Shape_ConfigsRecord.UniqueId = "6beef079-e29e-7256-385a-c77b93f8d4bb";
Internal_Shape_ConfigsRecord.init();
return Internal_Shape_ConfigsRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.Internal_Shape_ConfigsRecord = Internal_Shape_ConfigsRecord;

});
define("OutSystemsMaps.model$OptionalMarkerConfigsRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var OptionalMarkerConfigsRec = (function (_super) {
__extends(OptionalMarkerConfigsRec, _super);
function OptionalMarkerConfigsRec(defaults) {
_super.apply(this, arguments);
}
OptionalMarkerConfigsRec.attributesToDeclare = function () {
return [
this.attr("IconURL", "iconURLAttr", "IconURL", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Title", "titleAttr", "Title", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("AllowDrag", "allowDragAttr", "AllowDrag", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
OptionalMarkerConfigsRec.init();
return OptionalMarkerConfigsRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.OptionalMarkerConfigsRec = OptionalMarkerConfigsRec;

});
define("OutSystemsMaps.model$OptionalMarkerConfigsList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$OptionalMarkerConfigsRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var OptionalMarkerConfigsList = (function (_super) {
__extends(OptionalMarkerConfigsList, _super);
function OptionalMarkerConfigsList(defaults) {
_super.apply(this, arguments);
}
OptionalMarkerConfigsList.itemType = OutSystemsMapsModel.OptionalMarkerConfigsRec;
return OptionalMarkerConfigsList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.OptionalMarkerConfigsList = OptionalMarkerConfigsList;

});
define("OutSystemsMaps.model$OptionalMarkerConfigsRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$OptionalMarkerConfigsRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var OptionalMarkerConfigsRecord = (function (_super) {
__extends(OptionalMarkerConfigsRecord, _super);
function OptionalMarkerConfigsRecord(defaults) {
_super.apply(this, arguments);
}
OptionalMarkerConfigsRecord.attributesToDeclare = function () {
return [
this.attr("OptionalMarkerConfigs", "optionalMarkerConfigsAttr", "OptionalMarkerConfigs", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.OptionalMarkerConfigsRec());
}, true, OutSystemsMapsModel.OptionalMarkerConfigsRec)
].concat(_super.attributesToDeclare.call(this));
};
OptionalMarkerConfigsRecord.fromStructure = function (str) {
return new OptionalMarkerConfigsRecord(new OptionalMarkerConfigsRecord.RecordClass({
optionalMarkerConfigsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
OptionalMarkerConfigsRecord._isAnonymousRecord = true;
OptionalMarkerConfigsRecord.UniqueId = "c97612a2-7be8-5a55-32e2-b3b5ddfcfa27";
OptionalMarkerConfigsRecord.init();
return OptionalMarkerConfigsRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.OptionalMarkerConfigsRecord = OptionalMarkerConfigsRecord;

});
define("OutSystemsMaps.model$OptionalMarkerConfigsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$OptionalMarkerConfigsRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var OptionalMarkerConfigsRecordList = (function (_super) {
__extends(OptionalMarkerConfigsRecordList, _super);
function OptionalMarkerConfigsRecordList(defaults) {
_super.apply(this, arguments);
}
OptionalMarkerConfigsRecordList.itemType = OutSystemsMapsModel.OptionalMarkerConfigsRecord;
return OptionalMarkerConfigsRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.OptionalMarkerConfigsRecordList = OptionalMarkerConfigsRecordList;

});
define("OutSystemsMaps.model$ReturnMessageRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var ReturnMessageRec = (function (_super) {
__extends(ReturnMessageRec, _super);
function ReturnMessageRec(defaults) {
_super.apply(this, arguments);
}
ReturnMessageRec.attributesToDeclare = function () {
return [
this.attr("IsSuccess", "isSuccessAttr", "isSuccess", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("Code", "codeAttr", "code", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Message", "messageAttr", "message", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ReturnMessageRec.init();
return ReturnMessageRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.ReturnMessageRec = ReturnMessageRec;

});
define("OutSystemsMaps.model$ReturnMessageRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$ReturnMessageRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var ReturnMessageRecord = (function (_super) {
__extends(ReturnMessageRecord, _super);
function ReturnMessageRecord(defaults) {
_super.apply(this, arguments);
}
ReturnMessageRecord.attributesToDeclare = function () {
return [
this.attr("ReturnMessage", "returnMessageAttr", "ReturnMessage", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.ReturnMessageRec());
}, true, OutSystemsMapsModel.ReturnMessageRec)
].concat(_super.attributesToDeclare.call(this));
};
ReturnMessageRecord.fromStructure = function (str) {
return new ReturnMessageRecord(new ReturnMessageRecord.RecordClass({
returnMessageAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ReturnMessageRecord._isAnonymousRecord = true;
ReturnMessageRecord.UniqueId = "7511ee1a-8615-9a13-9a2f-21acdabfee5b";
ReturnMessageRecord.init();
return ReturnMessageRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.ReturnMessageRecord = ReturnMessageRecord;

});
define("OutSystemsMaps.model$MarkerEventTriggeredRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var MarkerEventTriggeredRec = (function (_super) {
__extends(MarkerEventTriggeredRec, _super);
function MarkerEventTriggeredRec(defaults) {
_super.apply(this, arguments);
}
MarkerEventTriggeredRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
MarkerEventTriggeredRec.fromStructure = function (str) {
return new MarkerEventTriggeredRec(new MarkerEventTriggeredRec.RecordClass({
idAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MarkerEventTriggeredRec.init();
return MarkerEventTriggeredRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.MarkerEventTriggeredRec = MarkerEventTriggeredRec;

});
define("OutSystemsMaps.model$MarkerEventTriggeredRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$MarkerEventTriggeredRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var MarkerEventTriggeredRecord = (function (_super) {
__extends(MarkerEventTriggeredRecord, _super);
function MarkerEventTriggeredRecord(defaults) {
_super.apply(this, arguments);
}
MarkerEventTriggeredRecord.attributesToDeclare = function () {
return [
this.attr("MarkerEventTriggered", "markerEventTriggeredAttr", "MarkerEventTriggered", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.MarkerEventTriggeredRec());
}, true, OutSystemsMapsModel.MarkerEventTriggeredRec)
].concat(_super.attributesToDeclare.call(this));
};
MarkerEventTriggeredRecord.fromStructure = function (str) {
return new MarkerEventTriggeredRecord(new MarkerEventTriggeredRecord.RecordClass({
markerEventTriggeredAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MarkerEventTriggeredRecord._isAnonymousRecord = true;
MarkerEventTriggeredRecord.UniqueId = "d18425d8-0352-34c4-43ec-bdefa0da8210";
MarkerEventTriggeredRecord.init();
return MarkerEventTriggeredRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.MarkerEventTriggeredRecord = MarkerEventTriggeredRecord;

});
define("OutSystemsMaps.model$MarkerEventTriggeredRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$MarkerEventTriggeredRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var MarkerEventTriggeredRecordList = (function (_super) {
__extends(MarkerEventTriggeredRecordList, _super);
function MarkerEventTriggeredRecordList(defaults) {
_super.apply(this, arguments);
}
MarkerEventTriggeredRecordList.itemType = OutSystemsMapsModel.MarkerEventTriggeredRecord;
return MarkerEventTriggeredRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.MarkerEventTriggeredRecordList = MarkerEventTriggeredRecordList;

});
define("OutSystemsMaps.model$MarkerList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$MarkerRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var MarkerList = (function (_super) {
__extends(MarkerList, _super);
function MarkerList(defaults) {
_super.apply(this, arguments);
}
MarkerList.itemType = OutSystemsMapsModel.MarkerRec;
return MarkerList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.MarkerList = MarkerList;

});
define("OutSystemsMaps.model$Internal_ConfigsRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$Internal_to_provider_configsRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var Internal_ConfigsRec = (function (_super) {
__extends(Internal_ConfigsRec, _super);
function Internal_ConfigsRec(defaults) {
_super.apply(this, arguments);
}
Internal_ConfigsRec.attributesToDeclare = function () {
return [
this.attr("ExtendedClass", "extendedClassAttr", "ExtendedClass", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Height", "heightAttr", "Height", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Internal_to_provider_configs", "internal_to_provider_configsAttr", "Internal_to_provider_configs", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.Internal_to_provider_configsRec());
}, true, OutSystemsMapsModel.Internal_to_provider_configsRec), 
this.attr("StaticMapURL", "staticMapURLAttr", "StaticMapURL", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("UniqueId", "uniqueIdAttr", "UniqueId", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
Internal_ConfigsRec.init();
return Internal_ConfigsRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.Internal_ConfigsRec = Internal_ConfigsRec;

});
define("OutSystemsMaps.model$OptionalPolylineConfigsList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$OptionalPolylineConfigsRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var OptionalPolylineConfigsList = (function (_super) {
__extends(OptionalPolylineConfigsList, _super);
function OptionalPolylineConfigsList(defaults) {
_super.apply(this, arguments);
}
OptionalPolylineConfigsList.itemType = OutSystemsMapsModel.OptionalPolylineConfigsRec;
return OptionalPolylineConfigsList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.OptionalPolylineConfigsList = OptionalPolylineConfigsList;

});
define("OutSystemsMaps.model$StaticMarkerList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$StaticMarkerRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var StaticMarkerList = (function (_super) {
__extends(StaticMarkerList, _super);
function StaticMarkerList(defaults) {
_super.apply(this, arguments);
}
StaticMarkerList.itemType = OutSystemsMapsModel.StaticMarkerRec;
return StaticMarkerList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.StaticMarkerList = StaticMarkerList;

});
define("OutSystemsMaps.model$CoordinatesList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$CoordinatesRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var CoordinatesList = (function (_super) {
__extends(CoordinatesList, _super);
function CoordinatesList(defaults) {
_super.apply(this, arguments);
}
CoordinatesList.itemType = OutSystemsMapsModel.CoordinatesRec;
return CoordinatesList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.CoordinatesList = CoordinatesList;

});
define("OutSystemsMaps.model$ZoomRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$ZoomRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var ZoomRecord = (function (_super) {
__extends(ZoomRecord, _super);
function ZoomRecord(defaults) {
_super.apply(this, arguments);
}
ZoomRecord.attributesToDeclare = function () {
return [
this.attr("Zoom", "zoomAttr", "Zoom", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.ZoomRec());
}, true, OutSystemsMapsModel.ZoomRec)
].concat(_super.attributesToDeclare.call(this));
};
ZoomRecord.fromStructure = function (str) {
return new ZoomRecord(new ZoomRecord.RecordClass({
zoomAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ZoomRecord._isAnonymousRecord = true;
ZoomRecord.UniqueId = "80e81fdd-ca00-89d3-f29f-81106c0bee34";
ZoomRecord.init();
return ZoomRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.ZoomRecord = ZoomRecord;

});
define("OutSystemsMaps.model$MarkerRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$MarkerRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var MarkerRecord = (function (_super) {
__extends(MarkerRecord, _super);
function MarkerRecord(defaults) {
_super.apply(this, arguments);
}
MarkerRecord.attributesToDeclare = function () {
return [
this.attr("Marker", "markerAttr", "Marker", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.MarkerRec());
}, true, OutSystemsMapsModel.MarkerRec)
].concat(_super.attributesToDeclare.call(this));
};
MarkerRecord.fromStructure = function (str) {
return new MarkerRecord(new MarkerRecord.RecordClass({
markerAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MarkerRecord._isAnonymousRecord = true;
MarkerRecord.UniqueId = "bff46e92-99d5-3c31-f521-81ed865bd729";
MarkerRecord.init();
return MarkerRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.MarkerRecord = MarkerRecord;

});
define("OutSystemsMaps.model$MarkerRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$MarkerRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var MarkerRecordList = (function (_super) {
__extends(MarkerRecordList, _super);
function MarkerRecordList(defaults) {
_super.apply(this, arguments);
}
MarkerRecordList.itemType = OutSystemsMapsModel.MarkerRecord;
return MarkerRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.MarkerRecordList = MarkerRecordList;

});
define("OutSystemsMaps.model$Internal_ConfigsList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$Internal_ConfigsRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var Internal_ConfigsList = (function (_super) {
__extends(Internal_ConfigsList, _super);
function Internal_ConfigsList(defaults) {
_super.apply(this, arguments);
}
Internal_ConfigsList.itemType = OutSystemsMapsModel.Internal_ConfigsRec;
return Internal_ConfigsList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.Internal_ConfigsList = Internal_ConfigsList;

});
define("OutSystemsMaps.model$Internal_ConfigsRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$Internal_ConfigsRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var Internal_ConfigsRecord = (function (_super) {
__extends(Internal_ConfigsRecord, _super);
function Internal_ConfigsRecord(defaults) {
_super.apply(this, arguments);
}
Internal_ConfigsRecord.attributesToDeclare = function () {
return [
this.attr("Internal_Configs", "internal_ConfigsAttr", "Internal_Configs", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.Internal_ConfigsRec());
}, true, OutSystemsMapsModel.Internal_ConfigsRec)
].concat(_super.attributesToDeclare.call(this));
};
Internal_ConfigsRecord.fromStructure = function (str) {
return new Internal_ConfigsRecord(new Internal_ConfigsRecord.RecordClass({
internal_ConfigsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
Internal_ConfigsRecord._isAnonymousRecord = true;
Internal_ConfigsRecord.UniqueId = "afeb3af8-7221-b535-eb5e-95ea10936666";
Internal_ConfigsRecord.init();
return Internal_ConfigsRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.Internal_ConfigsRecord = Internal_ConfigsRecord;

});
define("OutSystemsMaps.model$Internal_ConfigsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$Internal_ConfigsRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var Internal_ConfigsRecordList = (function (_super) {
__extends(Internal_ConfigsRecordList, _super);
function Internal_ConfigsRecordList(defaults) {
_super.apply(this, arguments);
}
Internal_ConfigsRecordList.itemType = OutSystemsMapsModel.Internal_ConfigsRecord;
return Internal_ConfigsRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.Internal_ConfigsRecordList = Internal_ConfigsRecordList;

});
define("OutSystemsMaps.model$LogTypeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$LogTypeRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var LogTypeRecordList = (function (_super) {
__extends(LogTypeRecordList, _super);
function LogTypeRecordList(defaults) {
_super.apply(this, arguments);
}
LogTypeRecordList.itemType = OutSystemsMapsModel.LogTypeRecord;
return LogTypeRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.LogTypeRecordList = LogTypeRecordList;

});
define("OutSystemsMaps.model$StrokeList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$StrokeRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var StrokeList = (function (_super) {
__extends(StrokeList, _super);
function StrokeList(defaults) {
_super.apply(this, arguments);
}
StrokeList.itemType = OutSystemsMapsModel.StrokeRec;
return StrokeList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.StrokeList = StrokeList;

});
define("OutSystemsMaps.model$TypeRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var TypeRec = (function (_super) {
__extends(TypeRec, _super);
function TypeRec(defaults) {
_super.apply(this, arguments);
}
TypeRec.attributesToDeclare = function () {
return [
this.attr("MapType", "mapTypeAttr", "MapType", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
TypeRec.init();
return TypeRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.TypeRec = TypeRec;

});
define("OutSystemsMaps.model$TypeList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$TypeRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var TypeList = (function (_super) {
__extends(TypeList, _super);
function TypeList(defaults) {
_super.apply(this, arguments);
}
TypeList.itemType = OutSystemsMapsModel.TypeRec;
return TypeList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.TypeList = TypeList;

});
define("OutSystemsMaps.model$DecimalDecimalRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var DecimalDecimalRecord = (function (_super) {
__extends(DecimalDecimalRecord, _super);
function DecimalDecimalRecord(defaults) {
_super.apply(this, arguments);
}
DecimalDecimalRecord.attributesToDeclare = function () {
return [
this.attr("Lat", "latAttr", "Lat", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true), 
this.attr("Lng", "lngAttr", "Lng", false, false, OS.Types.Decimal, function () {
return OS.DataTypes.Decimal.defaultValue;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DecimalDecimalRecord._isAnonymousRecord = true;
DecimalDecimalRecord.UniqueId = "df078695-1d23-57ea-5f13-ac02dccd68c2";
DecimalDecimalRecord.init();
return DecimalDecimalRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.DecimalDecimalRecord = DecimalDecimalRecord;

});
define("OutSystemsMaps.model$DecimalDecimalRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$DecimalDecimalRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var DecimalDecimalRecordList = (function (_super) {
__extends(DecimalDecimalRecordList, _super);
function DecimalDecimalRecordList(defaults) {
_super.apply(this, arguments);
}
DecimalDecimalRecordList.itemType = OutSystemsMapsModel.DecimalDecimalRecord;
return DecimalDecimalRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.DecimalDecimalRecordList = DecimalDecimalRecordList;

});
define("OutSystemsMaps.model$ShapeEventRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var ShapeEventRec = (function (_super) {
__extends(ShapeEventRec, _super);
function ShapeEventRec(defaults) {
_super.apply(this, arguments);
}
ShapeEventRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ShapeEventRec.fromStructure = function (str) {
return new ShapeEventRec(new ShapeEventRec.RecordClass({
idAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ShapeEventRec.init();
return ShapeEventRec;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.ShapeEventRec = ShapeEventRec;

});
define("OutSystemsMaps.model$ShapeEventRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$ShapeEventRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var ShapeEventRecord = (function (_super) {
__extends(ShapeEventRecord, _super);
function ShapeEventRecord(defaults) {
_super.apply(this, arguments);
}
ShapeEventRecord.attributesToDeclare = function () {
return [
this.attr("ShapeEvent", "shapeEventAttr", "ShapeEvent", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.ShapeEventRec());
}, true, OutSystemsMapsModel.ShapeEventRec)
].concat(_super.attributesToDeclare.call(this));
};
ShapeEventRecord.fromStructure = function (str) {
return new ShapeEventRecord(new ShapeEventRecord.RecordClass({
shapeEventAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ShapeEventRecord._isAnonymousRecord = true;
ShapeEventRecord.UniqueId = "edb1f7bb-91dd-bc76-1736-a4f9fe9ed955";
ShapeEventRecord.init();
return ShapeEventRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.ShapeEventRecord = ShapeEventRecord;

});
define("OutSystemsMaps.model$ShapeEventRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$ShapeEventRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var ShapeEventRecordList = (function (_super) {
__extends(ShapeEventRecordList, _super);
function ShapeEventRecordList(defaults) {
_super.apply(this, arguments);
}
ShapeEventRecordList.itemType = OutSystemsMapsModel.ShapeEventRecord;
return ShapeEventRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.ShapeEventRecordList = ShapeEventRecordList;

});
define("OutSystemsMaps.model$ShapeTypeList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$ShapeTypeRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var ShapeTypeList = (function (_super) {
__extends(ShapeTypeList, _super);
function ShapeTypeList(defaults) {
_super.apply(this, arguments);
}
ShapeTypeList.itemType = OutSystemsMapsModel.ShapeTypeRec;
return ShapeTypeList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.ShapeTypeList = ShapeTypeList;

});
define("OutSystemsMaps.model$TravelModeRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$TravelModeRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var TravelModeRecord = (function (_super) {
__extends(TravelModeRecord, _super);
function TravelModeRecord(defaults) {
_super.apply(this, arguments);
}
TravelModeRecord.attributesToDeclare = function () {
return [
this.attr("TravelMode", "travelModeAttr", "TravelMode", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.TravelModeRec());
}, true, OutSystemsMapsModel.TravelModeRec)
].concat(_super.attributesToDeclare.call(this));
};
TravelModeRecord.fromStructure = function (str) {
return new TravelModeRecord(new TravelModeRecord.RecordClass({
travelModeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
TravelModeRecord._isAnonymousRecord = true;
TravelModeRecord.UniqueId = "fd916ed3-e439-afbf-2b3a-8036c2de75ba";
TravelModeRecord.init();
return TravelModeRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.TravelModeRecord = TravelModeRecord;

});
define("OutSystemsMaps.model$TravelModeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$TravelModeRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var TravelModeRecordList = (function (_super) {
__extends(TravelModeRecordList, _super);
function TravelModeRecordList(defaults) {
_super.apply(this, arguments);
}
TravelModeRecordList.itemType = OutSystemsMapsModel.TravelModeRecord;
return TravelModeRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.TravelModeRecordList = TravelModeRecordList;

});
define("OutSystemsMaps.model$Internal_Shape_ConfigsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$Internal_Shape_ConfigsRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var Internal_Shape_ConfigsRecordList = (function (_super) {
__extends(Internal_Shape_ConfigsRecordList, _super);
function Internal_Shape_ConfigsRecordList(defaults) {
_super.apply(this, arguments);
}
Internal_Shape_ConfigsRecordList.itemType = OutSystemsMapsModel.Internal_Shape_ConfigsRecord;
return Internal_Shape_ConfigsRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.Internal_Shape_ConfigsRecordList = Internal_Shape_ConfigsRecordList;

});
define("OutSystemsMaps.model$TypeRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$TypeRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var TypeRecord = (function (_super) {
__extends(TypeRecord, _super);
function TypeRecord(defaults) {
_super.apply(this, arguments);
}
TypeRecord.attributesToDeclare = function () {
return [
this.attr("Type", "typeAttr", "Type", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.TypeRec());
}, true, OutSystemsMapsModel.TypeRec)
].concat(_super.attributesToDeclare.call(this));
};
TypeRecord.fromStructure = function (str) {
return new TypeRecord(new TypeRecord.RecordClass({
typeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
TypeRecord._isAnonymousRecord = true;
TypeRecord.UniqueId = "b32e755d-03dd-085a-4b97-5b8c0c7d4454";
TypeRecord.init();
return TypeRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.TypeRecord = TypeRecord;

});
define("OutSystemsMaps.model$MapTypeList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$MapTypeRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var MapTypeList = (function (_super) {
__extends(MapTypeList, _super);
function MapTypeList(defaults) {
_super.apply(this, arguments);
}
MapTypeList.itemType = OutSystemsMapsModel.MapTypeRec;
return MapTypeList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.MapTypeList = MapTypeList;

});
define("OutSystemsMaps.model$TravelModeList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$TravelModeRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var TravelModeList = (function (_super) {
__extends(TravelModeList, _super);
function TravelModeList(defaults) {
_super.apply(this, arguments);
}
TravelModeList.itemType = OutSystemsMapsModel.TravelModeRec;
return TravelModeList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.TravelModeList = TravelModeList;

});
define("OutSystemsMaps.model$Internal_to_provider_marker_configsRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$Internal_to_provider_marker_configsRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var Internal_to_provider_marker_configsRecord = (function (_super) {
__extends(Internal_to_provider_marker_configsRecord, _super);
function Internal_to_provider_marker_configsRecord(defaults) {
_super.apply(this, arguments);
}
Internal_to_provider_marker_configsRecord.attributesToDeclare = function () {
return [
this.attr("Internal_to_provider_marker_configs", "internal_to_provider_marker_configsAttr", "Internal_to_provider_marker_configs", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsMapsModel.Internal_to_provider_marker_configsRec());
}, true, OutSystemsMapsModel.Internal_to_provider_marker_configsRec)
].concat(_super.attributesToDeclare.call(this));
};
Internal_to_provider_marker_configsRecord.fromStructure = function (str) {
return new Internal_to_provider_marker_configsRecord(new Internal_to_provider_marker_configsRecord.RecordClass({
internal_to_provider_marker_configsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
Internal_to_provider_marker_configsRecord._isAnonymousRecord = true;
Internal_to_provider_marker_configsRecord.UniqueId = "fc0e8940-fcfc-7eca-ecb5-48b5cf8eab5d";
Internal_to_provider_marker_configsRecord.init();
return Internal_to_provider_marker_configsRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsMapsModel.Internal_to_provider_marker_configsRecord = Internal_to_provider_marker_configsRecord;

});
define("OutSystemsMaps.model$Internal_to_provider_marker_configsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$Internal_to_provider_marker_configsRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var Internal_to_provider_marker_configsRecordList = (function (_super) {
__extends(Internal_to_provider_marker_configsRecordList, _super);
function Internal_to_provider_marker_configsRecordList(defaults) {
_super.apply(this, arguments);
}
Internal_to_provider_marker_configsRecordList.itemType = OutSystemsMapsModel.Internal_to_provider_marker_configsRecord;
return Internal_to_provider_marker_configsRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.Internal_to_provider_marker_configsRecordList = Internal_to_provider_marker_configsRecordList;

});
define("OutSystemsMaps.model$ZoomRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$ZoomRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var ZoomRecordList = (function (_super) {
__extends(ZoomRecordList, _super);
function ZoomRecordList(defaults) {
_super.apply(this, arguments);
}
ZoomRecordList.itemType = OutSystemsMapsModel.ZoomRecord;
return ZoomRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.ZoomRecordList = ZoomRecordList;

});
define("OutSystemsMaps.model$OffsetList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$OffsetRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var OffsetList = (function (_super) {
__extends(OffsetList, _super);
function OffsetList(defaults) {
_super.apply(this, arguments);
}
OffsetList.itemType = OutSystemsMapsModel.OffsetRec;
return OffsetList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.OffsetList = OffsetList;

});
define("OutSystemsMaps.model$TypeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$TypeRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var TypeRecordList = (function (_super) {
__extends(TypeRecordList, _super);
function TypeRecordList(defaults) {
_super.apply(this, arguments);
}
TypeRecordList.itemType = OutSystemsMapsModel.TypeRecord;
return TypeRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.TypeRecordList = TypeRecordList;

});
define("OutSystemsMaps.model$MapEventTriggeredList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$MapEventTriggeredRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var MapEventTriggeredList = (function (_super) {
__extends(MapEventTriggeredList, _super);
function MapEventTriggeredList(defaults) {
_super.apply(this, arguments);
}
MapEventTriggeredList.itemType = OutSystemsMapsModel.MapEventTriggeredRec;
return MapEventTriggeredList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.MapEventTriggeredList = MapEventTriggeredList;

});
define("OutSystemsMaps.model$ReturnMessageList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$ReturnMessageRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var ReturnMessageList = (function (_super) {
__extends(ReturnMessageList, _super);
function ReturnMessageList(defaults) {
_super.apply(this, arguments);
}
ReturnMessageList.itemType = OutSystemsMapsModel.ReturnMessageRec;
return ReturnMessageList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.ReturnMessageList = ReturnMessageList;

});
define("OutSystemsMaps.model$MarkerEventTriggeredList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$MarkerEventTriggeredRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var MarkerEventTriggeredList = (function (_super) {
__extends(MarkerEventTriggeredList, _super);
function MarkerEventTriggeredList(defaults) {
_super.apply(this, arguments);
}
MarkerEventTriggeredList.itemType = OutSystemsMapsModel.MarkerEventTriggeredRec;
return MarkerEventTriggeredList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.MarkerEventTriggeredList = MarkerEventTriggeredList;

});
define("OutSystemsMaps.model$MarkerEventRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$MarkerEventRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var MarkerEventRecordList = (function (_super) {
__extends(MarkerEventRecordList, _super);
function MarkerEventRecordList(defaults) {
_super.apply(this, arguments);
}
MarkerEventRecordList.itemType = OutSystemsMapsModel.MarkerEventRecord;
return MarkerEventRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.MarkerEventRecordList = MarkerEventRecordList;

});
define("OutSystemsMaps.model$OptionalPopupMarkerConfigsList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$OptionalPopupMarkerConfigsRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var OptionalPopupMarkerConfigsList = (function (_super) {
__extends(OptionalPopupMarkerConfigsList, _super);
function OptionalPopupMarkerConfigsList(defaults) {
_super.apply(this, arguments);
}
OptionalPopupMarkerConfigsList.itemType = OutSystemsMapsModel.OptionalPopupMarkerConfigsRec;
return OptionalPopupMarkerConfigsList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.OptionalPopupMarkerConfigsList = OptionalPopupMarkerConfigsList;

});
define("OutSystemsMaps.model$OptionalPolygonConfigsList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$OptionalPolygonConfigsRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var OptionalPolygonConfigsList = (function (_super) {
__extends(OptionalPolygonConfigsList, _super);
function OptionalPolygonConfigsList(defaults) {
_super.apply(this, arguments);
}
OptionalPolygonConfigsList.itemType = OutSystemsMapsModel.OptionalPolygonConfigsRec;
return OptionalPolygonConfigsList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.OptionalPolygonConfigsList = OptionalPolygonConfigsList;

});
define("OutSystemsMaps.model$OptionalShapeConfigsList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$OptionalShapeConfigsRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var OptionalShapeConfigsList = (function (_super) {
__extends(OptionalShapeConfigsList, _super);
function OptionalShapeConfigsList(defaults) {
_super.apply(this, arguments);
}
OptionalShapeConfigsList.itemType = OutSystemsMapsModel.OptionalShapeConfigsRec;
return OptionalShapeConfigsList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.OptionalShapeConfigsList = OptionalShapeConfigsList;

});
define("OutSystemsMaps.model$VerbosityList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$VerbosityRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var VerbosityList = (function (_super) {
__extends(VerbosityList, _super);
function VerbosityList(defaults) {
_super.apply(this, arguments);
}
VerbosityList.itemType = OutSystemsMapsModel.VerbosityRec;
return VerbosityList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.VerbosityList = VerbosityList;

});
define("OutSystemsMaps.model$MapEventRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$MapEventRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var MapEventRecordList = (function (_super) {
__extends(MapEventRecordList, _super);
function MapEventRecordList(defaults) {
_super.apply(this, arguments);
}
MapEventRecordList.itemType = OutSystemsMapsModel.MapEventRecord;
return MapEventRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.MapEventRecordList = MapEventRecordList;

});
define("OutSystemsMaps.model$FillRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$FillRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var FillRecordList = (function (_super) {
__extends(FillRecordList, _super);
function FillRecordList(defaults) {
_super.apply(this, arguments);
}
FillRecordList.itemType = OutSystemsMapsModel.FillRecord;
return FillRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.FillRecordList = FillRecordList;

});
define("OutSystemsMaps.model$ShapeTypeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$ShapeTypeRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var ShapeTypeRecordList = (function (_super) {
__extends(ShapeTypeRecordList, _super);
function ShapeTypeRecordList(defaults) {
_super.apply(this, arguments);
}
ShapeTypeRecordList.itemType = OutSystemsMapsModel.ShapeTypeRecord;
return ShapeTypeRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.ShapeTypeRecordList = ShapeTypeRecordList;

});
define("OutSystemsMaps.model$ShapeEventList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$ShapeEventRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var ShapeEventList = (function (_super) {
__extends(ShapeEventList, _super);
function ShapeEventList(defaults) {
_super.apply(this, arguments);
}
ShapeEventList.itemType = OutSystemsMapsModel.ShapeEventRec;
return ShapeEventList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.ShapeEventList = ShapeEventList;

});
define("OutSystemsMaps.model$ReturnMessageRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$ReturnMessageRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var ReturnMessageRecordList = (function (_super) {
__extends(ReturnMessageRecordList, _super);
function ReturnMessageRecordList(defaults) {
_super.apply(this, arguments);
}
ReturnMessageRecordList.itemType = OutSystemsMapsModel.ReturnMessageRecord;
return ReturnMessageRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.ReturnMessageRecordList = ReturnMessageRecordList;

});
define("OutSystemsMaps.model$StaticMarkerRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$StaticMarkerRecord"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var StaticMarkerRecordList = (function (_super) {
__extends(StaticMarkerRecordList, _super);
function StaticMarkerRecordList(defaults) {
_super.apply(this, arguments);
}
StaticMarkerRecordList.itemType = OutSystemsMapsModel.StaticMarkerRecord;
return StaticMarkerRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.StaticMarkerRecordList = StaticMarkerRecordList;

});
define("OutSystemsMaps.model$FillList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsMaps.model", "OutSystemsMaps.model$FillRec"], function (exports, OutSystems, OutSystemsMapsModel) {
var OS = OutSystems.Internal;
var FillList = (function (_super) {
__extends(FillList, _super);
function FillList(defaults) {
_super.apply(this, arguments);
}
FillList.itemType = OutSystemsMapsModel.FillRec;
return FillList;
})(OS.DataTypes.GenericRecordList);
OutSystemsMapsModel.FillList = FillList;

});
define("OutSystemsMaps.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var OutSystemsMapsModel = exports;
Object.defineProperty(OutSystemsMapsModel, "module", {
get: function () {
return OS.ApplicationInfo.getModules()["95bb31d1-f079-4fd6-ab2e-5c8326855aaa"];
}
});

OutSystemsMapsModel.staticEntities = {};
OutSystemsMapsModel.staticEntities.logType = {};
var getLogTypeRecord = function (record) {
return OutSystemsMapsModel.module.staticEntities["00f4d392-689e-4d22-b7e4-fb21b53c5072"][record];
};
Object.defineProperty(OutSystemsMapsModel.staticEntities.logType, "general", {
get: function () {
return getLogTypeRecord("05ba06bb-e92c-48f6-80e4-59fa6027ed87");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.logType, "error", {
get: function () {
return getLogTypeRecord("184278a7-c1da-43ba-a648-ff6a0fa998f8");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.logType, "debug", {
get: function () {
return getLogTypeRecord("85417598-4189-43a5-985e-7f166e2ccf71");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.logType, "performance", {
get: function () {
return getLogTypeRecord("8830a485-47ca-48fe-94f4-51981f4d12b3");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.logType, "warning", {
get: function () {
return getLogTypeRecord("a4c9c84d-1612-4795-9cd9-eddd46ceb586");
}
});

OutSystemsMapsModel.staticEntities.mapErrors = {};
var getMapErrorsRecord = function (record) {
return OutSystemsMapsModel.module.staticEntities["0ae015e4-c953-4e33-aec0-91674d05cbf5"][record];
};
Object.defineProperty(OutSystemsMapsModel.staticEntities.mapErrors, "cFG_APIKeyAlreadySetStaticMap", {
get: function () {
return getMapErrorsRecord("0f831d7e-ee70-4c2a-9cf8-f80b5bdbf3ea");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.mapErrors, "aPI_FailedRemoveDirections", {
get: function () {
return getMapErrorsRecord("12583894-c5e3-42c9-9ddb-6619367173e5");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.mapErrors, "cFG_APIKeyAlreadySetMap", {
get: function () {
return getMapErrorsRecord("175088ab-952a-4b2a-ba19-e17797dc8816");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.mapErrors, "cFG_CantChangeParamsStaticMap", {
get: function () {
return getMapErrorsRecord("19598f13-d1c9-4434-b83b-b9b6a81956e9");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.mapErrors, "lIB_InvalidApiKeyMap", {
get: function () {
return getMapErrorsRecord("50d0d685-005b-4006-90cc-c9a1fa077387");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.mapErrors, "gEN_UnsupportedEventMap", {
get: function () {
return getMapErrorsRecord("5362bfe0-fceb-4cae-a0be-9d55fcfc5aaf");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.mapErrors, "cFG_InvalidPolylineShapeLocations", {
get: function () {
return getMapErrorsRecord("77efde4c-10fb-4c7e-9d6b-0ec4a93bf7bf");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.mapErrors, "lIB_InvalidApiKeyStaticMap", {
get: function () {
return getMapErrorsRecord("797b52d0-62ac-4b1b-b804-eee898a83b98");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.mapErrors, "lIB_FailedGeocodingShapeLocations", {
get: function () {
return getMapErrorsRecord("7c2c49bd-d8c1-4112-b78a-70076eb2e040");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.mapErrors, "gEN_InvalidChangePropertyMap", {
get: function () {
return getMapErrorsRecord("7c41d2e7-0a80-461a-a986-458120f7f1f0");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.mapErrors, "gEN_InvalidChangePropertyMarker", {
get: function () {
return getMapErrorsRecord("821715b4-659d-45d2-8332-944993d9101e");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.mapErrors, "lIB_FailedGeocodingMarker", {
get: function () {
return getMapErrorsRecord("af0f70d8-a4b3-4ac6-8b9c-18659afc9848");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.mapErrors, "gEN_UnsupportedEventShape", {
get: function () {
return getMapErrorsRecord("b6a198f1-5cb6-40b1-bdb8-124f5ac7408e");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.mapErrors, "gEN_UnsupportedEventMarker", {
get: function () {
return getMapErrorsRecord("bf033d7d-3fbe-460b-9a49-5183040a99ee");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.mapErrors, "cFG_InvalidPolygonShapeLocations", {
get: function () {
return getMapErrorsRecord("c6c90813-d484-4b48-8a6e-65c26ad61e54");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.mapErrors, "lIB_FailedSetDirections", {
get: function () {
return getMapErrorsRecord("d384ad4c-2ee4-401a-b4ee-dbfe48b16ea6");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.mapErrors, "gEN_InvalidChangePropertyShape", {
get: function () {
return getMapErrorsRecord("d3a70a7b-ba8c-4c4d-84e5-f5dedf319ac3");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.mapErrors, "lIB_FailedGeocodingMap", {
get: function () {
return getMapErrorsRecord("e02e6e2f-78cc-4b3b-bbfc-9769a3cee611");
}
});

OutSystemsMapsModel.staticEntities.shapeType = {};
var getShapeTypeRecord = function (record) {
return OutSystemsMapsModel.module.staticEntities["14fd2674-7979-4bb0-b74d-83a246b11f1f"][record];
};
Object.defineProperty(OutSystemsMapsModel.staticEntities.shapeType, "polyline", {
get: function () {
return getShapeTypeRecord("d38bdbfc-a543-4b0c-8d46-a918458c8567");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.shapeType, "polygon", {
get: function () {
return getShapeTypeRecord("efe8bc2d-0a59-478f-ac8e-4d4ec0ced28c");
}
});

OutSystemsMapsModel.staticEntities.popupEvent = {};
var getPopupEventRecord = function (record) {
return OutSystemsMapsModel.module.staticEntities["25c28812-61a5-472c-b946-caa03aeed4aa"][record];
};
Object.defineProperty(OutSystemsMapsModel.staticEntities.popupEvent, "onMouseover", {
get: function () {
return getPopupEventRecord("67ac79e4-f351-440e-8dbd-4e4682b74a62");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.popupEvent, "onMouseout", {
get: function () {
return getPopupEventRecord("758bb3bb-be4a-462f-b435-9f619e7d04d5");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.popupEvent, "onClick", {
get: function () {
return getPopupEventRecord("ab4a3f2c-09bf-413d-b802-08b908bbf0b7");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.popupEvent, "rightClick", {
get: function () {
return getPopupEventRecord("b4771495-2113-4142-accf-33ab49321635");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.popupEvent, "doubleClick", {
get: function () {
return getPopupEventRecord("efb935c6-8fd2-430b-8443-48a5d8372b06");
}
});

OutSystemsMapsModel.staticEntities.type = {};
var getTypeRecord = function (record) {
return OutSystemsMapsModel.module.staticEntities["321464c3-cb26-412f-b60a-1c7140dc8c1b"][record];
};
Object.defineProperty(OutSystemsMapsModel.staticEntities.type, "hybrid", {
get: function () {
return getTypeRecord("029187c2-5fe2-46af-b8d4-a583c7061bdb");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.type, "terrain", {
get: function () {
return getTypeRecord("0c4b34b6-05e3-400a-a07b-1818beec8b52");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.type, "roadmap", {
get: function () {
return getTypeRecord("68adf7a2-8657-4eb8-8c70-15837272cb12");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.type, "satellite", {
get: function () {
return getTypeRecord("b07cb01e-0e29-4968-b114-868e9deaf9c1");
}
});

OutSystemsMapsModel.staticEntities.shapeEvent = {};
var getShapeEventRecord = function (record) {
return OutSystemsMapsModel.module.staticEntities["381a1deb-bc9a-4931-8d1e-90177993e176"][record];
};
Object.defineProperty(OutSystemsMapsModel.staticEntities.shapeEvent, "onClick", {
get: function () {
return getShapeEventRecord("3cee2b83-e476-4cbc-86e8-cef7a9ae1be4");
}
});

OutSystemsMapsModel.staticEntities.markerType = {};
var getMarkerTypeRecord = function (record) {
return OutSystemsMapsModel.module.staticEntities["3d05f10a-28e9-4029-bb84-5ab7ade9e36a"][record];
};
Object.defineProperty(OutSystemsMapsModel.staticEntities.markerType, "markerPopup", {
get: function () {
return getMarkerTypeRecord("7c9806c2-68ee-42e3-8f06-7e0baa5bc9a9");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.markerType, "marker", {
get: function () {
return getMarkerTypeRecord("c93f15a4-6022-410c-b51f-ac5c5e0af8e1");
}
});

OutSystemsMapsModel.staticEntities.mapEvent = {};
var getMapEventRecord = function (record) {
return OutSystemsMapsModel.module.staticEntities["5caa5df9-dc3a-4864-874f-6ecf22baa80f"][record];
};
Object.defineProperty(OutSystemsMapsModel.staticEntities.mapEvent, "initialized", {
get: function () {
return getMapEventRecord("2dc33543-44dd-4256-90f9-89d6d7fe90f3");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.mapEvent, "onError", {
get: function () {
return getMapEventRecord("3b80fd8b-48b3-4216-9a88-93fc3ee9fe09");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.mapEvent, "onEventTriggered_DEPRECATED", {
get: function () {
return getMapEventRecord("75faa4d7-e9e0-49e6-ad41-35056bbafe81");
}
});

OutSystemsMapsModel.staticEntities.mapEventTriggered = {};
var getMapEventTriggeredRecord = function (record) {
return OutSystemsMapsModel.module.staticEntities["7cf2a964-5ef8-4901-abe6-e84cb6616a62"][record];
};
Object.defineProperty(OutSystemsMapsModel.staticEntities.mapEventTriggered, "dragEnd", {
get: function () {
return getMapEventTriggeredRecord("1e4fc6d3-f736-48a8-9794-fc52e3e05a2a");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.mapEventTriggered, "rightClick", {
get: function () {
return getMapEventTriggeredRecord("22a3a8eb-3d4e-47b8-af22-237ad82eb9d8");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.mapEventTriggered, "doubleClick", {
get: function () {
return getMapEventTriggeredRecord("291ac09a-41ad-4041-97d9-539e7ea4216c");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.mapEventTriggered, "click", {
get: function () {
return getMapEventTriggeredRecord("91de1dbe-ad22-465a-a1e2-bc4a2ab18cee");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.mapEventTriggered, "zoomChanged", {
get: function () {
return getMapEventTriggeredRecord("ae939fd4-46b8-41d3-b746-32369402d31b");
}
});

OutSystemsMapsModel.staticEntities.markerEvent = {};
var getMarkerEventRecord = function (record) {
return OutSystemsMapsModel.module.staticEntities["88306854-60f3-4fc9-b928-db3e0ca7f7b6"][record];
};
Object.defineProperty(OutSystemsMapsModel.staticEntities.markerEvent, "onClick", {
get: function () {
return getMarkerEventRecord("0e1a4832-f1b4-4062-93a1-e2fc39c117d4");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.markerEvent, "initialized", {
get: function () {
return getMarkerEventRecord("1e34c61a-9d7c-4ac3-92d0-48969917c483");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.markerEvent, "onMouseout", {
get: function () {
return getMarkerEventRecord("34dadaa9-cbe0-42a0-a563-f9c488519332");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.markerEvent, "onMouseover", {
get: function () {
return getMarkerEventRecord("beb2b6ca-56da-4da9-bd61-ee7d9cce70c4");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.markerEvent, "onEventTriggered", {
get: function () {
return getMarkerEventRecord("dbbbb4fc-d89c-47fb-b403-8bf6440d4598");
}
});

OutSystemsMapsModel.staticEntities.style = {};
var getStyleRecord = function (record) {
return OutSystemsMapsModel.module.staticEntities["a0adb83b-e208-4039-bc92-91d01b8e2081"][record];
};
Object.defineProperty(OutSystemsMapsModel.staticEntities.style, "silver", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getStyleRecord("039b612a-9671-4660-8713-4227c9c536e7"));
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.style, "standard", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getStyleRecord("46a675cf-0150-4fd0-9ac7-2c96f73da970"));
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.style, "dark", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getStyleRecord("517fb120-6b81-478c-a75c-4c917ffcca47"));
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.style, "night", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getStyleRecord("a13ac6f1-5b2f-4000-adbe-dce29adec7bd"));
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.style, "aubergine", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getStyleRecord("ef4b6628-727d-4fac-848e-5307eab5f9c2"));
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.style, "retro", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getStyleRecord("f46e0309-8397-48b0-a0e2-7f92e1f7965f"));
}
});

OutSystemsMapsModel.staticEntities.markerEventTriggered = {};
var getMarkerEventTriggeredRecord = function (record) {
return OutSystemsMapsModel.module.staticEntities["cf5812b2-bdc9-4eb2-8240-09f6367c6ad6"][record];
};
Object.defineProperty(OutSystemsMapsModel.staticEntities.markerEventTriggered, "doubleClick", {
get: function () {
return getMarkerEventTriggeredRecord("7ddaed11-1a2e-43e6-bc9c-a0b6043034e6");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.markerEventTriggered, "rightClick", {
get: function () {
return getMarkerEventTriggeredRecord("b87052cc-b00f-4924-9c30-e8b8b36f2062");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.markerEventTriggered, "dragEnd", {
get: function () {
return getMarkerEventTriggeredRecord("f9e91264-1aba-4202-a05b-1662779d618e");
}
});

OutSystemsMapsModel.staticEntities.mapType = {};
var getMapTypeRecord = function (record) {
return OutSystemsMapsModel.module.staticEntities["d4ae68c7-58a9-4003-96c0-e23e7c46b48a"][record];
};
Object.defineProperty(OutSystemsMapsModel.staticEntities.mapType, "googleStaticMaps", {
get: function () {
return getMapTypeRecord("9d3ad106-0c0f-412b-b820-e082881e3a19");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.mapType, "googleMaps", {
get: function () {
return getMapTypeRecord("b5b5ea77-144e-4419-9088-a873f127ddf5");
}
});

OutSystemsMapsModel.staticEntities.zoom = {};
var getZoomRecord = function (record) {
return OutSystemsMapsModel.module.staticEntities["e4acf07c-b38a-4871-a7c2-4017eaabe95c"][record];
};
Object.defineProperty(OutSystemsMapsModel.staticEntities.zoom, "zoom13", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getZoomRecord("0922ce32-4035-4463-a75a-d3f8b54f4f94"));
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.zoom, "zoom9", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getZoomRecord("11f603b5-040e-4f8a-b083-79c5267c71b6"));
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.zoom, "zoom10_City", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getZoomRecord("15bacab1-f45a-4fe2-ad76-baa770fdfeff"));
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.zoom, "zoom3", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getZoomRecord("2bf601f1-4db3-4c49-9845-b932615a32f1"));
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.zoom, "zoom15_Streets", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getZoomRecord("5499149d-d268-4120-a938-8cdad4846c48"));
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.zoom, "zoom20_Buildings", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getZoomRecord("7a19665e-df15-4f8d-b5c9-d0727ee0c621"));
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.zoom, "zoom19", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getZoomRecord("833f6b68-54dd-4abe-8610-4603e82b5426"));
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.zoom, "zoom7", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getZoomRecord("8dbf8113-5ad5-416b-a567-5bc6d084be7a"));
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.zoom, "zoom4", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getZoomRecord("8f578193-3014-4472-b852-0c41c470ce8e"));
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.zoom, "zoom16", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getZoomRecord("9aec5bf4-d8cc-46cb-90ec-4f4cc0e91468"));
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.zoom, "zoom5_Continent", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getZoomRecord("9b1873f3-33f4-4346-8e3c-ed2023f0bf27"));
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.zoom, "zoom18", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getZoomRecord("a73ab79e-3049-4e75-b45e-2a6bf0cd2341"));
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.zoom, "zoom11", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getZoomRecord("b9786be0-7e13-421d-bfb5-2846dd6384e4"));
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.zoom, "zoom1_World", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getZoomRecord("bf7ff033-06f7-4cc8-a42d-26349c212d9a"));
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.zoom, "zoom8", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getZoomRecord("bfcf13bd-f6e4-495f-a514-a3f608fc8092"));
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.zoom, "zoom2", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getZoomRecord("c617d3e9-ebcb-4dd3-bfa0-b7cf50a94489"));
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.zoom, "zoom6", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getZoomRecord("d0f47b1a-0256-417c-8c9a-25ffd0e62bc2"));
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.zoom, "zoom17", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getZoomRecord("e1a365bd-624a-4125-b484-afd05d80920b"));
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.zoom, "zoom12", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getZoomRecord("ebab583b-bb56-4179-827a-2cb7c814e48d"));
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.zoom, "zoom14", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getZoomRecord("f31f4a8c-76d5-4e1e-872e-89e885e7999f"));
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.zoom, "auto", {
get: function () {
return OS.BuiltinFunctions.textToInteger(getZoomRecord("fb39ba58-7d90-4803-802f-b11efd3cbcc5"));
}
});

OutSystemsMapsModel.staticEntities.verbosity = {};
var getVerbosityRecord = function (record) {
return OutSystemsMapsModel.module.staticEntities["e622b827-468a-483f-9c56-4d5bc2d8635b"][record];
};
Object.defineProperty(OutSystemsMapsModel.staticEntities.verbosity, "verbose", {
get: function () {
return getVerbosityRecord("61a2c631-05d7-42eb-b578-3b0797543db4");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.verbosity, "noLogging", {
get: function () {
return getVerbosityRecord("69095bec-b674-4249-a12d-325f2fcda9a0");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.verbosity, "error", {
get: function () {
return getVerbosityRecord("a023e852-9023-413c-810d-ea7810f573db");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.verbosity, "warning", {
get: function () {
return getVerbosityRecord("e09280f0-1e86-4e65-b66f-b3c6e515768e");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.verbosity, "log", {
get: function () {
return getVerbosityRecord("f158c567-b27d-4794-963e-e92f8c4b11a5");
}
});

OutSystemsMapsModel.staticEntities.shapeEventTriggered = {};
var getShapeEventTriggeredRecord = function (record) {
return OutSystemsMapsModel.module.staticEntities["ecd875a9-9c28-48b3-8693-d77fa52bfcb9"][record];
};
Object.defineProperty(OutSystemsMapsModel.staticEntities.shapeEventTriggered, "dragEnd", {
get: function () {
return getShapeEventTriggeredRecord("af409273-46ab-40ac-8448-bafec36488df");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.shapeEventTriggered, "shapeChanged", {
get: function () {
return getShapeEventTriggeredRecord("c3ffb978-1647-4d3f-8fc7-ff8018f96985");
}
});

OutSystemsMapsModel.staticEntities.travelMode = {};
var getTravelModeRecord = function (record) {
return OutSystemsMapsModel.module.staticEntities["fd1f3f9a-87ad-45fa-81b4-46a61da60671"][record];
};
Object.defineProperty(OutSystemsMapsModel.staticEntities.travelMode, "dRIVING", {
get: function () {
return getTravelModeRecord("01caf696-6b22-4fe3-bada-0e98f5c6e981");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.travelMode, "bICYCLING", {
get: function () {
return getTravelModeRecord("961b2b5c-94c2-4f2c-ae12-48755e6c8d4a");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.travelMode, "tRANSIT", {
get: function () {
return getTravelModeRecord("d9668e81-df51-4ae4-b653-053f6477fc13");
}
});

Object.defineProperty(OutSystemsMapsModel.staticEntities.travelMode, "wALKING", {
get: function () {
return getTravelModeRecord("f8ca5d81-b182-44c9-b790-8d92812454f1");
}
});

});
