﻿define("YESBankPOC.MainFlow.controller",["exports", "OutSystems/ClientRuntime/Main", "YESBankPOC.model", "YESBankPOC.controller", "YESBankPOC.Common.controller", "YESBankPOC.clientVariables"], function(exports, OutSystems, YESBankPOCModel, YESBankPOCController, YESBankPOC_CommonController, YESBankPOCClientVariables) {
	var OS = OutSystems.Internal;
	var YESBankPOC_MainFlowController = exports;
	var Controller = (function(_super) {
		__extends(Controller, _super);
		function Controller() {
			_super.apply(this, arguments);
		}
		Controller.prototype.getDefaultTimeout = function() {
			return YESBankPOCController.default.defaultTimeout;
		};
		Controller.prototype.handleError = function(ex, callContext) {
			var controller = this.controller;
			OS.Logger.trace("MainFlow", OS.Exceptions.getMessage(ex), ex.name);
			return YESBankPOC_CommonController.default.handleError(ex, callContext);


		};
		return Controller;
	}
	) (OS.Controller.BaseController);
	YESBankPOC_MainFlowController.default = new Controller();
});

