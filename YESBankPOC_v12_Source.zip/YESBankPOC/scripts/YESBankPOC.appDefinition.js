﻿define("YESBankPOC.appDefinition",["OutSystems/ClientRuntime/Main"], function(OutSystems) {
	var OS = OutSystems.Internal;
	return {
		environmentKey: "b580868a-b86d-467d-b601-f21000d92a52",
		environmentName: "Development",
		applicationKey: "326d75eb-e3e0-486c-8c55-057237e78f2e",
		applicationName: "YESBank-POC",
		userProviderName: "Users",
		debugEnabled: false,
		homeModuleName: "YESBankPOC",
		homeModuleKey: "e474b255-7273-4204-ac0d-c5ea5320148d",
		homeModuleControllerName: "YESBankPOC.controller",
		homeModuleLanguageResourcesName: "YESBankPOC.languageResources",
		defaultTransition: "Fade",
		errorPageConfig: {
			showExceptionStack: false
		}
		,
		isWeb: true,
		personalArea: null,
		showWatermark: false
	};
});
