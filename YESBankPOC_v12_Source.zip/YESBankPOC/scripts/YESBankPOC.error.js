﻿try {
	require(["es6-promise", "tslib"], function(es6promise, tslib) {
		require(["OutSystems/ClientRuntime/Main", "YESBankPOC.appDefinition"], function(OutSystems, YESBankPOCAppDefinition) {
			var OS = OutSystems.Internal;
			OS.Settings.setPlatformSettings( {
				IndexedDBOffline: false,
				UseNewWebSQLImpl: false
			}
			);
			OS.ErrorScreen.initializeErrorPage(YESBankPOCAppDefinition, OS.Application);
		}
		);
	}
	);
} catch (ex) {
	console.error(e);
}

