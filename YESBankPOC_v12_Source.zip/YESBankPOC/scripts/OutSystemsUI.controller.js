﻿define("OutSystemsUI.controller$AddFavicon", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$AddFavicon.AddFaviconJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_AddFavicon_AddFaviconJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.addFavicon$Action = function (uRLIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.AddFavicon$vars"))());
vars.value.uRLInLocal = uRLIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:_0NYWTTYl0ycqAqbD2ODmA:/ClientActionFlows._0NYWTTYl0ycqAqbD2ODmA:Z425_y+sRVQjgldl6Ah_HA", "OutSystemsUI", "AddFavicon", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:R1cjlwOFUEeCXdUQnR+0jw", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZB3jt8cO6UyAPUoqxcSYmA", callContext.id);
// Add favicon to your project
controller.safeExecuteJSNode(OutSystemsUI_controller_AddFavicon_AddFaviconJS, "AddFavicon", "AddFavicon", {
URL: OS.DataConversion.JSNodeParamConverter.to(vars.value.uRLInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:7FkirfGRwUmbJAkF3xWlsw", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:_0NYWTTYl0ycqAqbD2ODmA", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.AddFavicon$vars", [{
name: "URL",
attrName: "uRLInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.addFavicon$Action = function (uRLIn) {
uRLIn = (uRLIn === undefined) ? "" : uRLIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.addFavicon$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(uRLIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$AddFavicon.AddFaviconJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var link = document.querySelector("link[rel*='icon']") || document.createElement('link');
link.type = 'image/x-icon';
link.rel = 'shortcut icon';
link.href = $parameters.URL;
document.getElementsByTagName('head')[0].appendChild(link);
};
});

define("OutSystemsUI.controller$BinaryToURLImage", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$BinaryToURLImage.JsBinaryToBase64JS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_BinaryToURLImage_JsBinaryToBase64JS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.binaryToURLImage$Action = function (imageIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.BinaryToURLImage$vars"))());
vars.value.imageInLocal = imageIn;
var jsBinaryToBase64JSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.BinaryToURLImage$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.jsBinaryToBase64JSResult = jsBinaryToBase64JSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:hpEuNetfiEerhxAiMSbrQQ:/ClientActionFlows.hpEuNetfiEerhxAiMSbrQQ:HQD8eL4joPfBvwkqEaHdWg", "OutSystemsUI", "BinaryToURLImage", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:6_chTCWxTEKRvUATn0WuUg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:HoTpRIE1m0e2MkudNr4zSg", callContext.id);
// Script to convert base64 into binary data.
jsBinaryToBase64JSResult.value = controller.safeExecuteJSNode(OutSystemsUI_controller_BinaryToURLImage_JsBinaryToBase64JS, "JsBinaryToBase64", "BinaryToURLImage", {
Binary: OS.DataConversion.JSNodeParamConverter.to(vars.value.imageInLocal, OS.Types.BinaryData),
Base64: OS.DataConversion.JSNodeParamConverter.to("", OS.Types.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsUI.BinaryToURLImage$jsBinaryToBase64JSResult"))();
jsNodeResult.base64Out = OS.DataConversion.JSNodeParamConverter.from($parameters.Base64, OS.Types.Text);
return jsNodeResult;
}, {}, {});
// Set Image URL
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ISMbm2SpY0KnWedxlbL5Uw", callContext.id);
// URL = "data:image/gif;base64," + JsBinaryToBase64.Base64
outVars.value.uRLOut = ("data:image/gif;base64," + jsBinaryToBase64JSResult.value.base64Out);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:D16PzPiI8kSjZFs4QGscNw", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:hpEuNetfiEerhxAiMSbrQQ", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.BinaryToURLImage$vars", [{
name: "Image",
attrName: "imageInLocal",
mandatory: true,
dataType: OS.Types.BinaryData,
defaultValue: function () {
return OS.DataTypes.BinaryData.defaultValue;
}
}]);
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.BinaryToURLImage$jsBinaryToBase64JSResult", [{
name: "Base64",
attrName: "base64Out",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.BinaryToURLImage$outVars", [{
name: "URL",
attrName: "uRLOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.binaryToURLImage$Action = function (imageIn) {
imageIn = (imageIn === undefined) ? OS.DataTypes.BinaryData.defaultValue : imageIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.binaryToURLImage$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(imageIn, OS.Types.BinaryData)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
URL: OS.DataConversion.JSNodeParamConverter.to(actionResults.uRLOut, OS.Types.Text)
};
});
};
});
define("OutSystemsUI.controller$BinaryToURLImage.JsBinaryToBase64JS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.Base64 = $parameters.Binary;
};
});

define("OutSystemsUI.controller$CarouselDisableSwipe", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$CarouselDisableSwipe.AddClassNoSwipeJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_CarouselDisableSwipe_AddClassNoSwipeJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.carouselDisableSwipe$Action = function (carouselIDIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.CarouselDisableSwipe$vars"))());
vars.value.carouselIDInLocal = carouselIDIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:SAFhfi45BU6VeqYFazfRRg:/ClientActionFlows.SAFhfi45BU6VeqYFazfRRg:D15QJoDg7Ut5_m57hWVGeQ", "OutSystemsUI", "CarouselDisableSwipe", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:X0580Gn280imj6vUP3PEwA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:EA76gLu_y0WEapiQoFodxg", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_CarouselDisableSwipe_AddClassNoSwipeJS, "AddClassNoSwipe", "CarouselDisableSwipe", {
CarouselID: OS.DataConversion.JSNodeParamConverter.to(vars.value.carouselIDInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:PqihoXYUMkKbUMgD_UvU5w", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:SAFhfi45BU6VeqYFazfRRg", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.CarouselDisableSwipe$vars", [{
name: "CarouselID",
attrName: "carouselIDInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.carouselDisableSwipe$Action = function (carouselIDIn) {
carouselIDIn = (carouselIDIn === undefined) ? "" : carouselIDIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.carouselDisableSwipe$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(carouselIDIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$CarouselDisableSwipe.AddClassNoSwipeJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var elem = document.getElementById($parameters.CarouselID).querySelector('.carousel');

if(elem) {
    elem.classList.add('no-swipe');
}
};
});

define("OutSystemsUI.controller$CarouselGoTo", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$CarouselGoTo.CallGoToActionJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_CarouselGoTo_CallGoToActionJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.carouselGoTo$Action = function (widgetIdIn, targetIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.CarouselGoTo$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
vars.value.targetInLocal = targetIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:Z5AAPK6NwEC74YLVRyAFLQ:/ClientActionFlows.Z5AAPK6NwEC74YLVRyAFLQ:ds3GnwE3FNruQba8+tCuyg", "OutSystemsUI", "CarouselGoTo", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:g8Q4KSOw+kesTnGRUDg74Q", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:dBRtEJ1oXUeFmuSC_CWu9Q", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_CarouselGoTo_CallGoToActionJS, "CallGoToAction", "CarouselGoTo", {
Target: OS.DataConversion.JSNodeParamConverter.to(vars.value.targetInLocal, OS.Types.Integer),
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:mDXwbVp8BE+5mlkO+9_7nQ", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:Z5AAPK6NwEC74YLVRyAFLQ", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.CarouselGoTo$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Target",
attrName: "targetInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
OutSystemsUIController.default.clientActionProxies.carouselGoTo$Action = function (widgetIdIn, targetIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
targetIn = (targetIn === undefined) ? 0 : targetIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.carouselGoTo$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(targetIn, OS.Types.Integer)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$CarouselGoTo.CallGoToActionJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var element = document.getElementById($parameters.WidgetId).querySelector('.carousel-container-content').goto($parameters.Target);
};
});

define("OutSystemsUI.controller$CarouselNext", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$CarouselNext.CallNextActionJS", "OutSystemsUI.controller$IsRTL"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_CarouselNext_CallNextActionJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.carouselNext$Action = function (widgetIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.CarouselNext$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:s3o2xkm11kWBC1DM24ANFA:/ClientActionFlows.s3o2xkm11kWBC1DM24ANFA:MRlu927xaJNuM0SHsPqwkQ", "OutSystemsUI", "CarouselNext", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:UlUeFYUFyk6CQLCV7HGwwg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:53BVu_67OUOpcv5eedIWzw", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_CarouselNext_CallNextActionJS, "CallNextAction", "CarouselNext", {
IsRTL: OS.DataConversion.JSNodeParamConverter.to(OutSystemsDebugger.handleFunctionCall(function () {
return OutSystemsUIController.default.isRTL$Action(callContext).isRTLOut;
}, OS.Types.Boolean, callContext.id), OS.Types.Boolean),
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:CfcmfBv7PE6zw+XQkz6LhQ", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:s3o2xkm11kWBC1DM24ANFA", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.CarouselNext$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.carouselNext$Action = function (widgetIdIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.carouselNext$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$CarouselNext.CallNextActionJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var element;
if($parameters.IsRTL){
    element = document.getElementById($parameters.WidgetId).querySelector('.carousel-container-content').previous();
} else{
    element = document.getElementById($parameters.WidgetId).querySelector('.carousel-container-content').next();
}

};
});

define("OutSystemsUI.controller$CarouselPrevious", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$CarouselPrevious.CallPreviousActionJS", "OutSystemsUI.controller$IsRTL"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_CarouselPrevious_CallPreviousActionJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.carouselPrevious$Action = function (widgetIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.CarouselPrevious$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:CffDzLB_b06BcWvnmqj02w:/ClientActionFlows.CffDzLB_b06BcWvnmqj02w:wwcdszOo59p8oJR15nAL8A", "OutSystemsUI", "CarouselPrevious", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:iABzbqhH5EG01r7OLD2N+g", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:mfJ8xdFCcEm0t1Gi9snU+Q", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_CarouselPrevious_CallPreviousActionJS, "CallPreviousAction", "CarouselPrevious", {
IsRTL: OS.DataConversion.JSNodeParamConverter.to(OutSystemsDebugger.handleFunctionCall(function () {
return OutSystemsUIController.default.isRTL$Action(callContext).isRTLOut;
}, OS.Types.Boolean, callContext.id), OS.Types.Boolean),
IdCarousel: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:nFHHZdm9Fkmgy91n4K5uSA", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:CffDzLB_b06BcWvnmqj02w", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.CarouselPrevious$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.carouselPrevious$Action = function (widgetIdIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.carouselPrevious$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$CarouselPrevious.CallPreviousActionJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var element;

if($parameters.IsRTL){
    element = document.getElementById($parameters.IdCarousel).querySelector('.carousel-container-content').next();
} else{
    element = document.getElementById($parameters.IdCarousel).querySelector('.carousel-container-content').previous();
}

};
});

define("OutSystemsUI.controller$CarouselUpdate", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$CarouselUpdate.CallUpdateActionJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_CarouselUpdate_CallUpdateActionJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.carouselUpdate$Action = function (widgetIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.CarouselUpdate$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:Q9gj08KLHEKuYcqlD371lQ:/ClientActionFlows.Q9gj08KLHEKuYcqlD371lQ:o_8aYga1jD4AegVoLG7Fqg", "OutSystemsUI", "CarouselUpdate", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:FUpJO9Gw5US7hEcadm2mpQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:LrnR4YHuPEaFFAmbmSTz1Q", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_CarouselUpdate_CallUpdateActionJS, "CallUpdateAction", "CarouselUpdate", {
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:PMNXmASQ7EWX0M3vuqW2uA", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:Q9gj08KLHEKuYcqlD371lQ", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.CarouselUpdate$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.carouselUpdate$Action = function (widgetIdIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.carouselUpdate$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$CarouselUpdate.CallUpdateActionJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var element = document.getElementById($parameters.WidgetId).querySelector('.carousel-container-content').updateCarousel();
};
});

define("OutSystemsUI.controller$ConfigureOfflineDataSync", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$ConfigureOfflineDataSync.ConfigureOfflineDataSyncJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_ConfigureOfflineDataSync_ConfigureOfflineDataSyncJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.configureOfflineDataSync$Action = function (syncOnOnlineIn, syncOnResumeIn, retryOnErrorIn, retryIntervalInSecondsIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.ConfigureOfflineDataSync$vars"))());
vars.value.syncOnOnlineInLocal = syncOnOnlineIn;
vars.value.syncOnResumeInLocal = syncOnResumeIn;
vars.value.retryOnErrorInLocal = retryOnErrorIn;
vars.value.retryIntervalInSecondsInLocal = retryIntervalInSecondsIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:wlq1EEBDSk6XBVqBnqrN_w:/ClientActionFlows.wlq1EEBDSk6XBVqBnqrN_w:2cSasMUYyxMLULWUER6qdQ", "OutSystemsUI", "ConfigureOfflineDataSync", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:dDeqycVUN0SauMDQ4RwX3Q", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Q3ziLgpmwEiLfbtrD1nU_A", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_ConfigureOfflineDataSync_ConfigureOfflineDataSyncJS, "ConfigureOfflineDataSync", "ConfigureOfflineDataSync", {
SyncOnResume: OS.DataConversion.JSNodeParamConverter.to(vars.value.syncOnResumeInLocal, OS.Types.Boolean),
RetryIntervalInSeconds: OS.DataConversion.JSNodeParamConverter.to(vars.value.retryIntervalInSecondsInLocal, OS.Types.Integer),
SyncOnOnline: OS.DataConversion.JSNodeParamConverter.to(vars.value.syncOnOnlineInLocal, OS.Types.Boolean),
RetryOnError: OS.DataConversion.JSNodeParamConverter.to(vars.value.retryOnErrorInLocal, OS.Types.Boolean)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:cata8UPkrUmg_S6Y1sbHKw", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:wlq1EEBDSk6XBVqBnqrN_w", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.ConfigureOfflineDataSync$vars", [{
name: "SyncOnOnline",
attrName: "syncOnOnlineInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "SyncOnResume",
attrName: "syncOnResumeInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "RetryOnError",
attrName: "retryOnErrorInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "RetryIntervalInSeconds",
attrName: "retryIntervalInSecondsInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
OutSystemsUIController.default.clientActionProxies.configureOfflineDataSync$Action = function (syncOnOnlineIn, syncOnResumeIn, retryOnErrorIn, retryIntervalInSecondsIn) {
syncOnOnlineIn = (syncOnOnlineIn === undefined) ? false : syncOnOnlineIn;
syncOnResumeIn = (syncOnResumeIn === undefined) ? false : syncOnResumeIn;
retryOnErrorIn = (retryOnErrorIn === undefined) ? false : retryOnErrorIn;
retryIntervalInSecondsIn = (retryIntervalInSecondsIn === undefined) ? 0 : retryIntervalInSecondsIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.configureOfflineDataSync$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(syncOnOnlineIn, OS.Types.Boolean), OS.DataConversion.JSNodeParamConverter.from(syncOnResumeIn, OS.Types.Boolean), OS.DataConversion.JSNodeParamConverter.from(retryOnErrorIn, OS.Types.Boolean), OS.DataConversion.JSNodeParamConverter.from(retryIntervalInSecondsIn, OS.Types.Integer)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$ConfigureOfflineDataSync.ConfigureOfflineDataSyncJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
window.offlineDataSync.configure(
    $parameters.SyncOnOnline,
    $parameters.SyncOnResume,
    $parameters.RetryOnError,
    $parameters.RetryIntervalInSeconds);

};
});

define("OutSystemsUI.controller$DatePickerClearInputDate", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$DatePickerClearInputDate.ClearDateJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_DatePickerClearInputDate_ClearDateJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.datePickerClearInputDate$Action = function (inputIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.DatePickerClearInputDate$vars"))());
vars.value.inputIdInLocal = inputIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:ZkPC3kYsK0+u70AN5Ynciw:/ClientActionFlows.ZkPC3kYsK0+u70AN5Ynciw:QOoArkE1w4zIqlX3DREFdg", "OutSystemsUI", "DatePickerClearInputDate", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:pDLWshK5Ik+7QrM+4prHhg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:24BYYGogjEamX0Nv0eDlVA", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_DatePickerClearInputDate_ClearDateJS, "ClearDate", "DatePickerClearInputDate", {
widgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.inputIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:MEU8EdFMN0q_aDPX2sgtNA", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:ZkPC3kYsK0+u70AN5Ynciw", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.DatePickerClearInputDate$vars", [{
name: "InputId",
attrName: "inputIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.datePickerClearInputDate$Action = function (inputIdIn) {
inputIdIn = (inputIdIn === undefined) ? "" : inputIdIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.datePickerClearInputDate$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(inputIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$DatePickerClearInputDate.ClearDateJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var widget = document.getElementById($parameters.widgetId);

if(widget) {
    try {
        widget.clearDate();
    } catch (e) {
        console.warn('The action ClearDatePickerInput only works when bounding a DatePicker to an input widget');
    }
}
};
});

define("OutSystemsUI.controller$DatepickerExposeTranslations", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.model$TextTextTextTextTextWeekday1Weekday2Weekday3Weekday4Weekday5Weekday6Weekday7RecordListWeekdayShort1WeekdayShort2WeekRecordList", "OutSystemsUI.model$TextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextShortcutsDialog1ShortcutsDialog2RecordList"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.datepickerExposeTranslations$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.DatepickerExposeTranslations$outVars"))());
varBag.callContext = callContext;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:EmOJTVVnHUKuypR_b66DFA:/ClientActionFlows.EmOJTVVnHUKuypR_b66DFA:lhJcZrmNbcnUQJdGVmCxtw", "OutSystemsUI", "DatepickerExposeTranslations", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZryHpmudIUOYCE6zOeN+mA", callContext.id);
// i18n Defaults Translations
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Vv4YFHDbXk2n5y8ZtIvrxg", callContext.id);
// i18nDefaults.Current.PreviousMonth = "Previous Month"
outVars.value.i18nDefaultsOut.getCurrent(callContext.iterationContext).previousMonthAttr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("1fCvKiR860iF8y93wqzElg#Value.1784051735.1", "Previous Month");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Vv4YFHDbXk2n5y8ZtIvrxg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// i18nDefaults.Current.NextMonth = "Next Month"
outVars.value.i18nDefaultsOut.getCurrent(callContext.iterationContext).nextMonthAttr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("FRQkwo9Yp0iVKYmvglli4w#Value.-766743789.1", "Next Month");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Vv4YFHDbXk2n5y8ZtIvrxg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// i18nDefaults.Current.TodayButton = "Today"
outVars.value.i18nDefaultsOut.getCurrent(callContext.iterationContext).todayButtonAttr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("c93RG+ceD0WdMhhBlgm7sA#Value.80981793.1", "Today");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Vv4YFHDbXk2n5y8ZtIvrxg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// i18nDefaults.Current.Midnight = "Midnight"
outVars.value.i18nDefaultsOut.getCurrent(callContext.iterationContext).midnightAttr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("tI9n5r_Dx0iO64Cd0TsZQg#Value.-1576218896.1", "Midnight");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Vv4YFHDbXk2n5y8ZtIvrxg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// i18nDefaults.Current.Noon = "Noon"
outVars.value.i18nDefaultsOut.getCurrent(callContext.iterationContext).noonAttr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("7JkNQfmve0ybQuEBCcmHfw#Value.2433920.1", "Noon");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Vv4YFHDbXk2n5y8ZtIvrxg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// i18nDefaults.Current.Months.Current.Month1 = "January"
outVars.value.i18nDefaultsOut.getCurrent(callContext.iterationContext).monthsAttr.getCurrent(callContext.iterationContext).month1Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("Elw2vXw960izxzIMvM1qpA#Value.-162006966.1", "January");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Vv4YFHDbXk2n5y8ZtIvrxg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// i18nDefaults.Current.Months.Current.Month2 = "February"
outVars.value.i18nDefaultsOut.getCurrent(callContext.iterationContext).monthsAttr.getCurrent(callContext.iterationContext).month2Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("4BHq85s+VE+IylptE9ZukQ#Value.-199248958.1", "February");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Vv4YFHDbXk2n5y8ZtIvrxg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "8");
// i18nDefaults.Current.Months.Current.Month3 = "March"
outVars.value.i18nDefaultsOut.getCurrent(callContext.iterationContext).monthsAttr.getCurrent(callContext.iterationContext).month3Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("mbDBy4VjB0SzzkLzOXUdFg#Value.74113571.1", "March");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Vv4YFHDbXk2n5y8ZtIvrxg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "9");
// i18nDefaults.Current.Months.Current.Month4 = "April"
outVars.value.i18nDefaultsOut.getCurrent(callContext.iterationContext).monthsAttr.getCurrent(callContext.iterationContext).month4Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("jNVk7nRwUkKdBhDRLgvUag#Value.63478374.1", "April");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Vv4YFHDbXk2n5y8ZtIvrxg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "10");
// i18nDefaults.Current.Months.Current.Month5 = "May"
outVars.value.i18nDefaultsOut.getCurrent(callContext.iterationContext).monthsAttr.getCurrent(callContext.iterationContext).month5Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("Ew9YPH2yzEGI5SqyvW_2sQ#Value.77125.1", "May");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Vv4YFHDbXk2n5y8ZtIvrxg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "11");
// i18nDefaults.Current.Months.Current.Month6 = "June"
outVars.value.i18nDefaultsOut.getCurrent(callContext.iterationContext).monthsAttr.getCurrent(callContext.iterationContext).month6Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("q6eCYPoiPE6Z8gtzavUUWg#Value.2320482.1", "June");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Vv4YFHDbXk2n5y8ZtIvrxg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "12");
// i18nDefaults.Current.Months.Current.Month7 = "July"
outVars.value.i18nDefaultsOut.getCurrent(callContext.iterationContext).monthsAttr.getCurrent(callContext.iterationContext).month7Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("OG7OPs09EEmIHvBtd09u5Q#Value.2320440.1", "July");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Vv4YFHDbXk2n5y8ZtIvrxg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "13");
// i18nDefaults.Current.Months.Current.Month8 = "August"
outVars.value.i18nDefaultsOut.getCurrent(callContext.iterationContext).monthsAttr.getCurrent(callContext.iterationContext).month8Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("ZIkkytkF00C62bRH6ZRMcA#Value.1972131363.1", "August");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Vv4YFHDbXk2n5y8ZtIvrxg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "14");
// i18nDefaults.Current.Months.Current.Month9 = "September"
outVars.value.i18nDefaultsOut.getCurrent(callContext.iterationContext).monthsAttr.getCurrent(callContext.iterationContext).month9Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("nX8TB7S5xkW2vLpNGzji6A#Value.-25881423.1", "September");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Vv4YFHDbXk2n5y8ZtIvrxg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "15");
// i18nDefaults.Current.Months.Current.Month10 = "October"
outVars.value.i18nDefaultsOut.getCurrent(callContext.iterationContext).monthsAttr.getCurrent(callContext.iterationContext).month10Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("9LIV9yDE20eRBuqb7_MUNQ#Value.43165376.1", "October");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Vv4YFHDbXk2n5y8ZtIvrxg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "16");
// i18nDefaults.Current.Months.Current.Month11 = "November"
outVars.value.i18nDefaultsOut.getCurrent(callContext.iterationContext).monthsAttr.getCurrent(callContext.iterationContext).month11Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("duL0nCW7+0uMBTLcjoL7Xg#Value.1703773522.1", "November");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Vv4YFHDbXk2n5y8ZtIvrxg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "17");
// i18nDefaults.Current.Months.Current.Month12 = "December"
outVars.value.i18nDefaultsOut.getCurrent(callContext.iterationContext).monthsAttr.getCurrent(callContext.iterationContext).month12Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("mSVpIhn5x0WuqHFplsMTFw#Value.626483269.1", "December");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Vv4YFHDbXk2n5y8ZtIvrxg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "18");
// i18nDefaults.Current.Weekdays.Current.Weekday1 = "Sunday"
outVars.value.i18nDefaultsOut.getCurrent(callContext.iterationContext).weekdaysAttr.getCurrent(callContext.iterationContext).weekday1Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("PP+e0FO51k2OuDR1+EhorQ#Value.-1807319568.1", "Sunday");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Vv4YFHDbXk2n5y8ZtIvrxg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "19");
// i18nDefaults.Current.Weekdays.Current.Weekday2 = "Monday"
outVars.value.i18nDefaultsOut.getCurrent(callContext.iterationContext).weekdaysAttr.getCurrent(callContext.iterationContext).weekday2Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("WV8_eD4RTE61GB2a0BkwuQ#Value.-1984635600.1", "Monday");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Vv4YFHDbXk2n5y8ZtIvrxg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "20");
// i18nDefaults.Current.Weekdays.Current.Weekday3 = "Tuesday"
outVars.value.i18nDefaultsOut.getCurrent(callContext.iterationContext).weekdaysAttr.getCurrent(callContext.iterationContext).weekday3Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("CdvV1OKrjUSoC4jJteUE6A#Value.687309357.1", "Tuesday");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Vv4YFHDbXk2n5y8ZtIvrxg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "21");
// i18nDefaults.Current.Weekdays.Current.Weekday4 = "Wednesday"
outVars.value.i18nDefaultsOut.getCurrent(callContext.iterationContext).weekdaysAttr.getCurrent(callContext.iterationContext).weekday4Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("2cEIAtVIlES4bU387yYKFA#Value.-897468618.1", "Wednesday");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Vv4YFHDbXk2n5y8ZtIvrxg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "22");
// i18nDefaults.Current.Weekdays.Current.Weekday5 = "Thursday"
outVars.value.i18nDefaultsOut.getCurrent(callContext.iterationContext).weekdaysAttr.getCurrent(callContext.iterationContext).weekday5Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("rZxYcEOLE0SMy_WUK1USbg#Value.1636699642.1", "Thursday");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Vv4YFHDbXk2n5y8ZtIvrxg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "23");
// i18nDefaults.Current.Weekdays.Current.Weekday6 = "Friday"
outVars.value.i18nDefaultsOut.getCurrent(callContext.iterationContext).weekdaysAttr.getCurrent(callContext.iterationContext).weekday6Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("PTUebe2ghUGIcIlmoiHGTA#Value.2112549247.1", "Friday");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Vv4YFHDbXk2n5y8ZtIvrxg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "24");
// i18nDefaults.Current.Weekdays.Current.Weekday7 = "Saturday"
outVars.value.i18nDefaultsOut.getCurrent(callContext.iterationContext).weekdaysAttr.getCurrent(callContext.iterationContext).weekday7Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("fxhdUHdd30WEIUqlUd3Dgg#Value.-2049557543.1", "Saturday");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Vv4YFHDbXk2n5y8ZtIvrxg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "25");
// i18nDefaults.Current.WeekdaysShort.Current.WeekdayShort1 = "Sun"
outVars.value.i18nDefaultsOut.getCurrent(callContext.iterationContext).weekdaysShortAttr.getCurrent(callContext.iterationContext).weekdayShort1Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("Q0atH4XnxESfNPKXcNCMhg#Value.83500.1", "Sun");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Vv4YFHDbXk2n5y8ZtIvrxg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "26");
// i18nDefaults.Current.WeekdaysShort.Current.WeekdayShort2 = "Mon"
outVars.value.i18nDefaultsOut.getCurrent(callContext.iterationContext).weekdaysShortAttr.getCurrent(callContext.iterationContext).weekdayShort2Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("pWtYDFh+oEGF3oMu1ST3SA#Value.77548.1", "Mon");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Vv4YFHDbXk2n5y8ZtIvrxg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "27");
// i18nDefaults.Current.WeekdaysShort.Current.WeekdayShort3 = "Tue"
outVars.value.i18nDefaultsOut.getCurrent(callContext.iterationContext).weekdaysShortAttr.getCurrent(callContext.iterationContext).weekdayShort3Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("TxFtPzJ8eEmwSbWV_8uB3w#Value.84452.1", "Tue");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Vv4YFHDbXk2n5y8ZtIvrxg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "28");
// i18nDefaults.Current.WeekdaysShort.Current.WeekdayShort4 = "Wed"
outVars.value.i18nDefaultsOut.getCurrent(callContext.iterationContext).weekdaysShortAttr.getCurrent(callContext.iterationContext).weekdayShort4Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("n_faF_hqU0qU+TQPqypwbg#Value.86838.1", "Wed");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Vv4YFHDbXk2n5y8ZtIvrxg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "29");
// i18nDefaults.Current.WeekdaysShort.Current.WeekdayShort5 = "Thu"
outVars.value.i18nDefaultsOut.getCurrent(callContext.iterationContext).weekdaysShortAttr.getCurrent(callContext.iterationContext).weekdayShort5Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("C5ZwndaAOUOl74fkEmefDw#Value.84065.1", "Thu");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Vv4YFHDbXk2n5y8ZtIvrxg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "30");
// i18nDefaults.Current.WeekdaysShort.Current.WeekdayShort6 = "Fri"
outVars.value.i18nDefaultsOut.getCurrent(callContext.iterationContext).weekdaysShortAttr.getCurrent(callContext.iterationContext).weekdayShort6Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("7Dxp7GHv9kO9AEdEXQqPGA#Value.70909.1", "Fri");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Vv4YFHDbXk2n5y8ZtIvrxg", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "31");
// i18nDefaults.Current.WeekdaysShort.Current.WeekdayShort7 = "Sat"
outVars.value.i18nDefaultsOut.getCurrent(callContext.iterationContext).weekdaysShortAttr.getCurrent(callContext.iterationContext).weekdayShort7Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("wupNrsljn0+ZgKsDAgws7w#Value.82886.1", "Sat");
// i18n Accessibility Translations
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZnZvYqAqnkC8lMuM5PuscA", callContext.id);
// i18nAccessibility.Current.IsDisabled = "Disabled. "
outVars.value.i18nAccessibilityOut.getCurrent(callContext.iterationContext).isDisabledAttr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("0JFpmf26qEmLPKk06zPUDg#Value.374566222.1", "Disabled. ");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZnZvYqAqnkC8lMuM5PuscA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// i18nAccessibility.Current.IsToday = "Is Today. "
outVars.value.i18nAccessibilityOut.getCurrent(callContext.iterationContext).isTodayAttr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("iqF5Pqcm+EuQgVmDvcRfXQ#Value.1584999357.1", "Is Today. ");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZnZvYqAqnkC8lMuM5PuscA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "3");
// i18nAccessibility.Current.DaySelected = "Day selected. "
outVars.value.i18nAccessibilityOut.getCurrent(callContext.iterationContext).daySelectedAttr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("pXZo0bRIl0KKarFWqwJMoA#Value.997213361.1", "Day selected. ");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZnZvYqAqnkC8lMuM5PuscA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "4");
// i18nAccessibility.Current.HasEvent = "Has event. "
outVars.value.i18nAccessibilityOut.getCurrent(callContext.iterationContext).hasEventAttr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("s6Mc6dzsq0O31GbSo7QbpQ#Value.-1258432986.1", "Has event. ");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZnZvYqAqnkC8lMuM5PuscA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "5");
// i18nAccessibility.Current.DaysInRange = "Day is in range. "
outVars.value.i18nAccessibilityOut.getCurrent(callContext.iterationContext).daysInRangeAttr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("nmdHfe62kkWmZZi8twrJvg#Value.-1662297402.1", "Day is in range. ");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZnZvYqAqnkC8lMuM5PuscA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "6");
// i18nAccessibility.Current.StartRange = "Start range. "
outVars.value.i18nAccessibilityOut.getCurrent(callContext.iterationContext).startRangeAttr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("6yUVQvdC90Gm4KUFQBj81w#Value.1774776785.1", "Start range. ");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZnZvYqAqnkC8lMuM5PuscA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "7");
// i18nAccessibility.Current.EndRange = "End range. "
outVars.value.i18nAccessibilityOut.getCurrent(callContext.iterationContext).endRangeAttr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("Ou2_Lg3vvEe3aQ7GWyGPBQ#Value.979281226.1", "End range. ");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZnZvYqAqnkC8lMuM5PuscA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "8");
// i18nAccessibility.Current.Navigation = "navigation"
outVars.value.i18nAccessibilityOut.getCurrent(callContext.iterationContext).navigationAttr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("q2HVeR5fq06ujvR8mwXC1g#Value.1862666772.1", "navigation");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZnZvYqAqnkC8lMuM5PuscA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "9");
// i18nAccessibility.Current.Month = "month"
outVars.value.i18nAccessibilityOut.getCurrent(callContext.iterationContext).monthAttr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("iKX__y0GCEK4HvMWgzSWjA#Value.104080000.1", "month");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZnZvYqAqnkC8lMuM5PuscA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "10");
// i18nAccessibility.Current.Year = "year"
outVars.value.i18nAccessibilityOut.getCurrent(callContext.iterationContext).yearAttr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("H6apzIN1TUKPQopWFy0zBw#Value.3704893.1", "year");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZnZvYqAqnkC8lMuM5PuscA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "11");
// i18nAccessibility.Current.KeyboardShortcuts = "Keyboard shortcuts"
outVars.value.i18nAccessibilityOut.getCurrent(callContext.iterationContext).keyboardShortcutsAttr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("k2YfRkJbhkWi6MaJmqxhJg#Value.1665633300.1", "Keyboard shortcuts");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZnZvYqAqnkC8lMuM5PuscA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "12");
// i18nAccessibility.Current.CalendarDates = "Calendar dates"
outVars.value.i18nAccessibilityOut.getCurrent(callContext.iterationContext).calendarDatesAttr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("XTzYOcd0uEuBcu+inuc+jg#Value.-2092303549.1", "Calendar dates");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZnZvYqAqnkC8lMuM5PuscA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "13");
// i18nAccessibility.Current.DateSelected = "Date selected: "
outVars.value.i18nAccessibilityOut.getCurrent(callContext.iterationContext).dateSelectedAttr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("bOB6QpW3y0qaPPNGZE3U9A#Value.-911153517.1", "Date selected: ");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZnZvYqAqnkC8lMuM5PuscA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "14");
// i18nAccessibility.Current.Calendar = "Calendar"
outVars.value.i18nAccessibilityOut.getCurrent(callContext.iterationContext).calendarAttr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("Bra9RrfzZk+b3rOW0R7aWA#Value.-113680546.1", "Calendar");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZnZvYqAqnkC8lMuM5PuscA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "15");
// i18nAccessibility.Current.GoToToday = "Go to today"
outVars.value.i18nAccessibilityOut.getCurrent(callContext.iterationContext).goToTodayAttr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("StrMC+dU8UKyWJfLxq6nJA#Value.-18794124.1", "Go to today");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZnZvYqAqnkC8lMuM5PuscA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "16");
// i18nAccessibility.Current.OpenCalendar = "Open. Press Enter to close the Calendar"
outVars.value.i18nAccessibilityOut.getCurrent(callContext.iterationContext).openCalendarAttr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("1b5_VD14vEWCUSQsUQ8m8g#Value.-464608999.1", "Open. Press Enter to close the Calendar");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZnZvYqAqnkC8lMuM5PuscA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "17");
// i18nAccessibility.Current.CloseCalendar = "Closed. Press Enter to open the Calendar"
outVars.value.i18nAccessibilityOut.getCurrent(callContext.iterationContext).closeCalendarAttr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("hw5vDiQKrESpaaxSlyRHCA#Value.857568417.1", "Closed. Press Enter to open the Calendar");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZnZvYqAqnkC8lMuM5PuscA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "18");
// i18nAccessibility.Current.EnterCalendar = "Press Tab to enter the Calendar"
outVars.value.i18nAccessibilityOut.getCurrent(callContext.iterationContext).enterCalendarAttr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("eVkbzc3vuEypSjfR3Hr9bA#Value.1511082002.1", "Press Tab to enter the Calendar");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZnZvYqAqnkC8lMuM5PuscA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "19");
// i18nAccessibility.Current.MonthNext = "Next Month"
outVars.value.i18nAccessibilityOut.getCurrent(callContext.iterationContext).monthNextAttr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("d7ISJdppoUa87s3wJLedig#Value.-766743789.1", "Next Month");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZnZvYqAqnkC8lMuM5PuscA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "20");
// i18nAccessibility.Current.MonthPrevious = "Previous Month"
outVars.value.i18nAccessibilityOut.getCurrent(callContext.iterationContext).monthPreviousAttr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("lRJU8QwPl0iwqv3N9eqD+Q#Value.1784051735.1", "Previous Month");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZnZvYqAqnkC8lMuM5PuscA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "21");
// i18nAccessibility.Current.ShortcutsDialog.Current.ShortcutsDialog1 = "The following keyboard shortcuts are available"
outVars.value.i18nAccessibilityOut.getCurrent(callContext.iterationContext).shortcutsDialogAttr.getCurrent(callContext.iterationContext).shortcutsDialog1Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("7KBMokDeIEC_mM_EfFiiKA#Value.82125743.1", "The following keyboard shortcuts are available");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZnZvYqAqnkC8lMuM5PuscA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "22");
// i18nAccessibility.Current.ShortcutsDialog.Current.ShortcutsDialog2 = "LEFT / RIGHT to move day to day."
outVars.value.i18nAccessibilityOut.getCurrent(callContext.iterationContext).shortcutsDialogAttr.getCurrent(callContext.iterationContext).shortcutsDialog2Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("aUoleWSZBEGHb_sk4X7m8A#Value.-1916325413.1", "LEFT / RIGHT to move day to day.");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZnZvYqAqnkC8lMuM5PuscA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "23");
// i18nAccessibility.Current.ShortcutsDialog.Current.ShortcutsDialog3 = "UP / DOWN to move week to week."
outVars.value.i18nAccessibilityOut.getCurrent(callContext.iterationContext).shortcutsDialogAttr.getCurrent(callContext.iterationContext).shortcutsDialog3Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("I6J5cRrTyk6bSZ6JvMUtBg#Value.-1048883153.1", "UP / DOWN to move week to week.");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZnZvYqAqnkC8lMuM5PuscA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "24");
// i18nAccessibility.Current.ShortcutsDialog.Current.ShortcutsDialog4 = "DELETE to reset the date."
outVars.value.i18nAccessibilityOut.getCurrent(callContext.iterationContext).shortcutsDialogAttr.getCurrent(callContext.iterationContext).shortcutsDialog4Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("yqo5pCbrYUa4Qeqn0J_qOg#Value.-1565462224.1", "DELETE to reset the date.");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZnZvYqAqnkC8lMuM5PuscA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "25");
// i18nAccessibility.Current.ShortcutsDialog.Current.ShortcutsDialog5 = "ESCAPE to close the calendar."
outVars.value.i18nAccessibilityOut.getCurrent(callContext.iterationContext).shortcutsDialogAttr.getCurrent(callContext.iterationContext).shortcutsDialog5Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("9s+39UgfEUOBkGEECmMZsw#Value.887781619.1", "ESCAPE to close the calendar.");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZnZvYqAqnkC8lMuM5PuscA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "26");
// i18nAccessibility.Current.ShortcutsDialog.Current.ShortcutsDialog6 = "PAGE UP to move to the previous month."
outVars.value.i18nAccessibilityOut.getCurrent(callContext.iterationContext).shortcutsDialogAttr.getCurrent(callContext.iterationContext).shortcutsDialog6Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("2pdORbIMeUmJLoWBa4tFQQ#Value.-513930751.1", "PAGE UP to move to the previous month.");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZnZvYqAqnkC8lMuM5PuscA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "27");
// i18nAccessibility.Current.ShortcutsDialog.Current.ShortcutsDialog7 = "PAGE DOWN to move to the next month."
outVars.value.i18nAccessibilityOut.getCurrent(callContext.iterationContext).shortcutsDialogAttr.getCurrent(callContext.iterationContext).shortcutsDialog7Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("hxu4s7ASlUCI3vkxgsoR+A#Value.941141342.1", "PAGE DOWN to move to the next month.");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZnZvYqAqnkC8lMuM5PuscA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "28");
// i18nAccessibility.Current.ShortcutsDialog.Current.ShortcutsDialog8 = "SPACE / ENTER to select a date."
outVars.value.i18nAccessibilityOut.getCurrent(callContext.iterationContext).shortcutsDialogAttr.getCurrent(callContext.iterationContext).shortcutsDialog8Attr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("EKgo2wktLUWoYHof84369Q#Value.58078159.1", "SPACE / ENTER to select a date.");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZnZvYqAqnkC8lMuM5PuscA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "29");
// i18nAccessibility.Current.DialogButton = "Got it!"
outVars.value.i18nAccessibilityOut.getCurrent(callContext.iterationContext).dialogButtonAttr = OS.Injector.resolve(OS.ServiceNames.TranslationsService).getMessage("lg7NoSsYfEuhIOQNq772Tw#Value.1874273954.1", "Got it!");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:qPOorQqLIkSyODdI6Zf8oA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:EmOJTVVnHUKuypR_b66DFA", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.DatepickerExposeTranslations$outVars", [{
name: "i18nDefaults",
attrName: "i18nDefaultsOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new OutSystemsUIModel.TextTextTextTextTextWeekday1Weekday2Weekday3Weekday4Weekday5Weekday6Weekday7RecordListWeekdayShort1WeekdayShort2WeekRecordList();
},
complexType: OutSystemsUIModel.TextTextTextTextTextWeekday1Weekday2Weekday3Weekday4Weekday5Weekday6Weekday7RecordListWeekdayShort1WeekdayShort2WeekRecordList
}, {
name: "i18nAccessibility",
attrName: "i18nAccessibilityOut",
mandatory: false,
dataType: OS.Types.RecordList,
defaultValue: function () {
return new OutSystemsUIModel.TextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextShortcutsDialog1ShortcutsDialog2RecordList();
},
complexType: OutSystemsUIModel.TextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextTextShortcutsDialog1ShortcutsDialog2RecordList
}]);
OutSystemsUIController.default.clientActionProxies.datepickerExposeTranslations$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.datepickerExposeTranslations$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
i18nDefaults: actionResults.i18nDefaultsOut,
i18nAccessibility: actionResults.i18nAccessibilityOut
};
});
};
});

define("OutSystemsUI.controller$DEPRECATED_AccessibilityConfiguration", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$DEPRECATED_AccessibilityConfiguration.setConfigJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_DEPRECATED_AccessibilityConfiguration_setConfigJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.dEPRECATED_AccessibilityConfiguration$Action = function (showFocusIn, showSkipToContentIn, langIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.DEPRECATED_AccessibilityConfiguration$vars"))());
vars.value.showFocusInLocal = showFocusIn;
vars.value.showSkipToContentInLocal = showSkipToContentIn;
vars.value.langInLocal = langIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:wjS927+CN0i5kgkU+vhqLw:/ClientActionFlows.wjS927+CN0i5kgkU+vhqLw:5Uc8tR1NSOmQvYtAI4Iz2A", "OutSystemsUI", "DEPRECATED_AccessibilityConfiguration", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Cs9+PccrmUGziPOmvs2rpA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:OEiKilqUO0uT5hWyOOJlmQ", callContext.id);
// Action used to configure Accessibility options, live the visibility of the focus otline, the "Skip to content" link and to set the html language.
//
//This is present by default on OutSystems UI Layouts.
controller.safeExecuteJSNode(OutSystemsUI_controller_DEPRECATED_AccessibilityConfiguration_setConfigJS, "setConfig", "DEPRECATED_AccessibilityConfiguration", {
ShowFocus: OS.DataConversion.JSNodeParamConverter.to(vars.value.showFocusInLocal, OS.Types.Boolean),
Lang: OS.DataConversion.JSNodeParamConverter.to(vars.value.langInLocal, OS.Types.Text),
ShowSkipToContent: OS.DataConversion.JSNodeParamConverter.to(vars.value.showSkipToContentInLocal, OS.Types.Boolean)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:z_+mjvAMDkez19Ek6ar9Fw", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:wjS927+CN0i5kgkU+vhqLw", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.DEPRECATED_AccessibilityConfiguration$vars", [{
name: "ShowFocus",
attrName: "showFocusInLocal",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "ShowSkipToContent",
attrName: "showSkipToContentInLocal",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "Lang",
attrName: "langInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.dEPRECATED_AccessibilityConfiguration$Action = function (showFocusIn, showSkipToContentIn, langIn) {
showFocusIn = (showFocusIn === undefined) ? false : showFocusIn;
showSkipToContentIn = (showSkipToContentIn === undefined) ? false : showSkipToContentIn;
langIn = (langIn === undefined) ? "" : langIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.dEPRECATED_AccessibilityConfiguration$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(showFocusIn, OS.Types.Boolean), OS.DataConversion.JSNodeParamConverter.from(showSkipToContentIn, OS.Types.Boolean), OS.DataConversion.JSNodeParamConverter.from(langIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$DEPRECATED_AccessibilityConfiguration.setConfigJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var elem = document.querySelector('.skip-nav');
var layout = document.querySelector('.layout');

if(elem) {
    elem.setAttribute('data-showSkipContent', $parameters.ShowSkipToContent);
}

if(layout && $parameters.ShowFocus) {
    document.body.classList.add('is-focusable');   
    layout.classList.add('has-accessible-features');   
}

if($parameters.Lang !== "") {
    document.documentElement.setAttribute('lang', $parameters.Lang);
}
};
});

define("OutSystemsUI.controller$DEPRECATED_SetActiveMenuItems", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$DEPRECATED_SetActiveMenuItems.SetActiveJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_DEPRECATED_SetActiveMenuItems_SetActiveJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.dEPRECATED_SetActiveMenuItems$Action = function (activeItemIn, activeSubItemIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.DEPRECATED_SetActiveMenuItems$vars"))());
vars.value.activeItemInLocal = activeItemIn;
vars.value.activeSubItemInLocal = activeSubItemIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:uHyStiD+ZkKHYmlhJmLnAQ:/ClientActionFlows.uHyStiD+ZkKHYmlhJmLnAQ:h32nPjVK2YqIsA3mlYQvfA", "OutSystemsUI", "DEPRECATED_SetActiveMenuItems", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:vYg7WslDaUaY2sGvqQla_w", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:uauiLqkNdU2Vr4TlJvBStA", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_DEPRECATED_SetActiveMenuItems_SetActiveJS, "SetActive", "DEPRECATED_SetActiveMenuItems", {
ActiveItem: OS.DataConversion.JSNodeParamConverter.to(vars.value.activeItemInLocal, OS.Types.Integer),
ActiveSubItem: OS.DataConversion.JSNodeParamConverter.to(vars.value.activeSubItemInLocal, OS.Types.Integer)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:xlMASpfuCES1HtjwT6+7QQ", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:uHyStiD+ZkKHYmlhJmLnAQ", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.DEPRECATED_SetActiveMenuItems$vars", [{
name: "ActiveItem",
attrName: "activeItemInLocal",
mandatory: false,
dataType: OS.Types.Integer,
defaultValue: function () {
return -1;
}
}, {
name: "ActiveSubItem",
attrName: "activeSubItemInLocal",
mandatory: false,
dataType: OS.Types.Integer,
defaultValue: function () {
return -1;
}
}]);
OutSystemsUIController.default.clientActionProxies.dEPRECATED_SetActiveMenuItems$Action = function (activeItemIn, activeSubItemIn) {
activeItemIn = (activeItemIn === undefined) ? -1 : activeItemIn;
activeSubItemIn = (activeSubItemIn === undefined) ? -1 : activeSubItemIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.dEPRECATED_SetActiveMenuItems$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(activeItemIn, OS.Types.Integer), OS.DataConversion.JSNodeParamConverter.from(activeSubItemIn, OS.Types.Integer)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$DEPRECATED_SetActiveMenuItems.SetActiveJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var appMenuLinks = document.querySelector('.app-menu-links');

if(appMenuLinks) {
    var activeLinkBlock = appMenuLinks.children[$parameters.ActiveItem];
    
    if(activeLinkBlock) {
        activeLinkBlock.classList.add("active");
        var activeSubMenu = activeLinkBlock.querySelector('.submenu');
        
        if(activeSubMenu) {
            activeSubMenu.classList.add("active");
            var activeSubMenuItem = activeSubMenu.querySelector('.submenu-items').children[$parameters.ActiveSubItem];
            
            if(activeSubMenuItem) {
                activeSubMenuItem.classList.add("active");
            }
        }
    }
    
}
};
});

define("OutSystemsUI.controller$DEPRECATED_SetMenuListeners", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$DEPRECATED_SetMenuListeners.setEventListenerJS", "OutSystemsUI.controller$ToggleSideMenu", "OutSystemsUI.controller$SetMenuAttributes"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_DEPRECATED_SetMenuListeners_setEventListenerJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.dEPRECATED_SetMenuListeners$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:CkiPP8+8i0mkzflRrnuYLw:/ClientActionFlows.CkiPP8+8i0mkzflRrnuYLw:U08ApqGFEa1i84JerP0yWQ", "OutSystemsUI", "DEPRECATED_SetMenuListeners", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:dL6z+3ZDe0qLFkk_AScR2g", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Wbo+S7HMhUadZf94GvsqTg", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_DEPRECATED_SetMenuListeners_setEventListenerJS, "setEventListener", "DEPRECATED_SetMenuListeners", null, function ($parameters) {
}, {
ToggleSideMenu: OutSystemsUIController.default.clientActionProxies.toggleSideMenu$Action,
SetMenuAttributes: OutSystemsUIController.default.clientActionProxies.setMenuAttributes$Action
}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:24n1aES+60yMRWyK72zG7Q", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:CkiPP8+8i0mkzflRrnuYLw", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.clientActionProxies.dEPRECATED_SetMenuListeners$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.dEPRECATED_SetMenuListeners$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$DEPRECATED_SetMenuListeners.setEventListenerJS", [], function () {
return function ($actions, $roles, $public) {
var layout = document.querySelector('.layout');
var menu = document.querySelector('.app-menu-content');

if(layout && menu) {
    
    var isTopMenuMobile;
    var isVisibleMobile;
    var isExpanded = layout.classList.contains('menu-visible');
    var isOverlay = layout.classList.contains('aside-overlay');
    var isExpandable = layout.classList.contains('aside-expandable');
    
    var menuLinks = menu.querySelector('.app-menu-links');

    var menuOnKeypress = function(e) {
        var isTabPressed = (e.key === 'Tab' || e.keyCode === 9);
        var isEscapedPressed = (e.key === 'Escape' || e.keyCode === 27);
        var isShiftKey = e.shiftKey;
        var focusableEls = menu.querySelectorAll('a[href]:not([disabled]),[tabindex="0"], button:not([disabled]), textarea:not([disabled]), input[type="text"]:not([disabled]), input[type="radio"]:not([disabled]), input[type="checkbox"]:not([disabled]),input[type="submit"]:not([disabled]), select:not([disabled])');
        var firstFocusableEl = focusableEls[0]; 
        var lastFocusableEl = focusableEls[focusableEls.length - 1];
        var isExpandableDesktop = document.querySelector('.desktop .active-screen .layout-side.aside-expandable') || document.querySelector('.tablet.landscape .active-screen .layout-side.aside-expandable');
        
        if(!isTabPressed && !isEscapedPressed) {
            return;
        }
    
        isExpanded = layout.classList.contains('menu-visible');
        
        //If esc, Close Menu
        if(isExpanded && isEscapedPressed) {
            e.preventDefault();
            e.stopPropagation();
            $actions.ToggleSideMenu();
        }
        
        if (!isExpandableDesktop) {
            if (isShiftKey) {
                if (document.activeElement === firstFocusableEl) {
                    lastFocusableEl.focus();
                    e.preventDefault();
                }
            } else if (document.activeElement === lastFocusableEl) {
                firstFocusableEl.focus();
                e.preventDefault();
            }     
        }
        
    };
    
    // Invoking setTimeout to schedule the callback to be run asynchronously
    setTimeout(function(){
        isTopMenuMobile = document.querySelector('.tablet .active-screen .layout-top') || document.querySelector('.phone .active-screen .layout-top');
        isVisibleMobile = document.querySelector('.tablet.portrait .active-screen .layout-side.aside-visible') || document.querySelector('.phone .active-screen .layout-side.aside-visible');
        
        if(isOverlay || isExpandable || isTopMenuMobile || isVisibleMobile) {
            menu.addEventListener('keydown', menuOnKeypress);
            $actions.SetMenuAttributes();
        }
    }, 0);
    
    if(menuLinks){
        menuLinks = menuLinks.children;
        
        // Add role menuitem to all links on menu
        for(var i = 0; i < menuLinks.length; i++) {
            if(!menuLinks[i].hasAttribute("role") && menuLinks[i].tagName === "A") {      
                menuLinks[i].setAttribute("role", "menuitem");
            }
        }  
        
    }
  
}



};
});

define("OutSystemsUI.controller$DeviceDetection", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$DeviceDetection.AddNativeClassesJS", "OutSystemsUI.controller$DeviceDetection.AddWebClassesJS", "OutSystemsUI.controller$GetBrowser", "OutSystemsUI.controller$GetOS", "OutSystemsUI.controller$GetIsTouch"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_DeviceDetection_AddNativeClassesJS, OutSystemsUI_controller_DeviceDetection_AddWebClassesJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.deviceDetection$Action = function (isWebAppIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.DeviceDetection$vars"))());
vars.value.isWebAppInLocal = isWebAppIn;
var getBrowserVar = new OS.DataTypes.VariableHolder();
var getOSVar = new OS.DataTypes.VariableHolder();
var getIsTouchVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.getBrowserVar = getBrowserVar;
varBag.getOSVar = getOSVar;
varBag.getIsTouchVar = getIsTouchVar;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:OOQHk+EK0UyAa1lqT_YN4w:/ClientActionFlows.OOQHk+EK0UyAa1lqT_YN4w:P6tusmF6exl0NQX9BiWm1g", "OutSystemsUI", "DeviceDetection", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:TteqoKGApkaHPTQdW6ZGzw", callContext.id);
// Get User Agent
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Wa2mzxPdA0a8e0hDqn4HSw", callContext.id);
// UserAgent = ToLower
vars.value.userAgentVar = OS.BuiltinFunctions.toLower(OS.BuiltinFunctions.getUserAgent());
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:SO6yYH8njUOWeZhQo6DNmQ", callContext.id);
// Execute Action: GetOS
getOSVar.value = OutSystemsUIController.default.getOS$Action(vars.value.userAgentVar, callContext);

if((OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ixUEhPBrC0GC0rKi0G8GgQ", callContext.id) && vars.value.isWebAppInLocal)) {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:802dRsv2ZkmMTp_gvSZjQg", callContext.id);
// Execute Action: GetBrowser
getBrowserVar.value = OutSystemsUIController.default.getBrowser$Action(vars.value.userAgentVar, callContext);

OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:5WQ6+EOI20qlKf+sVTvE1A", callContext.id);
// Execute Action: GetIsTouch
getIsTouchVar.value = OutSystemsUIController.default.getIsTouch$Action(callContext);

OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:FDjUnNglU0GGZuMXhNjSKQ", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_DeviceDetection_AddWebClassesJS, "AddWebClasses", "DeviceDetection", {
IsTouch: OS.DataConversion.JSNodeParamConverter.to(getIsTouchVar.value.isTouchOut, OS.Types.Boolean),
Browser: OS.DataConversion.JSNodeParamConverter.to(getBrowserVar.value.browserOut, OS.Types.Text),
OS: OS.DataConversion.JSNodeParamConverter.to(getOSVar.value.oSOut, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:8RZidRamT0W1nSDxrR7HUQ", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:RWt+kXHuzUSxVy0cZJHDGw", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_DeviceDetection_AddNativeClassesJS, "AddNativeClasses", "DeviceDetection", {
OS: OS.DataConversion.JSNodeParamConverter.to(getOSVar.value.oSOut, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:8RZidRamT0W1nSDxrR7HUQ", callContext.id);
}

return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:OOQHk+EK0UyAa1lqT_YN4w", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.DeviceDetection$vars", [{
name: "IsWebApp",
attrName: "isWebAppInLocal",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "UserAgent",
attrName: "userAgentVar",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.deviceDetection$Action = function (isWebAppIn) {
isWebAppIn = (isWebAppIn === undefined) ? false : isWebAppIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.deviceDetection$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(isWebAppIn, OS.Types.Boolean)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$DeviceDetection.AddNativeClassesJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var body = document.querySelector('body');

if(body) {
    if($parameters.OS !== "") {
        body.classList.add($parameters.OS);    
    }
    
    // Detect IpadPro to add desktop class
    if(!body.classList.contains('phone') && !body.classList.contains('tablet')) {
        body.classList.add('desktop');
    }
    
    if(body.classList.contains('tablet') || body.classList.contains('desktop')) {
        window.addEventListener('orientationchange', function(){
            
            setTimeout(function(){
                if(!body.classList.contains('phone') && !body.classList.contains('tablet')) {
                    body.classList.add('desktop');
                } else if(body.classList.contains('desktop') && body.classList.contains('tablet')) {
                    body.classList.remove('desktop');
                }
            }, 500);
            
        });
    }
}

};
});
define("OutSystemsUI.controller$DeviceDetection.AddWebClassesJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var body = document.querySelector('body');

if($parameters.Browser !== "") {
    body.classList.add($parameters.Browser);
}

if($parameters.OS !== "") {
    body.classList.add($parameters.OS);    
}

if($parameters.IsTouch) {
    body.classList.add('is--touch');
}
};
});

define("OutSystemsUI.controller$ECTCall", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$ECTCall.InitECTJS", "OutSystemsUI.controller$GetECTURL"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_ECTCall_InitECTJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.eCTCall$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:JQm1Wit7_EeqJznh4EqEmw:/ClientActionFlows.JQm1Wit7_EeqJznh4EqEmw:nuRGvuAQatqtTIXFLAvHoA", "OutSystemsUI", "ECTCall", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:mHckDcDGTkefbeqoxIZ3+w", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:AZ_lAiT4PkqroKU27DpP1Q", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_ECTCall_InitECTJS, "InitECT", "ECTCall", {
URL: OS.DataConversion.JSNodeParamConverter.to(OutSystemsDebugger.handleFunctionCall(function () {
return OutSystemsUIController.default.getECTURL$Action(callContext).uRLOut;
}, OS.Types.Text, callContext.id), OS.Types.Text),
ModuleName: OS.DataConversion.JSNodeParamConverter.to(OS.BuiltinFunctions.getEntryEspaceName(), OS.Types.Text),
CurrentLocale: OS.DataConversion.JSNodeParamConverter.to(OS.BuiltinFunctions.getCurrentLocale(), OS.Types.Text),
UserId: OS.DataConversion.JSNodeParamConverter.to(OS.BuiltinFunctions.getUserId(), OS.Types.Integer)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:KUo1WCwkPE+5mz3TvPfI1g", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:JQm1Wit7_EeqJznh4EqEmw", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.clientActionProxies.eCTCall$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.eCTCall$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$ECTCall.InitECTJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
function createHTMLElement(block){
    var range = document.createRange();
    var documentFragment = range.createContextualFragment(block);
    
    // Removes the non existant Theme file
    if(documentFragment.querySelector('#ect_wtOutFeedbackDiv') !== null && documentFragment.querySelector('#ect_wtOutFeedbackDiv').childNodes[0].childNodes[0].href.includes('Theme')) {
        documentFragment.querySelector('#ect_wtOutFeedbackDiv').childNodes[0].childNodes[0].remove();
    }
    
    document.body.appendChild(documentFragment);
    
    var floating = document.querySelector('[data-block="Interaction.FloatingActions"]');

    if(floating){
        var elements = document.querySelectorAll('.ECT_FeedbackContainer div[class^="Feedback"]');
        elements.forEach(function(i){
           i.style.bottom = '100px';
           i.style.right = '35px';
        });
    }
    
}

var soapRequest = new XMLHttpRequest();
var soapBody = '<?xml version="1.0" encoding="utf-8"?>' +
                '<soapenv:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:api="http://127.0.0.1/Integrics/Enswitch/API" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">' +
                    '<soapenv:Body>' +
                        '<GetModernECT xmlns="http://www.outsystems.com"> <moduleName>' + $parameters.ModuleName + '</moduleName>  <userId>' + $parameters.UserId + '</userId>  <locale>' + $parameters.CurrentLocale + '</locale>  </GetModernECT>' +
                    '</soapenv:Body>' +
                '</soapenv:Envelope>';
var timeout = 2000;
                
                
soapRequest.open('POST', window.location.origin + $parameters.URL, true);

soapRequest.setRequestHeader('Content-Type', 'text/xml');
soapRequest.responseType = 'document';
soapRequest.timeout = timeout;

soapRequest.onload = function() {
    if (soapRequest.readyState === 4) {
        if (soapRequest.status === 200) {
            createHTMLElement(soapRequest.response.getElementsByTagName('GetModernECTResponse')[0].getElementsByTagName('html')[0].textContent);
            if(document.getElementById('ect_wtFeedbackInput') !== null) {
                document.getElementById('ect_wtFeedbackInput').setAttribute('onchange', '');
                document.getElementById('ect_wtFeedbackInput').setAttribute('onkeyup', '');
            }
        } else {
            console.error(soapRequest.statusText);
        }
    }
    
} 

soapRequest.send(soapBody);
};
});

define("OutSystemsUI.controller$EndOfflineDataSync", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$EndOfflineDataSync.TriggerSyncCompleteEventJS", "OutSystemsUI.controller$EndOfflineDataSync.TriggerSyncErrorEventJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_EndOfflineDataSync_TriggerSyncCompleteEventJS, OutSystemsUI_controller_EndOfflineDataSync_TriggerSyncErrorEventJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.endOfflineDataSync$Action = function (hasErrorIn, errorMessageIn, allowRetryIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.EndOfflineDataSync$vars"))());
vars.value.hasErrorInLocal = hasErrorIn;
vars.value.errorMessageInLocal = errorMessageIn;
vars.value.allowRetryInLocal = allowRetryIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:AB+048wZeESjgZV4xG1UYg:/ClientActionFlows.AB+048wZeESjgZV4xG1UYg:nzzr3PCOOkTPkRQSPfTDjA", "OutSystemsUI", "EndOfflineDataSync", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:vEmEoYJ_GUeCgNb_hSa5lQ", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ncGVGJ0owEmKLlIy4BaxiQ", callContext.id) && vars.value.hasErrorInLocal)) {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:iIqr4yohpki+TJEMODfuzQ", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_EndOfflineDataSync_TriggerSyncErrorEventJS, "TriggerSyncErrorEvent", "EndOfflineDataSync", {
ErrorMessage: OS.DataConversion.JSNodeParamConverter.to(vars.value.errorMessageInLocal, OS.Types.Text),
AllowRetry: OS.DataConversion.JSNodeParamConverter.to(vars.value.allowRetryInLocal, OS.Types.Boolean)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:b5IFu_KqQUCcrmTBRopVKw", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:v03QPIY87ECIHTsz5R0JNA", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_EndOfflineDataSync_TriggerSyncCompleteEventJS, "TriggerSyncCompleteEvent", "EndOfflineDataSync", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:b5IFu_KqQUCcrmTBRopVKw", callContext.id);
}

return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:AB+048wZeESjgZV4xG1UYg", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.EndOfflineDataSync$vars", [{
name: "HasError",
attrName: "hasErrorInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "ErrorMessage",
attrName: "errorMessageInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "AllowRetry",
attrName: "allowRetryInLocal",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.clientActionProxies.endOfflineDataSync$Action = function (hasErrorIn, errorMessageIn, allowRetryIn) {
hasErrorIn = (hasErrorIn === undefined) ? false : hasErrorIn;
errorMessageIn = (errorMessageIn === undefined) ? "" : errorMessageIn;
allowRetryIn = (allowRetryIn === undefined) ? false : allowRetryIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.endOfflineDataSync$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(hasErrorIn, OS.Types.Boolean), OS.DataConversion.JSNodeParamConverter.from(errorMessageIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(allowRetryIn, OS.Types.Boolean)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$EndOfflineDataSync.TriggerSyncCompleteEventJS", [], function () {
return function ($actions, $roles, $public) {
window.offlineDataSync.triggerSyncCompleteEvent();

};
});
define("OutSystemsUI.controller$EndOfflineDataSync.TriggerSyncErrorEventJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
window.offlineDataSync.triggerSyncErrorEvent($parameters.ErrorMessage, $parameters.AllowRetry);

};
});

define("OutSystemsUI.controller$FeedbackMessageClose", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$FeedbackMessageClose.closeFeedbackMessageJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_FeedbackMessageClose_closeFeedbackMessageJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.feedbackMessageClose$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:vy1eQyrsuUan5_Z_P27S8A:/ClientActionFlows.vy1eQyrsuUan5_Z_P27S8A:hOxKy5HJQwzm9R_+v7mOaQ", "OutSystemsUI", "FeedbackMessageClose", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:cvboV7I1R0iF_GxvqynOHw", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:aP3W63E880Oz+FpnEt9gtw", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_FeedbackMessageClose_closeFeedbackMessageJS, "closeFeedbackMessage", "FeedbackMessageClose", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:NERNA0DdZ0OzDPJ4F7LZyQ", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:vy1eQyrsuUan5_Z_P27S8A", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.clientActionProxies.feedbackMessageClose$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.feedbackMessageClose$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$FeedbackMessageClose.closeFeedbackMessageJS", [], function () {
return function ($actions, $roles, $public) {
$public.FeedbackMessage.closeFeedbackMessage();
};
});

define("OutSystemsUI.controller$FeedbackMessageShow", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$FeedbackMessageShow.ShowFeedbackMessageJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_FeedbackMessageShow_ShowFeedbackMessageJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.feedbackMessageShow$Action = function (messageIn, messageTypeIn, encodedHTMLIn, extendedClassIn, closeOnClickIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.FeedbackMessageShow$vars"))());
vars.value.messageInLocal = messageIn;
vars.value.messageTypeInLocal = messageTypeIn;
vars.value.encodedHTMLInLocal = encodedHTMLIn;
vars.value.extendedClassInLocal = extendedClassIn;
vars.value.closeOnClickInLocal = closeOnClickIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:pHVUgsFyJUaj_aYZTEPMOA:/ClientActionFlows.pHVUgsFyJUaj_aYZTEPMOA:0Bgc2KOkvoXY23yX0xsGwQ", "OutSystemsUI", "FeedbackMessageShow", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:kf1LIwrg4kO7EXqlxgbscw", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:tVD78iKKA0mkOwErjC3kog", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_FeedbackMessageShow_ShowFeedbackMessageJS, "ShowFeedbackMessage", "FeedbackMessageShow", {
ExtraCSSClasses: OS.DataConversion.JSNodeParamConverter.to(vars.value.extendedClassInLocal, OS.Types.Text),
EncodedHtml: OS.DataConversion.JSNodeParamConverter.to(vars.value.encodedHTMLInLocal, OS.Types.Boolean),
MessageType: OS.DataConversion.JSNodeParamConverter.to(vars.value.messageTypeInLocal, OS.Types.Integer),
CloseOnClick: OS.DataConversion.JSNodeParamConverter.to(vars.value.closeOnClickInLocal, OS.Types.Boolean),
Message: OS.DataConversion.JSNodeParamConverter.to(vars.value.messageInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:6ezIvWPdQU6wxvtvGEHW9Q", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:pHVUgsFyJUaj_aYZTEPMOA", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.FeedbackMessageShow$vars", [{
name: "Message",
attrName: "messageInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "MessageType",
attrName: "messageTypeInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "EncodedHTML",
attrName: "encodedHTMLInLocal",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return true;
}
}, {
name: "ExtendedClass",
attrName: "extendedClassInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "CloseOnClick",
attrName: "closeOnClickInLocal",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return true;
}
}]);
OutSystemsUIController.default.clientActionProxies.feedbackMessageShow$Action = function (messageIn, messageTypeIn, encodedHTMLIn, extendedClassIn, closeOnClickIn) {
messageIn = (messageIn === undefined) ? "" : messageIn;
messageTypeIn = (messageTypeIn === undefined) ? 0 : messageTypeIn;
encodedHTMLIn = (encodedHTMLIn === undefined) ? true : encodedHTMLIn;
extendedClassIn = (extendedClassIn === undefined) ? "" : extendedClassIn;
closeOnClickIn = (closeOnClickIn === undefined) ? true : closeOnClickIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.feedbackMessageShow$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(messageIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(messageTypeIn, OS.Types.Integer), OS.DataConversion.JSNodeParamConverter.from(encodedHTMLIn, OS.Types.Boolean), OS.DataConversion.JSNodeParamConverter.from(extendedClassIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(closeOnClickIn, OS.Types.Boolean)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$FeedbackMessageShow.ShowFeedbackMessageJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$public.FeedbackMessage.showFeedbackMessage($parameters.Message, $parameters.MessageType, $parameters.EncodedHtml, $parameters.ExtraCSSClasses, $parameters.CloseOnClick);

};
});

define("OutSystemsUI.controller$FixInputs", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$FixInputs.FixInputsJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_FixInputs_FixInputsJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.fixInputs$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:joiCQJkwhEazo8+aMtGV2Q:/ClientActionFlows.joiCQJkwhEazo8+aMtGV2Q:McVEsuOhRjKyc_XrFjSw2g", "OutSystemsUI", "FixInputs", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:zHVm52HnGkCutkyhJ8Q6sw", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:PQa9fzVt50+PvtBRPKnhgQ", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_FixInputs_FixInputsJS, "FixInputs", "FixInputs", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:MHp2qeIBc0OkgRuqHvU2vQ", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:joiCQJkwhEazo8+aMtGV2Q", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.clientActionProxies.fixInputs$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.fixInputs$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$FixInputs.FixInputsJS", [], function () {
return function ($actions, $roles, $public) {
// apply the iOS inputs fix for webviews
osui.FixInputs();
};
});

define("OutSystemsUI.controller$GetBrowser", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.getBrowser$Action = function (userAgentIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.GetBrowser$vars"))());
vars.value.userAgentInLocal = userAgentIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.GetBrowser$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:dV1fY48Rm0muX7QLAz_Zeg:/ClientActionFlows.dV1fY48Rm0muX7QLAz_Zeg:XO8WZ6fgZc7aQxPRRsLZVw", "OutSystemsUI", "GetBrowser", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:enpNVcI00UmoatR0IGRzJA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:LNyF1J3OzkyRhjunPMh7dA", callContext.id);
// UserAgent = ToLower
vars.value.userAgentInLocal = OS.BuiltinFunctions.toLower(vars.value.userAgentInLocal);
// DetectBrowser
if((OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:e8RM0whGOUeEDg0Sr0uuNA", callContext.id) && (OS.BuiltinFunctions.index(vars.value.userAgentInLocal, "edge", 0, false, false) > -1))) {
// Edge
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:RMQogNJuREukkmWOqCDqLg", callContext.id);
// Browser = "edge"
outVars.value.browserOut = "edge";
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:tJLANBnAAECuLWQLmQUMQA", callContext.id);
} else {
if((OS.BuiltinFunctions.index(vars.value.userAgentInLocal, "firefox", 0, false, false) > -1)) {
// Firefox
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:dXew8pG+N0ubvxq9eJvk0Q", callContext.id);
// Browser = "firefox"
outVars.value.browserOut = "firefox";
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:tJLANBnAAECuLWQLmQUMQA", callContext.id);
} else {
if(((OS.BuiltinFunctions.index(vars.value.userAgentInLocal, "chrome", 0, false, false) > -1) || (OS.BuiltinFunctions.index(vars.value.userAgentInLocal, "crios", 0, false, false) > -1))) {
// Chrome
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:VRQ0rVhJfU62Aj6UOQjqOg", callContext.id);
// Browser = "chrome"
outVars.value.browserOut = "chrome";
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:tJLANBnAAECuLWQLmQUMQA", callContext.id);
} else {
if(((OS.BuiltinFunctions.index(vars.value.userAgentInLocal, "safari", 0, false, false) > -1) && (OS.BuiltinFunctions.index(vars.value.userAgentInLocal, "chrome", 0, false, false) <= -1))) {
// Safari
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:0uBexWpwIUOBEZnWA1YVWw", callContext.id);
// Browser = "safari"
outVars.value.browserOut = "safari";
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:tJLANBnAAECuLWQLmQUMQA", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:tJLANBnAAECuLWQLmQUMQA", callContext.id);
}

}

}

}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:dV1fY48Rm0muX7QLAz_Zeg", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.GetBrowser$vars", [{
name: "UserAgent",
attrName: "userAgentInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.GetBrowser$outVars", [{
name: "Browser",
attrName: "browserOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.getBrowser$Action = function (userAgentIn) {
userAgentIn = (userAgentIn === undefined) ? "" : userAgentIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.getBrowser$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(userAgentIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Browser: OS.DataConversion.JSNodeParamConverter.to(actionResults.browserOut, OS.Types.Text)
};
});
};
});

define("OutSystemsUI.controller$GetDeviceOrientation", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$GetDeviceOrientation.CheckDeviceJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_GetDeviceOrientation_CheckDeviceJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.getDeviceOrientation$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var checkDeviceJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.GetDeviceOrientation$outVars"))());
varBag.callContext = callContext;
varBag.checkDeviceJSResult = checkDeviceJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:tGVz89UL+E+S9m21JwQD0w:/ClientActionFlows.tGVz89UL+E+S9m21JwQD0w:e3jWoXW6l0vG9_rJypZTAA", "OutSystemsUI", "GetDeviceOrientation", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:WlXLDSxzeE2HWrZvOK8R9A", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:gbjVoiko4UGtMqk2GHLr1g", callContext.id);
checkDeviceJSResult.value = controller.safeExecuteJSNode(OutSystemsUI_controller_GetDeviceOrientation_CheckDeviceJS, "CheckDevice", "GetDeviceOrientation", {
Orientation: OS.DataConversion.JSNodeParamConverter.to("", OS.Types.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsUI.GetDeviceOrientation$checkDeviceJSResult"))();
jsNodeResult.orientationOut = OS.DataConversion.JSNodeParamConverter.from($parameters.Orientation, OS.Types.Text);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:5mf9zMosH0iwQ_WWqvwkug", callContext.id);
// Orientation = CheckDevice.Orientation
outVars.value.orientationOut = checkDeviceJSResult.value.orientationOut;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:eJeV2aTII0yt5v5wbvM3kg", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:tGVz89UL+E+S9m21JwQD0w", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.GetDeviceOrientation$checkDeviceJSResult", [{
name: "Orientation",
attrName: "orientationOut",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.GetDeviceOrientation$outVars", [{
name: "Orientation",
attrName: "orientationOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.getDeviceOrientation$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.getDeviceOrientation$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Orientation: OS.DataConversion.JSNodeParamConverter.to(actionResults.orientationOut, OS.Types.Text)
};
});
};
});
define("OutSystemsUI.controller$GetDeviceOrientation.CheckDeviceJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var classList = document.body.classList;

if(classList.contains("landscape")) {
    $parameters.Orientation = "landscape";
} else if(classList.contains("portrait")) {
    $parameters.Orientation = "portrait";
}
};
});

define("OutSystemsUI.controller$GetDeviceType", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$GetDeviceType.CheckDeviceJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_GetDeviceType_CheckDeviceJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.getDeviceType$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var checkDeviceJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.GetDeviceType$outVars"))());
varBag.callContext = callContext;
varBag.checkDeviceJSResult = checkDeviceJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:V8kn6TfTuUWAmMWp18n+Vw:/ClientActionFlows.V8kn6TfTuUWAmMWp18n+Vw:9Zh_rdLAgDsBOjcR12SHxg", "OutSystemsUI", "GetDeviceType", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZvhAJGrMGkeKAvnAYcWXlQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:N9WTj9dLUkuBdvhGabzneA", callContext.id);
checkDeviceJSResult.value = controller.safeExecuteJSNode(OutSystemsUI_controller_GetDeviceType_CheckDeviceJS, "CheckDevice", "GetDeviceType", {
Device: OS.DataConversion.JSNodeParamConverter.to("", OS.Types.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsUI.GetDeviceType$checkDeviceJSResult"))();
jsNodeResult.deviceOut = OS.DataConversion.JSNodeParamConverter.from($parameters.Device, OS.Types.Text);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Z+YNE6HFAEC_aV40cAT4ZA", callContext.id);
// Device = CheckDevice.Device
outVars.value.deviceOut = checkDeviceJSResult.value.deviceOut;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ivLLSyFVj0uFhq3EYv2bFg", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:V8kn6TfTuUWAmMWp18n+Vw", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.GetDeviceType$checkDeviceJSResult", [{
name: "Device",
attrName: "deviceOut",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.GetDeviceType$outVars", [{
name: "Device",
attrName: "deviceOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.getDeviceType$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.getDeviceType$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Device: OS.DataConversion.JSNodeParamConverter.to(actionResults.deviceOut, OS.Types.Text)
};
});
};
});
define("OutSystemsUI.controller$GetDeviceType.CheckDeviceJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var classList = document.body.classList;

if(classList.contains("phone")) {
    $parameters.Device = "phone";
} else if(classList.contains("tablet")) {
    $parameters.Device = "tablet";
} else {
    $parameters.Device = "desktop";
}
};
});

define("OutSystemsUI.controller$GetECTURL", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.getECTURL$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.GetECTURL$outVars"))());
varBag.callContext = callContext;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:fXEH2WZHUUydeeqXb58htg:/ClientActionFlows.fXEH2WZHUUydeeqXb58htg:7bzxyFKGRLRdjqFnEtOtxA", "OutSystemsUI", "GetECTURL", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:F_yOm7loL06q_516kLwKbA", callContext.id);
// URL
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:AoRQO0BVQkKF3zbzl5IiYw", callContext.id);
// URL = "/ECT_Provider/WS_ECT.asmx"
outVars.value.uRLOut = "/ECT_Provider/WS_ECT.asmx";
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:czCiPkd8T0q1ZbAgZlnbjA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:fXEH2WZHUUydeeqXb58htg", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.GetECTURL$outVars", [{
name: "URL",
attrName: "uRLOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.getECTURL$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.getECTURL$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
URL: OS.DataConversion.JSNodeParamConverter.to(actionResults.uRLOut, OS.Types.Text)
};
});
};
});

define("OutSystemsUI.controller$GetIsTouch", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$GetIsTouch.SetIsTouchJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_GetIsTouch_SetIsTouchJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.getIsTouch$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var setIsTouchJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.GetIsTouch$outVars"))());
varBag.callContext = callContext;
varBag.setIsTouchJSResult = setIsTouchJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:RZ1a65S6TEG+U0tQG3j8vA:/ClientActionFlows.RZ1a65S6TEG+U0tQG3j8vA:2Ic9JOCalng9TxkE4PTHBg", "OutSystemsUI", "GetIsTouch", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:eq_Hnst4vkq_06kai8zFAA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:UzL18+5tCEyY2xczP1HzpQ", callContext.id);
setIsTouchJSResult.value = controller.safeExecuteJSNode(OutSystemsUI_controller_GetIsTouch_SetIsTouchJS, "SetIsTouch", "GetIsTouch", {
IsTouch: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsUI.GetIsTouch$setIsTouchJSResult"))();
jsNodeResult.isTouchOut = OS.DataConversion.JSNodeParamConverter.from($parameters.IsTouch, OS.Types.Boolean);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:XxzUi3lJf0C_2edgopB4Tw", callContext.id);
// IsTouch = SetIsTouch.IsTouch
outVars.value.isTouchOut = setIsTouchJSResult.value.isTouchOut;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:hc1FN68lS0+PvmL2nVXeFQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:RZ1a65S6TEG+U0tQG3j8vA", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.GetIsTouch$setIsTouchJSResult", [{
name: "IsTouch",
attrName: "isTouchOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.GetIsTouch$outVars", [{
name: "IsTouch",
attrName: "isTouchOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.clientActionProxies.getIsTouch$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.getIsTouch$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
IsTouch: OS.DataConversion.JSNodeParamConverter.to(actionResults.isTouchOut, OS.Types.Boolean)
};
});
};
});
define("OutSystemsUI.controller$GetIsTouch.SetIsTouchJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var body = document.body;
var isTouch = false;
  
function detectTouchscreen() {
  if (window.PointerEvent && ('maxTouchPoints' in navigator)) {
    // if Pointer Events are supported, just check maxTouchPoints
    if (navigator.maxTouchPoints > 0) {
      isTouch = true;
    }
  } else {
    // no Pointer Events...
    if (window.matchMedia && window.matchMedia("(any-pointer:coarse)").matches) {
      // check for any-pointer:coarse which mostly means touchscreen
      isTouch = true;
    } else if (window.TouchEvent || ('ontouchstart' in window)) {
      // last resort - check for exposed touch events API / event handler
      isTouch = true;
    }
  }
  
  return isTouch;
  
}

detectTouchscreen();
$parameters.IsTouch = isTouch;
};
});

define("OutSystemsUI.controller$GetNetworkStatus", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$GetNetworkStatus.CheckDeviceOnlineJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_GetNetworkStatus_CheckDeviceOnlineJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.getNetworkStatus$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var checkDeviceOnlineJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.GetNetworkStatus$outVars"))());
varBag.callContext = callContext;
varBag.checkDeviceOnlineJSResult = checkDeviceOnlineJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:Jy8FxeT960+JHkWnvjJmrA:/ClientActionFlows.Jy8FxeT960+JHkWnvjJmrA:dlgQZ5M9jdEPWK+_bv4Z8Q", "OutSystemsUI", "GetNetworkStatus", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:xI6lj4cJrkycwMKaYxJ9qg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:lLAk3sElnEm+ySLNkSsrjw", callContext.id);
checkDeviceOnlineJSResult.value = controller.safeExecuteJSNode(OutSystemsUI_controller_GetNetworkStatus_CheckDeviceOnlineJS, "CheckDeviceOnline", "GetNetworkStatus", {
NavigatorOnline: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsUI.GetNetworkStatus$checkDeviceOnlineJSResult"))();
jsNodeResult.navigatorOnlineOut = OS.DataConversion.JSNodeParamConverter.from($parameters.NavigatorOnline, OS.Types.Boolean);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:EVe_1N6TwkOPoX_6BvPMwg", callContext.id);
// IsOnline = CheckDeviceOnline.NavigatorOnline
outVars.value.isOnlineOut = checkDeviceOnlineJSResult.value.navigatorOnlineOut;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:DxBwnwxWYkGRFq2qdQoUeQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:Jy8FxeT960+JHkWnvjJmrA", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.GetNetworkStatus$checkDeviceOnlineJSResult", [{
name: "NavigatorOnline",
attrName: "navigatorOnlineOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.GetNetworkStatus$outVars", [{
name: "IsOnline",
attrName: "isOnlineOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.clientActionProxies.getNetworkStatus$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.getNetworkStatus$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
IsOnline: OS.DataConversion.JSNodeParamConverter.to(actionResults.isOnlineOut, OS.Types.Boolean)
};
});
};
});
define("OutSystemsUI.controller$GetNetworkStatus.CheckDeviceOnlineJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
// Uses navigator to check if device is online
$parameters.NavigatorOnline = navigator.onLine;
};
});

define("OutSystemsUI.controller$GetNetworkType", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$GetNetworkType.CheckNetworkTypeJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_GetNetworkType_CheckNetworkTypeJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.getNetworkType$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var checkNetworkTypeJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.GetNetworkType$outVars"))());
varBag.callContext = callContext;
varBag.checkNetworkTypeJSResult = checkNetworkTypeJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:+ZNpq6EuMUqlKdDF3430RQ:/ClientActionFlows.+ZNpq6EuMUqlKdDF3430RQ:TmD+dN3JZpo3oQQuV55tSg", "OutSystemsUI", "GetNetworkType", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:cJs2O+6qmEa1MRh3D3tRSg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:DdnOaND2fkCpllA7GTAiCg", callContext.id);
checkNetworkTypeJSResult.value = controller.safeExecuteJSNode(OutSystemsUI_controller_GetNetworkType_CheckNetworkTypeJS, "CheckNetworkType", "GetNetworkType", {
NetworkType: OS.DataConversion.JSNodeParamConverter.to("", OS.Types.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsUI.GetNetworkType$checkNetworkTypeJSResult"))();
jsNodeResult.networkTypeOut = OS.DataConversion.JSNodeParamConverter.from($parameters.NetworkType, OS.Types.Text);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:5ClbImcBE0CofTng9C3dZg", callContext.id);
// NetworkType = CheckNetworkType.NetworkType
outVars.value.networkTypeOut = checkNetworkTypeJSResult.value.networkTypeOut;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:1d7KSzcSFUmHBadz77dl9Q", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:+ZNpq6EuMUqlKdDF3430RQ", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.GetNetworkType$checkNetworkTypeJSResult", [{
name: "NetworkType",
attrName: "networkTypeOut",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.GetNetworkType$outVars", [{
name: "NetworkType",
attrName: "networkTypeOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.getNetworkType$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.getNetworkType$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
NetworkType: OS.DataConversion.JSNodeParamConverter.to(actionResults.networkTypeOut, OS.Types.Text)
};
});
};
});
define("OutSystemsUI.controller$GetNetworkType.CheckNetworkTypeJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
if (typeof navigator.connection !== "undefined") {
    //In a mobile device
    if(typeof navigator.connection.type !== "undefined"){
        $parameters.NetworkType = navigator.connection.type;
    } else {
        //In a web browser
        $parameters.NetworkType = "webbrowser"; 
    }
} else {
    //In a web browser
    $parameters.NetworkType = "webbrowser";
}
};
});

define("OutSystemsUI.controller$GetOS", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$GetOS.DetectIphoneXJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_GetOS_DetectIphoneXJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.getOS$Action = function (userAgentIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.GetOS$vars"))());
vars.value.userAgentInLocal = userAgentIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.GetOS$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:xv7Qrjz7QUGtBmrY543I6A:/ClientActionFlows.xv7Qrjz7QUGtBmrY543I6A:pTbCSsM+KxGES2tlROXLQQ", "OutSystemsUI", "GetOS", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:qCrxHG1sYkiv4suX4MWRJQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:4AGvjje3wEG4pmEkTTJrQA", callContext.id);
// UserAgent = ToLower
vars.value.userAgentInLocal = OS.BuiltinFunctions.toLower(vars.value.userAgentInLocal);
// Detect Device
if((OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:kq5UEbH41kSUDgj9ytpzpA", callContext.id) && ((OS.BuiltinFunctions.index(vars.value.userAgentInLocal, "ipad", 0, false, false) > -1) || (OS.BuiltinFunctions.index(vars.value.userAgentInLocal, "iphone", 0, false, false) > -1)))) {
// Ios
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:qxbU+4BD2kqtbcKBet0mmg", callContext.id);
// OS = "ios"
outVars.value.oSOut = "ios";
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:UTNgkVilxEuT_Cr3S2KMTA", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_GetOS_DetectIphoneXJS, "DetectIphoneX", "GetOS", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:WWtYynhaykGMr7fxAZWZEQ", callContext.id);
} else {
if((OS.BuiltinFunctions.index(vars.value.userAgentInLocal, "android", 0, false, false) > -1)) {
// Android
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:g5GMKvCPfUSIkYWgdSmmOg", callContext.id);
// OS = "android"
outVars.value.oSOut = "android";
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:WWtYynhaykGMr7fxAZWZEQ", callContext.id);
} else {
if((OS.BuiltinFunctions.index(vars.value.userAgentInLocal, "windows", 0, false, false) > -1)) {
// Windows
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Gw8OZz1r0E2KMJp2nMTTag", callContext.id);
// OS = "windows"
outVars.value.oSOut = "windows";
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:WWtYynhaykGMr7fxAZWZEQ", callContext.id);
} else {
if((OS.BuiltinFunctions.index(vars.value.userAgentInLocal, "mac", 0, false, false) > -1)) {
// OSX
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:bshK_kErOEq3Y_BrL+gZ+g", callContext.id);
// OS = "osx"
outVars.value.oSOut = "osx";
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:WWtYynhaykGMr7fxAZWZEQ", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:WWtYynhaykGMr7fxAZWZEQ", callContext.id);
}

}

}

}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:xv7Qrjz7QUGtBmrY543I6A", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.GetOS$vars", [{
name: "UserAgent",
attrName: "userAgentInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.GetOS$outVars", [{
name: "OS",
attrName: "oSOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.getOS$Action = function (userAgentIn) {
userAgentIn = (userAgentIn === undefined) ? "" : userAgentIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.getOS$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(userAgentIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
OS: OS.DataConversion.JSNodeParamConverter.to(actionResults.oSOut, OS.Types.Text)
};
});
};
});
define("OutSystemsUI.controller$GetOS.DetectIphoneXJS", [], function () {
return function ($actions, $roles, $public) {
var body = document.querySelector("body");

// detect iPhoneX
function detectIphoneX() {
    // devices list and their screen sizes
    var devices = [
        {width: 1125, height: 2436, description: "iphone x/xs"},
        {width: 828, height: 1792, description: "iphone xr"},
        {width: 750, height: 1624, description: "iphone xr scaled"},
        {width: 1242, height: 2688, description: "iphone xs max"},
        {width: 1170, height: 2532, description: "iphone 12"},
        {width: 1284, height: 2778, description: "iphone 12 pro max"},
    ];
    
    // get the device pixel ratio
    var ratio = window.devicePixelRatio || 1;

    // get the device screen dimensions
    var screen = {
        width : window.screen.width * ratio,
        height : window.screen.height * ratio
    };

    // check if the screen size matches any of the devices in the list
    for(var i = 0; i < devices.length; i++) {
        if(devices[i].width === screen.width && devices[i].height === screen.height) {
            window.iphoneX = true;
        }
    }
    
    if(window.iphoneX) {
        // get orientation and register an event to update it
        detectOrientation();
        window.addEventListener("orientationchange", function() {
            setTimeout(detectOrientation, 500);
        });
    }
}

// update orientation
function detectOrientation() {
    // store the notch position value
    var notchPosition;
    
    if("orientation" in window) {
        // mobile browers
        if (window.orientation == 90) {
            notchPosition = "left";
        } else if (window.orientation == -90) {
            notchPosition = "right";
        } else {
            notchPosition = "up";
        }
    } else if ("orientation" in window.screen) {
        // webkit browsers
        if( window.screen.orientation.type === "landscape-primary") {
            notchPosition = "left";
        } else if( window.screen.orientation.type === "landscape-secondary") {
            notchPosition = "right";
        } else {
            notchPosition = "up";
        }
    } else if("mozOrientation" in window.screen) {
        // firefox browsers
        if( window.screen.mozOrientation === "landscape-primary") {
            notchPosition = "left";
        } else if( window.screen.mozOrientation === "landscape-secondary") {
            notchPosition = "right";
        } else {
            notchPosition = "up";
        }
    }
    
    window.notch = notchPosition;
    updateClasses();
}

function updateClasses() {
    // set the iphonex class on the body
    body.classList.add("iphonex");
    
    // override tablet detection on landscape mode
    if (window.notch == "left" || window.notch == "right") {
        body.classList.remove("tablet");
        body.classList.add("phone");
    }
}

// detect iPhoneX
detectIphoneX();
};
});

define("OutSystemsUI.controller$HasMasterDetail", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$HasMasterDetail.HasMasterDetailJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_HasMasterDetail_HasMasterDetailJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.hasMasterDetail$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:eTjJM+ziD0ikmEqvObe7+Q:/ClientActionFlows.eTjJM+ziD0ikmEqvObe7+Q:GbxmZ+iReIjVCsoS5tSEFA", "OutSystemsUI", "HasMasterDetail", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:2frMzbJO8Ey842DmBNh2dQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:4tPDI+5d60iT0y9hC+_RjA", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_HasMasterDetail_HasMasterDetailJS, "HasMasterDetail", "HasMasterDetail", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:c2L+7egkAUeHomqzEpbFDw", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:eTjJM+ziD0ikmEqvObe7+Q", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.clientActionProxies.hasMasterDetail$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.hasMasterDetail$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$HasMasterDetail.HasMasterDetailJS", [], function () {
return function ($actions, $roles, $public) {
// detect if master detail is used
osui.HasMasterDetail();
};
});

define("OutSystemsUI.controller$HideHeader", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$HideHeader.HideOnScrollJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_HideHeader_HideOnScrollJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.hideHeader$Action = function (hideHeaderIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.HideHeader$vars"))());
vars.value.hideHeaderInLocal = hideHeaderIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:yWN3I3mUa0+a7mgU7VdRyw:/ClientActionFlows.yWN3I3mUa0+a7mgU7VdRyw:vNzz0RmiEKZWbO63qloD+w", "OutSystemsUI", "HideHeader", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:RcQh4R4oTkimx1nMetHWXw", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:3JmP0Rp+3Uuc_SKPk_Ui0Q", callContext.id) && vars.value.hideHeaderInLocal)) {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:YIoLAMN9y0C6r84F2nZDLg", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_HideHeader_HideOnScrollJS, "HideOnScroll", "HideHeader", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:kUv59cqJ6Uyzd_kOmdu1RA", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:sjl7Mgg+Ck2k3OuMhnkwFQ", callContext.id);
}

return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:yWN3I3mUa0+a7mgU7VdRyw", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.HideHeader$vars", [{
name: "HideHeader",
attrName: "hideHeaderInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.clientActionProxies.hideHeader$Action = function (hideHeaderIn) {
hideHeaderIn = (hideHeaderIn === undefined) ? false : hideHeaderIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.hideHeader$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(hideHeaderIn, OS.Types.Boolean)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$HideHeader.HideOnScrollJS", [], function () {
return function ($actions, $roles, $public) {
// window.performance.timing is deprecated but the technology that MDN suggest to use is stil experimental and does not work on IE and Safari. Please visit the following link for context: 
// https://developer.mozilla.org/en-US/docs/Web/API/Performance/timing
var loadTime = window.performance.timing.domContentLoadedEventEnd- window.performance.timing.navigationStart;

setTimeout(function(){
    var hideOnScroll = new osui.HideOnScroll();
    hideOnScroll.init();
}, loadTime);
};
});

define("OutSystemsUI.controller$iPhoneXPreview", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$iPhoneXPreview.DetectPreviewInDevicesJS", "OutSystemsUI.controller$SetStickyObserver"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_iPhoneXPreview_DetectPreviewInDevicesJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.iPhoneXPreview$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.iPhoneXPreview$vars"))());
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:NbOckAGFXESom8tE91RycA:/ClientActionFlows.NbOckAGFXESom8tE91RycA:XE9EGq1G8MjOqqS5Bv7fsA", "OutSystemsUI", "iPhoneXPreview", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:sUoEZhrvbEuF6HCvCEDvVQ", callContext.id);
// iPhoneX Preview CSS
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:pXgbImTph0amgXBBKeCMoA", callContext.id);
// PreviewCSS = "/* iPhoneX Preview in Devices */
//._phantom-limb .iphonex.portrait .layout-native:not(.blank) .content {
//    padding-top: calc(var(--header-size) + var(--header-size-content) + 35px);
//    padding-bottom: var(--footer-height);
//}
//
//._phantom-limb .iphonex.portrait .layout-native.hide-header-on-scroll .header {
//    top: calc(-1 * (var(--header-size) + 35px));
//}
//
//._phantom-limb .iphonex.portrait .layout-native.hide-header-on-scroll.header-is--visible .header-top-content {
//   padding-top: 0; 
//}
//
//._phantom-limb .iphonex.portrait .layout-native.hide-header-on-scroll .header-top-content {
//   padding-top: 35px; 
//}
//
//._phantom-limb .iphonex.portrait .layout-native.hide-header-on-scroll .content {
//    padding-top: 0;
//}
//
//._phantom-limb .iphonex.landscape .layout-native .content {
//    padding-left: 35px;
//    padding-right: 35px;
//}
//
//.iphonex .bottom-bar-wrapper {    
//    padding-bottom: 5px;    
//}
//
//.iphonex .action-sheet {
//    padding-bottom: 35px; 
//}
//
//.iphonex .split-right-close a,
//.split-right-close a:link,
//.split-right-close a:visited {
//    color: var(--color-neutral-8);
//}
//
///* portrait only */
//.iphonex.portrait .header,
//.iphonex.portrait .app-menu-content,
//.iphonex.portrait .notification {
//    padding-top: 35px;
//}
//
//.iphonex.portrait .notification--visible {
//    margin-top: 35px;
//}
//
//.iphonex.portrait .app-menu,
//.iphonex.portrait .sidebar {
//    padding-top: 35px;
//    padding-bottom: 5px;
//}
//
//.iphonex.portrait .section-group.is--sticky .section-title {
//    top: calc(var(--section-top-position) + 35px);
//}
//
//.iphonex.portrait .section-index.is--sticky {
//    top: calc(var(--header-size) + var(--header-size-content) + var(--top-position) + 35px);
//}
//
//.iphonex.ios.phone.portrait .layout-native .floating-actions-wrapper {
//    margin-bottom: 16px;
//}
//
//.iphonex.ios.phone.portrait .layout-native .floating-actions-wrapper.bottom-bar-exists {
//    margin-bottom: 0;
//}
//
//.iphonex.portrait .layout-native .split-right {
//    padding-top: calc(var(--header-size) + var(--header-size-content) + 35px);
//}
//
//.iphonex.ios.phone.portrait .layout-native .split-right-close {
//    top: 47px;
//}
//
//.iphonex.portrait .split-right-close {
//    top: 41px;
//}
//
//.iphonex.portrait .header-right .search-input {
//    padding-top: 40px;
//}
//
//.iphonex.portrait .header-right .search-input:after {
//    top: 50px; 
//}
//
//.iphonex.portrait .feedback-message {
//    padding-top: 45px;
//}
//
///* landscape */
//.iphonex.landscape .app-menu,
//.iphonex.landscape .sidebar {
//    padding-bottom: 5px;
//}
//
//.iphonex.landscape .app-menu-links {
//    padding-left: 35px; 
//}
//
//.iphonex.landscape .header,
//.iphonex.landscape .main-content,
//.iphonex.landscape .bottom-bar-wrapper {
//    padding-left: 35px;
//    padding-right: 35px;
//}
//
//.iphonex.ios.phone.landscape .layout-native .split-right-close {
//    display: block;
//}
//
//.ios.phone.landscape .layout-native .floating-actions-wrapper {
//    margin-right: calc(35px + var(--space-base));
//}
//
//"
vars.value.previewCSSVar = "/* iPhoneX Preview in Devices */\r\n._phantom-limb .iphonex.portrait .layout-native:not(.blank) .content {\r\n    padding-top: calc(var(--header-size) + var(--header-size-content) + 35px);\r\n    padding-bottom: var(--footer-height);\r\n}\r\n\r\n._phantom-limb .iphonex.portrait .layout-native.hide-header-on-scroll .header {\r\n    top: calc(-1 * (var(--header-size) + 35px));\r\n}\r\n\r\n._phantom-limb .iphonex.portrait .layout-native.hide-header-on-scroll.header-is--visible .header-top-content {\r\n   padding-top: 0; \r\n}\r\n\r\n._phantom-limb .iphonex.portrait .layout-native.hide-header-on-scroll .header-top-content {\r\n   padding-top: 35px; \r\n}\r\n\r\n._phantom-limb .iphonex.portrait .layout-native.hide-header-on-scroll .content {\r\n    padding-top: 0;\r\n}\r\n\r\n._phantom-limb .iphonex.landscape .layout-native .content {\r\n    padding-left: 35px;\r\n    padding-right: 35px;\r\n}\r\n\r\n.iphonex .bottom-bar-wrapper {    \r\n    padding-bottom: 5px;    \r\n}\r\n\r\n.iphonex .action-sheet {\r\n    padding-bottom: 35px; \r\n}\r\n\r\n.iphonex .split-right-close a,\r\n.split-right-close a:link,\r\n.split-right-close a:visited {\r\n    color: var(--color-neutral-8);\r\n}\r\n\r\n/* portrait only */\r\n.iphonex.portrait .header,\r\n.iphonex.portrait .app-menu-content,\r\n.iphonex.portrait .notification {\r\n    padding-top: 35px;\r\n}\r\n\r\n.iphonex.portrait .notification--visible {\r\n    margin-top: 35px;\r\n}\r\n\r\n.iphonex.portrait .app-menu,\r\n.iphonex.portrait .sidebar {\r\n    padding-top: 35px;\r\n    padding-bottom: 5px;\r\n}\r\n\r\n.iphonex.portrait .section-group.is--sticky .section-title {\r\n    top: calc(var(--section-top-position) + 35px);\r\n}\r\n\r\n.iphonex.portrait .section-index.is--sticky {\r\n    top: calc(var(--header-size) + var(--header-size-content) + var(--top-position) + 35px);\r\n}\r\n\r\n.iphonex.ios.phone.portrait .layout-native .floating-actions-wrapper {\r\n    margin-bottom: 16px;\r\n}\r\n\r\n.iphonex.ios.phone.portrait .layout-native .floating-actions-wrapper.bottom-bar-exists {\r\n    margin-bottom: 0;\r\n}\r\n\r\n.iphonex.portrait .layout-native .split-right {\r\n    padding-top: calc(var(--header-size) + var(--header-size-content) + 35px);\r\n}\r\n\r\n.iphonex.ios.phone.portrait .layout-native .split-right-close {\r\n    top: 47px;\r\n}\r\n\r\n.iphonex.portrait .split-right-close {\r\n    top: 41px;\r\n}\r\n\r\n.iphonex.portrait .header-right .search-input {\r\n    padding-top: 40px;\r\n}\r\n\r\n.iphonex.portrait .header-right .search-input:after {\r\n    top: 50px; \r\n}\r\n\r\n.iphonex.portrait .feedback-message {\r\n    padding-top: 45px;\r\n}\r\n\r\n/* landscape */\r\n.iphonex.landscape .app-menu,\r\n.iphonex.landscape .sidebar {\r\n    padding-bottom: 5px;\r\n}\r\n\r\n.iphonex.landscape .app-menu-links {\r\n    padding-left: 35px; \r\n}\r\n\r\n.iphonex.landscape .header,\r\n.iphonex.landscape .main-content,\r\n.iphonex.landscape .bottom-bar-wrapper {\r\n    padding-left: 35px;\r\n    padding-right: 35px;\r\n}\r\n\r\n.iphonex.ios.phone.landscape .layout-native .split-right-close {\r\n    display: block;\r\n}\r\n\r\n.ios.phone.landscape .layout-native .floating-actions-wrapper {\r\n    margin-right: calc(35px + var(--space-base));\r\n}\r\n\r\n";
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:pXgbImTph0amgXBBKeCMoA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// GeneralCss = "/* General Devices Preview */
//._phantom-limb body {
//    overflow: initial !important;
//}
//
//._phantom-limb .layout-native.hide-header-on-scroll .header {
//    position: sticky;
//}
//
//._phantom-limb .layout-native.hide-header-on-scroll .content {
//    padding-top: 0;
//}
//
//._phantom-limb .layout-native:not(.hide-header-on-scroll) .header {
//    top: 0;
//}
//
//._phantom-limb .layout-native .footer {
//    bottom: 0;
//}
//
//._phantom-limb .layout-native .header,
//._phantom-limb .layout-native .footer {
//    position: fixed;
//    left: 0;
//    right: 0;
//}
//
//._phantom-limb .layout-native .footer {
//    bottom: 0;
//}
//
//._phantom-limb .layout-native:not(.blank) .content {
//    padding-top: calc(var(--header-size) + var(--header-size-content));
//    padding-bottom: var(--footer-height);
//}
//
//._phantom-limb .landscape .layout.layout-side.layout-native .header {
//    z-index: 150;
//}
//
//._phantom-limb .landscape.phone.tablet.windows .layout-native .split-right-close {
//    display: block;
//}
//
//._phantom-limb .split-right-close a,
//._phantom-limb .split-right-close a:link,
//._phantom-limb .split-right-close a:visited {
//    color: var(--color-neutral-8);
//}
//"
vars.value.generalCssVar = "/* General Devices Preview */\r\n._phantom-limb body {\r\n    overflow: initial !important;\r\n}\r\n\r\n._phantom-limb .layout-native.hide-header-on-scroll .header {\r\n    position: sticky;\r\n}\r\n\r\n._phantom-limb .layout-native.hide-header-on-scroll .content {\r\n    padding-top: 0;\r\n}\r\n\r\n._phantom-limb .layout-native:not(.hide-header-on-scroll) .header {\r\n    top: 0;\r\n}\r\n\r\n._phantom-limb .layout-native .footer {\r\n    bottom: 0;\r\n}\r\n\r\n._phantom-limb .layout-native .header,\r\n._phantom-limb .layout-native .footer {\r\n    position: fixed;\r\n    left: 0;\r\n    right: 0;\r\n}\r\n\r\n._phantom-limb .layout-native .footer {\r\n    bottom: 0;\r\n}\r\n\r\n._phantom-limb .layout-native:not(.blank) .content {\r\n    padding-top: calc(var(--header-size) + var(--header-size-content));\r\n    padding-bottom: var(--footer-height);\r\n}\r\n\r\n._phantom-limb .landscape .layout.layout-side.layout-native .header {\r\n    z-index: 150;\r\n}\r\n\r\n._phantom-limb .landscape.phone.tablet.windows .layout-native .split-right-close {\r\n    display: block;\r\n}\r\n\r\n._phantom-limb .split-right-close a,\r\n._phantom-limb .split-right-close a:link,\r\n._phantom-limb .split-right-close a:visited {\r\n    color: var(--color-neutral-8);\r\n}\r\n";
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:NuLUeUgpEUCTkx4KpN0klA", callContext.id);
// Detects the Preview In Devices and adds support for the iPhoneX if needed
controller.safeExecuteJSNode(OutSystemsUI_controller_iPhoneXPreview_DetectPreviewInDevicesJS, "DetectPreviewInDevices", "iPhoneXPreview", {
GeneralCss: OS.DataConversion.JSNodeParamConverter.to(vars.value.generalCssVar, OS.Types.Text),
PreviewCSS: OS.DataConversion.JSNodeParamConverter.to(vars.value.previewCSSVar, OS.Types.Text)
}, function ($parameters) {
}, {
SetStickyObserver: OutSystemsUIController.default.clientActionProxies.setStickyObserver$Action
}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:lbIIpqHAUECLHUDQU3_2eA", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:NbOckAGFXESom8tE91RycA", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.iPhoneXPreview$vars", [{
name: "PreviewCSS",
attrName: "previewCSSVar",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "GeneralCss",
attrName: "generalCssVar",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.iPhoneXPreview$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.iPhoneXPreview$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$iPhoneXPreview.DetectPreviewInDevicesJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var body = document.querySelector('body');
var isIframe;
var isPreviewInDevices;

// detect Preview in Devices
function detectPreviewInDevices() {
    isIframe = window.self !== window.top;
    
    try {
        if(isIframe) {
           isPreviewInDevices = window.top.document.querySelector(".marvel-device") !== null;
        }
    } catch(e) {
        isPreviewInDevices = false;
    }
    
    if(isPreviewInDevices) {
        if(window.top.document.querySelector(".marvel-device").classList.contains("iphone-x") || window.top.document.querySelector(".marvel-device").classList.contains("iphone12mini") || window.top.document.querySelector(".marvel-device").classList.contains("iphone12pro") || window.top.document.querySelector(".marvel-device").classList.contains("iphone12max")) {
            body.classList.add('ios');
            body.classList.add('iphonex');
        }
        
        // check if sticky-observer is available and call the action for Preview in Devices
        if(document.querySelector("._phantom-limb .active-screen .sticky-observer")){
            $actions.SetStickyObserver(); 
        }
        
        addGeneralPreview();
        
    }
}

// Holds the logic to add or not the iPhoneX css preview
function addGeneralPreview() {
  
    var stylesEl = document.getElementById("preview-css");
    var css;

    if (stylesEl === null) {
        if(window.top.document.querySelector(".marvel-device").classList.contains("iphone-x") || window.top.document.querySelector(".marvel-device").classList.contains("iphone12mini") || window.top.document.querySelector(".marvel-device").classList.contains("iphone12pro") || window.top.document.querySelector(".marvel-device").classList.contains("iphone12max")) { 
            css = $parameters.PreviewCSS + $parameters.GeneralCss;
        } else {
            css = $parameters.GeneralCss;
        }
        
        var style = document.createElement('style');
        style.type = 'text/css';
        style.id = "preview-css";
      
        if (style.styleSheet){
            style.styleSheet.cssText = css;
        } else {
            style.appendChild(document.createTextNode(css));
        }
      
        document.body.appendChild(style);
    }
}

detectPreviewInDevices();
};
});

define("OutSystemsUI.controller$IsDesktop", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$GetDeviceType"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.isDesktop$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var getDeviceTypeVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.IsDesktop$outVars"))());
varBag.callContext = callContext;
varBag.getDeviceTypeVar = getDeviceTypeVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:A+Ouy1m8hEqkJ1_FDu4WGw:/ClientActionFlows.A+Ouy1m8hEqkJ1_FDu4WGw:bgZdKfEt+tvPCz4wG_A0gA", "OutSystemsUI", "IsDesktop", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:NTLxb6dpl0GnKezFuLXCrg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:LyPCmHPMOUiz05omO6N5Kg", callContext.id);
// Execute Action: GetDeviceType
getDeviceTypeVar.value = OutSystemsUIController.default.getDeviceType$Action(callContext);

OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:cxAlCplvwEOSSdLslc2ylQ", callContext.id);
// IsDesktop = GetDeviceType.Device = "desktop"
outVars.value.isDesktopOut = (getDeviceTypeVar.value.deviceOut === "desktop");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:shg_i4TieE2fMp_GRRTp+w", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:A+Ouy1m8hEqkJ1_FDu4WGw", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.IsDesktop$outVars", [{
name: "IsDesktop",
attrName: "isDesktopOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.clientActionProxies.isDesktop$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.isDesktop$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
IsDesktop: OS.DataConversion.JSNodeParamConverter.to(actionResults.isDesktopOut, OS.Types.Boolean)
};
});
};
});

define("OutSystemsUI.controller$IsLayoutNative", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$IsLayoutNative.CheckIsWebAppJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_IsLayoutNative_CheckIsWebAppJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.isLayoutNative$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var checkIsWebAppJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.IsLayoutNative$outVars"))());
varBag.callContext = callContext;
varBag.checkIsWebAppJSResult = checkIsWebAppJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:lx9tgaLOqEueK5wx+OeU2g:/ClientActionFlows.lx9tgaLOqEueK5wx+OeU2g:6y2UazCXEDU9TNpkxj5y_w", "OutSystemsUI", "IsLayoutNative", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:WxC60Fvoo0imnOA_0M6dRA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:BjdfYuAz7k2Qa63M89MgIQ", callContext.id);
checkIsWebAppJSResult.value = controller.safeExecuteJSNode(OutSystemsUI_controller_IsLayoutNative_CheckIsWebAppJS, "CheckIsWebApp", "IsLayoutNative", {
IsNative: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsUI.IsLayoutNative$checkIsWebAppJSResult"))();
jsNodeResult.isNativeOut = OS.DataConversion.JSNodeParamConverter.from($parameters.IsNative, OS.Types.Boolean);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZEnosUnOOEaBCy8p+AwC_A", callContext.id);
// IsNative = CheckIsWebApp.IsNative
outVars.value.isNativeOut = checkIsWebAppJSResult.value.isNativeOut;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:dL+JpQQ7_U+uB5tJ+k+j1g", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:lx9tgaLOqEueK5wx+OeU2g", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.IsLayoutNative$checkIsWebAppJSResult", [{
name: "IsNative",
attrName: "isNativeOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.IsLayoutNative$outVars", [{
name: "IsNative",
attrName: "isNativeOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.clientActionProxies.isLayoutNative$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.isLayoutNative$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
IsNative: OS.DataConversion.JSNodeParamConverter.to(actionResults.isNativeOut, OS.Types.Boolean)
};
});
};
});
define("OutSystemsUI.controller$IsLayoutNative.CheckIsWebAppJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var layout = document.body.querySelector('.layout');

if(layout) {
    var isNative = layout.classList.contains('layout-native');

    if(isNative) {
        $parameters.IsNative = true;
    } else {
        $parameters.IsNative = false;
    }
}

};
});

define("OutSystemsUI.controller$IsMenuDraggable", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$IsMenuDraggable.CheckIfNativeJS", "OutSystemsUI.controller$IsRunningAsPWA"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_IsMenuDraggable_CheckIfNativeJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.isMenuDraggable$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var checkIfNativeJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.IsMenuDraggable$outVars"))());
varBag.callContext = callContext;
varBag.checkIfNativeJSResult = checkIfNativeJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:Nrq11Yu9QUG7x8e2miqF_g:/ClientActionFlows.Nrq11Yu9QUG7x8e2miqF_g:_60TO+Fhro7TrjWWY6Xweg", "OutSystemsUI", "IsMenuDraggable", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:AoRWa3vjr0KRRO58Ml_SZQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:9uW+UGQms020qoCwM_hTwA", callContext.id);
checkIfNativeJSResult.value = controller.safeExecuteJSNode(OutSystemsUI_controller_IsMenuDraggable_CheckIfNativeJS, "CheckIfNative", "IsMenuDraggable", {
IsRunninAsNative: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsUI.IsMenuDraggable$checkIfNativeJSResult"))();
jsNodeResult.isRunninAsNativeOut = OS.DataConversion.JSNodeParamConverter.from($parameters.IsRunninAsNative, OS.Types.Boolean);
return jsNodeResult;
}, {}, {});
if((OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:x_zsccUNzkqBWuVlx3BtvQ", callContext.id) && (checkIfNativeJSResult.value.isRunninAsNativeOut && !(OutSystemsDebugger.handleFunctionCall(function () {
return OutSystemsUIController.default.isRunningAsPWA$Action(callContext).isStandaloneOut;
}, OS.Types.Boolean, callContext.id))))) {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:WN5EkcnMEUa9gSAwr73Jzw", callContext.id);
// AddDrag = True
outVars.value.addDragOut = true;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:yZhYFGAlTECYmc1mZ+rvVw", callContext.id);
} else {
// RemoveDrag
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:bDUEP7C72U+kTjHaTC6eow", callContext.id);
// AddDrag = False
outVars.value.addDragOut = false;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:yZhYFGAlTECYmc1mZ+rvVw", callContext.id);
}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:Nrq11Yu9QUG7x8e2miqF_g", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.IsMenuDraggable$checkIfNativeJSResult", [{
name: "IsRunninAsNative",
attrName: "isRunninAsNativeOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.IsMenuDraggable$outVars", [{
name: "AddDrag",
attrName: "addDragOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.clientActionProxies.isMenuDraggable$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.isMenuDraggable$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
AddDrag: OS.DataConversion.JSNodeParamConverter.to(actionResults.addDragOut, OS.Types.Boolean)
};
});
};
});
define("OutSystemsUI.controller$IsMenuDraggable.CheckIfNativeJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
if(window.cordova) {
    $parameters.IsRunninAsNative = true;
}
};
});

define("OutSystemsUI.controller$IsPhone", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$GetDeviceType"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.isPhone$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var getDeviceTypeVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.IsPhone$outVars"))());
varBag.callContext = callContext;
varBag.getDeviceTypeVar = getDeviceTypeVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:yHQFd4E_hEmOMh7uK+5Fyg:/ClientActionFlows.yHQFd4E_hEmOMh7uK+5Fyg:jlNGnkfs63fUxTw_ptXEWQ", "OutSystemsUI", "IsPhone", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:sqTjqT20_kKX0XFd6smU8g", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:BX3uLVf1k0Wr5zgao8m4ow", callContext.id);
// Execute Action: GetDeviceType
getDeviceTypeVar.value = OutSystemsUIController.default.getDeviceType$Action(callContext);

OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:sI5YvXpAx0yzCJClQinRcA", callContext.id);
// IsPhone = GetDeviceType.Device = "phone"
outVars.value.isPhoneOut = (getDeviceTypeVar.value.deviceOut === "phone");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:HiJh7DVYkUquZoFhy0NigQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:yHQFd4E_hEmOMh7uK+5Fyg", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.IsPhone$outVars", [{
name: "IsPhone",
attrName: "isPhoneOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.clientActionProxies.isPhone$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.isPhone$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
IsPhone: OS.DataConversion.JSNodeParamConverter.to(actionResults.isPhoneOut, OS.Types.Boolean)
};
});
};
});

define("OutSystemsUI.controller$IsRTL", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$IsRTL.CheckRTLJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_IsRTL_CheckRTLJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.isRTL$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var checkRTLJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.IsRTL$outVars"))());
varBag.callContext = callContext;
varBag.checkRTLJSResult = checkRTLJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:HjGQh2D2hU+nLBMXmpwmcw:/ClientActionFlows.HjGQh2D2hU+nLBMXmpwmcw:fGGKlGcrnSM93Y4YwPcAAw", "OutSystemsUI", "IsRTL", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Ph4QaBIuWUSY1qD+ld_GMw", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:AvkLh6PCIkWXMP_fWWgdKA", callContext.id);
// Retunrs the value of IsRTL
checkRTLJSResult.value = controller.safeExecuteJSNode(OutSystemsUI_controller_IsRTL_CheckRTLJS, "CheckRTL", "IsRTL", {
RTL: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsUI.IsRTL$checkRTLJSResult"))();
jsNodeResult.rTLOut = OS.DataConversion.JSNodeParamConverter.from($parameters.RTL, OS.Types.Boolean);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:p6P7C3DiI0WZrIN1Stmo_w", callContext.id);
// IsRTL = CheckRTL.RTL
outVars.value.isRTLOut = checkRTLJSResult.value.rTLOut;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:a1AFToz+ZEiA_fuuO2V99w", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:HjGQh2D2hU+nLBMXmpwmcw", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.IsRTL$checkRTLJSResult", [{
name: "RTL",
attrName: "rTLOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.IsRTL$outVars", [{
name: "IsRTL",
attrName: "isRTLOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.clientActionProxies.isRTL$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.isRTL$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
IsRTL: OS.DataConversion.JSNodeParamConverter.to(actionResults.isRTLOut, OS.Types.Boolean)
};
});
};
});
define("OutSystemsUI.controller$IsRTL.CheckRTLJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.RTL = document.querySelector('.is-rtl') ? true : false;
};
});

define("OutSystemsUI.controller$IsRunningAsPWA", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$IsRunningAsPWA.IsRunningAsPWAJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_IsRunningAsPWA_IsRunningAsPWAJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.isRunningAsPWA$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var isRunningAsPWAJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.IsRunningAsPWA$outVars"))());
varBag.callContext = callContext;
varBag.isRunningAsPWAJSResult = isRunningAsPWAJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:O_Ml7RGknUKI9tOPbQZuzQ:/ClientActionFlows.O_Ml7RGknUKI9tOPbQZuzQ:QJJA3hJclpNgXUH9hduXmA", "OutSystemsUI", "IsRunningAsPWA", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:iAzpqeW8YE+hQY0ysv1bTQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ho14ByP0d0KPoK4vE2Wcbw", callContext.id);
isRunningAsPWAJSResult.value = controller.safeExecuteJSNode(OutSystemsUI_controller_IsRunningAsPWA_IsRunningAsPWAJS, "IsRunningAsPWA", "IsRunningAsPWA", {
isStandalone: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsUI.IsRunningAsPWA$isRunningAsPWAJSResult"))();
jsNodeResult.isStandaloneOut = OS.DataConversion.JSNodeParamConverter.from($parameters.isStandalone, OS.Types.Boolean);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:jefUQlH3PUaIAN9jziLkZw", callContext.id);
// IsStandalone = IsRunningAsPWA.isStandalone
outVars.value.isStandaloneOut = isRunningAsPWAJSResult.value.isStandaloneOut;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:z1rKWThoikyqbsqTH28vdw", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:O_Ml7RGknUKI9tOPbQZuzQ", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.IsRunningAsPWA$isRunningAsPWAJSResult", [{
name: "isStandalone",
attrName: "isStandaloneOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.IsRunningAsPWA$outVars", [{
name: "IsStandalone",
attrName: "isStandaloneOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.clientActionProxies.isRunningAsPWA$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.isRunningAsPWA$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
IsStandalone: OS.DataConversion.JSNodeParamConverter.to(actionResults.isStandaloneOut, OS.Types.Boolean)
};
});
};
});
define("OutSystemsUI.controller$IsRunningAsPWA.IsRunningAsPWAJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
if (window.matchMedia && (window.matchMedia('(display-mode: standalone)').matches) || window.navigator.standalone === true) {
    $parameters.isStandalone = true;
}
else {
    $parameters.isStandalone = false;
}
};
});

define("OutSystemsUI.controller$IsTablet", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$GetDeviceType"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.isTablet$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var getDeviceTypeVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.IsTablet$outVars"))());
varBag.callContext = callContext;
varBag.getDeviceTypeVar = getDeviceTypeVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:eSfw9qKoGkSe9uxu_d4bSg:/ClientActionFlows.eSfw9qKoGkSe9uxu_d4bSg:z2DgsomQNC4CEYwnUUgrQQ", "OutSystemsUI", "IsTablet", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:AoelbxLQKUqZjyK10lGysw", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ioZf772KpUSfGBw8JlIMDw", callContext.id);
// Execute Action: GetDeviceType
getDeviceTypeVar.value = OutSystemsUIController.default.getDeviceType$Action(callContext);

OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:PbdePxtRWE68PTVq_rpzaw", callContext.id);
// IsTablet = GetDeviceType.Device = "tablet"
outVars.value.isTabletOut = (getDeviceTypeVar.value.deviceOut === "tablet");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:JWCYa7HVNEGLLv_HARuYcQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:eSfw9qKoGkSe9uxu_d4bSg", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.IsTablet$outVars", [{
name: "IsTablet",
attrName: "isTabletOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.clientActionProxies.isTablet$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.isTablet$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
IsTablet: OS.DataConversion.JSNodeParamConverter.to(actionResults.isTabletOut, OS.Types.Boolean)
};
});
};
});

define("OutSystemsUI.controller$IsWebApp", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$IsWebApp.CheckIsWebAppJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_IsWebApp_CheckIsWebAppJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.isWebApp$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var checkIsWebAppJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.IsWebApp$outVars"))());
varBag.callContext = callContext;
varBag.checkIsWebAppJSResult = checkIsWebAppJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:02qGF+VI30iww9i_k+iKfA:/ClientActionFlows.02qGF+VI30iww9i_k+iKfA:QFjHOVPP1wij7uuBuqRr3g", "OutSystemsUI", "IsWebApp", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:GielZ0yGqkW7VIAg9TrmJQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:A8C7OkSCkkqYxzxiYRUweA", callContext.id);
checkIsWebAppJSResult.value = controller.safeExecuteJSNode(OutSystemsUI_controller_IsWebApp_CheckIsWebAppJS, "CheckIsWebApp", "IsWebApp", {
IsWebApp: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsUI.IsWebApp$checkIsWebAppJSResult"))();
jsNodeResult.isWebAppOut = OS.DataConversion.JSNodeParamConverter.from($parameters.IsWebApp, OS.Types.Boolean);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:e0xiL7IHIkuRGzAdAPR3hw", callContext.id);
// IsWebApp = CheckIsWebApp.IsWebApp
outVars.value.isWebAppOut = checkIsWebAppJSResult.value.isWebAppOut;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:++p8oBPhkEiRVivVDh0l0A", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:02qGF+VI30iww9i_k+iKfA", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.IsWebApp$checkIsWebAppJSResult", [{
name: "IsWebApp",
attrName: "isWebAppOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.IsWebApp$outVars", [{
name: "IsWebApp",
attrName: "isWebAppOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.clientActionProxies.isWebApp$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.isWebApp$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
IsWebApp: OS.DataConversion.JSNodeParamConverter.to(actionResults.isWebAppOut, OS.Types.Boolean)
};
});
};
});
define("OutSystemsUI.controller$IsWebApp.CheckIsWebAppJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var layout = document.body.querySelector('.layout');

if(layout) {
    var isNative = layout.classList.contains('layout-native');
    var isNotOldNativeLayouts = document.querySelector('.active-screen .layout.layout-top') || document.querySelector('.active-screen .layout.layout-side') || document.querySelector('.active-screen .layout.blank') || document.querySelector('.active-screen .layout.layout-blank');
    
    if(isNotOldNativeLayouts && !isNative) {
            $parameters.IsWebApp = true;
    }
}

};
});

define("OutSystemsUI.controller$LayoutReady", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$LayoutReady.RunOnStartJS", "OutSystemsUI.controller$LayoutReady.GetHeaderAndFooterSizeJS", "OutSystemsUI.controller$LayoutReady.FixForRenderingIssuesJS", "OutSystemsUI.controller$LayoutReady.ViewportJS", "OutSystemsUI.controller$LayoutReady.CloseMenuOnBodyClickJS", "OutSystemsUI.controller$LayoutReady.SetExpandableExceptionsJS", "OutSystemsUI.controller$iPhoneXPreview", "OutSystemsUI.controller$FixInputs", "OutSystemsUI.controller$IsRunningAsPWA", "OutSystemsUI.controller$IsWebApp", "OutSystemsUI.controller$DeviceDetection", "OutSystemsUI.controller$ECTCall", "OutSystemsUI.controller$WCAGMetaTag", "OutSystemsUI.controller$ToggleSideMenu", "OutSystemsUI.controller$SetStickyObserver"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_LayoutReady_RunOnStartJS, OutSystemsUI_controller_LayoutReady_GetHeaderAndFooterSizeJS, OutSystemsUI_controller_LayoutReady_FixForRenderingIssuesJS, OutSystemsUI_controller_LayoutReady_ViewportJS, OutSystemsUI_controller_LayoutReady_CloseMenuOnBodyClickJS, OutSystemsUI_controller_LayoutReady_SetExpandableExceptionsJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.layoutReady$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.LayoutReady$vars"))());
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:3YPe0a8dvEOq0s0BQKEmYA:/ClientActionFlows.3YPe0a8dvEOq0s0BQKEmYA:maFz7tckDZs0qYvuaF0Rfw", "OutSystemsUI", "LayoutReady", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:gGkKczYuTUWJTqZtPQ8ZWw", callContext.id);
// Init IsWebApp and IsPWA
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:abi+PXG80Uq9gnuUQfZdJA", callContext.id);
// IsWebApp = IsWebApp()
vars.value.isWebAppVar = OutSystemsDebugger.handleFunctionCall(function () {
return OutSystemsUIController.default.isWebApp$Action(callContext).isWebAppOut;
}, OS.Types.Boolean, callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:abi+PXG80Uq9gnuUQfZdJA", callContext.id, OutSystemsDebugger.BreakpointType.BetweenAssignments, "2");
// IsPWA = IsRunningAsPWA()
vars.value.isPWAVar = OutSystemsDebugger.handleFunctionCall(function () {
return OutSystemsUIController.default.isRunningAsPWA$Action(callContext).isStandaloneOut;
}, OS.Types.Boolean, callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:PdwtDmJ9MUKMS4YDtId34w", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_LayoutReady_RunOnStartJS, "RunOnStart", "LayoutReady", {
IsPWA: OS.DataConversion.JSNodeParamConverter.to(vars.value.isPWAVar, OS.Types.Boolean),
IsWebApp: OS.DataConversion.JSNodeParamConverter.to(vars.value.isWebAppVar, OS.Types.Boolean)
}, function ($parameters) {
}, {
DeviceDetection: OutSystemsUIController.default.clientActionProxies.deviceDetection$Action,
ECTCall: OutSystemsUIController.default.clientActionProxies.eCTCall$Action,
WCAGMetaTag: OutSystemsUIController.default.clientActionProxies.wCAGMetaTag$Action
}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:fd7I_BtwWkecM47jRYQwFQ", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_LayoutReady_SetExpandableExceptionsJS, "SetExpandableExceptions", "LayoutReady", null, function ($parameters) {
}, {
ToggleSideMenu: OutSystemsUIController.default.clientActionProxies.toggleSideMenu$Action,
SetStickyObserver: OutSystemsUIController.default.clientActionProxies.setStickyObserver$Action
}, {});
if((OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:cub9l9AjtE+lUq_EVw9sqg", callContext.id) && vars.value.isWebAppVar)) {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:9bcwgxs8tka6zDwDgHPlfg", callContext.id);
// Execute Action: FixInputs
OutSystemsUIController.default.fixInputs$Action(callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:B2Fl0bIY5UqjnDYFY8KlvA", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_LayoutReady_CloseMenuOnBodyClickJS, "CloseMenuOnBodyClick", "LayoutReady", null, function ($parameters) {
}, {}, {});
} else {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:b0DbFMMJeE6xWwKtJdAwxA", callContext.id);
// Execute Action: iPhoneXPreview
OutSystemsUIController.default.iPhoneXPreview$Action(callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:07SEFfNsg0K4cJ3Z4ke3iA", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_LayoutReady_GetHeaderAndFooterSizeJS, "GetHeaderAndFooterSize", "LayoutReady", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:vedik6OqRESlGJkYBGu5Tg", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_LayoutReady_FixForRenderingIssuesJS, "FixForRenderingIssues", "LayoutReady", null, function ($parameters) {
}, {}, {});
}

OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:9hie0LpEdE24tR9bVTqriQ", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_LayoutReady_ViewportJS, "Viewport", "LayoutReady", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:gSzoQbcWEEqViZ16wV_Brg", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:3YPe0a8dvEOq0s0BQKEmYA", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.LayoutReady$vars", [{
name: "IsWebApp",
attrName: "isWebAppVar",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "IsPWA",
attrName: "isPWAVar",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.clientActionProxies.layoutReady$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.layoutReady$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$LayoutReady.RunOnStartJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
// Actions that run only once per application start

if(window.applicationStarted === undefined) {
    $actions.DeviceDetection($parameters.IsWebApp);

    if($parameters.IsWebApp || $parameters.IsPWA) {
        $actions.ECTCall();  
        $actions.WCAGMetaTag();
    }
    
    // Call the "Built with OutSystems" label for Reactive Web apps
    var showMWO = false;
    
    try {
        showMWO = $public.Branding.showOutSystemsWatermark();
    } catch(e) {
        
    }
    
    if(showMWO && $parameters.IsWebApp) {
        osui.StartMWO();
    }
    
    window.applicationStarted = true;
}
};
});
define("OutSystemsUI.controller$LayoutReady.GetHeaderAndFooterSizeJS", [], function () {
return function ($actions, $roles, $public) {
var headerContent = document.querySelector('.header-top-content');
var footer = document.querySelector('.footer');
var body = document.body;

if(headerContent) {
    var headerContentHeight = headerContent.getBoundingClientRect().height;
    body.style.setProperty('--header-size-content', headerContentHeight + "px");
}

if(footer) {
    var footerHeight = footer.getBoundingClientRect().height;
    body.style.setProperty('--footer-height', footerHeight + "px"); 
}
};
});
define("OutSystemsUI.controller$LayoutReady.FixForRenderingIssuesJS", [], function () {
return function ($actions, $roles, $public) {
// Simulate scroll to avoid rendering issues on WebView (replicated on Tablet devices)
var docElem = document.documentElement;

docElem.scrollLeft = 2;

setTimeout(function(){ 
    docElem.scrollLeft = 0;
}, 100);
};
});
define("OutSystemsUI.controller$LayoutReady.ViewportJS", [], function () {
return function ($actions, $roles, $public) {
if(document.body.classList.contains('phone') || document.body.classList.contains('tablet')) {
    document.body.style.setProperty('--viewport-height', innerHeight + 'px');
}
};
});
define("OutSystemsUI.controller$LayoutReady.CloseMenuOnBodyClickJS", [], function () {
return function ($actions, $roles, $public) {
var isDesktop = document.body.classList.contains('desktop');
var layout = document.querySelector('.layout');
var isSideMenu;

if(layout) {
   isSideMenu = layout.classList.contains('layout-side'); 
}

var closeOnBodyClick = function() {
    var menu = document.querySelector('.app-menu-links');
    
    if(menu) {
        var subItems = menu.querySelectorAll('.submenu');
        
        if(subItems.length > 0) {
            for(var i = 0; i < subItems.length; i++) {
                if(subItems[i].classList.contains('open')) {
                    subItems[i].CloseMenu();
                } 
            }
        }    
    }
};

// If is Desktop and not SideMenu, add eventListener on Body, to close Menu on click
if(isDesktop && !isSideMenu) {
   document.body.addEventListener('click', closeOnBodyClick);
}

};
});
define("OutSystemsUI.controller$LayoutReady.SetExpandableExceptionsJS", [], function () {
return function ($actions, $roles, $public) {
var layout = document.querySelector('.layout');
var body = document.body;
var isExpandable = layout.classList.contains('aside-expandable');
var nativeLayout = layout.classList.contains('layout-native');
var isTabletLandscape = body.classList.contains('tablet') && body.classList.contains('landscape');
var isDesktop = body.classList.contains('desktop');
var isHideOnScroll = layout.classList.contains('hide-header-on-scroll');


if(layout && isExpandable && (nativeLayout && isTabletLandscape || isDesktop)) {
    $actions.ToggleSideMenu();
}

// Set StickyListener when HideHeaderOnScroll is used to adapt menu padding when Expandable
if(layout && nativeLayout && isHideOnScroll && isExpandable && (isTabletLandscape || isDesktop)) {
    $actions.SetStickyObserver();
}
};
});

define("OutSystemsUI.controller$LayoutReadyMobile", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$HasMasterDetail", "OutSystemsUI.controller$ECTCall", "OutSystemsUI.controller$iPhoneXPreview", "OutSystemsUI.controller$FixInputs", "OutSystemsUI.controller$DeviceDetection", "OutSystemsUI.controller$HideHeader", "OutSystemsUI.controller$IsRunningAsPWA"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.layoutReadyMobile$Action = function (hideHeaderOnScrollIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.LayoutReadyMobile$vars"))());
vars.value.hideHeaderOnScrollInLocal = hideHeaderOnScrollIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:gMQKaTC8KUWmUEZZexJTUA:/ClientActionFlows.gMQKaTC8KUWmUEZZexJTUA:P5fV5HYfb_HUX8I0bw5_Vw", "OutSystemsUI", "LayoutReadyMobile", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:nv6CGv91ZEC553LJXqmGZg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:vBVwkeGXhUWn8nVijd41Fg", callContext.id);
// Execute Action: DeviceDetection
OutSystemsUIController.default.deviceDetection$Action(false, callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:e3SDeDlqWUuEd2GHxB8F_w", callContext.id);
// Execute Action: iPhoneXPreview
OutSystemsUIController.default.iPhoneXPreview$Action(callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:E7sEqVzT0ECAYxEv56NPlw", callContext.id);
// Execute Action: HideHeader
OutSystemsUIController.default.hideHeader$Action(vars.value.hideHeaderOnScrollInLocal, callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Ly3djGDLQ0eI92tAbDMTAw", callContext.id);
// Execute Action: FixInputs
OutSystemsUIController.default.fixInputs$Action(callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:YAbyNvISkkOmjdeqPvPIPQ", callContext.id);
// Execute Action: HasMasterDetail
OutSystemsUIController.default.hasMasterDetail$Action(callContext);
// isPWA?
if((OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:HsxguUD1z0i2pq1+B4miHg", callContext.id) && OutSystemsDebugger.handleFunctionCall(function () {
return OutSystemsUIController.default.isRunningAsPWA$Action(callContext).isStandaloneOut;
}, OS.Types.Boolean, callContext.id))) {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:IiwkQ+FNyEmosnFoHFcnkw", callContext.id);
// Execute Action: ECTCall
OutSystemsUIController.default.eCTCall$Action(callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:xz_lS09TxkawPtD9+erq_A", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:xz_lS09TxkawPtD9+erq_A", callContext.id);
}

return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:gMQKaTC8KUWmUEZZexJTUA", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.LayoutReadyMobile$vars", [{
name: "HideHeaderOnScroll",
attrName: "hideHeaderOnScrollInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.clientActionProxies.layoutReadyMobile$Action = function (hideHeaderOnScrollIn) {
hideHeaderOnScrollIn = (hideHeaderOnScrollIn === undefined) ? false : hideHeaderOnScrollIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.layoutReadyMobile$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(hideHeaderOnScrollIn, OS.Types.Boolean)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});

define("OutSystemsUI.controller$ListItemHint", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$ListItemHint.ListItemAnimateJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_ListItemHint_ListItemAnimateJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.listItemHint$Action = function (listIdIn, hasLeftActionIn, hasRightActionIn, animationTimeIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.ListItemHint$vars"))());
vars.value.listIdInLocal = listIdIn;
vars.value.hasLeftActionInLocal = hasLeftActionIn;
vars.value.hasRightActionInLocal = hasRightActionIn;
vars.value.animationTimeInLocal = animationTimeIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:zInTb5waXk6r33Wt42NZGg:/ClientActionFlows.zInTb5waXk6r33Wt42NZGg:1W2pivi+QoNAa1KGwqCC0Q", "OutSystemsUI", "ListItemHint", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:TqkjCJNYoUiv3yTkFD6Q_g", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:HI7FczBGrEKwVfINKPZ6vA", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_ListItemHint_ListItemAnimateJS, "ListItemAnimate", "ListItemHint", {
AnimationTime: OS.DataConversion.JSNodeParamConverter.to(vars.value.animationTimeInLocal, OS.Types.Decimal),
ListId: OS.DataConversion.JSNodeParamConverter.to(vars.value.listIdInLocal, OS.Types.Text),
HasRightAction: OS.DataConversion.JSNodeParamConverter.to(vars.value.hasRightActionInLocal, OS.Types.Boolean),
HasLeftAction: OS.DataConversion.JSNodeParamConverter.to(vars.value.hasLeftActionInLocal, OS.Types.Boolean)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:R5jQfKdCSkuzzP2KGVEAiA", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:zInTb5waXk6r33Wt42NZGg", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.ListItemHint$vars", [{
name: "ListId",
attrName: "listIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "HasLeftAction",
attrName: "hasLeftActionInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "HasRightAction",
attrName: "hasRightActionInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "AnimationTime",
attrName: "animationTimeInLocal",
mandatory: true,
dataType: OS.Types.Decimal,
defaultValue: function () {
return OS.DataTypes.Decimal.defaultValue;
}
}]);
OutSystemsUIController.default.clientActionProxies.listItemHint$Action = function (listIdIn, hasLeftActionIn, hasRightActionIn, animationTimeIn) {
listIdIn = (listIdIn === undefined) ? "" : listIdIn;
hasLeftActionIn = (hasLeftActionIn === undefined) ? false : hasLeftActionIn;
hasRightActionIn = (hasRightActionIn === undefined) ? false : hasRightActionIn;
animationTimeIn = (animationTimeIn === undefined) ? OS.DataTypes.Decimal.defaultValue : animationTimeIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.listItemHint$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(listIdIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(hasLeftActionIn, OS.Types.Boolean), OS.DataConversion.JSNodeParamConverter.from(hasRightActionIn, OS.Types.Boolean), OS.DataConversion.JSNodeParamConverter.from(animationTimeIn, OS.Types.Decimal)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$ListItemHint.ListItemAnimateJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var timeoutVar;
var timeAnimation = $parameters.AnimationTime / 6;

var waitListRender = function() {
    listEl = document.querySelector('#' + $parameters.ListId);

    if(!listEl.classList.contains('list-loading')) { 
        listAnimateItems();
        clearTimeout(timeoutVar);
    } else {
        timeoutVar = setTimeout(waitListRender, 50);
    }
};

var listAnimateItems = function() {
    setTimeout(function(){
        listElement = document.getElementById($parameters.ListId).childNodes[1];
        listItemContentLeft = listElement.querySelector('.active-screen .list-item-left-actions');
        listItemContentRight = listElement.querySelector('.active-screen .list-item-right-actions');
        
        listElement.style.pointerEvents = 'none';
        
        if($parameters.HasLeftAction && $parameters.HasRightAction || $parameters.HasLeftAction) {
            listItemContentLeft.classList.add('has-content-animation');
            listItemContentLeft.setAttribute('style', 'width:75px; transition: all ' + timeAnimation + 'ms !important;');
            
            setTimeout(function(){
                listItemContentLeft.style.width = '';
                
                listItemContentLeft.addEventListener("transitionend", function(event) {
                    listItemContentLeft.classList.remove('has-content-animation');
                    listItemContentLeft.removeAttribute('style');
                    listElement.style.pointerEvents = '';
                }, false);
                
            },timeAnimation * 3);
            
        } else if($parameters.HasRightAction) {
            listItemContentRight.classList.add('has-content-animation-right');
            listItemContentRight.setAttribute('style', 'width:75px; transition: all ' + timeAnimation + 'ms !important; height: ' + listElement.offsetHeight + 'px;');
            
            setTimeout(function(){
                listItemContentRight.style.width = '';
                
                listItemContentRight.addEventListener("transitionend", function(event) {
                    listItemContentRight.classList.remove('has-content-animation-right');
                    listItemContentRight.removeAttribute('style');
                    listElement.style.pointerEvents = '';
                }, false);

            }, timeAnimation * 3);
        }    
    },timeAnimation); // waiting for screen transition ends
};

waitListRender();

};
});

define("OutSystemsUI.controller$MasterDetailSetContentFocus", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$MasterDetailSetContentFocus.SetFocusBehaviourJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_MasterDetailSetContentFocus_SetFocusBehaviourJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.masterDetailSetContentFocus$Action = function (contentIdIn, triggerItemIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.MasterDetailSetContentFocus$vars"))());
vars.value.contentIdInLocal = contentIdIn;
vars.value.triggerItemInLocal = triggerItemIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:3wuNsg73ZEiE8P2CkpP9KQ:/ClientActionFlows.3wuNsg73ZEiE8P2CkpP9KQ:mx52CeutTkcBrBid7AqkEg", "OutSystemsUI", "MasterDetailSetContentFocus", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:umhO4t1XbkqQxH9AU8G4uQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:UufczVjIsEqSMRYpostVdw", callContext.id);
// MasterDetail focus behaviour
controller.safeExecuteJSNode(OutSystemsUI_controller_MasterDetailSetContentFocus_SetFocusBehaviourJS, "SetFocusBehaviour", "MasterDetailSetContentFocus", {
SetFocusWidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.contentIdInLocal, OS.Types.Text),
ClickedItemId: OS.DataConversion.JSNodeParamConverter.to(vars.value.triggerItemInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:p8Zn95o0eEe6GzaS83pa1g", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:3wuNsg73ZEiE8P2CkpP9KQ", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.MasterDetailSetContentFocus$vars", [{
name: "ContentId",
attrName: "contentIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "TriggerItem",
attrName: "triggerItemInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.masterDetailSetContentFocus$Action = function (contentIdIn, triggerItemIn) {
contentIdIn = (contentIdIn === undefined) ? "" : contentIdIn;
triggerItemIn = (triggerItemIn === undefined) ? "" : triggerItemIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.masterDetailSetContentFocus$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(contentIdIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(triggerItemIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$MasterDetailSetContentFocus.SetFocusBehaviourJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
// Set focus in the container
var elementId = document.getElementById($parameters.SetFocusWidgetId);
var isPhone = document.body.classList.contains('phone');

elementId.setAttribute('tabindex', "0");
elementId.focus();

if(!isPhone) {
    // Set the properties to define the tab navigation inside the content
    var focusItemTop = elementId.closest(".split-right-content").querySelector("span.focus-item.top");
    focusItemTop.setAttribute("tabindex", "0");
    focusItemTop.setAttribute("focusItemId", $parameters.ClickedItemId);
    
    var focusItemBottom = elementId.closest(".split-right-content").querySelector("span.focus-item.bottom");
    if(document.querySelector("#"+$parameters.ClickedItemId + " + div")){
        focusItemBottom.setAttribute("tabindex", "0");
        focusItemBottom.setAttribute("focusItemId", document.querySelector("#"+$parameters.ClickedItemId + " + div").id);   
    }
    else {
        focusItemBottom.setAttribute("tabindex", "-1");
        focusItemBottom.removeAttribute("focusItemId");
    } 
}
};
});

define("OutSystemsUI.controller$MenuHide", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$MenuHide.ToggleLayoutClassJS", "OutSystemsUI.controller$SetMenuAttributes"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_MenuHide_ToggleLayoutClassJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.menuHide$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:rTUt1ZeC60SXXTbA17bXvg:/ClientActionFlows.rTUt1ZeC60SXXTbA17bXvg:2Ruf3xRqYsKlBeUrgfWZMw", "OutSystemsUI", "MenuHide", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:GDX+rV1O5kq12XItQlSn0Q", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:9md9YTHjZkiZZN3suuWnkg", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_MenuHide_ToggleLayoutClassJS, "ToggleLayoutClass", "MenuHide", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:2CMMB0HzZEC6nyNriXP6hw", callContext.id);
// Execute Action: SetMenuAttributes
OutSystemsUIController.default.setMenuAttributes$Action(callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:MHbbMoVcvUqcZ22JkcaTVA", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:rTUt1ZeC60SXXTbA17bXvg", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.clientActionProxies.menuHide$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.menuHide$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$MenuHide.ToggleLayoutClassJS", [], function () {
return function ($actions, $roles, $public) {
var menu = document.querySelector('.menu');
var appMenu = document.querySelector('.app-menu-container');
var menuOverlay = document.querySelector('.menu-background');

if(menu) {
    menu.classList.remove('menu--visible');

     if(menuOverlay) {
            menuOverlay.style.opacity = "";
    }
    
    appMenu.style.transform =  "";
    appMenu.style.webkitTransform =  "";
    
    
    menu.addEventListener("transitionend", OnTransitionEnd, false);
}

function OnTransitionEnd() {
    menu.classList.remove('menu--animatable');
    
    menu.removeEventListener("transitionend", OnTransitionEnd);
}

};
});

define("OutSystemsUI.controller$MenuShow", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$MenuShow.ToggleLayoutClassJS", "OutSystemsUI.controller$SetMenuAttributes"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_MenuShow_ToggleLayoutClassJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.menuShow$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:kaZY_xZ0Q0WkzEXP5e61QQ:/ClientActionFlows.kaZY_xZ0Q0WkzEXP5e61QQ:RJPceJR1VqyP0vAE3Qknxw", "OutSystemsUI", "MenuShow", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:1F_gKW0w3kiU1fVedwTQPA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:+p4JrADMgEuyMGCRVuSHCA", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_MenuShow_ToggleLayoutClassJS, "ToggleLayoutClass", "MenuShow", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Bdzy9IeAXEWqOgmZoO4bnQ", callContext.id);
// Execute Action: SetMenuAttributes
OutSystemsUIController.default.setMenuAttributes$Action(callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:tLfQai9OfkS9OKvWPJfK5w", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:kaZY_xZ0Q0WkzEXP5e61QQ", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.clientActionProxies.menuShow$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.menuShow$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$MenuShow.ToggleLayoutClassJS", [], function () {
return function ($actions, $roles, $public) {
var myMenu = document.querySelector(".menu");

myMenu.classList.add('menu--visible');
myMenu.classList.add('menu--animatable');
};
});

define("OutSystemsUI.controller$MoveElement", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$MoveElement.MoveElementJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_MoveElement_MoveElementJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.moveElement$Action = function (widgetIDIn, targetIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.MoveElement$vars"))());
vars.value.widgetIDInLocal = widgetIDIn;
vars.value.targetInLocal = targetIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:fKauCzBE8E+Jnb0QL5gRGQ:/ClientActionFlows.fKauCzBE8E+Jnb0QL5gRGQ:8WpESp+7t2849CNeYVszpg", "OutSystemsUI", "MoveElement", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:X4j8W89180G23LxsRYkLpA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ys785lY_qE6ziCYEBGOpgw", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_MoveElement_MoveElementJS, "MoveElement", "MoveElement", {
Target: OS.DataConversion.JSNodeParamConverter.to(vars.value.targetInLocal, OS.Types.Object),
Element: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIDInLocal, OS.Types.Object)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:oolQX8C0XUGcbQqdZ6H8Hg", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:fKauCzBE8E+Jnb0QL5gRGQ", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.MoveElement$vars", [{
name: "WidgetID",
attrName: "widgetIDInLocal",
mandatory: true,
dataType: OS.Types.Object,
defaultValue: function () {
return null;
}
}, {
name: "Target",
attrName: "targetInLocal",
mandatory: true,
dataType: OS.Types.Object,
defaultValue: function () {
return null;
}
}]);
OutSystemsUIController.default.clientActionProxies.moveElement$Action = function (widgetIDIn, targetIn) {
widgetIDIn = (widgetIDIn === undefined) ? null : widgetIDIn;
targetIn = (targetIn === undefined) ? null : targetIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.moveElement$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIDIn, OS.Types.Object), OS.DataConversion.JSNodeParamConverter.from(targetIn, OS.Types.Object)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$MoveElement.MoveElementJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
if($parameters.Target && $parameters.Element) {
    var screenEl = document.getElementById($parameters.Element);
    var element = document.querySelector($parameters.Target);
    
    if(screenEl && element) {
        element.appendChild(screenEl);
    }
}
};
});

define("OutSystemsUI.controller$RTLObserver", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$RTLObserver.ObserverJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_RTLObserver_ObserverJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.rTLObserver$Action = function (callbackIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.RTLObserver$vars"))());
vars.value.callbackInLocal = callbackIn;
var observerJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.RTLObserver$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.observerJSResult = observerJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:h6QfrQ1kp0aqFegcitXG2A:/ClientActionFlows.h6QfrQ1kp0aqFegcitXG2A:TOAXcf+YVepQQ4lmQAGNzQ", "OutSystemsUI", "RTLObserver", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:kM1cIjyAE0azqw4BpmIuHQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:I0v7qVLxN0yTq6rIFmubjw", callContext.id);
observerJSResult.value = controller.safeExecuteJSNode(OutSystemsUI_controller_RTLObserver_ObserverJS, "Observer", "RTLObserver", {
Callback: OS.DataConversion.JSNodeParamConverter.to(vars.value.callbackInLocal, OS.Types.Object),
RTLObserverObj: OS.DataConversion.JSNodeParamConverter.to(null, OS.Types.Object)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsUI.RTLObserver$observerJSResult"))();
jsNodeResult.rTLObserverObjOut = OS.DataConversion.JSNodeParamConverter.from($parameters.RTLObserverObj, OS.Types.Object);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:YIynuWPltkSaOoOYPknDRg", callContext.id);
// RTObserverObj = Observer.RTLObserverObj
outVars.value.rTObserverObjOut = observerJSResult.value.rTLObserverObjOut;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:+NagTJ0RIUqSXgZDjhvq3A", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:h6QfrQ1kp0aqFegcitXG2A", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.RTLObserver$vars", [{
name: "Callback",
attrName: "callbackInLocal",
mandatory: true,
dataType: OS.Types.Object,
defaultValue: function () {
return null;
}
}]);
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.RTLObserver$observerJSResult", [{
name: "RTLObserverObj",
attrName: "rTLObserverObjOut",
mandatory: true,
dataType: OS.Types.Object,
defaultValue: function () {
return null;
}
}]);
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.RTLObserver$outVars", [{
name: "RTObserverObj",
attrName: "rTObserverObjOut",
mandatory: false,
dataType: OS.Types.Object,
defaultValue: function () {
return null;
}
}]);
OutSystemsUIController.default.clientActionProxies.rTLObserver$Action = function (callbackIn) {
callbackIn = (callbackIn === undefined) ? null : callbackIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.rTLObserver$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(callbackIn, OS.Types.Object)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
RTObserverObj: OS.DataConversion.JSNodeParamConverter.to(actionResults.rTObserverObjOut, OS.Types.Object)
};
});
};
});
define("OutSystemsUI.controller$RTLObserver.ObserverJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var elemToObserve = document.body;
var hasAlreadyRTL = elemToObserve.classList.contains('is-rtl');

var observer = new MutationObserver(function(mutations) {
                    mutations.forEach(function(mutation) {
                        if(mutation.attributeName == "class"){
                            var hasRTLNow = mutation.target.classList.contains('is-rtl');
                            if(hasAlreadyRTL !== hasRTLNow){
                                hasAlreadyRTL = hasRTLNow;
                                $parameters.Callback();
                            }
                        }
                    });
                });
observer.observe(elemToObserve, {attributes: true});


$parameters.RTLObserverObj = observer;
};
});

define("OutSystemsUI.controller$ScrollToElement", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$ScrollToElement.ScrollToElementJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_ScrollToElement_ScrollToElementJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.scrollToElement$Action = function (widgetIdIn, isSmoothIn, offSetIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.ScrollToElement$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
vars.value.isSmoothInLocal = isSmoothIn;
vars.value.offSetInLocal = offSetIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:I55BcigVtEezFElENRqUAg:/ClientActionFlows.I55BcigVtEezFElENRqUAg:KYB0bid7EVSFEzgL_2LE4A", "OutSystemsUI", "ScrollToElement", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:E+Ij_as6bEm21n4IAFpCWA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:mE133IzgnEmi05Gp0HG3Nw", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_ScrollToElement_ScrollToElementJS, "ScrollToElement", "ScrollToElement", {
IsSmooth: OS.DataConversion.JSNodeParamConverter.to(vars.value.isSmoothInLocal, OS.Types.Boolean),
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text),
OffSet: OS.DataConversion.JSNodeParamConverter.to(vars.value.offSetInLocal, OS.Types.Integer)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:kUCWkT5P006vwSboeaiJ8w", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:I55BcigVtEezFElENRqUAg", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.ScrollToElement$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "IsSmooth",
attrName: "isSmoothInLocal",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return true;
}
}, {
name: "OffSet",
attrName: "offSetInLocal",
mandatory: false,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
OutSystemsUIController.default.clientActionProxies.scrollToElement$Action = function (widgetIdIn, isSmoothIn, offSetIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
isSmoothIn = (isSmoothIn === undefined) ? true : isSmoothIn;
offSetIn = (offSetIn === undefined) ? 0 : offSetIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.scrollToElement$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(isSmoothIn, OS.Types.Boolean), OS.DataConversion.JSNodeParamConverter.from(offSetIn, OS.Types.Integer)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$ScrollToElement.ScrollToElementJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
// isolate the code in order for the variables not be reacheable through the console and therefore manipulated without awareness
var scrollToElement = function() { 
    var isSmooth = $parameters.IsSmooth;
    var target = document.getElementById($parameters.WidgetId);
    var header = document.querySelector('.header');
    var layout = document.querySelector('.layout');
    var isFixed = layout.classList.contains('fixed-header');
    
    // pull the target up from its original position, pulling it the header amount so in the end it won't be covered by the header
    // it removes the height from whatever offset you might want to remove from the top
    if(isFixed) {
        target.style.transform = 'translateY(' + (-header.offsetHeight + (-$parameters.OffSet))+ 'px)';
    } else {
        target.style.transform = 'translateY('+ (-$parameters.OffSet) + 'px)';
    }
    
    target.style.display = 'block';


    // timeout needs to be added as a hack for the scrollIntoView to act
    setTimeout(function() { 
        if(isSmooth) {
            target.scrollIntoView({behavior: 'smooth', block: 'start'});
        } else {
            target.scrollIntoView({behavior: 'instant', block: 'start'});
        }

        // reset to the original position
        target.style.transform = ''; 
        target.style.display = '';
    }, 0);
}();



};
});

define("OutSystemsUI.controller$SetAccessibilityRole", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$SetAccessibilityRole.SetRoleJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_SetAccessibilityRole_SetRoleJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.setAccessibilityRole$Action = function (widgetIdIn, roleIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.SetAccessibilityRole$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
vars.value.roleInLocal = roleIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:nIPZ47GGZkyGi3Ef5TZsqw:/ClientActionFlows.nIPZ47GGZkyGi3Ef5TZsqw:Jj56toGQlO3vmDg9ThrNcQ", "OutSystemsUI", "SetAccessibilityRole", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:E932h+7ZnEyjZB_fbjIe_g", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:4O88zbHElkSgAsLU0yIERw", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_SetAccessibilityRole_SetRoleJS, "SetRole", "SetAccessibilityRole", {
Role: OS.DataConversion.JSNodeParamConverter.to(vars.value.roleInLocal, OS.Types.Text),
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:0H7pHuK6Ck+hdcXUrGMGhA", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:nIPZ47GGZkyGi3Ef5TZsqw", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.SetAccessibilityRole$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Role",
attrName: "roleInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.setAccessibilityRole$Action = function (widgetIdIn, roleIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
roleIn = (roleIn === undefined) ? "" : roleIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.setAccessibilityRole$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(roleIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$SetAccessibilityRole.SetRoleJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var element = document.getElementById($parameters.WidgetId);

if (element) {
    var isBlock = element.hasAttribute('data-block');
    
    if(isBlock) {
       element.children[0].setAttribute('role', $parameters.Role); 
    } else {
        element.setAttribute('role', $parameters.Role);
    }
}

};
});

define("OutSystemsUI.controller$SetActiveElement", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$SetActiveElement.SetActiveElementJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_SetActiveElement_SetActiveElementJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.setActiveElement$Action = function (widgetIdIn, isActiveIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.SetActiveElement$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
vars.value.isActiveInLocal = isActiveIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:WkrqyYiP70KuHnjgeUkWGg:/ClientActionFlows.WkrqyYiP70KuHnjgeUkWGg:FTJ_0dnokC_tAWfj9Mh+jA", "OutSystemsUI", "SetActiveElement", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:njUly_cwd0Khl3g1Ftrcng", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:IO79uJFMWEeJUfqEirGmkg", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_SetActiveElement_SetActiveElementJS, "SetActiveElement", "SetActiveElement", {
IsActive: OS.DataConversion.JSNodeParamConverter.to(vars.value.isActiveInLocal, OS.Types.Boolean),
ID: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:GWR2eHd5v0GLCZnFxKd8bQ", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:WkrqyYiP70KuHnjgeUkWGg", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.SetActiveElement$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "IsActive",
attrName: "isActiveInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.clientActionProxies.setActiveElement$Action = function (widgetIdIn, isActiveIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
isActiveIn = (isActiveIn === undefined) ? false : isActiveIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.setActiveElement$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(isActiveIn, OS.Types.Boolean)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$SetActiveElement.SetActiveElementJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var elem = document.getElementById($parameters.ID);

if($parameters.IsActive) {
    elem.classList.add('active-element');    
} else {
    elem.classList.remove('active-element');
}
};
});

define("OutSystemsUI.controller$SetActiveMenuItems", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$SetActiveMenuItems.SetActiveJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_SetActiveMenuItems_SetActiveJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.setActiveMenuItems$Action = function (widgetIdIn, activeItemIn, activeSubItemIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.SetActiveMenuItems$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
vars.value.activeItemInLocal = activeItemIn;
vars.value.activeSubItemInLocal = activeSubItemIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:FMhBkkyTfUCBwiIQM1Ct6w:/ClientActionFlows.FMhBkkyTfUCBwiIQM1Ct6w:ji37rpFGj6ksagzDzZmmzw", "OutSystemsUI", "SetActiveMenuItems", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:bS6qNfol9Uyq1yiQBnoEZA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:eMpAyzImzUKwL_ip4d08TA", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_SetActiveMenuItems_SetActiveJS, "SetActive", "SetActiveMenuItems", {
ActiveItem: OS.DataConversion.JSNodeParamConverter.to(vars.value.activeItemInLocal, OS.Types.Integer),
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text),
ActiveSubItem: OS.DataConversion.JSNodeParamConverter.to(vars.value.activeSubItemInLocal, OS.Types.Integer)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:k88gLS2xmEiMeKwgrvrowQ", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:FMhBkkyTfUCBwiIQM1Ct6w", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.SetActiveMenuItems$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "ActiveItem",
attrName: "activeItemInLocal",
mandatory: false,
dataType: OS.Types.Integer,
defaultValue: function () {
return -1;
}
}, {
name: "ActiveSubItem",
attrName: "activeSubItemInLocal",
mandatory: false,
dataType: OS.Types.Integer,
defaultValue: function () {
return -1;
}
}]);
OutSystemsUIController.default.clientActionProxies.setActiveMenuItems$Action = function (widgetIdIn, activeItemIn, activeSubItemIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
activeItemIn = (activeItemIn === undefined) ? -1 : activeItemIn;
activeSubItemIn = (activeSubItemIn === undefined) ? -1 : activeSubItemIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.setActiveMenuItems$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(activeItemIn, OS.Types.Integer), OS.DataConversion.JSNodeParamConverter.from(activeSubItemIn, OS.Types.Integer)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$SetActiveMenuItems.SetActiveJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var widgetSelector = '';
if($parameters.WidgetId !== '') {
    widgetSelector = '#'+$parameters.WidgetId+' ';
}

var appMenuLinks = document.querySelector(widgetSelector + '.app-menu-links') || document.querySelector(widgetSelector + '.app-sidemenu-links');

if(appMenuLinks) {
    var activeLinkBlock = appMenuLinks.children[$parameters.ActiveItem];
    
    if(activeLinkBlock) {
        activeLinkBlock.classList.add("active");
        var activeSubMenu = activeLinkBlock.querySelector('.submenu');
        
        if(activeSubMenu) {
            activeSubMenu.classList.add("active");
            var activeSubMenuItem = activeSubMenu.querySelector('.submenu-items').children[$parameters.ActiveSubItem];
            
            if(activeSubMenuItem) {
                activeSubMenuItem.classList.add("active");
            }
        }
    }
    
}
};
});

define("OutSystemsUI.controller$SetAriaHidden", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$SetAriaHidden.setAriaHiddenJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_SetAriaHidden_setAriaHiddenJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.setAriaHidden$Action = function (widgetIdIn, isHiddenIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.SetAriaHidden$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
vars.value.isHiddenInLocal = isHiddenIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:sdxo8WObfkKHDkj1hJ+dxQ:/ClientActionFlows.sdxo8WObfkKHDkj1hJ+dxQ:PiqkRC7243vUpald0Az7pQ", "OutSystemsUI", "SetAriaHidden", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:pBfV5nTmJkuOwunbPpENXA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:r0z5tyLSlUqGLBeTxTzxqA", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_SetAriaHidden_setAriaHiddenJS, "setAriaHidden", "SetAriaHidden", {
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text),
IsHidden: OS.DataConversion.JSNodeParamConverter.to(vars.value.isHiddenInLocal, OS.Types.Boolean)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ujeL83Nl0Ue9C4lkulPrHQ", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:sdxo8WObfkKHDkj1hJ+dxQ", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.SetAriaHidden$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "IsHidden",
attrName: "isHiddenInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.clientActionProxies.setAriaHidden$Action = function (widgetIdIn, isHiddenIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
isHiddenIn = (isHiddenIn === undefined) ? false : isHiddenIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.setAriaHidden$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(isHiddenIn, OS.Types.Boolean)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$SetAriaHidden.setAriaHiddenJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var elem = document.getElementById($parameters.WidgetId);

if(elem) {
    elem.setAttribute('aria-hidden', $parameters.IsHidden);   
}

};
});

define("OutSystemsUI.controller$SetBottomBarActiveElement", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$SetBottomBarActiveElement.AddActiveJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_SetBottomBarActiveElement_AddActiveJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.setBottomBarActiveElement$Action = function (activeItemIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.SetBottomBarActiveElement$vars"))());
vars.value.activeItemInLocal = activeItemIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:aKul3GyFdUyInhOVT5pVnQ:/ClientActionFlows.aKul3GyFdUyInhOVT5pVnQ:cvLcCozQjJb0xb7Jy09rhw", "OutSystemsUI", "SetBottomBarActiveElement", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:hoF9LLURdEuNu_81ywHtXQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ft1g983_JkyOahUTuGF5kA", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_SetBottomBarActiveElement_AddActiveJS, "AddActive", "SetBottomBarActiveElement", {
Active: OS.DataConversion.JSNodeParamConverter.to(vars.value.activeItemInLocal, OS.Types.Integer)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Y_2iPO77Dk+huBTotnzLBg", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:aKul3GyFdUyInhOVT5pVnQ", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.SetBottomBarActiveElement$vars", [{
name: "ActiveItem",
attrName: "activeItemInLocal",
mandatory: false,
dataType: OS.Types.Integer,
defaultValue: function () {
return -1;
}
}]);
OutSystemsUIController.default.clientActionProxies.setBottomBarActiveElement$Action = function (activeItemIn) {
activeItemIn = (activeItemIn === undefined) ? -1 : activeItemIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.setBottomBarActiveElement$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(activeItemIn, OS.Types.Integer)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$SetBottomBarActiveElement.AddActiveJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var bottomBar = document.querySelector('.bottom-bar');
var bottomBarChild = bottomBar ? bottomBar.children[$parameters.Active] : undefined;

if(bottomBar && bottomBarChild) {
    bottomBarChild.classList.add("active");
}
};
});

define("OutSystemsUI.controller$SetDeviceBreakpoints", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$SetDeviceBreakpoints.SetDeviceOnResizeJS", "OutSystemsUI.model$DeviceConfigurationRec"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_SetDeviceBreakpoints_SetDeviceOnResizeJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.setDeviceBreakpoints$Action = function (deviceConfigurationIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.SetDeviceBreakpoints$vars"))());
vars.value.deviceConfigurationInLocal = deviceConfigurationIn.clone();
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:kzLCurPnyEiZZBS7mNwWSA:/ClientActionFlows.kzLCurPnyEiZZBS7mNwWSA:Dyz7yQhJNrK5Z+eRwE1VWg", "OutSystemsUI", "SetDeviceBreakpoints", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZFkpLrDlmEeaDRVWUDxnXA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:VoR2nu8KDUyBS7WGi_Ed1w", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_SetDeviceBreakpoints_SetDeviceOnResizeJS, "SetDeviceOnResize", "SetDeviceBreakpoints", {
Phone: OS.DataConversion.JSNodeParamConverter.to(vars.value.deviceConfigurationInLocal.phoneWidthAttr, OS.Types.Integer),
Tablet: OS.DataConversion.JSNodeParamConverter.to(vars.value.deviceConfigurationInLocal.tabletWidthAttr, OS.Types.Integer)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:3F+2DIwLeUW4IU_xmn+BDg", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:kzLCurPnyEiZZBS7mNwWSA", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.SetDeviceBreakpoints$vars", [{
name: "DeviceConfiguration",
attrName: "deviceConfigurationInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new OutSystemsUIModel.DeviceConfigurationRec();
},
complexType: OutSystemsUIModel.DeviceConfigurationRec
}]);
OutSystemsUIController.default.clientActionProxies.setDeviceBreakpoints$Action = function (deviceConfigurationIn) {
deviceConfigurationIn = (deviceConfigurationIn === undefined) ? new OutSystemsUIModel.DeviceConfigurationRec() : deviceConfigurationIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.setDeviceBreakpoints$Action.bind(controller, deviceConfigurationIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$SetDeviceBreakpoints.SetDeviceOnResizeJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$public.View.registerDeviceClassGetter(function() {

    var deviceList;
    var userValues;
    var device;
    var body = document.body;
    var windowWidth = window.innerWidth || document.documentElement.clientWidth;
    var windowHeight = window.innerHeight || document.documentElement.clientHeight;
    var orient = windowWidth > windowHeight ? "landscape" : "portrait";
    var isLandscape = (orient === "landscape");
    
    userValues = {
        phone: $parameters.Phone,
        tablet: $parameters.Tablet,
    };
    
    var phoneMax = userValues.phone ? userValues.phone : 700;
    var tabletMax = userValues.tablet ? userValues.tablet : 1024;
   
    deviceList = ["phone", "tablet","desktop"];
    
    switch(true) {
        case (windowWidth < phoneMax || (!isLandscape && windowHeight < phoneMax)):
            device = 0;
            break;
        case ((windowWidth >= phoneMax && windowWidth <= tabletMax) || (windowHeight >= phoneMax && windowHeight <= tabletMax && isLandscape)):
            device = 1;
            break;
        case (windowWidth > tabletMax ||(windowHeight > tabletMax && isLandscape)):  
            device = 2;
            break;
    }
   
   return [orient, deviceList[device]];
   
});

};
});

define("OutSystemsUI.controller$SetFocus", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$SetFocus.SetFocusJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_SetFocus_SetFocusJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.setFocus$Action = function (widgetIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.SetFocus$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:oih6gdN1p02bcN63KtmoNg:/ClientActionFlows.oih6gdN1p02bcN63KtmoNg:KZc4c3TJzEe7TbFR05_vHA", "OutSystemsUI", "SetFocus", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:5mv2cB2E5Eet16lMvAxBUA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:wEwcXvm0jUKJwZd5VMepaQ", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_SetFocus_SetFocusJS, "SetFocus", "SetFocus", {
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:UQKGVPn0+k+Xkj7vNccKcg", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:oih6gdN1p02bcN63KtmoNg", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.SetFocus$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.setFocus$Action = function (widgetIdIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.setFocus$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$SetFocus.SetFocusJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var elementId = document.getElementById($parameters.WidgetId);

if(elementId) {
    elementId.focus();
}    


};
});

define("OutSystemsUI.controller$SetLang", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$SetLang.SetLangJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_SetLang_SetLangJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.setLang$Action = function (langIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.SetLang$vars"))());
vars.value.langInLocal = langIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:WxQ0Foobt06XqI2YgwwILQ:/ClientActionFlows.WxQ0Foobt06XqI2YgwwILQ:hvj2YFFR7ZmtHe6XNmFO0Q", "OutSystemsUI", "SetLang", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:yI1TXv5l2U+xKhyk1uGcHg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:yIPv6fhPdU6R+151g6zGBw", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_SetLang_SetLangJS, "SetLang", "SetLang", {
Lang: OS.DataConversion.JSNodeParamConverter.to(vars.value.langInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:35CWYx64yUiXptKyv_hhlQ", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:WxQ0Foobt06XqI2YgwwILQ", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.SetLang$vars", [{
name: "Lang",
attrName: "langInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.setLang$Action = function (langIn) {
langIn = (langIn === undefined) ? "" : langIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.setLang$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(langIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$SetLang.SetLangJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var hasLangAttribute = document.documentElement.lang !== "";

if(!hasLangAttribute && $parameters.Lang !== "") {
    document.documentElement.lang = $parameters.Lang;
}
};
});

define("OutSystemsUI.controller$SetMenuAttributes", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$SetMenuAttributes.setAttributesJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_SetMenuAttributes_setAttributesJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.setMenuAttributes$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:ESHkOFhygUSr2c6PVMh1+Q:/ClientActionFlows.ESHkOFhygUSr2c6PVMh1+Q:PUzn5uICuRLhKK9y9DYqYw", "OutSystemsUI", "SetMenuAttributes", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:sOA1S7fJf0SC6iXUOiGs1g", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:sIHiSdj210KF+db9x5sfgg", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_SetMenuAttributes_setAttributesJS, "setAttributes", "SetMenuAttributes", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:U6f0ASFieUaz4CrnUYLqyw", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:ESHkOFhygUSr2c6PVMh1+Q", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.clientActionProxies.setMenuAttributes$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.setMenuAttributes$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$SetMenuAttributes.setAttributesJS", [], function () {
return function ($actions, $roles, $public) {
var layout = document.querySelector('.layout');
var menu = document.querySelector('.app-menu-content') || document.querySelector('.app-menu-container');
var isExpanded = layout.classList.contains('menu-visible') || layout.classList.contains('menu--visible');

if(menu) {
    var focusableEls = menu.querySelectorAll('a[href]:not([disabled]),[tabindex], [role=button],button:not([disabled]),textarea:not([disabled]),input[type="text"]:not([disabled]),input[type="radio"]:not([disabled]),input[type="checkbox"]:not([disabled]),input[type="submit"]:not([disabled]),select:not([disabled])');
    focusableEls = [].slice.call(focusableEls);
    
    var setAttributes = function(){
        if(isExpanded) {
            menu.setAttribute('tabindex', '0');
            menu.setAttribute('aria-expanded', 'true');
            
        } else {
            menu.setAttribute('tabindex', '-1');
            menu.setAttribute('aria-expanded', 'false');
            
        }
    }();
    
    var toggleTabindex = function(){
        // Toggle tabindex value if Menu is closed or open
        if(isExpanded) {
            // apply tabindex = -1 by default to disable the navigation inside the sidebar when is hidden
            focusableEls.forEach(function(item) {
                item.setAttribute('tabindex', '0');
            }); 
        } else {
            focusableEls.forEach(function(item) {
                item.setAttribute('tabindex', '-1');
            }); 
        }
    }();
}
};
});

define("OutSystemsUI.controller$SetMenuIcon", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$SetMenuIcon.FindMenuLinksJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_SetMenuIcon_FindMenuLinksJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.setMenuIcon$Action = function (menuActionIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.SetMenuIcon$vars"))());
vars.value.menuActionInLocal = menuActionIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:ZETeHV+it0+N0my823scLA:/ClientActionFlows.ZETeHV+it0+N0my823scLA:j2Fucvjjc3lgi6OmrT3VxQ", "OutSystemsUI", "SetMenuIcon", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:NmF_8AW1KkGeiFIvO9blhA", callContext.id);
// Auto?
if((OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZKUCOQN2MU6NhBsUtij4aw", callContext.id) && (vars.value.menuActionInLocal === OutSystemsUIModel.staticEntities.menuAction.auto))) {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:u1xwWmjOrUmCUq_MktIlVg", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_SetMenuIcon_FindMenuLinksJS, "FindMenuLinks", "SetMenuIcon", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:pJbaDv6PLE2VHW9iYjYl2Q", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:rXkEjvPVHkmK4GMFMM9AuQ", callContext.id);
}

return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:ZETeHV+it0+N0my823scLA", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.SetMenuIcon$vars", [{
name: "MenuAction",
attrName: "menuActionInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.setMenuIcon$Action = function (menuActionIn) {
menuActionIn = (menuActionIn === undefined) ? "" : menuActionIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.setMenuIcon$Action.bind(controller, menuActionIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$SetMenuIcon.FindMenuLinksJS", [], function () {
return function ($actions, $roles, $public) {
var appMenu = Array.prototype.slice.call(document.querySelectorAll(".bottom-bar a")),
    bottomBar = Array.prototype.slice.call(document.querySelectorAll(".app-menu a"))

var links = appMenu.concat(bottomBar);

var showMenu = false;

for (var i = 0; i < links.length; i++) {
    /* removing platform timestamps */
    var timestampIndex = window.location.href.indexOf("_ts")-1;
    var currentPage = timestampIndex > 0 ? window.location.href.substring(0, timestampIndex) : window.location.href;
    if(links[i].attributes["href"]) {
        if (currentPage.indexOf(links[i].attributes["href"].value) >= 0 || 
            currentPage[currentPage.length-1] === "/") {
            showMenu = (window.history ? window.history.length > 0 : true);        
        }
    }
}

if(showMenu) {
    document.querySelector(".app-menu-icon").classList.remove('back');
} else {
    document.querySelector(".app-menu-icon").classList.add('back');
}
};
});

define("OutSystemsUI.controller$SetMenuIconListeners", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$SetMenuIconListeners.setEventListenerJS", "OutSystemsUI.controller$ToggleSideMenu"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_SetMenuIconListeners_setEventListenerJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.setMenuIconListeners$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:_11xLwz33EKTaCdoVOzzhQ:/ClientActionFlows._11xLwz33EKTaCdoVOzzhQ:dsSHVKNIxhCYkyZ8YJ6eBA", "OutSystemsUI", "SetMenuIconListeners", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:TQJHloqQb0218XBRh0K83A", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:DQfQnUbxxUqjf787Hk7CTA", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_SetMenuIconListeners_setEventListenerJS, "setEventListener", "SetMenuIconListeners", null, function ($parameters) {
}, {
ToggleSideMenu: OutSystemsUIController.default.clientActionProxies.toggleSideMenu$Action
}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:PX6vMCSusECOzH18XaRgPg", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:_11xLwz33EKTaCdoVOzzhQ", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.clientActionProxies.setMenuIconListeners$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.setMenuIconListeners$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$SetMenuIconListeners.setEventListenerJS", [], function () {
return function ($actions, $roles, $public) {
var layout = document.querySelector('.layout');
var menuIcon = document.querySelector('.menu-icon');
var isExpanded;

if(menuIcon) {
    var menuIconOnKeypress = function(e) {
        isExpanded = layout.classList.contains('menu-visible');
        //If enter or space use the menuIcon to validate
        if (e.keyCode == "32" || e.keyCode == "13") {
            e.preventDefault();
            e.stopPropagation();
            $actions.ToggleSideMenu();
        }
    };
    
    menuIcon.addEventListener('keydown', menuIconOnKeypress);
}
};
});

define("OutSystemsUI.controller$SetMenuListeners", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$SetMenuListeners.setEventListenerJS", "OutSystemsUI.controller$ToggleSideMenu", "OutSystemsUI.controller$SetMenuAttributes"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_SetMenuListeners_setEventListenerJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.setMenuListeners$Action = function (widgetIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.SetMenuListeners$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:9cFahaid_ESaRP3Q6_FwUw:/ClientActionFlows.9cFahaid_ESaRP3Q6_FwUw:lGYwElySlvafyhph5i2xPg", "OutSystemsUI", "SetMenuListeners", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:YQPr42UAPEqQgZkGU1ldLA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:46YnzcXd6UmkwH+nqi2Q0A", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_SetMenuListeners_setEventListenerJS, "setEventListener", "SetMenuListeners", {
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {
ToggleSideMenu: OutSystemsUIController.default.clientActionProxies.toggleSideMenu$Action,
SetMenuAttributes: OutSystemsUIController.default.clientActionProxies.setMenuAttributes$Action
}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Y8nvnVZ7XUGhMQSHxu1aRQ", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:9cFahaid_ESaRP3Q6_FwUw", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.SetMenuListeners$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.setMenuListeners$Action = function (widgetIdIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.setMenuListeners$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$SetMenuListeners.setEventListenerJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var widgetSelector = '';
if($parameters.WidgetId !== '') {
    widgetSelector = '#'+$parameters.WidgetId;
}

var layout = document.querySelector('.layout');
var menu = document.querySelector(widgetSelector+'.app-menu-content');

if(layout && menu) {
    
    var isTopMenuMobile;
    var isVisibleMobile;
    var isExpanded = layout.classList.contains('menu-visible');
    var isOverlay = layout.classList.contains('aside-overlay');
    var isExpandable = layout.classList.contains('aside-expandable');
    
    var menuLinks = menu.querySelector('.app-menu-links');

    var menuOnKeypress = function(e) {
        var isTabPressed = (e.key === 'Tab' || e.keyCode === 9);
        var isEscapedPressed = (e.key === 'Escape' || e.keyCode === 27);
        var isShiftKey = e.shiftKey;
        var focusableEls = menu.querySelectorAll('a[href]:not([disabled]),[tabindex="0"], button:not([disabled]), textarea:not([disabled]), input[type="text"]:not([disabled]), input[type="radio"]:not([disabled]), input[type="checkbox"]:not([disabled]),input[type="submit"]:not([disabled]), select:not([disabled])');
        var firstFocusableEl = focusableEls[0]; 
        var lastFocusableEl = focusableEls[focusableEls.length - 1];
        var isExpandableDesktop = document.querySelector('.desktop .active-screen .layout-side.aside-expandable') || document.querySelector('.tablet.landscape .active-screen .layout-side.aside-expandable');
        
        if(!isTabPressed && !isEscapedPressed) {
            return;
        }
    
        isExpanded = layout.classList.contains('menu-visible');
        
        //If esc, Close Menu
        if(isExpanded && isEscapedPressed) {
            e.preventDefault();
            e.stopPropagation();
            $actions.ToggleSideMenu();
        }
        
        if (!isExpandableDesktop) {
            if (isShiftKey) {
                if (document.activeElement === firstFocusableEl) {
                    lastFocusableEl.focus();
                    e.preventDefault();
                }
            } else if (document.activeElement === lastFocusableEl) {
                firstFocusableEl.focus();
                e.preventDefault();
            }     
        }
        
    };
    
    // Invoking setTimeout to schedule the callback to be run asynchronously
    setTimeout(function(){
        isTopMenuMobile = document.querySelector('.tablet .active-screen .layout-top') || document.querySelector('.phone .active-screen .layout-top');
        isVisibleMobile = document.querySelector('.tablet.portrait .active-screen .layout-side.aside-visible') || document.querySelector('.phone .active-screen .layout-side.aside-visible');
        
        if(isOverlay || isExpandable || isTopMenuMobile || isVisibleMobile) {
            menu.addEventListener('keydown', menuOnKeypress);
            $actions.SetMenuAttributes();
        }
    }, 0);
    
    if(menuLinks){
        menuLinks = menuLinks.children;
        
        // Add role menuitem to all links on menu
        for(var i = 0; i < menuLinks.length; i++) {
            if(!menuLinks[i].hasAttribute("role") && menuLinks[i].tagName === "A") {      
                menuLinks[i].setAttribute("role", "menuitem");
            }
        }  
        
    }
  
}



};
});

define("OutSystemsUI.controller$SetSelectedTableRow", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$SetSelectedTableRow.SetSelectedRowJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_SetSelectedTableRow_SetSelectedRowJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.setSelectedTableRow$Action = function (tableIdIn, rowNumberIn, isSelectedIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.SetSelectedTableRow$vars"))());
vars.value.tableIdInLocal = tableIdIn;
vars.value.rowNumberInLocal = rowNumberIn;
vars.value.isSelectedInLocal = isSelectedIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:6iLdt8t_ZUOkaPCUy9o4OQ:/ClientActionFlows.6iLdt8t_ZUOkaPCUy9o4OQ:6Zg4QlWTAFpYCnJrUCaxrw", "OutSystemsUI", "SetSelectedTableRow", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Xy8qMy44yUij3dTCSoXTbw", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ATatOzJqo0u2ApIml90UFg", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_SetSelectedTableRow_SetSelectedRowJS, "SetSelectedRow", "SetSelectedTableRow", {
Value: OS.DataConversion.JSNodeParamConverter.to(vars.value.isSelectedInLocal, OS.Types.Boolean),
RowNumber: OS.DataConversion.JSNodeParamConverter.to(vars.value.rowNumberInLocal, OS.Types.Integer),
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.tableIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:wvnnWu9em0iOBY6Et5Hw+w", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:6iLdt8t_ZUOkaPCUy9o4OQ", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.SetSelectedTableRow$vars", [{
name: "TableId",
attrName: "tableIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "RowNumber",
attrName: "rowNumberInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "IsSelected",
attrName: "isSelectedInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.clientActionProxies.setSelectedTableRow$Action = function (tableIdIn, rowNumberIn, isSelectedIn) {
tableIdIn = (tableIdIn === undefined) ? "" : tableIdIn;
rowNumberIn = (rowNumberIn === undefined) ? 0 : rowNumberIn;
isSelectedIn = (isSelectedIn === undefined) ? false : isSelectedIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.setSelectedTableRow$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(tableIdIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(rowNumberIn, OS.Types.Integer), OS.DataConversion.JSNodeParamConverter.from(isSelectedIn, OS.Types.Boolean)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$SetSelectedTableRow.SetSelectedRowJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var table = document.getElementById($parameters.WidgetId);

if(table) {
    var tableRow = table.querySelectorAll('.table-row');

    if(tableRow[$parameters.RowNumber]) {
        if($parameters.Value) {
            tableRow[$parameters.RowNumber].classList.add('table-row-selected');    
        } else {
            tableRow[$parameters.RowNumber].classList.remove('table-row-selected');    
        }
    }
}



};
});

define("OutSystemsUI.controller$SetStickyObserver", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$SetStickyObserver.StickyObserverJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_SetStickyObserver_StickyObserverJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.setStickyObserver$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:1O3INw5CAUquLN4jLtAbkA:/ClientActionFlows.1O3INw5CAUquLN4jLtAbkA:EfSZpiHumSH2R9Jy2SacgA", "OutSystemsUI", "SetStickyObserver", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:jHs6Uy+HMk+65BlMLQDz8A", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:1MNAe+J_ZUObGzwngACR8g", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_SetStickyObserver_StickyObserverJS, "StickyObserver", "SetStickyObserver", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:P1IB+2nZVk6Hb2_BHfsn5w", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:1O3INw5CAUquLN4jLtAbkA", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.clientActionProxies.setStickyObserver$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.setStickyObserver$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$SetStickyObserver.StickyObserverJS", [], function () {
return function ($actions, $roles, $public) {
var layout = document.querySelector('.active-screen .layout');
var stickyObserver = document.querySelector(".active-screen .sticky-observer");
 
var observer = new IntersectionObserver(function(entries) {
    if(entries[0].isIntersecting) {
        layout.classList.add('header-is--visible');
    } else {
        layout.classList.remove('header-is--visible');
    }
});

observer.observe(stickyObserver);

};
});

define("OutSystemsUI.controller$ShowPassword", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$ShowPassword.ShowPasswordJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_ShowPassword_ShowPasswordJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.showPassword$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:IPzU9ikG0ESQIuRuOj5wDw:/ClientActionFlows.IPzU9ikG0ESQIuRuOj5wDw:HqmytqiblSO_B0NvBWwjUw", "OutSystemsUI", "ShowPassword", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:PKLSaVAA3Ueb1liPdD5UMg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:bxp8S_H10kKMTwwJmoLfTQ", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_ShowPassword_ShowPasswordJS, "ShowPassword", "ShowPassword", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:TOjICRQzdEKCDowrukraiQ", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:IPzU9ikG0ESQIuRuOj5wDw", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.clientActionProxies.showPassword$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.showPassword$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$ShowPassword.ShowPasswordJS", [], function () {
return function ($actions, $roles, $public) {
var inputPassword = document.querySelector('.login-password');

var typeInputPassword = inputPassword.type;

if(typeInputPassword === 'password') {
    inputPassword.setAttribute('type', 'text');
} else {
    inputPassword.setAttribute('type', 'password');   
}
};
});

define("OutSystemsUI.controller$SidebarToggle", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$SidebarToggle.ToggleSidebarJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_SidebarToggle_ToggleSidebarJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.sidebarToggle$Action = function (widgetIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.SidebarToggle$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:qit9KmBqB0mQXaPFQSKnRg:/ClientActionFlows.qit9KmBqB0mQXaPFQSKnRg:ynHUceMpS3DBbzA3jG7B0w", "OutSystemsUI", "SidebarToggle", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:8esdRllSMUqw9Hqhwp+AdQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:jaHB+obidUu+wcGD9DdGOw", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_SidebarToggle_ToggleSidebarJS, "ToggleSidebar", "SidebarToggle", {
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:JRPe6doJ_kS6syI0E_xQkA", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:qit9KmBqB0mQXaPFQSKnRg", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.SidebarToggle$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.sidebarToggle$Action = function (widgetIdIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.sidebarToggle$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$SidebarToggle.ToggleSidebarJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
// toggle Sidebar

var el;
var isOpen;

if($parameters.WidgetId !== "") {
    el = document.querySelector("#" + $parameters.WidgetId + " .sidebar");
}

if(el !== null) {
    isOpen = el.classList.contains("sidebar-open");
    
    if(isOpen) {
        el.classList.remove("sidebar-open");
    } else {
        el.classList.add("sidebar-open");
    }
}
};
});

define("OutSystemsUI.controller$SkipToContent", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$SkipToContent.SkipToContentJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_SkipToContent_SkipToContentJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.skipToContent$Action = function (targetIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.SkipToContent$vars"))());
vars.value.targetIdInLocal = targetIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:47TabZ9HT0ixaXEVUGyJag:/ClientActionFlows.47TabZ9HT0ixaXEVUGyJag:tgfK7UZQnZPDLbai4QN0vg", "OutSystemsUI", "SkipToContent", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:jeOesKjOSEGo7zI_+1uc+g", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:9yYTvLbuNE2F6DOfAk65eg", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_SkipToContent_SkipToContentJS, "SkipToContent", "SkipToContent", {
TargetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.targetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:15oljrWsnk+JvEvZqMz7qA", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:47TabZ9HT0ixaXEVUGyJag", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.SkipToContent$vars", [{
name: "TargetId",
attrName: "targetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.skipToContent$Action = function (targetIdIn) {
targetIdIn = (targetIdIn === undefined) ? "" : targetIdIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.skipToContent$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(targetIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$SkipToContent.SkipToContentJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var target = document.getElementById($parameters.TargetId);

if(target) {
    var isFocusable = target.getAttribute('tabindex');
    
    if(isFocusable === null) {
        target.setAttribute('tabindex', '0');
        target.focus();
        target.removeAttribute('tabindex');    
    } else {
        target.focus();
    }
}
};
});

define("OutSystemsUI.controller$StackedCardsSwipeLeft", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$StackedCardsSwipeLeft.SwipeLeftJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_StackedCardsSwipeLeft_SwipeLeftJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.stackedCardsSwipeLeft$Action = function (widgetIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.StackedCardsSwipeLeft$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:fk74nHYtG0aQv3rJupL3Yg:/ClientActionFlows.fk74nHYtG0aQv3rJupL3Yg:9PmvKzTtJczMu5bSZKBJHA", "OutSystemsUI", "StackedCardsSwipeLeft", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:s+iPGCWs_k+MMYfN3ziU3Q", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:bYAjhTuI_UCBz++CrCJsBg", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_StackedCardsSwipeLeft_SwipeLeftJS, "SwipeLeft", "StackedCardsSwipeLeft", {
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:1c7eHc5sLkWMsIBVVyheOw", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:fk74nHYtG0aQv3rJupL3Yg", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.StackedCardsSwipeLeft$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.stackedCardsSwipeLeft$Action = function (widgetIdIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.stackedCardsSwipeLeft$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$StackedCardsSwipeLeft.SwipeLeftJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var element;

var swipeActionInterval = setInterval(function(){
    
    element = document.getElementById($parameters.WidgetId);

    if( element !== null) {
        element.querySelector('.stackedcards-container').leftAction();
        clearInterval(swipeActionInterval);
    }
    
}, 100)
};
});

define("OutSystemsUI.controller$StackedCardsSwipeRight", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$StackedCardsSwipeRight.SwipeRightJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_StackedCardsSwipeRight_SwipeRightJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.stackedCardsSwipeRight$Action = function (widgetIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.StackedCardsSwipeRight$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:6tQbuDWdOEWMYpjaBjycWw:/ClientActionFlows.6tQbuDWdOEWMYpjaBjycWw:bVlhJ11T7x_3hNPHRpOCdA", "OutSystemsUI", "StackedCardsSwipeRight", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:VuD5cPGfhkeiduZM4nLpWQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:NdVbtmiNvESSTFMxbhkzFA", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_StackedCardsSwipeRight_SwipeRightJS, "SwipeRight", "StackedCardsSwipeRight", {
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:WNVQ6nuIvkGGt1RcEa_mpg", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:6tQbuDWdOEWMYpjaBjycWw", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.StackedCardsSwipeRight$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.stackedCardsSwipeRight$Action = function (widgetIdIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.stackedCardsSwipeRight$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$StackedCardsSwipeRight.SwipeRightJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var element;

var swipeActionInterval = setInterval(function(){
    
    element = document.getElementById($parameters.WidgetId);

    if( element !== null) {
        element.querySelector('.stackedcards-container').rightAction();
        clearInterval(swipeActionInterval);
    }
    
}, 100)
};
});

define("OutSystemsUI.controller$StackedCardsSwipeTop", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$StackedCardsSwipeTop.SwipeTopJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_StackedCardsSwipeTop_SwipeTopJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.stackedCardsSwipeTop$Action = function (widgetIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.StackedCardsSwipeTop$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:8YOsHAWvHESA5NDmbFugGA:/ClientActionFlows.8YOsHAWvHESA5NDmbFugGA:NB+6PhpJrH3mOakIV4Ugug", "OutSystemsUI", "StackedCardsSwipeTop", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:QM9QmX8J80OsfJOs1nLE0w", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:VGBdXlToIUWYcJSWS4uVRg", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_StackedCardsSwipeTop_SwipeTopJS, "SwipeTop", "StackedCardsSwipeTop", {
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:_UhNcUdIkEWxi1lLtcZXcA", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:8YOsHAWvHESA5NDmbFugGA", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.StackedCardsSwipeTop$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.stackedCardsSwipeTop$Action = function (widgetIdIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.stackedCardsSwipeTop$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$StackedCardsSwipeTop.SwipeTopJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var element;

var swipeActionInterval = setInterval(function(){
    
    element = document.getElementById($parameters.WidgetId);

    if( element !== null) {
        element.querySelector('.stackedcards-container').topAction();
        clearInterval(swipeActionInterval);
    }
    
}, 100)
};
});

define("OutSystemsUI.controller$StackedCardsUpdate", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$StackedCardsUpdate.UpdateUiJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_StackedCardsUpdate_UpdateUiJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.stackedCardsUpdate$Action = function (widgetIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.StackedCardsUpdate$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:qVJTiEelwUyyAIZ8YvF0kA:/ClientActionFlows.qVJTiEelwUyyAIZ8YvF0kA:icyWBqa6Z07UEiWpatgjaQ", "OutSystemsUI", "StackedCardsUpdate", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:3o5Fg1Sy30SjMSRtsAXFvQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:xMKXLKzze0S3+ZodJF1oqw", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_StackedCardsUpdate_UpdateUiJS, "UpdateUi", "StackedCardsUpdate", {
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:2ps+Ax4uM0++BiukTNgv2g", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:qVJTiEelwUyyAIZ8YvF0kA", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.StackedCardsUpdate$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.stackedCardsUpdate$Action = function (widgetIdIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.stackedCardsUpdate$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$StackedCardsUpdate.UpdateUiJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var element = document.getElementById($parameters.WidgetId).querySelector('.stackedcards-container').updateUi();
};
});

define("OutSystemsUI.controller$StartOfflineDataSync", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$StartOfflineDataSync.CallBlockHandlerJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_StartOfflineDataSync_CallBlockHandlerJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.startOfflineDataSync$Action = function (syncUnitIn, discardPendingSyncUnitsIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.StartOfflineDataSync$vars"))());
vars.value.syncUnitInLocal = syncUnitIn;
vars.value.discardPendingSyncUnitsInLocal = discardPendingSyncUnitsIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:6wYKHDHaTk24G0Nx4wSdrQ:/ClientActionFlows.6wYKHDHaTk24G0Nx4wSdrQ:6c+o6y23CS0r6_w8YmX+nA", "OutSystemsUI", "StartOfflineDataSync", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:eCwp1y5OvEmtYkivpmfoog", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:0Tc16cg8iEuflVtN94J9Dg", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_StartOfflineDataSync_CallBlockHandlerJS, "CallBlockHandler", "StartOfflineDataSync", {
SyncUnit: OS.DataConversion.JSNodeParamConverter.to(vars.value.syncUnitInLocal, OS.Types.Text),
DiscardPendingUnits: OS.DataConversion.JSNodeParamConverter.to(vars.value.discardPendingSyncUnitsInLocal, OS.Types.Boolean)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:9YoiDsnfdEadz05S8x5_ZA", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:6wYKHDHaTk24G0Nx4wSdrQ", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.StartOfflineDataSync$vars", [{
name: "SyncUnit",
attrName: "syncUnitInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "DiscardPendingSyncUnits",
attrName: "discardPendingSyncUnitsInLocal",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.clientActionProxies.startOfflineDataSync$Action = function (syncUnitIn, discardPendingSyncUnitsIn) {
syncUnitIn = (syncUnitIn === undefined) ? "" : syncUnitIn;
discardPendingSyncUnitsIn = (discardPendingSyncUnitsIn === undefined) ? false : discardPendingSyncUnitsIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.startOfflineDataSync$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(syncUnitIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(discardPendingSyncUnitsIn, OS.Types.Boolean)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$StartOfflineDataSync.CallBlockHandlerJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
if (window.offlineDataSync) {
    window.offlineDataSync.sync($parameters.SyncUnit, $parameters.DiscardPendingUnits);
}
};
});

define("OutSystemsUI.controller$TabsDisableSwipe", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$TabsDisableSwipe.AddClassNoSwipeJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_TabsDisableSwipe_AddClassNoSwipeJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.tabsDisableSwipe$Action = function (tabIDIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.TabsDisableSwipe$vars"))());
vars.value.tabIDInLocal = tabIDIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:8A4PWWqEo0eHrnR0AR3i9Q:/ClientActionFlows.8A4PWWqEo0eHrnR0AR3i9Q:mt1har0OcRexVb1lI1e0UQ", "OutSystemsUI", "TabsDisableSwipe", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:GtM0GXiS1UG1DaAH_MoTaQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:B3wXWZq7aUWYEIVdFUX_KA", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_TabsDisableSwipe_AddClassNoSwipeJS, "AddClassNoSwipe", "TabsDisableSwipe", {
TabID: OS.DataConversion.JSNodeParamConverter.to(vars.value.tabIDInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:2SYl0nbsbUifUcGePGHZQQ", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:8A4PWWqEo0eHrnR0AR3i9Q", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.TabsDisableSwipe$vars", [{
name: "TabID",
attrName: "tabIDInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.tabsDisableSwipe$Action = function (tabIDIn) {
tabIDIn = (tabIDIn === undefined) ? "" : tabIDIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.tabsDisableSwipe$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(tabIDIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$TabsDisableSwipe.AddClassNoSwipeJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var elem = document.getElementById($parameters.TabID).querySelector('.tabs');

if(elem) {
    elem.classList.add('no-swipe');
}
};
});

define("OutSystemsUI.controller$TabsGoTo", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$TabsGoTo.ChangeTabJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_TabsGoTo_ChangeTabJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.tabsGoTo$Action = function (widgetIdIn, tabNumberIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.TabsGoTo$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
vars.value.tabNumberInLocal = tabNumberIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:uBmPnAyh10iXcs4yts2GGw:/ClientActionFlows.uBmPnAyh10iXcs4yts2GGw:eo99ECJp+14VDlc_DzQxbw", "OutSystemsUI", "TabsGoTo", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:PZmGGuUzaEmvKzzO7xFVXg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:DkGb6z63NUeOAN_exev1sA", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_TabsGoTo_ChangeTabJS, "ChangeTab", "TabsGoTo", {
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text),
TabNumber: OS.DataConversion.JSNodeParamConverter.to(vars.value.tabNumberInLocal, OS.Types.Integer)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:L5BRA4V2M0CBIiYdrVYnsw", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:uBmPnAyh10iXcs4yts2GGw", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.TabsGoTo$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "TabNumber",
attrName: "tabNumberInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
OutSystemsUIController.default.clientActionProxies.tabsGoTo$Action = function (widgetIdIn, tabNumberIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
tabNumberIn = (tabNumberIn === undefined) ? 0 : tabNumberIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.tabsGoTo$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(tabNumberIn, OS.Types.Integer)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$TabsGoTo.ChangeTabJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var element = document.getElementById($parameters.WidgetId);
var countTabs = element.querySelectorAll(".tabs-header-tab").length -1;
var tabsElement = element.querySelectorAll(".tabs-header-tab");
var countEmptyTabs = element.querySelectorAll(".tabs-header-tab.ph");
var isEmpty = 0;

for(i = 0; i < tabsElement.length; i++) {
    
    if(countEmptyTabs[i].childNodes.length === 0) {
       isEmpty = isEmpty + 1;
    }
}


if(($parameters.TabNumber + 1) <= countTabs) {
    element.changeTab($parameters.TabNumber);
} else {
    element.changeTab(countTabs - isEmpty);
}









};
});

define("OutSystemsUI.controller$TextEllipsis", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.textEllipsis$Action = function (textIn, numberOfCharsIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.TextEllipsis$vars"))());
vars.value.textInLocal = textIn;
vars.value.numberOfCharsInLocal = numberOfCharsIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.TextEllipsis$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:vcPCjzmwt06eSWGQwvznuA:/ClientActionFlows.vcPCjzmwt06eSWGQwvznuA:LVSGFDl_rtj5L9TOtWoTXA", "OutSystemsUI", "TextEllipsis", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:p1XmnacGaEOcwbrR8D7Z0g", callContext.id);
// Set Text with Ellipsis
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:1sSXt7IPA06J2_AMOnpLfQ", callContext.id);
// Out = If + If
outVars.value.outOut = ((((OS.BuiltinFunctions.length(vars.value.textInLocal) > vars.value.numberOfCharsInLocal)) ? (OS.BuiltinFunctions.substr(vars.value.textInLocal, 0, vars.value.numberOfCharsInLocal)) : (vars.value.textInLocal)) + (((OS.BuiltinFunctions.length(vars.value.textInLocal) > vars.value.numberOfCharsInLocal)) ? ("...") : ("")));
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Gri2DOKqCE6VH4hPqVv76w", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:vcPCjzmwt06eSWGQwvznuA", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.TextEllipsis$vars", [{
name: "Text",
attrName: "textInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "NumberOfChars",
attrName: "numberOfCharsInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.TextEllipsis$outVars", [{
name: "Out",
attrName: "outOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.textEllipsis$Action = function (textIn, numberOfCharsIn) {
textIn = (textIn === undefined) ? "" : textIn;
numberOfCharsIn = (numberOfCharsIn === undefined) ? 0 : numberOfCharsIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.textEllipsis$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(textIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(numberOfCharsIn, OS.Types.Integer)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Out: OS.DataConversion.JSNodeParamConverter.to(actionResults.outOut, OS.Types.Text)
};
});
};
});

define("OutSystemsUI.controller$ToggleSideMenu", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$ToggleSideMenu.ToggleSideMenuJS", "OutSystemsUI.controller$SetMenuAttributes"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_ToggleSideMenu_ToggleSideMenuJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.toggleSideMenu$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:DCQtVNJTOkqa1AaUsdSc5w:/ClientActionFlows.DCQtVNJTOkqa1AaUsdSc5w:c4ZOxoX7AMJnn9CGsnfcwg", "OutSystemsUI", "ToggleSideMenu", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:XtNByosVU0a72x8r54raqQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:e_mF4MqD3kavK37a4fp_WA", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_ToggleSideMenu_ToggleSideMenuJS, "ToggleSideMenu", "ToggleSideMenu", null, function ($parameters) {
}, {
SetMenuAttributes: OutSystemsUIController.default.clientActionProxies.setMenuAttributes$Action
}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:tR4CDYbfKUCj9S2MJHARQg", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:DCQtVNJTOkqa1AaUsdSc5w", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.clientActionProxies.toggleSideMenu$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.toggleSideMenu$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$ToggleSideMenu.ToggleSideMenuJS", [], function () {
return function ($actions, $roles, $public) {
var layout = document.querySelector('.layout');
var menu = document.querySelector('.app-menu-content');
var menuIcon = document.querySelector('.menu-icon');

if(layout && menu) {
    var isExpanded = layout.classList.contains('menu-visible');
    
    var toggleMenu = function(){
       if(isExpanded && menuIcon) {
            layout.classList.remove('menu-visible');
            menuIcon.focus();
            isExpanded = false;
        } else {
            layout.classList.add('menu-visible');
            menu.focus(); 
            isExpanded = true;
        }
        
        $actions.SetMenuAttributes();
    }(); 
}


};
});

define("OutSystemsUI.controller$ToggleTextSpacing", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$ToggleTextSpacing.TextSpacingStylesJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_ToggleTextSpacing_TextSpacingStylesJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.toggleTextSpacing$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:lpumF0DITkK_p+HM2xm0Pg:/ClientActionFlows.lpumF0DITkK_p+HM2xm0Pg:h_6Yo6Afm4K6i8nXQIWx_Q", "OutSystemsUI", "ToggleTextSpacing", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:G43XKcaiGU6G8GDsKC+Ocg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:i+7a8WhXc0ibOM_sownrVQ", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_ToggleTextSpacing_TextSpacingStylesJS, "TextSpacingStyles", "ToggleTextSpacing", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:YjyxIe2J4EmvDi1GNkJQkQ", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:lpumF0DITkK_p+HM2xm0Pg", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.clientActionProxies.toggleTextSpacing$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.toggleTextSpacing$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$ToggleTextSpacing.TextSpacingStylesJS", [], function () {
return function ($actions, $roles, $public) {
var spacingStyles = document.querySelector('.acessibility-style-tag');

if (!spacingStyles) {
    spacingStyles = document.createElement('style');
    spacingStyles.classList.add('acessibility-style-tag');
    spacingStyles.textContent = " * { line-height: 1.5 !important; letter-spacing: 0.12em !important; word-spacing: 0.16em !important; } p { margin-bottom: 2em !important; } ";
    document.head.appendChild(spacingStyles);
} else if(spacingStyles) {
    spacingStyles.remove();
}
};
});

define("OutSystemsUI.controller$UpdateAccordion", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$UpdateAccordion.UpdateAccordionJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_UpdateAccordion_UpdateAccordionJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.updateAccordion$Action = function (widgetIdIn, multipleItemsIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.UpdateAccordion$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
vars.value.multipleItemsInLocal = multipleItemsIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:sur94UMpbkO2Xl28KlBPqQ:/ClientActionFlows.sur94UMpbkO2Xl28KlBPqQ:mh5uP3t5lui8Td7sMXw79Q", "OutSystemsUI", "UpdateAccordion", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:olaDm+5jIkmxToCysstNsA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ulTTWWisZE6vnyND5_2EsQ", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_UpdateAccordion_UpdateAccordionJS, "UpdateAccordion", "UpdateAccordion", {
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text),
MultipleItems: OS.DataConversion.JSNodeParamConverter.to(vars.value.multipleItemsInLocal, OS.Types.Boolean)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:CefwQWwUokSTgwCV2dpPAQ", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:sur94UMpbkO2Xl28KlBPqQ", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.UpdateAccordion$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "MultipleItems",
attrName: "multipleItemsInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.clientActionProxies.updateAccordion$Action = function (widgetIdIn, multipleItemsIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
multipleItemsIn = (multipleItemsIn === undefined) ? false : multipleItemsIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.updateAccordion$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(multipleItemsIn, OS.Types.Boolean)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$UpdateAccordion.UpdateAccordionJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var element = document.getElementById($parameters.WidgetId);
var elementNodes = element.querySelectorAll('.section-expandable');

// Check if exist elements inside accordion
if(elementNodes.length > 0){
    for(i = 0; i < elementNodes.length; i++){
        elementNodes[i].updateAccordion($parameters.MultipleItems);
    } 
}

};
});

define("OutSystemsUI.controller$VideoPause", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$VideoPause.PauseVideoJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_VideoPause_PauseVideoJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.videoPause$Action = function (widgetIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.VideoPause$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:XZhXecZh6EaW7R2FSGgeWQ:/ClientActionFlows.XZhXecZh6EaW7R2FSGgeWQ:r6avvjsRES7CnZm0JOwyjw", "OutSystemsUI", "VideoPause", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:60SFJR8Xgkq5rnzg0D37Ww", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:hRGnfc_5jkadLvrVm24NQQ", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_VideoPause_PauseVideoJS, "PauseVideo", "VideoPause", {
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:67D1E4xrs0mRjYUAnWo08A", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:XZhXecZh6EaW7R2FSGgeWQ", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.VideoPause$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.videoPause$Action = function (widgetIdIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.videoPause$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$VideoPause.PauseVideoJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var videoWidget = document.getElementById($parameters.WidgetId);
var videoTag = videoWidget.querySelector('video');
videoTag.pause();
};
});

define("OutSystemsUI.controller$VideoPlay", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$VideoPlay.PlayVideoJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_VideoPlay_PlayVideoJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.videoPlay$Action = function (widgetIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.VideoPlay$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:9RaZU8285Uq8mBSLGd60mQ:/ClientActionFlows.9RaZU8285Uq8mBSLGd60mQ:I_f0FgC0cHzQxV_qWIYCqQ", "OutSystemsUI", "VideoPlay", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:R_v+DsUpIEWquaClGVVciw", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Sw71dFhVZU+bIcw4SpveXA", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_VideoPlay_PlayVideoJS, "PlayVideo", "VideoPlay", {
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:1eMKnrmGL0K5+GjQaYVz5w", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:9RaZU8285Uq8mBSLGd60mQ", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.VideoPlay$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.videoPlay$Action = function (widgetIdIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.videoPlay$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$VideoPlay.PlayVideoJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var videoWidget = document.getElementById($parameters.WidgetId);
var videoTag = videoWidget.querySelector('video');
videoTag.play();
};
});

define("OutSystemsUI.controller$WCAGMetaTag", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$WCAGMetaTag.ViewportJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_WCAGMetaTag_ViewportJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.wCAGMetaTag$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:P1CTemhq5kGBBVkXbTT5aA:/ClientActionFlows.P1CTemhq5kGBBVkXbTT5aA:H15U4_KzRiNAxU1b+8v_zA", "OutSystemsUI", "WCAGMetaTag", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:p408KBPGHE+DuMm7SgHBdQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:8qRXUiX9DEuIdCtr_cT_BA", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_WCAGMetaTag_ViewportJS, "Viewport", "WCAGMetaTag", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:jAdlKKQ8GU60bOjK9y+izQ", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:P1CTemhq5kGBBVkXbTT5aA", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.clientActionProxies.wCAGMetaTag$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.wCAGMetaTag$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$WCAGMetaTag.ViewportJS", [], function () {
return function ($actions, $roles, $public) {
document.head.querySelector('[name="viewport"]').setAttribute('content', "viewport-fit=cover, width=device-width, initial-scale=1");
};
});

define("OutSystemsUI.controller", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller$debugger", "OutSystemsUI.controller$translationsResources"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUI_Controller_debugger, OutSystemsUI_Controller_translationsResources) {
var OS = OutSystems.Internal;
var OutSystemsUIController = exports;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
}
Controller.prototype.clientActionProxies = {};
Controller.prototype.roles = {};
Controller.prototype.defaultTimeout = 10;
Controller.prototype.getDefaultTimeout = function () {
return OutSystemsUIController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseModuleController);
OutSystemsUIController.default = new Controller(OutSystemsUI_Controller_translationsResources);
});
define("OutSystemsUI.controller$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"Iv4qqL2CAUyTooBa4SSJpg": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIDInLocal;
},
dataType: OS.Types.Object
},
"Tn+H6xGcAUWzRA9GgwDPeA": {
getter: function (varBag, idService) {
return varBag.vars.value.targetInLocal;
},
dataType: OS.Types.Object
},
"ys785lY_qE6ziCYEBGOpgw": {
getter: function (varBag, idService) {
return varBag.moveElementJSResult.value;
}
},
"iR_mzVvx4EWGZU1VRw3FkQ": {
getter: function (varBag, idService) {
return varBag.vars.value.syncOnOnlineInLocal;
},
dataType: OS.Types.Boolean
},
"7JGqGYj7tE+x8vgdNQiHAA": {
getter: function (varBag, idService) {
return varBag.vars.value.syncOnResumeInLocal;
},
dataType: OS.Types.Boolean
},
"3veDb5FLK0GnedPWNQeZTw": {
getter: function (varBag, idService) {
return varBag.vars.value.retryOnErrorInLocal;
},
dataType: OS.Types.Boolean
},
"aWKSMdKBYUipICKoqyHvUA": {
getter: function (varBag, idService) {
return varBag.vars.value.retryIntervalInSecondsInLocal;
},
dataType: OS.Types.Integer
},
"Q3ziLgpmwEiLfbtrD1nU_A": {
getter: function (varBag, idService) {
return varBag.configureOfflineDataSyncJSResult.value;
}
},
"bjySSodtmUmSoES7KUjPcQ": {
getter: function (varBag, idService) {
return varBag.vars.value.langInLocal;
},
dataType: OS.Types.Text
},
"yIPv6fhPdU6R+151g6zGBw": {
getter: function (varBag, idService) {
return varBag.setLangJSResult.value;
}
},
"nquViCwYO0O1G+h5jsG5SA": {
getter: function (varBag, idService) {
return varBag.outVars.value.isWebAppOut;
},
dataType: OS.Types.Boolean
},
"A8C7OkSCkkqYxzxiYRUweA": {
getter: function (varBag, idService) {
return varBag.checkIsWebAppJSResult.value;
}
},
"i+7a8WhXc0ibOM_sownrVQ": {
getter: function (varBag, idService) {
return varBag.textSpacingStylesJSResult.value;
}
},
"tZjZovcHS0yJd7OvtytkJQ": {
getter: function (varBag, idService) {
return varBag.vars.value.syncUnitInLocal;
},
dataType: OS.Types.Text
},
"yFRpWSObyUqhUpN24G94fA": {
getter: function (varBag, idService) {
return varBag.vars.value.discardPendingSyncUnitsInLocal;
},
dataType: OS.Types.Boolean
},
"0Tc16cg8iEuflVtN94J9Dg": {
getter: function (varBag, idService) {
return varBag.callBlockHandlerJSResult.value;
}
},
"dsUlges1bEaJZgxAH5ixpQ": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"VGBdXlToIUWYcJSWS4uVRg": {
getter: function (varBag, idService) {
return varBag.swipeTopJSResult.value;
}
},
"lox_6jGjDkaqtFjZZDxrRA": {
getter: function (varBag, idService) {
return varBag.vars.value.menuActionInLocal;
},
dataType: OS.Types.Text
},
"u1xwWmjOrUmCUq_MktIlVg": {
getter: function (varBag, idService) {
return varBag.findMenuLinksJSResult.value;
}
},
"ObH9X2EVfE2QMmbmUEtQ2g": {
getter: function (varBag, idService) {
return varBag.vars.value.hideHeaderInLocal;
},
dataType: OS.Types.Boolean
},
"YIoLAMN9y0C6r84F2nZDLg": {
getter: function (varBag, idService) {
return varBag.hideOnScrollJSResult.value;
}
},
"bQKATDoEQ0W7bsABQuI4fA": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"jaHB+obidUu+wcGD9DdGOw": {
getter: function (varBag, idService) {
return varBag.toggleSidebarJSResult.value;
}
},
"DQfQnUbxxUqjf787Hk7CTA": {
getter: function (varBag, idService) {
return varBag.setEventListenerJSResult.value;
}
},
"4tPDI+5d60iT0y9hC+_RjA": {
getter: function (varBag, idService) {
return varBag.hasMasterDetailJSResult.value;
}
},
"ReY8li7Au0aOnvDANbfgpw": {
getter: function (varBag, idService) {
return varBag.vars.value.imageInLocal;
},
dataType: OS.Types.BinaryData
},
"kX34EMu0a0eN8EHhusEQ0A": {
getter: function (varBag, idService) {
return varBag.outVars.value.uRLOut;
},
dataType: OS.Types.Text
},
"HoTpRIE1m0e2MkudNr4zSg": {
getter: function (varBag, idService) {
return varBag.jsBinaryToBase64JSResult.value;
}
},
"1MNAe+J_ZUObGzwngACR8g": {
getter: function (varBag, idService) {
return varBag.stickyObserverJSResult.value;
}
},
"sIHiSdj210KF+db9x5sfgg": {
getter: function (varBag, idService) {
return varBag.setAttributesJSResult.value;
}
},
"5Xc9s8o640OnMfDi59LYUg": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"Q46YfT8QYEW25B5LNZozRg": {
getter: function (varBag, idService) {
return varBag.vars.value.targetInLocal;
},
dataType: OS.Types.Integer
},
"dBRtEJ1oXUeFmuSC_CWu9Q": {
getter: function (varBag, idService) {
return varBag.callGoToActionJSResult.value;
}
},
"Wbo+S7HMhUadZf94GvsqTg": {
getter: function (varBag, idService) {
return varBag.setEventListenerJSResult.value;
}
},
"PQa9fzVt50+PvtBRPKnhgQ": {
getter: function (varBag, idService) {
return varBag.fixInputsJSResult.value;
}
},
"aP3W63E880Oz+FpnEt9gtw": {
getter: function (varBag, idService) {
return varBag.closeFeedbackMessageJSResult.value;
}
},
"uZIzUDZnhkidvR_hwGn9cQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.i18nDefaultsOut;
}
},
"s84zwxK1AUC5aIwYweIxUg": {
getter: function (varBag, idService) {
return varBag.outVars.value.i18nAccessibilityOut;
}
},
"N7UpWG6xpkmSVFWk5O6iLQ": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"Sw71dFhVZU+bIcw4SpveXA": {
getter: function (varBag, idService) {
return varBag.playVideoJSResult.value;
}
},
"e_mF4MqD3kavK37a4fp_WA": {
getter: function (varBag, idService) {
return varBag.toggleSideMenuJSResult.value;
}
},
"2T8OZEsJu0ySMPfim+kqxQ": {
getter: function (varBag, idService) {
return varBag.vars.value.tabIDInLocal;
},
dataType: OS.Types.Text
},
"B3wXWZq7aUWYEIVdFUX_KA": {
getter: function (varBag, idService) {
return varBag.addClassNoSwipeJSResult.value;
}
},
"e+h9u3XlcU22Ur1L_whNeA": {
getter: function (varBag, idService) {
return varBag.vars.value.uRLInLocal;
},
dataType: OS.Types.Text
},
"ZB3jt8cO6UyAPUoqxcSYmA": {
getter: function (varBag, idService) {
return varBag.addFaviconJSResult.value;
}
},
"AZ_lAiT4PkqroKU27DpP1Q": {
getter: function (varBag, idService) {
return varBag.initECTJSResult.value;
}
},
"umH3O5XZ906q3gkjTHHoNA": {
getter: function (varBag, idService) {
return varBag.vars.value.userAgentInLocal;
},
dataType: OS.Types.Text
},
"1B54odsIhUeCcVl+yrlE1A": {
getter: function (varBag, idService) {
return varBag.outVars.value.browserOut;
},
dataType: OS.Types.Text
},
"LFGiQlQsl0S6Vbs+hRPR+w": {
getter: function (varBag, idService) {
return varBag.vars.value.hideHeaderOnScrollInLocal;
},
dataType: OS.Types.Boolean
},
"sLbyV5S8UUiYjL7PQKZhKw": {
getter: function (varBag, idService) {
return varBag.vars.value.targetIdInLocal;
},
dataType: OS.Types.Text
},
"9yYTvLbuNE2F6DOfAk65eg": {
getter: function (varBag, idService) {
return varBag.skipToContentJSResult.value;
}
},
"bfGKJ1B_sk65pnXBgj4EhA": {
getter: function (varBag, idService) {
return varBag.vars.value.listIdInLocal;
},
dataType: OS.Types.Text
},
"xb07J7dEDEm05wY1sZpuZg": {
getter: function (varBag, idService) {
return varBag.vars.value.hasLeftActionInLocal;
},
dataType: OS.Types.Boolean
},
"lhbvA9M+YUGFlaR8fZIBVQ": {
getter: function (varBag, idService) {
return varBag.vars.value.hasRightActionInLocal;
},
dataType: OS.Types.Boolean
},
"SG5ALp9a6UqadpEzOTCXsw": {
getter: function (varBag, idService) {
return varBag.vars.value.animationTimeInLocal;
},
dataType: OS.Types.Decimal
},
"HI7FczBGrEKwVfINKPZ6vA": {
getter: function (varBag, idService) {
return varBag.listItemAnimateJSResult.value;
}
},
"+mIZIR6g4EevIAtvr6mUvw": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"Wx9W9EoAZkSWXpQJFznJ7A": {
getter: function (varBag, idService) {
return varBag.vars.value.isSmoothInLocal;
},
dataType: OS.Types.Boolean
},
"aYVdQMoTE02HjwAVGptmgg": {
getter: function (varBag, idService) {
return varBag.vars.value.offSetInLocal;
},
dataType: OS.Types.Integer
},
"mE133IzgnEmi05Gp0HG3Nw": {
getter: function (varBag, idService) {
return varBag.scrollToElementJSResult.value;
}
},
"P9DByrkeYEWaLabmT75fAw": {
getter: function (varBag, idService) {
return varBag.outVars.value.isPhoneOut;
},
dataType: OS.Types.Boolean
},
"BX3uLVf1k0Wr5zgao8m4ow": {
getter: function (varBag, idService) {
return varBag.getDeviceTypeVar.value;
}
},
"vy3Gn11jQU669hZMoQ11rw": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"hRGnfc_5jkadLvrVm24NQQ": {
getter: function (varBag, idService) {
return varBag.pauseVideoJSResult.value;
}
},
"8qRXUiX9DEuIdCtr_cT_BA": {
getter: function (varBag, idService) {
return varBag.viewportJSResult.value;
}
},
"ItfV8gXRx0ihT6BbYk+NBw": {
getter: function (varBag, idService) {
return varBag.vars.value.carouselIDInLocal;
},
dataType: OS.Types.Text
},
"EA76gLu_y0WEapiQoFodxg": {
getter: function (varBag, idService) {
return varBag.addClassNoSwipeJSResult.value;
}
},
"wZ+Ats11_0O0f7qIwJ4REw": {
getter: function (varBag, idService) {
return varBag.outVars.value.isNativeOut;
},
dataType: OS.Types.Boolean
},
"BjdfYuAz7k2Qa63M89MgIQ": {
getter: function (varBag, idService) {
return varBag.checkIsWebAppJSResult.value;
}
},
"8CzTk9WVw0C2xf1SdO8mPw": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"wEwcXvm0jUKJwZd5VMepaQ": {
getter: function (varBag, idService) {
return varBag.setFocusJSResult.value;
}
},
"RdqlYWlCYEeJpX5RZ0u2bA": {
getter: function (varBag, idService) {
return varBag.vars.value.messageInLocal;
},
dataType: OS.Types.Text
},
"6mFkQXPW5UaPu+V0jWwoKQ": {
getter: function (varBag, idService) {
return varBag.vars.value.messageTypeInLocal;
},
dataType: OS.Types.Integer
},
"l7wXGteR+0K7j67AdCMTPA": {
getter: function (varBag, idService) {
return varBag.vars.value.encodedHTMLInLocal;
},
dataType: OS.Types.Boolean
},
"++vlGAlP2kWWeNuQT_bGJQ": {
getter: function (varBag, idService) {
return varBag.vars.value.extendedClassInLocal;
},
dataType: OS.Types.Text
},
"pzBv2zFYdk+rl+Jw8uvqhg": {
getter: function (varBag, idService) {
return varBag.vars.value.closeOnClickInLocal;
},
dataType: OS.Types.Boolean
},
"tVD78iKKA0mkOwErjC3kog": {
getter: function (varBag, idService) {
return varBag.showFeedbackMessageJSResult.value;
}
},
"552dkyDrvEqubIYlI2ky2g": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"46YnzcXd6UmkwH+nqi2Q0A": {
getter: function (varBag, idService) {
return varBag.setEventListenerJSResult.value;
}
},
"oql0fj81MkKIBFWhByF83Q": {
getter: function (varBag, idService) {
return varBag.outVars.value.isRTLOut;
},
dataType: OS.Types.Boolean
},
"AvkLh6PCIkWXMP_fWWgdKA": {
getter: function (varBag, idService) {
return varBag.checkRTLJSResult.value;
}
},
"2v19Xbd0EEeAUeDvE9Jb9g": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"xMKXLKzze0S3+ZodJF1oqw": {
getter: function (varBag, idService) {
return varBag.updateUiJSResult.value;
}
},
"odudn8epsEOTFn+_2qQH1w": {
getter: function (varBag, idService) {
return varBag.vars.value.textInLocal;
},
dataType: OS.Types.Text
},
"mxxRiYR+zEaWQ2SeYGzMvQ": {
getter: function (varBag, idService) {
return varBag.vars.value.numberOfCharsInLocal;
},
dataType: OS.Types.Integer
},
"dtolCG+1Gkqewx1BgEUySg": {
getter: function (varBag, idService) {
return varBag.outVars.value.outOut;
},
dataType: OS.Types.Text
},
"E7XleKb+UkCOQdHGwDB4ZA": {
getter: function (varBag, idService) {
return varBag.vars.value.previewCSSVar;
},
dataType: OS.Types.Text
},
"Zti0Ncev_UyJyMoKDV009w": {
getter: function (varBag, idService) {
return varBag.vars.value.generalCssVar;
},
dataType: OS.Types.Text
},
"NuLUeUgpEUCTkx4KpN0klA": {
getter: function (varBag, idService) {
return varBag.detectPreviewInDevicesJSResult.value;
}
},
"v3AkUN5_y0GdM12HkGJrfg": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"aUK7xALNA0WoM3OE6OtJ5g": {
getter: function (varBag, idService) {
return varBag.vars.value.activeItemInLocal;
},
dataType: OS.Types.Integer
},
"xKvTcM8hRUWIkW6_mFYRZg": {
getter: function (varBag, idService) {
return varBag.vars.value.activeSubItemInLocal;
},
dataType: OS.Types.Integer
},
"eMpAyzImzUKwL_ip4d08TA": {
getter: function (varBag, idService) {
return varBag.setActiveJSResult.value;
}
},
"nnXQzS8kxU+Julm22dIqIw": {
getter: function (varBag, idService) {
return varBag.vars.value.userAgentVar;
},
dataType: OS.Types.Text
},
"ZbJB_cs_Mkqn+ANCAE8lPA": {
getter: function (varBag, idService) {
return varBag.vars.value.isWebAppInLocal;
},
dataType: OS.Types.Boolean
},
"802dRsv2ZkmMTp_gvSZjQg": {
getter: function (varBag, idService) {
return varBag.getBrowserVar.value;
}
},
"SO6yYH8njUOWeZhQo6DNmQ": {
getter: function (varBag, idService) {
return varBag.getOSVar.value;
}
},
"5WQ6+EOI20qlKf+sVTvE1A": {
getter: function (varBag, idService) {
return varBag.getIsTouchVar.value;
}
},
"RWt+kXHuzUSxVy0cZJHDGw": {
getter: function (varBag, idService) {
return varBag.addNativeClassesJSResult.value;
}
},
"FDjUnNglU0GGZuMXhNjSKQ": {
getter: function (varBag, idService) {
return varBag.addWebClassesJSResult.value;
}
},
"RcUKCznBskGsiPDjBehj5g": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"RAfjTcfSlU6imxmQMnCpsw": {
getter: function (varBag, idService) {
return varBag.vars.value.tabNumberInLocal;
},
dataType: OS.Types.Integer
},
"DkGb6z63NUeOAN_exev1sA": {
getter: function (varBag, idService) {
return varBag.changeTabJSResult.value;
}
},
"z3SR6adZJUWjR4CsYqcFRQ": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"bYAjhTuI_UCBz++CrCJsBg": {
getter: function (varBag, idService) {
return varBag.swipeLeftJSResult.value;
}
},
"n8TPmPwhBU2KRXr3lW5hzQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.networkTypeOut;
},
dataType: OS.Types.Text
},
"DdnOaND2fkCpllA7GTAiCg": {
getter: function (varBag, idService) {
return varBag.checkNetworkTypeJSResult.value;
}
},
"ULOJ1JdZV06nLBd32iU9zQ": {
getter: function (varBag, idService) {
return varBag.vars.value.callbackInLocal;
},
dataType: OS.Types.Object
},
"TnjtB1qi30uCRxJtSprrXg": {
getter: function (varBag, idService) {
return varBag.outVars.value.rTObserverObjOut;
},
dataType: OS.Types.Object
},
"I0v7qVLxN0yTq6rIFmubjw": {
getter: function (varBag, idService) {
return varBag.observerJSResult.value;
}
},
"0kG81uY5e0GVOSc67jGqBw": {
getter: function (varBag, idService) {
return varBag.vars.value.userAgentInLocal;
},
dataType: OS.Types.Text
},
"EIlIMad4pk+liSQRvrUwQQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.oSOut;
},
dataType: OS.Types.Text
},
"UTNgkVilxEuT_Cr3S2KMTA": {
getter: function (varBag, idService) {
return varBag.detectIphoneXJSResult.value;
}
},
"kjBPK70600CmwsglzKE0SA": {
getter: function (varBag, idService) {
return varBag.vars.value.contentIdInLocal;
},
dataType: OS.Types.Text
},
"Vz80WN2GxkarDKbQWZ84Xw": {
getter: function (varBag, idService) {
return varBag.vars.value.triggerItemInLocal;
},
dataType: OS.Types.Text
},
"UufczVjIsEqSMRYpostVdw": {
getter: function (varBag, idService) {
return varBag.setFocusBehaviourJSResult.value;
}
},
"UoTroLkEs0ipEBTZAHXTzw": {
getter: function (varBag, idService) {
return varBag.vars.value.activeItemInLocal;
},
dataType: OS.Types.Integer
},
"GBAp_B5zEEafCOEqAM20CQ": {
getter: function (varBag, idService) {
return varBag.vars.value.activeSubItemInLocal;
},
dataType: OS.Types.Integer
},
"uauiLqkNdU2Vr4TlJvBStA": {
getter: function (varBag, idService) {
return varBag.setActiveJSResult.value;
}
},
"sD28oLAE8kOYUOCl9kDTHw": {
getter: function (varBag, idService) {
return varBag.vars.value.tableIdInLocal;
},
dataType: OS.Types.Text
},
"aoNsjtr39EmXIYAk_8UCtQ": {
getter: function (varBag, idService) {
return varBag.vars.value.rowNumberInLocal;
},
dataType: OS.Types.Integer
},
"Kgq7hn4x70m93JvEJ1zJ1A": {
getter: function (varBag, idService) {
return varBag.vars.value.isSelectedInLocal;
},
dataType: OS.Types.Boolean
},
"ATatOzJqo0u2ApIml90UFg": {
getter: function (varBag, idService) {
return varBag.setSelectedRowJSResult.value;
}
},
"qLA8zbYCJ0GeeKTA6l0_Dg": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"NdVbtmiNvESSTFMxbhkzFA": {
getter: function (varBag, idService) {
return varBag.swipeRightJSResult.value;
}
},
"jK0u8VLe6E+1I1BAkhjrbA": {
getter: function (varBag, idService) {
return varBag.vars.value.deviceConfigurationInLocal;
}
},
"VoR2nu8KDUyBS7WGi_Ed1w": {
getter: function (varBag, idService) {
return varBag.setDeviceOnResizeJSResult.value;
}
},
"sSpuHDYDoE2Ew8OgBXKTvw": {
getter: function (varBag, idService) {
return varBag.outVars.value.isOnlineOut;
},
dataType: OS.Types.Boolean
},
"lLAk3sElnEm+ySLNkSsrjw": {
getter: function (varBag, idService) {
return varBag.checkDeviceOnlineJSResult.value;
}
},
"Vb34NY3zYEGX4ikxHnvp0A": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"53BVu_67OUOpcv5eedIWzw": {
getter: function (varBag, idService) {
return varBag.callNextActionJSResult.value;
}
},
"4CpUHNaQRUume7E1q0Su+g": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"X_gFhwE7Lkiq7jKcqYRqDA": {
getter: function (varBag, idService) {
return varBag.vars.value.isActiveInLocal;
},
dataType: OS.Types.Boolean
},
"IO79uJFMWEeJUfqEirGmkg": {
getter: function (varBag, idService) {
return varBag.setActiveElementJSResult.value;
}
},
"d1di0ONiQ0aOcg3byZYc0Q": {
getter: function (varBag, idService) {
return varBag.outVars.value.isDesktopOut;
},
dataType: OS.Types.Boolean
},
"LyPCmHPMOUiz05omO6N5Kg": {
getter: function (varBag, idService) {
return varBag.getDeviceTypeVar.value;
}
},
"A2ILCIEO7EGW0QZ6CB6LJg": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"mfJ8xdFCcEm0t1Gi9snU+Q": {
getter: function (varBag, idService) {
return varBag.callPreviousActionJSResult.value;
}
},
"onmE87DcFkiZyEYZNkE+eg": {
getter: function (varBag, idService) {
return varBag.vars.value.isWebAppVar;
},
dataType: OS.Types.Boolean
},
"7nyPIcv8REyRdnDThsUOJA": {
getter: function (varBag, idService) {
return varBag.vars.value.isPWAVar;
},
dataType: OS.Types.Boolean
},
"PdwtDmJ9MUKMS4YDtId34w": {
getter: function (varBag, idService) {
return varBag.runOnStartJSResult.value;
}
},
"07SEFfNsg0K4cJ3Z4ke3iA": {
getter: function (varBag, idService) {
return varBag.getHeaderAndFooterSizeJSResult.value;
}
},
"vedik6OqRESlGJkYBGu5Tg": {
getter: function (varBag, idService) {
return varBag.fixForRenderingIssuesJSResult.value;
}
},
"9hie0LpEdE24tR9bVTqriQ": {
getter: function (varBag, idService) {
return varBag.viewportJSResult.value;
}
},
"B2Fl0bIY5UqjnDYFY8KlvA": {
getter: function (varBag, idService) {
return varBag.closeMenuOnBodyClickJSResult.value;
}
},
"fd7I_BtwWkecM47jRYQwFQ": {
getter: function (varBag, idService) {
return varBag.setExpandableExceptionsJSResult.value;
}
},
"P_GwkYB2Qky8mj5wnK0Usg": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"LrnR4YHuPEaFFAmbmSTz1Q": {
getter: function (varBag, idService) {
return varBag.callUpdateActionJSResult.value;
}
},
"9md9YTHjZkiZZN3suuWnkg": {
getter: function (varBag, idService) {
return varBag.toggleLayoutClassJSResult.value;
}
},
"EbXefQSkc0aLbD3h3UfbNQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.addDragOut;
},
dataType: OS.Types.Boolean
},
"9uW+UGQms020qoCwM_hTwA": {
getter: function (varBag, idService) {
return varBag.checkIfNativeJSResult.value;
}
},
"+saQ0fhpUUq89_xpICnSAg": {
getter: function (varBag, idService) {
return varBag.outVars.value.uRLOut;
},
dataType: OS.Types.Text
},
"7srVpViX+EadwjmfHMaeMQ": {
getter: function (varBag, idService) {
return varBag.vars.value.showFocusInLocal;
},
dataType: OS.Types.Boolean
},
"ly2tKQ9rGECKJvMC6SY1ew": {
getter: function (varBag, idService) {
return varBag.vars.value.showSkipToContentInLocal;
},
dataType: OS.Types.Boolean
},
"ZsWmIvKBBkaNJGyYYN+RfA": {
getter: function (varBag, idService) {
return varBag.vars.value.langInLocal;
},
dataType: OS.Types.Text
},
"OEiKilqUO0uT5hWyOOJlmQ": {
getter: function (varBag, idService) {
return varBag.setConfigJSResult.value;
}
},
"Hlukjh42A0e7KTmBBV5kxw": {
getter: function (varBag, idService) {
return varBag.vars.value.activeItemInLocal;
},
dataType: OS.Types.Integer
},
"ft1g983_JkyOahUTuGF5kA": {
getter: function (varBag, idService) {
return varBag.addActiveJSResult.value;
}
},
"SeZaiei3l02bVsMlI7AgBw": {
getter: function (varBag, idService) {
return varBag.vars.value.inputIdInLocal;
},
dataType: OS.Types.Text
},
"24BYYGogjEamX0Nv0eDlVA": {
getter: function (varBag, idService) {
return varBag.clearDateJSResult.value;
}
},
"N9qM0cA0mkSxUqTm3IcUJw": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"WXaYc5PKJEOfP8_vtx0xtw": {
getter: function (varBag, idService) {
return varBag.vars.value.multipleItemsInLocal;
},
dataType: OS.Types.Boolean
},
"ulTTWWisZE6vnyND5_2EsQ": {
getter: function (varBag, idService) {
return varBag.updateAccordionJSResult.value;
}
},
"+I9JkjJjakK280+6IfwP8w": {
getter: function (varBag, idService) {
return varBag.vars.value.hasErrorInLocal;
},
dataType: OS.Types.Boolean
},
"DCs_wh+rgEKLx0aKR_Y_vA": {
getter: function (varBag, idService) {
return varBag.vars.value.errorMessageInLocal;
},
dataType: OS.Types.Text
},
"cgGNyx+ntUSOxm5inqsadA": {
getter: function (varBag, idService) {
return varBag.vars.value.allowRetryInLocal;
},
dataType: OS.Types.Boolean
},
"v03QPIY87ECIHTsz5R0JNA": {
getter: function (varBag, idService) {
return varBag.triggerSyncCompleteEventJSResult.value;
}
},
"iIqr4yohpki+TJEMODfuzQ": {
getter: function (varBag, idService) {
return varBag.triggerSyncErrorEventJSResult.value;
}
},
"7G0KMtWjn0+HjyqaZU0Vxw": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"OhEyJVmArkyNoKTm8dQpsA": {
getter: function (varBag, idService) {
return varBag.vars.value.roleInLocal;
},
dataType: OS.Types.Text
},
"4O88zbHElkSgAsLU0yIERw": {
getter: function (varBag, idService) {
return varBag.setRoleJSResult.value;
}
},
"QphTtzz8LUSMkYDEPg6ugQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.deviceOut;
},
dataType: OS.Types.Text
},
"N9WTj9dLUkuBdvhGabzneA": {
getter: function (varBag, idService) {
return varBag.checkDeviceJSResult.value;
}
},
"zC671vjgxUCxvuKBets7Cg": {
getter: function (varBag, idService) {
return varBag.outVars.value.isTouchOut;
},
dataType: OS.Types.Boolean
},
"UzL18+5tCEyY2xczP1HzpQ": {
getter: function (varBag, idService) {
return varBag.setIsTouchJSResult.value;
}
},
"yRkQ_D2_qEm2BiVxFUwylQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.isStandaloneOut;
},
dataType: OS.Types.Boolean
},
"ho14ByP0d0KPoK4vE2Wcbw": {
getter: function (varBag, idService) {
return varBag.isRunningAsPWAJSResult.value;
}
},
"yH10E7_NoEmaUrpAkuvkHg": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"X93MJr+xZUqCmwTVroWG_A": {
getter: function (varBag, idService) {
return varBag.vars.value.isHiddenInLocal;
},
dataType: OS.Types.Boolean
},
"r0z5tyLSlUqGLBeTxTzxqA": {
getter: function (varBag, idService) {
return varBag.setAriaHiddenJSResult.value;
}
},
"eyb8jAm6+kSOcY1dlExx2g": {
getter: function (varBag, idService) {
return varBag.outVars.value.orientationOut;
},
dataType: OS.Types.Text
},
"gbjVoiko4UGtMqk2GHLr1g": {
getter: function (varBag, idService) {
return varBag.checkDeviceJSResult.value;
}
},
"bxp8S_H10kKMTwwJmoLfTQ": {
getter: function (varBag, idService) {
return varBag.showPasswordJSResult.value;
}
},
"lGYz479sKE2RJjD9e6HHYg": {
getter: function (varBag, idService) {
return varBag.outVars.value.isTabletOut;
},
dataType: OS.Types.Boolean
},
"ioZf772KpUSfGBw8JlIMDw": {
getter: function (varBag, idService) {
return varBag.getDeviceTypeVar.value;
}
},
"+p4JrADMgEuyMGCRVuSHCA": {
getter: function (varBag, idService) {
return varBag.toggleLayoutClassJSResult.value;
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
define("OutSystemsUI.controller$translationsResources", ["exports", "OutSystemsUI.controller$translationsResources.pt", "OutSystemsUI.controller$translationsResources.ja-JP", "OutSystemsUI.controller$translationsResources.es"], function (exports, OutSystemsUI_controller_translationsResources_pt, OutSystemsUI_controller_translationsResources_jaJP, OutSystemsUI_controller_translationsResources_es) {
return {
"pt": {
"translations": OutSystemsUI_controller_translationsResources_pt,
"isRTL": false
},
"ja-JP": {
"translations": OutSystemsUI_controller_translationsResources_jaJP,
"isRTL": false
},
"es": {
"translations": OutSystemsUI_controller_translationsResources_es,
"isRTL": false
}
};
});
define("OutSystemsUI.controller$translationsResources.pt", [], function () {
return {
"lg7NoSsYfEuhIOQNq772Tw#Value.1874273954.1": "Aceitar",
"EKgo2wktLUWoYHof84369Q#Value.58078159.1": "ESPAÇO / ENTER para seleccionar a data",
"hxu4s7ASlUCI3vkxgsoR+A#Value.941141342.1": "PAGE DOWN para mover para o mês seguinte",
"2pdORbIMeUmJLoWBa4tFQQ#Value.-513930751.1": "PAGE UP para mover para o mês anterior",
"9s+39UgfEUOBkGEECmMZsw#Value.887781619.1": "ESCAPE para fechar o calendário",
"yqo5pCbrYUa4Qeqn0J_qOg#Value.-1565462224.1": "DELETE para volar a data inicial",
"I6J5cRrTyk6bSZ6JvMUtBg#Value.-1048883153.1": "CIMA / BAIXO para mover entre semanas",
"aUoleWSZBEGHb_sk4X7m8A#Value.-1916325413.1": "ESQUERDA / DIREITA para mover entre os dias",
"7KBMokDeIEC_mM_EfFiiKA#Value.82125743.1": "Os atalhos de teclado que estão disponiveis são os seguintes",
"lRJU8QwPl0iwqv3N9eqD+Q#Value.1784051735.1": "Mês anterior",
"d7ISJdppoUa87s3wJLedig#Value.-766743789.1": "Mês seguinte",
"eVkbzc3vuEypSjfR3Hr9bA#Value.1511082002.1": "Pressione a tecla Tab para entrar no Calendário",
"hw5vDiQKrESpaaxSlyRHCA#Value.857568417.1": "Fechado. Pressione a tecla Enter para abrir o Calendário",
"1b5_VD14vEWCUSQsUQ8m8g#Value.-464608999.1": "Aberto. Pressione a tecla Enter para fechar o Calendário",
"StrMC+dU8UKyWJfLxq6nJA#Value.-18794124.1": "Ir para o dia actual",
"Bra9RrfzZk+b3rOW0R7aWA#Value.-113680546.1": "Calendário",
"bOB6QpW3y0qaPPNGZE3U9A#Value.-911153517.1": "Data seleccionada: ",
"XTzYOcd0uEuBcu+inuc+jg#Value.-2092303549.1": "Datas do calendário ",
"k2YfRkJbhkWi6MaJmqxhJg#Value.1665633300.1": "Atalhos do teclado",
"H6apzIN1TUKPQopWFy0zBw#Value.3704893.1": "ano",
"iKX__y0GCEK4HvMWgzSWjA#Value.104080000.1": "mês",
"q2HVeR5fq06ujvR8mwXC1g#Value.1862666772.1": "navegação",
"Ou2_Lg3vvEe3aQ7GWyGPBQ#Value.979281226.1": "Fim de ciclo. ",
"6yUVQvdC90Gm4KUFQBj81w#Value.1774776785.1": "Inicio de ciclo. ",
"nmdHfe62kkWmZZi8twrJvg#Value.-1662297402.1": "Dia está no ciclo",
"s6Mc6dzsq0O31GbSo7QbpQ#Value.-1258432986.1": "Tem evento. ",
"pXZo0bRIl0KKarFWqwJMoA#Value.997213361.1": "Data seleccionada. ",
"iqF5Pqcm+EuQgVmDvcRfXQ#Value.1584999357.1": "Hoje. ",
"0JFpmf26qEmLPKk06zPUDg#Value.374566222.1": "Desactivado. ",
"wupNrsljn0+ZgKsDAgws7w#Value.82886.1": "Sab",
"7Dxp7GHv9kO9AEdEXQqPGA#Value.70909.1": "Sex",
"C5ZwndaAOUOl74fkEmefDw#Value.84065.1": "Qui",
"n_faF_hqU0qU+TQPqypwbg#Value.86838.1": "Qua",
"TxFtPzJ8eEmwSbWV_8uB3w#Value.84452.1": "Ter",
"pWtYDFh+oEGF3oMu1ST3SA#Value.77548.1": "Seg",
"Q0atH4XnxESfNPKXcNCMhg#Value.83500.1": "Dom",
"fxhdUHdd30WEIUqlUd3Dgg#Value.-2049557543.1": "Sábado",
"PTUebe2ghUGIcIlmoiHGTA#Value.2112549247.1": "Sexta",
"rZxYcEOLE0SMy_WUK1USbg#Value.1636699642.1": "Quinta",
"2cEIAtVIlES4bU387yYKFA#Value.-897468618.1": "Quarta",
"CdvV1OKrjUSoC4jJteUE6A#Value.687309357.1": "Terça",
"WV8_eD4RTE61GB2a0BkwuQ#Value.-1984635600.1": "Segunda",
"PP+e0FO51k2OuDR1+EhorQ#Value.-1807319568.1": "Domingo",
"mSVpIhn5x0WuqHFplsMTFw#Value.626483269.1": "Dezembro",
"duL0nCW7+0uMBTLcjoL7Xg#Value.1703773522.1": "Novembro",
"9LIV9yDE20eRBuqb7_MUNQ#Value.43165376.1": "Outubro",
"nX8TB7S5xkW2vLpNGzji6A#Value.-25881423.1": "Setembro",
"ZIkkytkF00C62bRH6ZRMcA#Value.1972131363.1": "Agosto",
"OG7OPs09EEmIHvBtd09u5Q#Value.2320440.1": "Julho",
"q6eCYPoiPE6Z8gtzavUUWg#Value.2320482.1": "Junho",
"Ew9YPH2yzEGI5SqyvW_2sQ#Value.77125.1": "Maio",
"jNVk7nRwUkKdBhDRLgvUag#Value.63478374.1": "Abril",
"mbDBy4VjB0SzzkLzOXUdFg#Value.74113571.1": "Março",
"4BHq85s+VE+IylptE9ZukQ#Value.-199248958.1": "Fevereiro",
"Elw2vXw960izxzIMvM1qpA#Value.-162006966.1": "Janeiro",
"7JkNQfmve0ybQuEBCcmHfw#Value.2433920.1": "meio-dia",
"tI9n5r_Dx0iO64Cd0TsZQg#Value.-1576218896.1": "meia-noite",
"c93RG+ceD0WdMhhBlgm7sA#Value.80981793.1": "Hoje",
"FRQkwo9Yp0iVKYmvglli4w#Value.-766743789.1": "Mês anterior",
"1fCvKiR860iF8y93wqzElg#Value.1784051735.1": "Mês seguinte"
};
});
define("OutSystemsUI.controller$translationsResources.ja-JP", [], function () {
return {
"wupNrsljn0+ZgKsDAgws7w#Value.82886.1": "土",
"7Dxp7GHv9kO9AEdEXQqPGA#Value.70909.1": "金",
"C5ZwndaAOUOl74fkEmefDw#Value.84065.1": "木",
"n_faF_hqU0qU+TQPqypwbg#Value.86838.1": "水",
"TxFtPzJ8eEmwSbWV_8uB3w#Value.84452.1": "火",
"pWtYDFh+oEGF3oMu1ST3SA#Value.77548.1": "月",
"Q0atH4XnxESfNPKXcNCMhg#Value.83500.1": "日",
"fxhdUHdd30WEIUqlUd3Dgg#Value.-2049557543.1": "土曜日",
"PTUebe2ghUGIcIlmoiHGTA#Value.2112549247.1": "金曜日",
"rZxYcEOLE0SMy_WUK1USbg#Value.1636699642.1": "木曜日",
"2cEIAtVIlES4bU387yYKFA#Value.-897468618.1": "水曜日",
"CdvV1OKrjUSoC4jJteUE6A#Value.687309357.1": "火曜日",
"WV8_eD4RTE61GB2a0BkwuQ#Value.-1984635600.1": "月曜日",
"PP+e0FO51k2OuDR1+EhorQ#Value.-1807319568.1": "日曜日",
"mSVpIhn5x0WuqHFplsMTFw#Value.626483269.1": "12月",
"duL0nCW7+0uMBTLcjoL7Xg#Value.1703773522.1": "11月",
"9LIV9yDE20eRBuqb7_MUNQ#Value.43165376.1": "10月",
"nX8TB7S5xkW2vLpNGzji6A#Value.-25881423.1": "9月",
"ZIkkytkF00C62bRH6ZRMcA#Value.1972131363.1": "8月",
"OG7OPs09EEmIHvBtd09u5Q#Value.2320440.1": "7月",
"q6eCYPoiPE6Z8gtzavUUWg#Value.2320482.1": "6月",
"Ew9YPH2yzEGI5SqyvW_2sQ#Value.77125.1": "5月",
"jNVk7nRwUkKdBhDRLgvUag#Value.63478374.1": "4月",
"mbDBy4VjB0SzzkLzOXUdFg#Value.74113571.1": "3月",
"4BHq85s+VE+IylptE9ZukQ#Value.-199248958.1": "2月",
"Elw2vXw960izxzIMvM1qpA#Value.-162006966.1": "1月"
};
});
define("OutSystemsUI.controller$translationsResources.es", [], function () {
return {
"7JkNQfmve0ybQuEBCcmHfw#Value.2433920.1": "noon espanhol",
"tI9n5r_Dx0iO64Cd0TsZQg#Value.-1576218896.1": "midnight espanhol",
"c93RG+ceD0WdMhhBlgm7sA#Value.80981793.1": "button espanhol"
};
});
