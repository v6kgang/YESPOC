﻿define("OutSystemsSampleDataDB.referencesHealth$BinaryData", [], function () {
// Reference to producer 'BinaryData' is OK.
});
define("OutSystemsSampleDataDB.referencesHealth$HTTPRequestHandler", [], function () {
// Reference to producer 'HTTPRequestHandler' is OK.
});
define("OutSystemsSampleDataDB.referencesHealth$ServiceCenter", [], function () {
// Reference to producer 'ServiceCenter' is OK.
});
define("OutSystemsSampleDataDB.referencesHealth$Users", [], function () {
// Reference to producer 'Users' is OK.
});
define("OutSystemsSampleDataDB.referencesHealth$Zip", [], function () {
// Reference to producer 'Zip' is OK.
});
define("OutSystemsSampleDataDB.referencesHealth", [], function () {
});
