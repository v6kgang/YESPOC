﻿/**************************************************************
* OutSystems UI
*
* 0. Version
* 1. Init Events
* 2. Handle clicks on body
* 3. Feedback on clicked list items and bottom bar items
* 4. Feedback of buttons clicked
* 5. Check if parent elements have the given class
* 6. Use Hide On Scroll feature
* 7. Generic toggle class function
* 8. Generic function to get closest element - Android 4.4.2
* 9. Fix Inputs for iOS devices
* 10. Check if has MasterDetail
* 11. Made with OutSystems
*
**************************************************************/
var osui = new osuijs();
// 0. Version
function osuijs() {
    
    //0. Version
    var getVersion = function() {
        var version = "2.6.13";
        console.log("OutSystems UI - Version " + version);
    };

    // 1. Init Events
    document.body.addEventListener("click", bodyClick);

    // 2. Handle clicks on body
    function bodyClick(event) {
        if(event.target.classList.contains("btn")) {
            buttonEffect(event.target);
            return;
        }
        
        var found = hasSomeParentTheClass(event.target, 'list-item') || hasSomeParentTheClass(event.target, 'bottom-bar-item');

        if(found) {
            clickEffect(found);
        }
    }
    
    // 3. Feedback on clicked elements
    function clickEffect(el) {
        var spanEl = document.createElement("span");
        spanEl.classList.add("scale-animation"); 
        
        el.appendChild(spanEl);
        
        el.addEventListener("animationend", OnTransitionEnd, false);
        el.addEventListener("webkitAnimationEnd", OnTransitionEnd, false);
            
        function OnTransitionEnd() {
            if(spanEl && this == el && this === spanEl.parentNode) {
                this.removeChild(spanEl);
            }
        }
    }
    
    // 4. Feedback on clicked buttons
    function buttonEffect(el) {
        var spanEl = document.createElement("span");
        spanEl.classList.add("btn-animation"); 
        el.appendChild(spanEl);
        
        setTimeout(function(){
            el.removeChild(spanEl);
        }, 1800);
    }
    
    // 5. Check if parent elements have the given class
    function hasSomeParentTheClass(element, classname) {
        if(element) {
            // only if it has a class, only if it's beneath 'main-content' and doesn't pass it, if it's not a chart
            if(typeof element.className !== 'undefined' && !element.classList.contains(".main-content") && !(element instanceof SVGElement)) {
                if (element.className.split(' ').indexOf(classname)>=0) {
                    return element;
                } else {
                    return hasSomeParentTheClass(element.parentNode, classname);
                }
            }
        }
        
        return undefined;
    }
    
    // 6. Use Hide On Scroll feature (only used on old Native apps)
    var hideOnScroll = function() {
        
        var addEvents = function(header) {
    
            var content = document.querySelector(".active-screen .content");
    
            if(header.classList.contains("hide") && content) {
                
                var mainContentHeight = document.querySelector('.main-content').scrollHeight;
                var startY = 0;
                var threshold = 60;
                var layout = document.querySelector('.layout');
                
                if(mainContentHeight - threshold > content.offsetHeight) {
                    content.addEventListener('touchstart', function(e) {
                        startY = e.touches[0].pageY;
                    }, false);
        
                    content.addEventListener('touchmove', function(e) {
                        var c = e.touches[0].pageY;
                        var translateY = c - startY;
                        
                        if (c < startY - threshold && translateY < 0){
                            header.classList.add("header-on-scroll");
                            layout.classList.add('header-is-hidden');
                        } else if(c > startY + threshold){
                            header.classList.remove("header-on-scroll");
                            layout.classList.remove('header-is-hidden');
                        }
        
                    }, false);
                }
            }
        };  
    
        return {        
            init: function() {        
                header = document.querySelector('.header');
                if(header !== null) {            
                    addEvents(header);
                }
            }
        };
        
    };
    
    // 7. Generic toggle class function
    var toggleClass = function(el, state, className) {
    
        var classList = el.classList;   
        
        if(!state) {
            setTimeout(function() {
                if(!state) {
                    classList.remove(className);
                }
            }, 500);
        } else {
            classList.add(className);
            el.offsetHeight;
        }    
    };
    
    // 8. Generic function to get closest element - Android 4.4.2
    var getClosest = function (elem, selector) {
        var firstChar = selector.charAt(0);
        // Get closest match
        for ( ; elem && elem !== document; elem = elem.parentNode ) {
            // If selector is a class
            if ( firstChar === '.' ) {
                if ( elem.classList.contains( selector.substr(1) ) ) {
                    return elem;
                }
            }
            // If selector is an ID
            if ( firstChar === '#' ) {
                if ( elem.id === selector.substr(1) ) {
                    return elem;
                }
            } 
            // If selector is a data attribute
            if ( firstChar === '[' ) {
                if ( elem.hasAttribute( selector.substr(1, selector.length - 2) ) ) {
                    return elem;
                }
            }
            // If selector is a tag
            if ( elem.tagName.toLowerCase() === selector ) {
                return elem;
            }
        }
        return false;
    };
    
    // 9. Fix Inputs for iOS devices
    
    var fixInputs = function() {
    
        var originalPosition = 0;
        var currentPosition = 0;
        var content = document.querySelector('.content');    
        var inputs = document.querySelectorAll('input:not([type=button]):not([type=checkbox]):not([type=color]):not([type=file]):not([type=hidden]):not([type=image]):not([type=image]):not([type=radio]):not([type=range]):not([type=reset]):not([type=submit]), textarea');
    
        if(inputs.length !== 0) {
            for (var i = inputs.length - 1; i >= 0; i--) {
                inputs[i].style.webkitUserSelect = 'auto';
            }
            
            if(content) {
                
                content.addEventListener('touchstart', function(e) {
                    originalPosition = e.changedTouches[0].pageY;
                    for (i = inputs.length - 1; i >= 0; i--) {
                        inputs[i].style.webkitUserSelect = 'auto';
                    }
                });
        
                content.addEventListener('touchmove', function(e) {
                    currentPosition = e.touches[0].pageY;
                    if(Math.abs(originalPosition - currentPosition) > 10) {
                        for (i = inputs.length - 1; i >= 0; i--) {
                            inputs[i].style.webkitUserSelect = 'none';
                        }    
                    } else {
                        for (i = inputs.length - 1; i >= 0; i--) {
                            inputs[i].style.webkitUserSelect = 'auto';
                        }     
                    }
                });
        
                content.addEventListener('touchend', function(e) {
                    setTimeout(function() {
                        for (i = inputs.length - 1; i >= 0; i--) {
                            inputs[i].style.webkitUserSelect = 'auto';
                        }
                     },0);
                });    
            }
        }
    };
    
    // 10. Check if has MasterDetail
    
    var hasMasterDetail = function() {
        
        var masterDetail = document.querySelector('.split-screen-wrapper');
        var content = document.querySelector(".active-screen .content");
        
        if(content && content.contains(masterDetail)) {
            content.classList.add('has-master-detail');
        } 
        
    };
    
    // 11. Made with OutSystems
    
    var startMWO = function() {
        
        function setStyles() {
            var mwo = document.querySelector(".mwo"); // Query the label wrapper link
            
            // set base styles
            mwo.style.setProperty('position', 'fixed', 'important');
            mwo.style.setProperty('bottom', '0', 'important');
            mwo.style.setProperty('left', '10px', 'important');
            mwo.style.setProperty('zIndex', '9999', 'important');
            
            // rewrite any possible styles that can hide the label
            mwo.style.setProperty('right', 'initial', 'important');
            mwo.style.setProperty('top', 'initial', 'important');
            mwo.style.setProperty('transform', 'none', 'important');
            mwo.style.setProperty('opacity', '1', 'important');
            mwo.style.setProperty('display', 'block', 'important');
            mwo.style.setProperty('visibility', 'visible', 'important');
            mwo.style.setProperty('clipPath', 'none', 'important');
            mwo.style.setProperty('width', 'auto', 'important');
            mwo.style.setProperty('height', 'auto', 'important');
        }
        
        function createMWO() {
            var appName = window.location.pathname.split('/')[1]; // Get app name
            var mwo = document.createElement('a'); // Create the link element
            mwo.classList.add("mwo"); // Add the CSS class
            
            // Create the link with parameters and SVG element
            mwo.href = "https://www.outsystems.com/p/built-with-outsystems/?utm_source=" + appName + "&utm_medium=referral&utm_campaign=made-with-os";
            mwo.target = "_blank";
            mwo.innerHTML = "<svg width='116' height='50' viewBox='0 0 116 50' fill='none' xmlns='http://www.w3.org/2000/svg'><g filter='url(#filter0_d)'><path d='M8 8C8 4.68629 10.6863 2 14 2H102C105.314 2 108 4.68629 108 8V30C108 33.3137 105.314 36 102 36H14C10.6863 36 8 33.3137 8 30V8Z' fill='white'/><rect x='16' y='8' width='22' height='22' rx='4' fill='#F22800'/><path fill-rule='evenodd' clip-rule='evenodd' d='M24.048 19.3518C24.1234 20.0821 24.4669 20.7585 25.0121 21.2503C25.5573 21.742 26.2655 22.0142 26.9997 22.0142C27.7339 22.0142 28.442 21.742 28.9872 21.2503C29.5324 20.7585 29.8759 20.0821 29.9514 19.3518C29.9614 19.2519 29.9663 19.1508 29.9663 19.0483C29.9697 18.6566 29.8954 18.2681 29.7478 17.9052C29.6003 17.5424 29.3823 17.2123 29.1065 16.9341C28.8306 16.6559 28.5025 16.4351 28.1409 16.2845C27.7793 16.1338 27.3914 16.0562 26.9997 16.0562C26.6079 16.0562 26.2201 16.1338 25.8585 16.2845C25.4969 16.4351 25.1687 16.6559 24.8929 16.9341C24.6171 17.2123 24.3991 17.5424 24.2515 17.9052C24.1039 18.2681 24.0296 18.6566 24.033 19.0483C24.033 19.1504 24.038 19.2519 24.048 19.3518ZM19 19.0002C19 17.4179 19.4691 15.8712 20.3482 14.5556C21.2272 13.2399 22.4767 12.2145 23.9385 11.609C25.4003 11.0035 27.0089 10.845 28.5607 11.1537C30.1126 11.4624 31.5381 12.2244 32.6569 13.3432C33.7758 14.4621 34.5377 15.8876 34.8463 17.4395C35.155 18.9913 34.9965 20.5999 34.3909 22.0617C33.7854 23.5235 32.7599 24.7729 31.4443 25.652C30.1286 26.531 28.5818 27.0001 26.9996 27C25.949 27 24.9088 26.7931 23.9382 26.391C22.9676 25.989 22.0858 25.3998 21.3429 24.6569C20.6001 23.9141 20.0109 23.0322 19.6089 22.0616C19.2069 21.091 19 20.0508 19 19.0002Z' fill='white'/><path d='M47.448 12.952C47.8 13.0373 48.0693 13.2027 48.256 13.448C48.4427 13.688 48.536 14.0053 48.536 14.4C48.536 14.896 48.376 15.288 48.056 15.576C47.7413 15.8587 47.3067 16 46.752 16H44.64V10.4H46.408C46.92 10.4 47.3147 10.5147 47.592 10.744C47.8747 10.9733 48.016 11.3147 48.016 11.768C48.016 12.0347 47.968 12.272 47.872 12.48C47.776 12.688 47.6347 12.8453 47.448 12.952ZM45.4 12.728H46.312C46.6107 12.728 46.8373 12.6693 46.992 12.552C47.152 12.4293 47.232 12.2133 47.232 11.904C47.232 11.5947 47.152 11.3813 46.992 11.264C46.8373 11.1413 46.6107 11.08 46.312 11.08H45.4V12.728ZM46.688 15.312C47.0027 15.312 47.2507 15.2347 47.432 15.08C47.6133 14.92 47.704 14.6853 47.704 14.376C47.704 13.736 47.3653 13.416 46.688 13.416H45.4V15.312H46.688ZM52.4384 12.08V16H51.7984L51.7184 15.568C51.5904 15.744 51.4384 15.8747 51.2624 15.96C51.0917 16.04 50.881 16.08 50.6304 16.08C50.161 16.08 49.801 15.9387 49.5504 15.656C49.305 15.368 49.1824 14.936 49.1824 14.36V12.08H49.9024V14.16C49.9024 14.5867 49.9744 14.9067 50.1184 15.12C50.2677 15.3333 50.4997 15.44 50.8144 15.44C51.001 15.44 51.1744 15.4027 51.3344 15.328C51.4997 15.2533 51.6277 15.144 51.7184 15V12.08H52.4384ZM53.4177 10.4H54.1377V11.2H53.4177V10.4ZM53.4177 12.08H54.1377V16H53.4177V12.08ZM56.121 16.08C55.769 16.08 55.5103 15.9893 55.345 15.808C55.185 15.6267 55.105 15.4027 55.105 15.136V10H55.825V14.72C55.825 14.9547 55.8383 15.1253 55.865 15.232C55.897 15.3387 55.9557 15.4107 56.041 15.448C56.1263 15.4853 56.265 15.504 56.457 15.504L56.353 16.08H56.121ZM58.3166 16.08C57.9699 16.08 57.7112 15.9893 57.5406 15.808C57.3752 15.6267 57.2926 15.4053 57.2926 15.144V12.64H56.6206L56.6846 12.08H57.2926V11.112L58.0126 11.04V12.08H59.0446V12.64H58.0126V14.704C58.0126 14.976 58.0286 15.1627 58.0606 15.264C58.0926 15.3653 58.1592 15.432 58.2606 15.464C58.3672 15.4907 58.5592 15.504 58.8366 15.504H59.0206L58.9646 16.08H58.3166ZM61.0648 12.08H61.9128L62.6648 15.208L63.4968 12.2H64.2408L65.0807 15.208L65.8328 12.08H66.6808L65.4968 16H64.6888L63.8728 13.104L63.0488 16H62.2408L61.0648 12.08ZM67.2536 10.4H67.9736V11.2H67.2536V10.4ZM67.2536 12.08H67.9736V16H67.2536V12.08ZM70.3009 16.08C69.9543 16.08 69.6956 15.9893 69.5249 15.808C69.3596 15.6267 69.2769 15.4053 69.2769 15.144V12.64H68.6049L68.6689 12.08H69.2769V11.112L69.9969 11.04V12.08H71.0289V12.64H69.9969V14.704C69.9969 14.976 70.0129 15.1627 70.0449 15.264C70.0769 15.3653 70.1436 15.432 70.2449 15.464C70.3516 15.4907 70.5436 15.504 70.8209 15.504H71.0049L70.9489 16.08H70.3009ZM73.5163 12C74.0123 12 74.3909 12.1627 74.6523 12.488C74.9136 12.8133 75.0443 13.256 75.0443 13.816V16H74.3243V13.904C74.3243 13.472 74.2443 13.1547 74.0843 12.952C73.9296 12.744 73.6869 12.64 73.3563 12.64C73.1536 12.64 72.9669 12.688 72.7963 12.784C72.6256 12.8747 72.4816 13.0053 72.3643 13.176V16H71.6363V10H72.3643V12.456C72.5189 12.3067 72.6869 12.1947 72.8683 12.12C73.0549 12.04 73.2709 12 73.5163 12Z' fill='#515860'/><path d='M47.8 27.14C47.14 27.14 46.5467 26.99 46.02 26.69C45.5 26.3833 45.09 25.9567 44.79 25.41C44.4967 24.8567 44.35 24.22 44.35 23.5C44.35 22.78 44.4967 22.1467 44.79 21.6C45.09 21.0467 45.5 20.62 46.02 20.32C46.5467 20.0133 47.14 19.86 47.8 19.86C48.46 19.86 49.05 20.0133 49.57 20.32C50.0967 20.62 50.5067 21.0467 50.8 21.6C51.1 22.1467 51.25 22.78 51.25 23.5C51.25 24.22 51.1 24.8567 50.8 25.41C50.5067 25.9567 50.0967 26.3833 49.57 26.69C49.05 26.99 48.46 27.14 47.8 27.14ZM47.8 25.9C48.48 25.9 49 25.68 49.36 25.24C49.7267 24.8 49.91 24.22 49.91 23.5C49.91 22.78 49.7267 22.2 49.36 21.76C49 21.32 48.48 21.1 47.8 21.1C47.12 21.1 46.5967 21.32 46.23 21.76C45.87 22.2 45.69 22.78 45.69 23.5C45.69 24.22 45.87 24.8 46.23 25.24C46.5967 25.68 47.12 25.9 47.8 25.9ZM56.4888 22V27H55.3288L55.3088 26.7C55.1555 26.8133 54.9788 26.91 54.7788 26.99C54.5788 27.0633 54.3855 27.1 54.1988 27.1C53.4588 27.1 52.9188 26.8867 52.5788 26.46C52.2455 26.0333 52.0788 25.4433 52.0788 24.69V22H53.3188V24.69C53.3188 25.1567 53.3955 25.5033 53.5488 25.73C53.7088 25.95 53.9622 26.06 54.3088 26.06C54.6955 26.06 55.0088 25.92 55.2488 25.64V22H56.4888ZM59.2764 27.1C58.8364 27.1 58.5031 26.9733 58.2764 26.72C58.0497 26.46 57.9364 26.15 57.9364 25.79V23.02H57.2264L57.3364 22H57.9364V20.9L59.1764 20.77V22H60.2764V23.02H59.1764V25.28C59.1764 25.5467 59.1897 25.7333 59.2164 25.84C59.2497 25.94 59.3131 26.0067 59.4064 26.04C59.5064 26.0667 59.6831 26.08 59.9364 26.08H60.2764L60.1664 27.1H59.2764ZM63.3039 27.14C62.9106 27.14 62.4872 27.0867 62.0339 26.98C61.5872 26.8733 61.2372 26.7567 60.9839 26.63L61.1339 25.27C62.0139 25.6967 62.7872 25.91 63.4539 25.91C63.8072 25.91 64.0839 25.8433 64.2839 25.71C64.4839 25.57 64.5839 25.3667 64.5839 25.1C64.5839 24.9 64.5272 24.7367 64.4139 24.61C64.3072 24.4767 64.1506 24.3667 63.9439 24.28C63.7372 24.1867 63.4072 24.06 62.9539 23.9C62.5272 23.7533 62.1739 23.6 61.8939 23.44C61.6139 23.2733 61.3906 23.0633 61.2239 22.81C61.0639 22.55 60.9839 22.2333 60.9839 21.86C60.9839 21.26 61.2039 20.7767 61.6439 20.41C62.0839 20.0433 62.7139 19.86 63.5339 19.86C63.9206 19.86 64.3039 19.9033 64.6839 19.99C65.0706 20.0767 65.4239 20.1833 65.7439 20.31L65.6139 21.62C65.2006 21.44 64.8206 21.3067 64.4739 21.22C64.1339 21.1267 63.7939 21.08 63.4539 21.08C63.0739 21.08 62.7839 21.1433 62.5839 21.27C62.3839 21.3967 62.2839 21.58 62.2839 21.82C62.2839 22.0067 62.3372 22.16 62.4439 22.28C62.5506 22.4 62.6939 22.5 62.8739 22.58C63.0606 22.66 63.3339 22.7567 63.6939 22.87C64.5006 23.1233 65.0872 23.4167 65.4539 23.75C65.8272 24.0767 66.0139 24.5267 66.0139 25.1C66.0139 25.6467 65.8239 26.1233 65.4439 26.53C65.0639 26.9367 64.3506 27.14 63.3039 27.14ZM68.297 26.67L66.217 22H67.597L68.877 25.22L70.177 22H71.557L68.427 29.42H67.187L68.297 26.67ZM73.5391 27.1C73.2191 27.1 72.9257 27.07 72.6591 27.01C72.3991 26.95 72.1291 26.8567 71.8491 26.73L71.9591 25.67C72.2391 25.8367 72.4991 25.9633 72.7391 26.05C72.9857 26.13 73.2391 26.17 73.4991 26.17C74.0057 26.17 74.2591 26.0033 74.2591 25.67C74.2591 25.49 74.1924 25.3533 74.0591 25.26C73.9257 25.16 73.6857 25.0433 73.3391 24.91C72.8457 24.73 72.4824 24.5267 72.2491 24.3C72.0157 24.0667 71.8991 23.7533 71.8991 23.36C71.8991 22.9267 72.0657 22.5767 72.3991 22.31C72.7324 22.0367 73.1824 21.9 73.7491 21.9C74.3157 21.9 74.8324 22.03 75.2991 22.29L75.1891 23.35C74.9357 23.1767 74.6957 23.0433 74.4691 22.95C74.2491 22.8567 74.0157 22.81 73.7691 22.81C73.5557 22.81 73.3891 22.8533 73.2691 22.94C73.1557 23.0267 73.0991 23.15 73.0991 23.31C73.0991 23.4367 73.1324 23.54 73.1991 23.62C73.2724 23.7 73.3724 23.7733 73.4991 23.84C73.6257 23.9 73.8357 23.9867 74.1291 24.1C74.6157 24.2867 74.9657 24.4933 75.1791 24.72C75.3924 24.94 75.4991 25.2367 75.4991 25.61C75.4991 26.0833 75.3291 26.45 74.9891 26.71C74.6491 26.97 74.1657 27.1 73.5391 27.1ZM77.9776 27.1C77.5376 27.1 77.2042 26.9733 76.9776 26.72C76.7509 26.46 76.6376 26.15 76.6376 25.79V23.02H75.9276L76.0376 22H76.6376V20.9L77.8776 20.77V22H78.9776V23.02H77.8776V25.28C77.8776 25.5467 77.8909 25.7333 77.9176 25.84C77.9509 25.94 78.0142 26.0067 78.1076 26.04C78.2076 26.0667 78.3842 26.08 78.6376 26.08H78.9776L78.8676 27.1H77.9776ZM82.1951 27.1C81.6151 27.1 81.1184 26.9833 80.7051 26.75C80.2984 26.51 79.9917 26.1933 79.7851 25.8C79.5851 25.4 79.4851 24.9567 79.4851 24.47C79.4851 24.0033 79.5817 23.5767 79.7751 23.19C79.9684 22.8033 80.2484 22.4967 80.6151 22.27C80.9817 22.0367 81.4184 21.92 81.9251 21.92C82.3917 21.92 82.7851 22.0167 83.1051 22.21C83.4317 22.4033 83.6751 22.6633 83.8351 22.99C84.0017 23.3167 84.0851 23.6833 84.0851 24.09C84.0851 24.29 84.0584 24.5167 84.0051 24.77H80.7751C80.8417 25.21 81.0151 25.54 81.2951 25.76C81.5751 25.9733 81.9117 26.08 82.3051 26.08C82.8451 26.08 83.3451 25.9433 83.8051 25.67L83.8651 26.72C83.6517 26.8333 83.4017 26.9267 83.1151 27C82.8351 27.0667 82.5284 27.1 82.1951 27.1ZM82.8251 23.93C82.8251 23.67 82.7517 23.44 82.6051 23.24C82.4584 23.04 82.2317 22.94 81.9251 22.94C81.6184 22.94 81.3717 23.03 81.1851 23.21C80.9984 23.39 80.8717 23.63 80.8051 23.93H82.8251ZM90.5416 21.92C91.2082 21.92 91.7016 22.1233 92.0216 22.53C92.3482 22.93 92.5116 23.4933 92.5116 24.22V27H91.2716V24.31C91.2716 23.8367 91.1982 23.49 91.0516 23.27C90.9049 23.05 90.6649 22.94 90.3316 22.94C90.0049 22.94 89.7582 23.0533 89.5916 23.28C89.4249 23.5 89.3416 23.8133 89.3416 24.22V27H88.1016V24.31C88.1016 23.8367 88.0249 23.49 87.8716 23.27C87.7182 23.05 87.4749 22.94 87.1416 22.94C86.7482 22.94 86.4249 23.0833 86.1716 23.37V27H84.9316V22H85.9916L86.0316 22.4C86.4849 22.08 86.9749 21.92 87.5016 21.92C88.1416 21.92 88.6182 22.15 88.9316 22.61C89.1049 22.39 89.3316 22.22 89.6116 22.1C89.8916 21.98 90.2016 21.92 90.5416 21.92ZM95.043 27.1C94.723 27.1 94.4296 27.07 94.163 27.01C93.903 26.95 93.633 26.8567 93.353 26.73L93.463 25.67C93.743 25.8367 94.003 25.9633 94.243 26.05C94.4896 26.13 94.743 26.17 95.003 26.17C95.5096 26.17 95.763 26.0033 95.763 25.67C95.763 25.49 95.6963 25.3533 95.563 25.26C95.4296 25.16 95.1896 25.0433 94.843 24.91C94.3496 24.73 93.9863 24.5267 93.753 24.3C93.5196 24.0667 93.403 23.7533 93.403 23.36C93.403 22.9267 93.5696 22.5767 93.903 22.31C94.2363 22.0367 94.6863 21.9 95.253 21.9C95.8196 21.9 96.3363 22.03 96.803 22.29L96.693 23.35C96.4396 23.1767 96.1996 23.0433 95.973 22.95C95.753 22.8567 95.5196 22.81 95.273 22.81C95.0596 22.81 94.893 22.8533 94.773 22.94C94.6596 23.0267 94.603 23.15 94.603 23.31C94.603 23.4367 94.6363 23.54 94.703 23.62C94.7763 23.7 94.8763 23.7733 95.003 23.84C95.1296 23.9 95.3396 23.9867 95.633 24.1C96.1196 24.2867 96.4696 24.4933 96.683 24.72C96.8963 24.94 97.003 25.2367 97.003 25.61C97.003 26.0833 96.833 26.45 96.493 26.71C96.153 26.97 95.6696 27.1 95.043 27.1Z' fill='#222B34'/></g><defs><filter id='filter0_d' x='0' y='0' width='116' height='50' filterUnits='userSpaceOnUse' color-interpolation-filters='sRGB'><feFlood flood-opacity='0' result='BackgroundImageFix'/><feColorMatrix in='SourceAlpha' type='matrix' values='0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0'/><feOffset dy='6'/><feGaussianBlur stdDeviation='4'/><feColorMatrix type='matrix' values='0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.1 0'/><feBlend mode='normal' in2='BackgroundImageFix' result='effect1_dropShadow'/><feBlend mode='normal' in='SourceGraphic' in2='effect1_dropShadow' result='shape'/></filter></defs></svg>";
            document.body.appendChild(mwo); // Append the link on the page    
            setStyles(); // Apply the default styles
            
            // Create an observer for any changes to the label
            var observer = new MutationObserver(function (mutations) {
                mutations.forEach(function (mutation) {
                	mutationHandler(mutation, observer, link, img);            
                });
            });
            
            // Observer configuration
            var config = {
                attributes: true,
                childList: true,
                subtree: true,
                attributeOldValue: true
            };    
            
            var body = document.body; // Query body of the page
            var link = document.querySelector(".mwo"); // Query the image
        	var img = document.querySelector(".mwo svg"); // Query the image  
            observer.observe(body, config);
            observer.observe(link, config);
        }
        
        function mutationHandler(mutation, observer, link, img) {	
        	var needsUpdate = false;
        
        	// If mutation is link properties
        	if(mutation.type === "attributes" && mutation.target === link) {
        		needsUpdate = true;
        	} else 
        
        	// If mutation is image properties
        	if(mutation.type === "attributes" && mutation.target === img) {
        		needsUpdate = true;	
        	} else
        
        	// If mutation is removed link, create link
        	if(mutation.type === "childList" && mutation.removedNodes[0] === link) {
                needsUpdate = true;
        	} else 
        
        	// If mutation is removed image, create link
        	if(mutation.type === "childList" && mutation.target === link) {
                needsUpdate = true;
        	} else
        
        	// If mutation is removed image, create link
        	if(mutation.type === "childList" && img.contains(mutation.target)) {
                needsUpdate = true;
        	}
        
        	if(needsUpdate) {
        		observer.disconnect();
                updateMWO();
        	}
        }
        
        function updateMWO() {
        	// If anything changes, remove the label and create a new one
            var link = document.querySelector(".mwo"); // Query the label wrapper link
            
            if(link) {
            	link.remove(); // Remove the link and create a new one
            }
            createMWO();
        }
        
        createMWO(); // create the label html
    };

    return {
        GetVersion: function() {
            getVersion();       
        },
        HideOnScroll: function() {
            return hideOnScroll();
        },
        ToggleClass: function(el, state, className) {
            toggleClass(el, state, className);
        },
        GetClosest: function(elem, selector) {
            return getClosest(elem, selector);
        },
        FixInputs: function() {
            fixInputs();
        },
        HasMasterDetail: function() {
            hasMasterDetail();
        },
        StartMWO: function() {
            startMWO();
        }
    };
    
}